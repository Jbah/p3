#include "atm.h"
#include "ports.h"
#include "split_command.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <openssl/sha.h>

ATM* atm_create(char* key_buff)
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    atm->logged_in = 0;
    atm->user = NULL;
    atm->key = key_buff;

    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

void atm_process_command(ATM *atm, char *command)
{
    // TODO: Implement the ATM's side of the ATM-bank protocol

	/*
	 * The following is a toy example that simply sends the
	 * user's command to the bank, receives a message from the
	 * bank, and then prints it to stdout.
	 */

	/*
    char recvline[10000];
    int n;

    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    fputs(recvline,stdout);
	*/
    CommandList *cl = split_command(command);
    int n = *(cl->n);

    if (strstr(command, "begin-session") == command) {
        if (!atm->logged_in) {
            if (n == 2 && checkUsername(cl->list[1])) {
                char *name = cl->list[1];
                char recvline[10000] = {'\0'};
                int n;
                char *prefix = "check-user ";
                char *atm_command = calloc((strlen(name) + strlen(prefix) + 1), sizeof(char));
                //return strings will be "<name> valid" or "<name> inval". construct and compare
                char *atm_check_valid = calloc((strlen(name) + 7), sizeof(char));
                char *atm_check_inval = calloc((strlen(name) + 7), sizeof(char));
                strncpy(atm_command, prefix, strlen(prefix));
                strncat(atm_command, name, strlen(name));
                strncpy(atm_check_valid, name, strlen(name));
                strncat(atm_check_valid, " valid", 6);
                strncpy(atm_check_inval, name, strlen(name));
                strncat(atm_check_inval, " inval", 6);
                //printf("%s", atm_command);
                atm_send(atm, atm_command, strlen(atm_command)+1);
                n = atm_recv(atm,recvline,10000);
                recvline[n]=0;
                //fputs(recvline,stdout);
                if (strncmp(recvline, atm_check_valid, strlen(atm_check_valid)) == 0) {
                    //printf("user found!\n");
                    // Now check the name.card file
                    FILE *cardfile = NULL;
                    int namelength = strlen(name);
                    char *filename = calloc((namelength + 6), sizeof(char));
                    strncpy(filename, name, namelength);
                    strncat(filename, ".card", 6);
                
                    cardfile = fopen(filename, "r");
                    if (cardfile) {
                        //TODO load card contents, do thing
                        char cardvalue[33] = {'\0'};
                        fgets(cardvalue, 11, cardfile);
                        //printf("string is %s!\n", cardvalue);
                        fclose(cardfile);
                        cardfile = NULL;

                        char user_input[11] = {'\0'};
                        printf("PIN? ");
                        fflush(stdout);
                        fgets(user_input, 10, stdin);
                        char *newline = strrchr(user_input, '\n');
                        if (newline) *newline = '\0';
                        if (checkPin(user_input)) {
                            //send "check-cardpin " + cardvalue, pin to bank
                            //TODO send pin (user_input) as hashed value? or just check hashed on bank side
                            char atm_command2[100] = {'\0'};
                            strncpy(atm_command2, "check-cardpin ", 15);
                            strncat(atm_command2, cardvalue, strlen(cardvalue));
                            strncat(atm_command2, " ", 1);
                            strncat(atm_command2, user_input, strlen(user_input));
                            atm_send(atm, atm_command2, strlen(atm_command2)+1);
                            n = atm_recv(atm,recvline,10000);
                            recvline[n]=0;
                            //printf("received :%s!\n", recvline);
                            if (strncmp(recvline, "valid", 5) == 0) {
                                atm->logged_in = 1;
                                atm->user = name;
                                printf("Authorized\n");
                            } else if (strncmp(recvline, "inval", 5) == 0) {
                                printf("Not authorized\n");
                            } else if (strncmp(recvline, "limit", 5) == 0) {
                                printf("Out of login attempts\n");
                            } else {
                                printf("Error in transmission\n");
                            }
                        } else {
                            printf("Not authorized\n");
                        }
                    } else {
                        printf("Unable to access %s's card\n", name);
                    }
                } else if (strncmp(recvline, atm_check_inval, strlen(atm_check_inval)) == 0) {
                    printf("No such user\n");
                } else {
                    //printf("the line is %s!\n", recvline);
                    printf("Error in data trasmission\n");
                }
                //free stuff?
            } else {
                printf("Usage:  begin-session <user-name>\n");
            }
        } else {
            printf("A user is already logged in\n");
        }
    } 
    else if (strstr(command, "withdraw") == command) {
        if (atm->logged_in) {
            if (n == 2 && checkBalance(cl->list[1])) {
                char recvline[10000] = {'\0'};
                int n;
                char *amt = cl->list[1];
                //sends withdraw user amount
                char *atm_command = calloc((strlen(atm->user) + strlen(amt) + 1), sizeof(char));
                strncpy(atm_command, "withdraw ", 11);
                strncat(atm_command, atm->user, strlen(atm->user));
                strncat(atm_command, " ", 2);
                strncat(atm_command, amt, strlen(amt));
                atm_send(atm, atm_command, strlen(atm_command)+1);
                n = atm_recv(atm,recvline,10000);
                recvline[n]=0;
                printf("%s\n", recvline);
            } else {
                printf("Usage:  withdraw <amt>\n");
            }
        } else {
            printf("No user logged in\n");
        }
    } 
    else if(strstr(command, "balance") == command){
	//printf("Balance?\n");
	if(atm->logged_in) {
		if(n == 1) {
			//printf("%s\n",atm->user);
			char recvline[10000];
                	int n;
			char* prefix = "balance ";
			char *atm_command = malloc(sizeof(char *) * (strlen(atm->user) + strlen(prefix) + 1));
			strncpy(atm_command, prefix, strlen(prefix)+1);
			strncat(atm_command, atm->user, strlen(atm->user));
			//printf("%s\n", atm_command);
			atm_send(atm, atm_command, strlen(atm_command)+1);
			n = atm_recv(atm,recvline,10000);
			recvline[n] = 0;
			printf("%s\n",recvline);
		} else {
			printf("Usage:  balance\n");
		}
			
	} else {
		printf("No user logged in\n");
	}
    }
    else if (strcmp(command, "end-session") == 0) {
        if (atm->logged_in) {
            atm->logged_in = 0;
            atm->user = NULL;
        } else {
            printf("No user logged in\n");
        }
    } 
    else {
        printf("Invalid command\n");
    }
}
