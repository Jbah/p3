#include "bank.h"
#include "ports.h"
#include "hash_table.h"
#include "split_command.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <openssl/sha.h>
#include <regex.h>
#include <stdio.h>

Bank* bank_create(char *key_buff)
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    HashTable *accounts = hash_table_create(256);
    bank->accounts = accounts;
    HashTable *cards = hash_table_create(256);
    bank->cards = cards;
    bank->key = key_buff;
    //TODO open bank file

    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}


void bank_process_local_command(Bank *bank, char *command, size_t len)
{
    // TODO: Implement the bank's local commands
    /*unsigned char test[32] = {0};
    SHA256(command, len-1, test);
    int i = 0;
    for (i=0; i< 32; i++) {
        printf("%02x ", test[i]);
    }*/
    CommandList *cl = split_command(command);
    int n = *(cl->n);
    /*printf("\n%d\n", n);
    while (i < n) {
        printf("\n%s\n", cl->list[i]);
        i+=1;
    }*/
    if (strstr(command, "create-user") == command) {
        if (n == 4 && checkUsername(cl->list[1]) && checkPin(cl->list[2]) && checkBalance(cl->list[3])) {
            char *name = cl->list[1];
            char *pin = cl->list[2];
            char *balance = cl->list[3];
            char *salt = urandom_str();
            char *pepper = urandom_str();
            Account *acc = malloc(sizeof(Account));
            //acc->pin = pin;
            acc->salt = salt;
            acc->pepper = pepper;
            //hash pin with random salt and pepper
            int sp_len = strlen(salt)+strlen(pin)+strlen(pepper)+1;
            char *seasonedpin = calloc(sp_len, sizeof(char));
            strncpy(seasonedpin, salt, strlen(salt)+1);
            strncat(seasonedpin, pin, strlen(pin)+1);
            strncat(seasonedpin, pepper, strlen(pepper)+1);
            unsigned char *hashedpin = calloc(33, sizeof(char));
            SHA256(seasonedpin, strlen(seasonedpin), hashedpin);
            memset(seasonedpin, 0, sp_len);
            free(seasonedpin);
            seasonedpin = NULL;
            acc->pin = hashedpin;
            acc->balance = atoi(balance);
            acc->attempts = 0;
            if (!hash_table_find(bank->accounts, name)) {
                FILE *cardfile = NULL;
                int namelength = strlen(name);
                char *filename = calloc((namelength + 6), sizeof(char));
                strncpy(filename, name, namelength+1);
                strncat(filename, ".card", 6);
                
                cardfile = fopen(filename, "w+");
                if (cardfile) {
                    //TODO add to cards table, create card
                    //Card is created as random long (converted to string) from /dev/urandom
                    //bank->cards stores card numbers mapped to usernames
                    //printf("random number is %lu!\n", urandom());
                    char *str = urandom_str();
                    hash_table_add(bank->cards, str, name);
                    //printf("added card !%s! len !%d! which maps to !%s!\n", str, strlen(str), hash_table_find(bank->cards, str));
                    fwrite(str, 1, strlen(str), cardfile);
                    fclose(cardfile);
                    cardfile = NULL;
                    hash_table_add(bank->accounts, name, acc);
                    printf("Created user %s\n", name);
                } else {
                    printf("Error creating card file for user %s\n", name);
                }
            } else {
                printf("Error:  user %s already exists\n", name);
            }
        } else {
            printf("Usage:  create-user <user-name> <pin> <balance>\n");
        }
    }
    else if (strstr(command, "deposit") == command) {
        if (n == 3 && checkUsername(cl->list[1]) && checkBalance(cl->list[2])) {
            char *name = cl->list[1];
            int amt = atoi(cl->list[2]);
            Account *acc = hash_table_find(bank->accounts, name);
            if (acc) {
                int newbalance = acc->balance + amt;
                if (newbalance >= acc->balance) {
                    acc->balance = newbalance;
                    printf("$%d added to %s's account\n", amt, name);
                } else {
                    printf("Too rich for this program\n");
                }
            } else {
                printf("No such user\n");
            }
        } else {
            printf("Usage:  deposit <user-name> <amt>\n");
        }
    } 
    else if (strstr(command, "balance") == command) {
        if(n == 2 && checkUsername(cl->list[1])) {
		char *name = cl->list[1];		
		Account *acc = hash_table_find(bank->accounts,name);
		if(acc) {
			printf("$%d\n", acc->balance);
		} else {
			printf("No such user\n");
		}
		
	} else {
		printf("Usage:  balance <user-name>\n");
	}
    }
    else {
        printf("Invalid command\n");
    }
}

void bank_process_remote_command(Bank *bank, char *command, size_t len)
{
    // TODO: Implement the bank side of the ATM-bank protocol

	/*
	 * The following is a toy example that simply receives a
	 * string from the ATM, prepends "Bank got: " and echoes 
	 * it back to the ATM before printing it to stdout.
	 */

	/*
    char sendline[1000];
    command[len]=0;
    sprintf(sendline, "Bank got: %s", command);
    bank_send(bank, sendline, strlen(sendline));
    printf("Received the following:\n");
    fputs(command, stdout);
	*/
    //printf("received %s!\n", command);
    CommandList *cl = split_command(command);
    int n = *(cl->n);
    /*printf("\n%d\n", n);
    while (i < n) {
        printf("\n%s\n", cl->list[i]);
        i+=1;
    }*/
    if (strstr(command, "check-user") == command) {
    //printf("n is %d and name is %s!", n, cl->list[1]);
        if (n == 2 && checkUsername(cl->list[1])) {
            char *name = cl->list[1];
            char *resp = calloc((strlen(name) + 8), sizeof(char));
            strncpy(resp, name, strlen(name)+1);
            if (hash_table_find(bank->accounts, name)) {
                strncat(resp, " valid", 7);
            } else {
                strncat(resp, " inval", 7);
            }
            bank_send(bank, resp, strlen(resp));
        } else {
            printf("Invalid user\n");
            char *resp = "inval";
            bank_send(bank, resp, strlen(resp));
        }
    }
    else if (strstr(command, "check-cardpin") == command) {
        char *resp = "inval";
        if (n == 3) {
            char *card = cl->list[1];
            char *pin = cl->list[2];
            char *name = NULL;
            //printf("checking card !%s! len !%d! and pin !%s!\n", card, strlen(card), pin);
            name = hash_table_find(bank->cards, card);
            //printf("name is !%s!\n", hash_table_find(bank->cards, card));
            if (name) {
                //printf("\nuser %s found\n", name);
                Account *acc = hash_table_find(bank->accounts, name);
                //printf("their pin is %s!\n", acc->pin);
                if (acc) {
                    int sp_len = strlen(acc->salt)+strlen(pin)+strlen(acc->pepper)+1;
                    char *seasonedpin = calloc(sp_len, sizeof(char));
                    strncpy(seasonedpin, acc->salt, strlen(acc->salt)+1);
                    strncat(seasonedpin, pin, strlen(pin)+1);
                    strncat(seasonedpin, acc->pepper, strlen(acc->pepper)+1);
                    unsigned char hashedpin[33] = {'\0'};
                    SHA256(seasonedpin, strlen(seasonedpin), hashedpin);
                    memset(seasonedpin, 0, sp_len);
                    free(seasonedpin);
                    seasonedpin = NULL;

                    if (acc->attempts > 5) {
                        resp = "limit";
                    }
                    else if (strncmp(acc->pin, hashedpin, strlen(acc->pin)) == 0) {
                        //valid
                        resp = "valid";
                    } 
                    else {
                        acc->attempts += 1;
                    }
                }
            } //else invalid card
        } 
        bank_send(bank, resp, strlen(resp));
    }
    else if (strstr(command, "withdraw") == command) {
        char *resp = "Usage:  withdraw <amt>";
        if (n == 3 && checkUsername(cl->list[1]) && checkBalance(cl->list[2])) {
            char *name = cl->list[1];
            char *amtstr = cl->list[2];
            int amt = atoi(amtstr);
            Account *acc = hash_table_find(bank->accounts, name);
            //printf("withdraw with !%s! amt !%s! !%d!\n", name, amtstr, amt);
            if (acc) {
                int tempbalance = acc->balance - amt;
                if (tempbalance >= 0) {
                    acc->balance = tempbalance;
                    resp = calloc((strlen(amtstr) + 12), sizeof(char));
                    strncpy(resp, "$", 1);
                    strncat(resp, amtstr, strlen(amtstr)+1);
                    strncat(resp, " dispensed", 11);
                } else {
                    resp = "Insufficient funds";
                }
            }
        }
        bank_send(bank, resp, strlen(resp));
    }
    else if (strstr(command, "balance") == command) {
	//printf("Checking balance?\n");
	if(n == 2) {
		char *name = cl->list[1];
		//printf("Recieved balance check for %s\n",name);
		Account *acc = hash_table_find(bank->accounts, name);
		//printf("%d\n", acc->balance);
		char balance_string[11];
		snprintf(balance_string,sizeof(char)*12,"$%d", acc->balance);
		//printf("%s\n",balance_string);
			
		bank_send(bank, balance_string, strlen(balance_string));
	}
    }
    else {
        char *resp = "Invalid command";
        bank_send(bank, resp, strlen(resp));
    }
}
