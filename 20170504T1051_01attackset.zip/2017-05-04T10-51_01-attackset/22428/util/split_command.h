#ifndef __SPLIT_COMMAND_H__
#define __SPLIT_COMMAND_H__

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include <limits.h>
#include <stdio.h>


typedef struct _CommandList {
    unsigned int *n;
    char *list[];
} CommandList;

CommandList* split_command(char *command);
bool checkUsername(char* userbuff);
bool checkPin(char* userbuff);
bool checkBalance(char* userbuff);
unsigned long urandom();
char * urandom_str();

#endif
