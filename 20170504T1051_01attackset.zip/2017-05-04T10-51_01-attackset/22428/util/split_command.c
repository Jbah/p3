#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "split_command.h"
#include <ctype.h>
#include <stdbool.h>
#include <limits.h>
#include <stdio.h>

CommandList* split_command(char *command) {
    const char *sp = " ";
    CommandList *split = malloc(sizeof(int *) + sizeof(char *) * 5);
    unsigned int i = 0;
    split->n = &i;
    char *str = NULL;
    char *newline = strrchr(command, '\n');
    if (newline) *newline = '\0';
    str = strtok(command, sp);
    while (str != NULL && i < 5) {
        char *new = malloc(sizeof(char) * (strlen(str)+1));
        strcpy(new, str);
        split->list[i] = new;
        i+=1;
        str = strtok(NULL, sp);
    }
    return split;
}

bool checkUsername(char* userbuff) {
	int len = strlen(userbuff);
	if(len > 250) {
		return false;
	}
	int i;
	for(i = 0; i < len; i++) {
		//printf("%d\n",userbuff[i]);
		if(!isalpha(userbuff[i])){
			//printf("Fail\n");
			return false;
		}
	}
	return true;
}

bool checkPin(char* userbuff) {
	int len = strlen(userbuff);
	if(len != 4) {
		return false;
	}
	int i;
	for(i = 0; i < len; i++) {
		//printf("%d\n", userbuff[i]);
		if(!isdigit(userbuff[i])){
			//printf("Fail\n");
			return false;
		}
	}
	return true;
}

bool checkBalance(char* userbuff) {
	char int_max_string[11];
	snprintf(int_max_string,sizeof(char)*11,"%d", INT_MAX);
	//printf("%s\n", int_max_string);
	int balance = atoi(userbuff);
	//printf("%d\n",balance);
	if(balance < 0) {
		return false;
	}
	int len = strlen(userbuff);
	if(balance == INT_MAX) {
		int i;
		//int len = strlen(userbuff);
		for(i = (len - 1); i >= 0; i--) {
			if(userbuff[i] != int_max_string[i]){
				return false;
			}
		}
	}
	int j;
	for(j = 0; j < len; j++) {
		if(!isdigit(userbuff[j])){
			return false;
		}
	}
	//printf("All Good!\n");
	return true;
}

unsigned long urandom() {
    FILE *urandom_file = fopen("/dev/urandom", "r");
    if (urandom_file) { 
        unsigned long num;
        fread(&num, sizeof(long), 1, urandom_file);
        return num;
    } else {
        printf("Failed to open urandom\n");
        exit(-1);
    }
    return 0;
}

char * urandom_str() {
    unsigned long ran = urandom();
    //printf(" ran is !%lu!\n", ran);
    char *str = calloc(33, sizeof(char));
    snprintf(str, 32, "%lu", ran);
    return str;
}

