#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <unistd.h>
#include "split_command.h"

int main(int argc, char *argv[])
{
	char *bank_path, *atm_path;
	FILE *bank_file, *atm_file = NULL;
	int path_size = 0;
	if (argc != 2) {
		printf("Usage:  init <filename>\n");
		exit(62);
	}
	path_size = strlen(argv[1]);

	bank_path = malloc(sizeof(char) * (path_size + 6));
	atm_path = malloc(sizeof(char) * (path_size + 5));
	if (!bank_path || !atm_path) {
		printf("Error creating initialization files\n");
		exit(64);
	}
	strncpy(bank_path, argv[1], path_size);
	strncat(bank_path, ".bank", 6);
	strncpy(atm_path, argv[1], path_size);
	strncat(atm_path, ".atm", 5);

	/* TOCTOU potential */
	if (access(bank_path, F_OK) != -1 || access(atm_path, F_OK) != -1) {
		printf("Error:  one of the files already exists\n");
		exit(63);
	}
	bank_file = fopen(bank_path, "w+");
	atm_file = fopen(atm_path, "w+");
	if (!bank_file || !atm_file) {
		printf("Error creating initialization files\n");
		exit(64);
	}
	char* key = urandom_str();
	fwrite(key, 1, strlen(key), bank_file);
	fwrite(key, 1, strlen(key), atm_file);
	//printf("%s\n", key);
	
	free(bank_path);
	free(atm_path);
	bank_path = atm_path = NULL;
	fclose(bank_file);
	fclose(atm_file);
	bank_file = atm_file = NULL;
	
	printf("Successfully initialized bank state\n");
	exit(0);
}
