#include "atm.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <regex.h>
#include <limits.h>
#include <stdbool.h>

/* global variable declaration */
bool loggedIn = false;
char current_user[251];
int pwd_attempts;

ATM* atm_create()
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if (atm == NULL) {
        perror("Could not allocate ATM");
        exit(1);
	}
	
	loggedIn = false;
	pwd_attempts = 0;

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    // TODO set up more, as needed

    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

int begin_session(ATM *atm, char* user_name) {
	
	int status;
    regex_t regex;
	char temp[11]; // max intger has 10 characters, then one more for the 
                   // null character
	int pin;
	char recvline[10000];
    int n;
	char *err;
	
	if (strlen(user_name) > 250) {
        printf("Usage: deposit <user-name> <amt>\n");
        return -1;
    }
    
    // checking user name
    
    if (regcomp(&regex, "^[a-zA-Z]+$", REG_EXTENDED) != 0) {
        return -1;  // compiling regex failed
    }
    
    status = regexec(&regex, user_name, (size_t) 0, NULL, 0);
    regfree(&regex);
    
    if (status != 0) {
        printf("Usage: begin-session <user-name>\n");
        return -1; // regex failed
    }
	
	// Check if another user is logged in
	if (loggedIn == true) {
		printf("A user is already logged in\n");
		return -1;
	}
	
	// Ask the bank if <user_name> exists

	// call bank to see if user exists	
	char command[10000] = "begin-session ";
	strcat(command, user_name);
	
    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
	
	// No such user registered with the bank
	if (strcmp(recvline, "user does not exist") == 0) { // user doesnt exist
		printf("No such user\n");
		return -1;
	}
	
	// read user's card
	char user_file[256]; // 250 for name + 5 for '.card'
		
	strcpy(user_file, strncpy(user_file, user_name, 250));
		
	strcat(user_file, ".card");
		
	FILE* fp_card;
   
	fp_card = fopen(user_file, "r");
	   
	if (fp_card == NULL) {
		printf("Unable to access %s's card\n", user_name);
		return 0;
	}
	
	// if there is no error accessing the card file,
	// prompt user for pin
	char p[6];
	printf("PIN? ");
	scanf("%5s", p);
	//fflush(stdout);
	
	// check if the user tried to enter more than 4 characters,
	// if so, error; limited to 5 to prevent buffer overflow
	if (strlen(p) != 4) {
		
		printf("Not authorized\n");
		
		pwd_attempts += 1;
		
		char* dump[10000];
		fgets(dump, 10000, stdin);
		
		return -1;
	}
		
	// checking pin
    if (regcomp(&regex, "^[0-9][0-9][0-9][0-9]$", REG_EXTENDED) != 0) {
        return -1; // compiling regex failed
    }
    
    sprintf(temp, "%s", p);
    
    status = regexec(&regex, temp, (size_t) 0, NULL, 0);
    regfree(&regex);
        
    if (status != 0) {
        
		printf("Not authorized\n");
		
		pwd_attempts += 1;
		
		char* dump[10000];
		fgets(dump, 10000, stdin);
		
		return -1; // regex failed
    }
	
	pin = (int) strtoul(p, &err, 10);
			
	// Check bank to see if the correct pin was
	// entered for user_name
		
	char command2[10000] = "pin ";
			
	sprintf(temp, "%d", pin);
	
	strcat(command2, user_name);
	strcat(command2, " ");
	strcat(command2, temp);
			
    atm_send(atm, command2, strlen(command2));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
	
	// Check if the user entered the correct pin
	if (strcmp(recvline, "correct pin") == 0) { // user doesnt exist
	
		loggedIn = true;
		
		// setting the global in atm.h #############################
		strcpy(current_user, user_name);
		
		printf("Authorized\n");
		
	} else {
		
		printf("Not authorized\n");
		
		pwd_attempts += 1;
		
		char* dump[10000];
		fgets(dump, 10000, stdin);
		
		return -1;
	}
	
	char* dump[10000];
	fgets(dump, 10000, stdin);
	
	return 0;
}

int withdraw(ATM *atm, char* amount) {
	
	int status;
    regex_t regex;
	char temp[11]; // max intger has 10 characters, 
                   // then one more for the null character
	unsigned long l;
	char recvline[10000];
    int n;
	char *err;
	
	// checking amount
	if (strlen(amount) > 10) { // too big for an int
		printf("Usage: withdraw <amt>\n");
		return -1;
	}
	
    if (regcomp(&regex, "^[0-9]+$", REG_EXTENDED) != 0) {
		printf("Usage: withdraw <amt>\n");   
		return -1; // compiling regex failed
    }
	
	sprintf(temp, "%s", amount);
	
    status = regexec(&regex, temp, (size_t) 0, NULL, 0);
    regfree(&regex);
    
    if (status != 0) {
        printf("Usage: withdraw <amt>\n");
        return -1; // regex failed
    }
	
	l = strtoul(amount, &err, 10);
	
	if (l > INT_MAX) {
      	printf("Usage: withdraw <amt>\n");
       	return -1;
    }
	
	int amt = (int) l;
	
	// No user is logged in
	if (loggedIn == false) {
		printf("No user logged in\n");
		return -1;
	}
	
	// TODO: how do we tell the bank who's account to look up??
	char command[10000] = "withdraw ";
			
	sprintf(temp, "%d", amt);
	// changed stuff ################################################
	strcat(command, current_user); // changed user_logged_in to current_user
	strcat(command, " ");
	strcat(command, temp);
			
    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
	
	// Check if the user had enough money
	if (strcmp(recvline, "sufficient funds") == 0) { // money withdrawn
		printf("$%d dispensed\n", amt);
	} else {
		printf("Insufficient funds\n");
		return -1;
	}
	
	return 0;
}

int balance(ATM *atm) {
	
	char recvline[10000];
    int n;
	unsigned long balance;
	char *err;
	
	// No user is logged in
	if (loggedIn == false) {
		printf("No user logged in\n");
		return 0;
	}
	
	// TODO: how do we tell the bank who's account to look up??
	char command[10000] = "balance ";
	
	// changed user_logged_in to current_user
	strcat(command, current_user);
		
    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
	
	// convert string to int
	balance = (int) strtoul(recvline, &err, 10);
		
	// Return balance
	if (strcmp(recvline, "No such user") != 0) {
		printf("$%d balance\n", balance);
	} else {
		return -1;
	}

	// If a user was logged in, then that user should stay 
	// logged in after this command.
	
	return 0;
}

// User terminating his or her session and logging out of the ATM
int end_session() {
	
	// No user is logged in
	if (loggedIn == false) {
		printf("No user logged in\n");
	} else {
		// Terminate the current session; ATM should then 
		// continue listening for further begin-session commands
		loggedIn = false;
		//*user_logged_in = '\0';
		*current_user = '\0';
		printf("User logged out\n");
	}
		
	return 0;
}

void atm_process_command(ATM *atm, char *command)
{	
	
    // TODO: Implement the ATM's side of the ATM-bank protocol
	
	int command_size = 1000;
    char *token;
    char commands[3][command_size];
    int i = 0;
	
	*commands[0] = '\0';
	*commands[1] = '\0';
	*commands[2] = '\0';
	
	// get all tokens, up to 2 (max amt requests)
	while (((token = strsep(&command, " ")) != NULL) && (i < 3)) {
        int ln = strlen(token) - 1;
        
        if (token[ln] == '\n') {
            token[ln] = '\0';
        }
        
        strcpy(commands[i], token);
        i++;
    }
	
	int length1 = strlen(commands[1]);
		
	if (strcmp(commands[0], "begin-session") == 0) {
		
		if (length1 > 0 && strlen(commands[2]) == 0 && pwd_attempts <= 10) {
			begin_session(atm, commands[1]);
		} else {
			printf("Usage: begin-session <user-name>\n");
		}

	} else if (strcmp(commands[0], "withdraw") == 0) {
		
		if (length1 > 0 && strlen(commands[2]) == 0 ) {
			withdraw(atm, commands[1]);
		} else {
			printf("Usage: withdraw <amt>\n");
		}
		
	} else if (strcmp(commands[0], "balance") == 0) {
		
		if (length1 == 0) {
			balance(atm);
		} else {
			printf("Usage: balance\n");
		}
		
	} else if (strcmp(commands[0], "end-session") == 0) {
		
		if (length1 == 0) {
			end_session();
		} else {
			printf("Usage: end-session\n");
		}
		
	} else {
		printf("Invalid command\n"); 
	}
	
	
	/*
	 * The following is a toy example that simply sends the
	 * user's command to the bank, receives a message from the
	 * bank, and then prints it to stdout.
	 */

	
	/*
    char recvline[10000];
    int n;

	printf("send commands: %s\n", c);
	printf("send to bank\n");
    atm_send(atm, c, strlen(c));
    n = atm_recv(atm,recvline,10000);
	printf("atm received\n");
    recvline[n]=0;
    fputs(recvline,stdout);
	*/
	// this clears the commands, so rogue commands aren't
	// staying around and it starts fresh.
	*commands[0] = '\0';
	*commands[1] = '\0';
	*commands[2] = '\0';
}
