/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char prompt[] = "ATM";
extern char current_user[251]; 
extern int pwd_attempts;

int main(int argc, char **argv)
{
    char user_input[1000];
	
	char atm_file[50];
   
    if (argc != 2) {
        printf("Error creating ATM initialization file\n");
		return 64;
    }
	
	strcpy(atm_file, strncpy(atm_file, argv[1], 49));
   
    FILE* fp_atm;
   
    fp_atm = fopen(atm_file, "r");
   
    if (fp_atm == NULL) {
		printf("Error creating ATM initialization file\n");
		return 64;
	} else {
		fclose(fp_atm);
	}
	
    ATM *atm = atm_create();

    printf("%s: ", prompt);
    fflush(stdout);

    while (fgets(user_input, 10000, stdin) != NULL)
    {
        atm_process_command(atm, user_input);
		
		if (strlen(current_user) == 0) {
			printf("%s: ", prompt);
		} else {
			printf("%s (%s): ", prompt, current_user);
		}
		
        fflush(stdin);
    }
	return EXIT_SUCCESS;
}
