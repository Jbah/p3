#include "bank.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <regex.h>
#include <limits.h>
#include <stdio.h>
#include "util/hash_table.h"

Bank* bank_create()
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    
    

    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}


int create_user(char* user_name, char* pin, char* balance, HashTable* ht) {
  
    int status;
    regex_t regex;
    char temp[11]; // max intger has 10 characters, then one more for the 
                   // null character
    char* err;
    unsigned long l;

    // checking user name
    if (strlen(user_name) > 250) {
        printf("Usage: create-user <user-name> <pin> <balance>\n");
        return 0;
    }
    
    if (regcomp(&regex, "^[a-zA-Z]+$", REG_EXTENDED) != 0) {
        return 0;  // compiling regex failed
    }
    
    status = regexec(&regex, user_name, (size_t) 0, NULL, 0);
    regfree(&regex);
    
    if (status != 0) {
        printf("Usage: create-user <user-name> <pin> <balance>\n");
        return 0; // regex failed
    }
	
	// checking pin
    
    if (regcomp(&regex, "^[0-9][0-9][0-9][0-9]$", REG_EXTENDED) != 0) {
        return 0;  // compiling regex failed
    }
    
    sprintf(temp, "%s", pin);
    
    status = regexec(&regex, temp, (size_t) 0, NULL, 0);
    regfree(&regex);
    
    sprintf(temp, "%s", "");
    
    if (status != 0) {
        printf("Usage: create-user <user-name> <pin> <balance>\n");
        return 0; // regex failed
    }
	
    int int_pin = (int) strtol(pin, &err, 10);
	
    // checking balance
    
    if (regcomp(&regex, "^[0-9]+$", REG_EXTENDED) != 0) {
        return 0;  // compiling regex failed
    }
    
    sprintf(temp, "%s", balance);
    
    status = regexec(&regex, temp, (size_t) 0, NULL, 0);
    regfree(&regex);
    
    if (status != 0) {
        printf("Usage: create-user <user-name> <pin> <balance>\n");
        return 0; // regex failed
    }
	
	l = strtoul(balance, &err, 10);
    
	if (l > INT_MAX) {
        printf("Usage: create-user <user-name> <pin> <balance>\n");
        return 0;
    }
	
    int int_balance = (int) l;
	 
    if (hash_table_find(ht, user_name) == NULL) {
		
		UserInfo user;
		
		// create user card
		char user_file[256]; // 250 for name + 5 for '.card'
		
		strcpy(user_file, strncpy(user_file, user_name, 250));
		
		strcat(user_file, ".card");
		
		FILE* fp_card;
   
		fp_card = fopen(user_file, "w");
	   
		if (fp_card == NULL) {
			printf("Error creating card file for user %s\n", user_name);
			return 0;
		} else {
			
			fclose(fp_card);
			
			// initialize user
			strcpy(user.user_name, user_name);
			user.pin = int_pin;
			user.balance = int_balance;
			
			hash_table_add(ht, user_name, user);
			printf("Created user %s\n", user_name);
		}
		
	} else {
		// user already exists
		printf("Error: user %s already exists\n", user_name);
	}
    
    return 0;
}

int deposit(char* user_name, char* amount, HashTable* ht) {
    int status;
    regex_t regex;
    char temp[11]; // max intger has 10 characters, 
                   // then one more for the null character
    char *err;
    unsigned long l;
    
    if (strlen(user_name) > 250) {
        printf("Usage: deposit <user-name> <amt>\n");
        return 0;
    }
    
    // checking user name
    
    if (regcomp(&regex, "^[a-zA-Z]+$", REG_EXTENDED) != 0) {
        return 0;  // compiling regex failed
    }
    
    status = regexec(&regex, user_name, (size_t) 0, NULL, 0);
    regfree(&regex);
    
    if (status != 0) {
        printf("Usage: deposit <user-name> <amt>\n");
        return 0; // regex failed
    }
	
    // checking amount
	    
    if (regcomp(&regex, "^[0-9]+$", REG_EXTENDED) != 0) {
         printf("Usage: deposit <user-name> <amt>\n");   
	 return 0; // compiling regex failed
    }

    sprintf(temp, "%s", amount);
    
    status = regexec(&regex, temp, (size_t) 0, NULL, 0);
    regfree(&regex);
    
    if (status != 0) {
        printf("Usage: deposit <user-name> <amt>\n");
        return 0; // regex failed
    }
	
    l = strtoul(amount, &err, 10);
       	
    if (l > INT_MAX) {
      	printf("Too rich for this program\n");
       	return 0;
    }
	
    int amt = (int) l;
	
    void* user = hash_table_find(ht, user_name);
    
    if (user == NULL) {
    	// user not found
    	printf("No such user\n");
    } else {
    	// user found
    	(*(UserInfo*)user).balance += amt;
    	printf("$%d added to %s's account\n", amt, user_name);
    }
    
    return 0;
}

// TODO: implement balance

int balance(char* user_name, HashTable* ht) {

    int status;
    regex_t regex;

    if (strlen(user_name) > 250) {
        printf("Usage: deposit <user-name> <amt>\n");
        return 0;
    }

    // checking user name
    
    if (regcomp(&regex, "^[a-zA-Z]+$", REG_EXTENDED) != 0) {
        return 0;  // compiling regex failed
    }
    
    status = regexec(&regex, user_name, (size_t) 0, NULL, 0);
    regfree(&regex);
    
    if (status != 0) {
        printf("Usage: balance <user-name>\n");
        return 0; // regex failed
    }
    
    void* user = hash_table_find(ht, user_name);
    
    if (user == NULL) {
    	// user not found
    	printf("No such user\n");
    } else {
    	// user found
    	printf("$%d\n", (*(UserInfo*)user).balance);
    }
	
    return 0;
}


void bank_process_local_command(Bank *bank, char *command, size_t len, HashTable* ht)
{
    // TODO: Implement the bank's local commands
    int command_size = 1000;
    char *token;
    char commands[4][command_size];
    int i = 0;
	
    //FILE *fp;
	
    // get all tokens, up to 4 (max amt requests)
    while (((token = strsep(&command, " ")) != NULL) && (i < 4)) {
        int ln = strlen(token) - 1;
        
        if (token[ln] == '\n') {
            token[ln] = '\0';
        }
        
        strcpy(commands[i], token);
        i++;
    }
    
    /*********** Legend **************
        commands[0]: bank command
        commands[1]: first argument
        commands[2]: second argument
        commands[3]: third argument
    **********************************/    
    // I used three arguments because this is the max amount of arguments any command can have

    // send the commands[i] to the helper functions, then check
    // if the criteria is met. Otherwise, there is no guarantee the
    // atoi will work as expected. i.e. if a string "fff" is submitted
    // instead of an integer "87", atoi will convert the string
    // to an invalid integer.
	
    if (strcmp(commands[0], "create-user") == 0) {

		if (strlen(commands[2]) < 5 && strlen(commands[3]) < 11) {
			create_user(commands[1], commands[2], commands[3], ht);
		} else {
			printf("Usage: create-user <user-name> <pin> <balance>\n");
		}
		
    } else if (strcmp(commands[0], "deposit") == 0) {
		
		if (strlen(commands[2]) < 11 && strlen(commands[3]) == 0) {
			deposit(commands[1], commands[2], ht);
		} else {
			printf("Usage: deposit <user-name> <amt>\n");
		}
		
    } else if (strcmp(commands[0], "balance") == 0) {
		
		if (strlen(commands[2]) == 0) {
			balance(commands[1], ht);
		} else {
			printf("Usage: balance <user-name>\n");
		}
		
    } else {
        printf("Invalid command\n");
    }
	
    // this clears the commands, so rogue commands aren't
    // staying around and it starts fresh.
    *commands[0] = '\0';
    *commands[1] = '\0';
    *commands[2] = '\0';
    *commands[3] = '\0';
	
}

void bank_process_remote_command(Bank *bank, char *command, size_t len, HashTable* ht)
{
    // TODO: Implement the bank side of the ATM-bank protocol
    //printf("remote command: %s\n", command);
	/*
	 * The following is a toy example that simply receives a
	 * string from the ATM, prepends "Bank got: " and echoes 
	 * it back to the ATM before printing it to stdout.
	 */
		
	int command_size = 1000;
    char *token;
    char commands[2][command_size];
    int i = 0;
	char *err;

    char sendline[1000];
    command[len]=0;
	
	// get all tokens, up to 2 (max amt requests)
	while (((token = strsep(&command, " ")) != NULL) && (i < 4)) {
        int ln = strlen(token) - 1;
        
        if (token[ln] == '\n') {
            token[ln] = '\0';
        }
        
        strcpy(commands[i], token);
        i++;
    }
		
	// parse commands from atm to determine what to send back
	if (strcmp(commands[0], "begin-session") == 0) {
		
		// check if user_name is in the table
		void* user = hash_table_find(ht, commands[1]);
    
		// check if user_name is in the table
		if (user == NULL) {
			
			// user does not exist
			char s[100] = "user does not exist";
			sprintf(sendline, "%s", s);
			
		} else {
			
			// user does exist
			char s[100] = "user does exist";
			sprintf(sendline, "%s", s);
		}
		
	} else if (strcmp(commands[0], "pin") == 0) {
		
		void* user = hash_table_find(ht, commands[1]);
    
		if (user == NULL) {
			// user not found
			printf("No such user\n");
		} else {
		
			int pin = (int) strtoul(commands[2], &err, 10);

			// user found
			if ((*(UserInfo*)user).pin == pin) {
				// correct pin
				char s[100] = "correct pin"; 
				sprintf(sendline, "%s", s);
			} else {
				// wrong pin
				char s[100] = "wrong pin"; 
				sprintf(sendline, "%s", s);
			}
			
		}
		
	} else if (strcmp(commands[0], "withdraw") == 0) {
		
		void* user = hash_table_find(ht, commands[1]);
    
		if (user == NULL) {
			// user not found
			sprintf(sendline, "%s", "No such user");
		} else {
		
			int amt_to_withdraw = (int) strtoul(commands[2], &err, 10);

			// user found
			if ((*(UserInfo*)user).balance >= amt_to_withdraw) {
				
				// withdraw amount from balance
				(*(UserInfo*)user).balance -= amt_to_withdraw;
								
				char s[100] = "sufficient funds"; 
				sprintf(sendline, "%s", s);
				
			} else {
				// not enough money to withdraw
				char s[100] = "insufficient funds"; 
				sprintf(sendline, "%s", s);
			}
			
		}
	} else if (strcmp(commands[0], "balance") == 0) {
		
		void* user = hash_table_find(ht, commands[1]);
    
		if (user == NULL) {
			// user not found
			sprintf(sendline, "%s", "No such user");
		} else {
			// user found - send balance
			sprintf(sendline, "%d", (*(UserInfo*)user).balance);
		}
	}
	
	bank_send(bank, sendline, strlen(sendline));
    
	//sprintf(sendline, "Bank got: %s", command);
	//printf("sendline --> %s\n", sendline);
    //bank_send(bank, sendline, strlen(sendline));
    //printf("Received the following:\n");
   // fputs("blah\n", stdout);
	
}
