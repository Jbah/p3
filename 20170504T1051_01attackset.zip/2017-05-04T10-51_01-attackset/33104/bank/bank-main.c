/* 
 * The main program for the Bank.
 *
 * You are free to change this as necessary.
 */

#include <string.h>
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>
#include "bank.h"
#include "ports.h"
#include "util/hash_table.h"

static const char prompt[] = "BANK: ";

int main(int argc, char **argv)
{
    int n;
    char sendline[1000];
    char recvline[1000];
   
    char bank_file[51];
   
    if (argc != 2) {
        printf("Error creating bank initialization file\n");
		return 64;
    }
   
    strcpy(bank_file, strncpy(bank_file, argv[1], 50));
   
    FILE* fp_bank;
   
    fp_bank = fopen(bank_file, "r");
   
    if (fp_bank == NULL) {
		printf("Error creating bank initialization file\n");
		return 64;
	} else {
		fclose(fp_bank);
	}
   
   HashTable* ht = hash_table_create(100);	
   
   Bank *bank = bank_create();

   printf("%s", prompt);
   fflush(stdout);

   while(1)
   {
       fd_set fds;
       FD_ZERO(&fds);
       FD_SET(0, &fds);
       FD_SET(bank->sockfd, &fds);
       select(bank->sockfd+1, &fds, NULL, NULL, NULL);

       if(FD_ISSET(0, &fds))
       {
           fgets(sendline, 10000,stdin);
           bank_process_local_command(bank, sendline, strlen(sendline), ht);
           printf("%s", prompt);
           fflush(stdout);
       }
       else if(FD_ISSET(bank->sockfd, &fds))
       {
           n = bank_recv(bank, recvline, 10000);
           bank_process_remote_command(bank, recvline, n, ht);
		   fflush(stdin);
       }
   }

   return EXIT_SUCCESS;
}
