#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    
    char atm_file[50];
    char bank_file[51];

    if (argc != 2) {
        printf("Usage: init <filename>\n");
        return 62;
    }
	
	// buffer overflow prevention
	if (strlen(argv[1]) > 44) {
		printf("Error creating initialization files\n");
		return 64;
	}
	
    // changed for buffer overflow prevention
    strcpy(atm_file, strncpy(atm_file, argv[1], 45));
    strcpy(bank_file, strncpy(bank_file, argv[1], 45));
    
    strcat(atm_file, ".atm");
    strcat(bank_file, ".bank");  
    
    if ((access(atm_file, F_OK) != -1) || (access(bank_file, F_OK) != -1)) {
        printf("Error: one of the files already exists\n");
        return 63;
    } else {
		FILE* fp_bank;
		FILE* fp_atm;
		
		fp_bank = fopen(bank_file, "w");
		fp_atm = fopen(atm_file, "w");
		
		if (fp_bank == NULL || fp_atm == NULL) {
			printf("Error creating initialization files\n");
			return 64;
		} else {
			fclose(fp_bank);
			fclose(fp_atm);
		}
		
	}
	// new changed code
	
	
	
    /* old code
    strcat(command1, atm_file);
    strcat(command2, bank_file);
    
    if (system(command1) == -1 || system(command2) == -1) {
       printf("Error creating initialization files\n");
       return 64;
    }
    */
	/*
    fp = fopen(bank_file,"w");
    
    if (fp == NULL) {
        // failed opening file
        return -1;
    }
    
    fwrite(ht, hash_table_size(ht), 1, fp);
    fclose(fp);
    */
	
    printf("Successfully initialized bank state\n");
	return 0;
}
