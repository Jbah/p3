#include "hash_table.h"
#include <stdio.h>
#include <stdlib.h>
#include <regex.h>

int main()
{
    HashTable *ht = hash_table_create(10);
    printf("Size: %d\n", hash_table_size(ht));

    int rv;
    int match;
    regex_t amount;
    char *amount_to_add;
    int al_bal = 50000;
    hash_table_add(ht, "Alice", &al_bal);

    int *a = (int*) hash_table_find(ht,"Alice");
    //int *b = (int*) hash_table_find(ht,"Bob");
    printf("Alice -> %d\n", *a);
    //printf("Bob -> %d\n", *b);

    printf("size of ht =%d\n", hash_table_size(ht) );
    amount_to_add = "99";

    rv = regcomp(&amount, "^[0-9]+$", REG_EXTENDED);

        /* checks if regex statement compiled */
        
    if(rv == 0){ 
        match = regexec(&amount, amount_to_add, 0, NULL, 0);
        regfree(&amount);
    }

    if (match != 0 ){
        printf("fail\n");
        return 1;
    }

    int *c = (int*) hash_table_find(ht,"Alice");
    printf(" after regex: Alice-> %d\n", *c);
    printf("size of ht =%d\n", hash_table_size(ht) );

    //hash_table_del(ht, "Alice");
    //hash_table_add(ht, "Alice", "234");
    //printf("Alice -> %s\n", hash_table_find(ht, "Alice"));
    
    printf("Charlie -> %s\n", (hash_table_find(ht, "Charlie") == NULL ? "Not Found" : "FAIL"));

    printf("Size: %d\n", hash_table_size(ht));

    return EXIT_SUCCESS;
}
