#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/rand.h>

int main(int argc, char** argv){
	FILE *fp1;
	FILE *fp2;
	char* atm = NULL; 
	char* bank = NULL;
	char* result_atm = NULL;
	char* result_bank = NULL;
	int key_result;
	unsigned char key[16];

	if(argc < 2 || argc > 2){
		printf("Usage: init <filename>\n");
		return 62;
	}

	atm = ".atm";
	bank = ".bank";
	result_atm = malloc(strlen(argv[1]) + strlen(atm) + 1);
	result_bank = malloc(strlen(argv[1]) + strlen(bank) + 1);
	
	if(result_atm == NULL || result_bank == NULL){
		printf("Error creating initialization files\n");
		return 64;
	}
	//create filename.bank and filename.atm filenames
	strcpy(result_atm,argv[1]);
	strcpy(result_bank,argv[1]);
	strcat(result_bank,bank);
	strcat(result_atm,atm);

	/* Try to open the .bank and .atm files , error if they already exist*/
	fp1 = fopen(result_atm, "r");
	fp2 = fopen(result_bank, "r");
	if(fp1 != NULL || fp2 != NULL){
		printf("Error: one of the files already exists\n");
		return 63;
	}

	//Generate 16 byte (128 bit) key
	key_result = RAND_bytes(key,sizeof(key));

	if(key_result != 1){
		printf("Error generating key : Aborting\n");
		return 1;
	}

	fp1 = fopen(result_atm, "w");
	fp2 = fopen(result_bank, "w");

	//writing to files
	fwrite(key,1,sizeof(key),fp1);
	fwrite(key,1,sizeof(key),fp2);

	fclose(fp1);
	fclose(fp2);

	free(result_bank);
	free(result_atm);
	result_bank = NULL;
	result_atm = NULL;

	printf("Successfully initialized bank state\n");
	return 0;

}
