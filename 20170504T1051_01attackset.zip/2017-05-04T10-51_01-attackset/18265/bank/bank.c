#include "bank.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <regex.h>
#include <limits.h>

Bank* bank_create()
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));

    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    //set hashtable 
    bank->table = hash_table_create(50);


    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as needed

    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
        hash_table_free(bank->table);
        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

void create_user(Bank *bank, char *command, size_t len, int num_of_cmds, char* cmd,
    char *arg1, char *arg2, char *arg3, char* bankfile){

    int rv1,rv2,rv3;
    int match1,match2,match3;
    unsigned long num;
    unsigned long intmax = (unsigned long) INT_MAX;
    regex_t username, pin, balance;
    FILE* fp;
    char* ext = ".card";
    char* cardfile = NULL;
    int* bal = NULL;
    bal = malloc(sizeof(int));
    int encrypt_result;
    char key[1000];
    char ctext[1000];
    FILE *bank_fp;

    bank_fp = fopen(bankfile,"r");
    fread(key,17,1,bank_fp); //only want 16 bytes for key
    fclose(bank_fp);

    if(num_of_cmds != 4){
        printf("Usage: create-user <user-name> <pin> <balance>\n");
        return;
    }else{
        //check valid create-user arguments
        rv1 = regcomp(&username, "^[a-zA-Z]+$" , REG_EXTENDED);
        //change to check all rv1,rv2,rv3 to 
        if(rv1 == 0){
            match1 = regexec(&username, arg1, 0, NULL, 0);
            regfree(&username);
        }
        rv2 = regcomp(&pin, "^[0-9][0-9][0-9][0-9]$", REG_EXTENDED);
        if(rv2 == 0){
            match2 = regexec(&pin,arg2,0,NULL,0);
            regfree(&pin);
        }
        rv3 = regcomp(&balance, "^[0-9]+$", REG_EXTENDED);
        if(rv3 == 0){
            match3 = regexec(&balance,arg3,0,NULL,0);
            regfree(&balance);
            num = strtoul(arg3,NULL,0);
            if (num > intmax){
                //set match to invalid
                match3 = 999;
            }else{
                *bal = (int) strtoul(arg3,NULL,0);
            }
        }
        if(match1 != 0 || match2 != 0 || match3 != 0){
            printf("Usage: create-user <user-name> <pin> <balance>\n");
            return;
        }else{
            //check if user exists
            if( hash_table_find(bank->table, arg1) != NULL){
                printf("Error: user %s already exists\n" , arg1);
                return;
            }else{//add user to table
                //create card (check if .card file exists already)
                cardfile = malloc(strlen(arg1) + strlen(ext) + 1);
                strcpy(cardfile, arg1);
                strcat(cardfile, ext);
                fp = fopen(cardfile,"r"); 
                if(fp != NULL){
                    printf("Error user <user-name> already exists\n");
                    return;
                }else{
                    fp = fopen(cardfile,"w+");
                    if(fp == NULL){
                        printf("Error creating card file for user %s\n", arg1);
                        return;
                    }
                    
                    //encrypt pin
                    encrypt_result = encrypt(arg2, strlen(arg2), key, ctext);
                    //printf("plaintext %s ciphertext %s",arg2,ctext);

                    fwrite(ctext,1,sizeof(ctext),fp);
                    //fprintf(fp,"%s",arg2);
                    fclose(fp);

                    free(cardfile);
                    hash_table_add(bank->table,arg1,bal);
                    printf("Created user %s\n", arg1);
                    return;
                }
            }
        }
    }   
}

void balance(Bank *bank, char *command, size_t len, int num_of_cmds, char *cmd, 
    char *arg1){

    int *bal;
    if(num_of_cmds != 2){
        printf("Usage: balance <user-name>\n");
        return;
    }else{
        if( hash_table_find(bank->table, arg1) == NULL){
            printf("No such user\n");
            return;
        }else{
            bal = (int*) hash_table_find(bank->table, arg1);
            printf("$%d\n", *bal);
            return;
        }
    }
}

 /*
    arg1 = user name
    arg2 = amt
*/
void bank_deposit(Bank *bank, int num_of_cmds, char *arg1, char *arg2){

    unsigned long intmax = (unsigned long) INT_MAX;
    int rv = 0 ;
    int match = 0;
    regex_t amount;
    unsigned long temp_amt;
    int *balance = NULL;
    int amt;

    if(num_of_cmds != 3){
        printf("Usage: deposit <user-name> <amt>\n");
        return;
    }

    if(arg1 == NULL || arg2 == NULL){
        printf("Usage: deposit <user-name> <amt>\n");
        return;
    }

    // TODO: check in hash table for valid user name 
    if(hash_table_find(bank->table, arg1) == NULL){
        printf("No such user\n");
        return;
    }else{

        rv = regcomp(&amount, "^[0-9]+$", REG_EXTENDED);

        /* checks if regex statement compiled */
        if(rv == 0){ 
            match = regexec(&amount, arg2, 0, NULL, 0);
            regfree(&amount);
        }
        
        if(match != 0){
            printf("Usage: deposit <username> <amt>\n");
            return;
        }
        
        temp_amt = strtoul(arg2, NULL,0);
        //todo: check temp_amt > intmax

        balance = (int*) hash_table_find(bank->table,arg1);
        
        unsigned long temp_bal = (unsigned long) *balance;
        
        /*Checks for integer overflow*/
        if(temp_amt > intmax){
            printf("Too rich for this program\n");
            return;
        }else if(temp_amt + temp_bal > intmax){ 
            printf("Too rich for this program\n");
            return;
        }else{
            amt = (int) temp_amt;
        }

        /*Here amt is finally added to balance*/
        *balance = *balance + amt;
        printf("$%d added to %s's account\n",amt,arg1);
    }    

}


void bank_process_local_command(Bank *bank, char *command, size_t len, char *bankfile)
{
    // TODO: Implement the bank's local commands
    char cmd[100];
    char arg1[251]; //max 250 char user
    char arg2[100]; //max 4 digit PIN
    char arg3[100]; //max 4 byte number
    int num_of_cmds = 0;
    
    
    num_of_cmds = sscanf(command, "%s%s%s%s",cmd,arg1,arg2,arg3);
    if(cmd != NULL && strcmp(cmd,"create-user") == 0){
        create_user(bank, command, len, num_of_cmds,cmd,arg1,arg2,arg3,bankfile);
    }else if(cmd != NULL && strcmp(cmd,"deposit") == 0){
        bank_deposit(bank,num_of_cmds,arg1,arg2);
    }else if(cmd != NULL && strcmp(cmd,"balance") == 0){
        balance(bank,command,len,num_of_cmds,cmd,arg1);
    }else{
        printf("Invalid command\n");
    }
}

int process_find_user(Bank *bank, char *command, size_t len, char *cmd, char *username){
    int *val; 
    if(username == NULL){
        return 0;
    }else{
        val = (int*) hash_table_find(bank->table,username);
        if(val == NULL){
            return 0;
        }else{
            return 1;
        }
    }
}

int process_withdraw(Bank *bank, char *command, size_t len, char *cmd, char* user, char *amount){

    int* balance = NULL;
    int amt = atoi(amount);

    balance = (int*) hash_table_find(bank->table,user);
    if (amt > (*balance)){
        return 0; //insufficient funds
    }else{
        *balance = *balance - amt;
        return 1;
    }


}

int* process_balance(Bank *bank, char* command, size_t len, char* cmd, char* user){
    int *balance = NULL;

    if(user == NULL){
        return NULL;
    }

    balance = (int *) hash_table_find(bank->table, user);
    if(balance == NULL){
        return NULL;
    }else{
        return balance;
    }

}

void bank_process_remote_command(Bank *bank, char *command, size_t len)
{
    // TODO: Implement the bank side of the ATM-bank protocol

	/*
	 * The following is a toy example that simply receives a
	 * string from the ATM, prepends "Bank got: " and echoes 
	 * it back to the ATM before printing it to stdout.
	 */

    char cmd[250];
    char arg[250];
    char arg2[250];
    char sendline[1000];
    int num_of_cmds;
    int is_user_valid;
    int withdraw;
    int *bal = NULL;

    command[len]=0;
    num_of_cmds = sscanf(command,"%s%s%s",cmd,arg,arg2);
    is_user_valid = 0;
    withdraw = 0;
    

    //printf("Received %s from ATM\n",command);
    if(cmd != NULL && strcmp(cmd,"find_user") == 0){
        is_user_valid = process_find_user(bank,command,len,cmd,arg);
        if(is_user_valid == 0){
            sprintf(sendline, "found_user false");
        }else{
            sprintf(sendline, "found_user true");
        }
        bank_send(bank,sendline,strlen(sendline));
    }else if(cmd != NULL && strcmp(cmd,"withdraw") == 0){
        withdraw = process_withdraw(bank,command,len,cmd,arg,arg2);
        if(withdraw == 0){
            sprintf(sendline, "withdraw false");
        }else{
            sprintf(sendline, "withdraw true");
        }
        bank_send(bank,sendline,strlen(sendline));
    }else if(cmd != NULL && strcmp(cmd,"balance") == 0){
        bal = process_balance(bank,command,len,cmd,arg);
        if(bal == NULL){
            sprintf(sendline, "balance false");
        }else{
            sprintf(sendline, "balance %d", *bal);
        }
        bank_send(bank,sendline,strlen(sendline));
    }

    /*
    command[len]=0;
    sprintf(sendline, "Bank got: %s", command);
    bank_send(bank, sendline, strlen(sendline));
    printf("Received the following:\n");
    fputs(command, stdout);
    */
	
}
