/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char prompt[] = "ATM: ";

int main(int argc, char** argv)
{
    char user_input[1000];

    ATM *atm = atm_create();
    char *p = NULL;
    FILE *fp = NULL;

    char *atmfile = NULL;
    

    /*Check if the number of arguments is not exactly 1*/
    if(argc < 2 || argc > 2){
        printf("Error with atm arguments\n");
        return 62;
    }

    atmfile = malloc(strlen(argv[1]) + 1);
    strcpy(atmfile,argv[1]);

    p = strrchr(argv[1], '.');
    /*Checks if there is a file extension, if not then a file 
        was not passed in*/

    /*Checks if file passed is .atm file otherwise atm cannot 
    access it */
    if(p == NULL){
        printf("Error no file extension\n");
        return 62;
    }else if(strcmp(p, ".atm")!= 0){
        printf("Error not a .atm file\n");
        return 62;
    }

    /*Try to open .atm file*/
    fp = fopen(argv[1], "r");
    /*If file cannot open*/
    if(fp == NULL){
        printf("Error opening ATM initialization file\n");
        return 64;
    }

    fclose(fp);

    /*If file opens*/
    printf("%s", prompt);
    fflush(stdout);

    while (fgets(user_input, 10000,stdin) != NULL)
    {
        atm_process_command(atm, user_input,atmfile);
        printf("%s", prompt);
        fflush(stdout);
    }
	return EXIT_SUCCESS;
}
