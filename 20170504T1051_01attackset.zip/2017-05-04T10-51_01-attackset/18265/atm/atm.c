#include "atm.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <regex.h>
#include <limits.h>

#define MAX_ATTEMPTS 5

ATM* atm_create()
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    //init table <username,attempts>
    atm->table = hash_table_create(50);


    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    // TODO set up more, as needed

    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        hash_table_free(atm->table);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

void session_withdraw(ATM *atm, int num_of_cmds, char *command, char* user, char *amount ){
    int n;
    char recvline[10000];
    char *req = NULL;
    int cmds;
    char valid_user_arg1[500];
    char valid_user_arg2[500];
    int rv = 0;
    int match = 0;
    regex_t regx;
    unsigned long intmax = (unsigned long) INT_MAX;
    unsigned long temp_amt;

    if(num_of_cmds != 2){
        printf("Usage: withdraw <amt>\n");
        return;
    }

    //check if amount was provided
    if(amount == NULL){
        printf("Usage: withdraw <amt>\n");
        return;
    }

    rv = regcomp(&regx, "^[0-9]+$", REG_EXTENDED);

    if(rv == 0){
        match = regexec(&regx,amount,0,NULL,0);
        regfree(&regx);
    }

    if(match != 0){
        printf("Usage: withdraw <amt>\n");
        return;
    }

    temp_amt = strtoul(amount,NULL,0);

    if(temp_amt > intmax){
        printf("Usage: withdraw <amt>\n");
        return;
    }

    //send withdraw <user> <amount> to bank
    req = malloc(strlen(amount) + strlen(user) + sizeof(char)*10 + 1);
    sprintf( req, "withdraw %s %s", user, amount);
    printf("Sending <%s> to bank\n", req);

    atm_send(atm, req, strlen(req));
    n = atm_recv(atm,recvline,10000);

    if(n == (-1)){
        printf("ATM did not receive bank message\n");
        return;
    }else{
        recvline[n]=0;
        cmds = sscanf(recvline,"%s%s", valid_user_arg1,valid_user_arg2);
        if(valid_user_arg1 != NULL && strcmp(valid_user_arg1, "withdraw") == 0){
            if(valid_user_arg2 != NULL && strcmp(valid_user_arg2,"false") == 0){
                printf("Insufficient funds\n");
                return;
            }else if(valid_user_arg2 != NULL && strcmp(valid_user_arg2,"true") == 0) {
                printf("$%s dispensed\n", amount);
                return;
            }
           
        }else{
            printf("ATM bank message invalid\n");
            return;
        }
    }
}

void session_balance(ATM *atm, int num_of_cmds, char *cmd, char *user){

    char recvline[10000];
    int n;
    char* req = NULL;
    int cmds;
    char valid_user_arg1[500];
    char valid_user_arg2[500];

    if(num_of_cmds != 1){
        printf("Usage: balance\n");
        return;
    }

    //send balance <user> to bank
    req = malloc(strlen(user) + sizeof(char)*8 + 1);
    sprintf( req, "balance %s", user);
    printf("Sending <%s> to bank\n", req);

    atm_send(atm, req, strlen(req));
    n = atm_recv(atm,recvline,10000);
    if(n == (-1)){
        printf("ATM did not receive bank message\n");
        return;   
    }else{
        recvline[n]=0;
        cmds = sscanf(recvline,"%s%s", valid_user_arg1,valid_user_arg2);
        if(valid_user_arg1 != NULL && strcmp(valid_user_arg1,"balance") == 0){
            if(valid_user_arg2 != NULL && strcmp(valid_user_arg2,"false") == 0){
                //soemthing went wrong with balance
                printf("Usage: balance\n");
                return;
            }else{
                printf("$%s\n",valid_user_arg2);
                return;
            }
        }
    }


}


void begin_session(ATM *atm, char *cmd, char* arg1, int num_of_cmds, char* atmfile ){
    
    FILE *fp;
    char *cardfile = NULL;
    char *ext = ".card";
    char validate_user_cmd[1000];
    char user_input[1000];
    const char pin_prompt[] = "PIN? ";
    char *resp = NULL;
    char *authorized_prompt = NULL;

    int does_user_exist = 0;
    int is_pin_valid = 0;
    int *val = NULL;
    
    char line[1000];

    char authorized_cmd[250];
    char amount[250];
    int auth_num_of_cmds = 0;

    char recvline[10000];
    int n;
    int validate_user;
    char valid_user_arg1[500];
    char valid_user_arg2[500];
    size_t ln;

    char key[1000];
    char ptext[1000];
    FILE *atm_fp;
    int decrypt_result;

    // check if inputs are valid
    if(arg1 == NULL){
        printf("Usage: begin-session <user-name>\n");
        return;
    }

    //get symmetric key
    atm_fp = fopen(atmfile, "r");
    fread(key,17,1,atm_fp);
    fclose(atm_fp);


    //check if user has a valid card file
    cardfile = malloc(strlen(arg1) + strlen(ext) + 1);
    strcpy(cardfile,arg1);
    strcat(cardfile,ext);
    fp = fopen(cardfile,"r");
    if(fp == NULL){
        printf("Unable to access %s's card\n", arg1);
        return;
    }

    sprintf(validate_user_cmd, "find_user %s", arg1);
    //printf("Sending <%s> to bank\n", validate_user_cmd);
    atm_send(atm, validate_user_cmd, strlen(validate_user_cmd));
    n = atm_recv(atm,recvline,10000);
    if(n == (-1)){
        printf("ATM did not receive bank message\n");
        return;
    }else{
        recvline[n]=0;
        validate_user = sscanf(recvline,"%s%s", valid_user_arg1,valid_user_arg2);
        if(valid_user_arg1 != NULL && strcmp(valid_user_arg1,"found_user")==0){
            if( valid_user_arg2 != NULL && strcmp(valid_user_arg2,"false")==0){
                printf("No such user\n" );
                return;
            }else if(valid_user_arg2 != NULL && strcmp(valid_user_arg2,"true") ==0){
                does_user_exist = 1;
            }
        }else{
            printf("ATM bank message invalid\n");
            return;
        }
    }

    if(does_user_exist == 0){
        printf("No such user\n");
        return;
    }else{
        //limit number of attempts
        if(hash_table_find(atm->table,arg1) == NULL){
            val = malloc(sizeof(int));
            *val = 0;
            hash_table_add(atm->table, arg1, val);
        }else{
            val = (int *)hash_table_find(atm->table,arg1);
        }

        if(*val >= MAX_ATTEMPTS){
            printf("too many bad attempts for this user\n");
            return;
        }

        printf("%s", pin_prompt);
        fflush(stdout);

        resp = fgets(user_input, 10000,stdin);

        if(resp != NULL){
            ln = strlen(user_input) -1;
            if(user_input[ln] == '\n'){
                user_input[ln] = '\0';
            }

            //validate pin 
            fgets(line,17,fp);
            decrypt_result = decrypt(line, strlen(line), key, ptext);
            ln = decrypt_result;
            ptext[ln] = '\0';
        
            if(strcmp(ptext,user_input) == 0){
                is_pin_valid = 1;
            }

            if(is_pin_valid == 0){
                //increment #of attempts
                printf("Not authorized\n");
                *val = *val + 1; 
                return;
            }else{
                printf("Authorized\n");

                authorized_prompt = malloc(strlen(arg1) + sizeof(char)*9); //9 for "ATM(): "
                sprintf(authorized_prompt, "ATM (%s): ",arg1);
                printf("%s",authorized_prompt);
                fflush(stdout);


                while(fgets(user_input,10000,stdin) != NULL){
                    //authorized session, look for 3 other commands here
                    auth_num_of_cmds = sscanf(user_input,"%s%s",authorized_cmd,amount);
                    if (authorized_cmd != NULL && strcmp(authorized_cmd,"begin-session") == 0){
                        printf("A user is already logged in\n");
                    }else if(authorized_cmd != NULL && strcmp(authorized_cmd,"balance") == 0){
                        session_balance(atm,auth_num_of_cmds,authorized_cmd,arg1);
                    }else if(authorized_cmd != NULL && strcmp(authorized_cmd,"withdraw") == 0){
                        session_withdraw(atm,auth_num_of_cmds,authorized_cmd,arg1,amount);
                    }else if(authorized_cmd != NULL && strcmp(authorized_cmd,"end-session") == 0){
                        printf("User logged out\n");
                        break;
                    }else{
                        printf("Invalid command\n");
                    }
                    printf("%s",authorized_prompt);
                    fflush(stdout);
                }

            }

        }
        
    }
}


void atm_process_command(ATM *atm, char *command, char* atmfile)
{
    /*char recvline[10000];
    int n;
    */
    // TODO: Implement the ATM's side of the ATM-bank protocol

	/*
	 * The following is a toy example that simply sends the
	 * user's command to the bank, receives a message from the
	 * bank, and then prints it to stdout.
	 */
    
     //use lib to encrypt command here
    /*
    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    fputs(recvline,stdout);
    */

    char cmd[250];
    char arg1[250];
    int num_of_cmds = 0;

    num_of_cmds = sscanf(command,"%s%s", cmd,arg1);
    if(cmd != NULL && strcmp(cmd,"begin-session") == 0){
        begin_session(atm,command,arg1,num_of_cmds,atmfile);
    }else if(cmd != NULL && strcmp(cmd,"balance") == 0){
        printf("No user logged in\n");
        return;    
    }else if(cmd != NULL && strcmp(cmd,"withdraw") == 0){
        printf("No user logged in\n");
        return;   
    }else if(cmd != NULL && strcmp(cmd,"end-session") == 0){
        printf("No user logged in\n");
        return;   
    }else{
        printf("Invalid command\n");
        return;
    }
}
