
/* 
 * The main program for the Bank.
 *
 * You are free to change this as necessary.
 */

#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdarg.h>
#include "bank.h"

static const char prompt[] = "BANK: ";


int main(int argc, char**argv)
{
   int n;
   char sendline[1000];
   char recvline[1000];


   printf("%s", prompt);
   fflush(stdout);


   if(file_exists(argv[1]) == 0){
     printf("Error opening bank initialization file\n");
     return 64;
   }
   Bank *bank = bank_create(argv[1]);

   char* send;
   int c = 0;
   int *usercount = &c;
   while(1)
   {
       fd_set fds;
       FD_ZERO(&fds);
       FD_SET(0, &fds);
       FD_SET(bank->sockfd, &fds);
       select(bank->sockfd+1, &fds, NULL, NULL, NULL);
     

       if(FD_ISSET(0, &fds))
       {
           fgets(sendline, 10000,stdin);
           send = bank_process_local_command(bank, sendline, strlen(sendline), usercount, 1);
           printf("%s", prompt);
           fflush(stdout);
	   free(send);
       }
       else if(FD_ISSET(bank->sockfd, &fds))
       {
           n = bank_recv(bank, recvline, 10000);
           bank_process_remote_command(bank, recvline, n, usercount);
       }
   }

   return EXIT_SUCCESS;
}
