#include "bank.h"
#include "ports.h"
#include "openssl.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdarg.h>

Bank* bank_create(char* fname)
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    bank->head = NULL;
   

    // Set up the protocol state
    // TODO set up more, as needed
    FILE *fp = fopen(fname, "r");
	bank->key = malloc(17);	
	fgets(bank->key, 17, fp);
	fclose(fp);

    return bank;
}


int randDigit() {
  return rand() % 10;
}
char* rand16() {
  char *str = calloc(17, 1);
  int i;
  for(i = 0;i < 16; i++){
    char tmp[2] = {0};
    sprintf(tmp, "%d\0", randDigit());
    strcat(str, tmp);
  }
  str[16] = '\0';
  return str;
}
void free_users(users * head){
  users * node = head;
  users * temp = NULL;
  while(node != NULL){
    temp = node;
    node = temp->next;
    free(temp);
  }
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
        free(bank->key);
		free_users(bank->head);
        free(bank);
    }
}



ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

int only_digits(const char *s){
  while (*s){
    if(isdigit(*s++)==0) return 0;
  }
  return 1;
}

int only_letters(const char *s){
  while (*s){
    if(isalpha(*s++)==0) return 0;
  }
  return 1;
}

int file_exists(const char *fname){
  FILE *f;
  if((f = fopen(fname, "r"))){
      fclose(f);
      return 1;
    }
  return 0;
}


int user_exists(Bank *bank, char *username, int *usercount){
  users * current = bank->head;

  while (current != NULL){
    if(strcmp(current->user, username) == 0){
      return 1;
    }
    current = current->next;
  }
  return 0;
}

void replace_char(char* str, char find, char replace) {
	int len = strlen(str);
	int i = 0;
	for(i = 0; i < len; i++) {
		if(str[i] == find) {
			str[i] = replace;
		}
	}
}

char* bank_process_create_user(Bank *bank, char *command, size_t len, int *usercount){
  

  char *send = (char *)malloc(280);

  
  //max length of "create-user" + username + pin + balance + spaces
  if(len > 279){
    sprintf(send, "Usage: create-user <user-name> <pin> <balance>\n");
    return send;
  }

  int i = 0;
  char *split;
  char *createuser = (char *)malloc(280);
  char *username = (char *)malloc(280);
  char *pin = (char *)malloc(280);
  char *balance = (char *)malloc(280);
  

  //splits the input on spaces and assigns name, pin, balance 

  

  split = strtok (command, " \n\r\t\0");
  while(split != NULL){
    if(i == 0){
      createuser = strdup(split);
    }
    if(i == 1){
      username = strdup(split);
    }
    else if(i == 2){
      pin = strdup(split);
    }
    else if (i == 3){
      balance = strdup(split);
    }
    split = strtok (NULL, " \n\r\t\0");
    i++;
    
    if(i >= 4){
      break;
    }

  }
  if(i!= 4){
    sprintf(send, "Usage: create-user <user-name> <pin> <balance>\n");
    free(createuser);
    free(username);
    free(pin);
    free(balance);
   
   
    return send;
  }


  
  char *cucheck = "create-user";

  int x = strcmp(cucheck, createuser);
  int plength = strlen(pin);
  int blength = strlen(balance);
  int ulength = strlen(username);


  int bIsDigits = only_digits(balance);
  int pIsDigits = only_digits(pin);

  int uIsLetters = only_letters(username);

  if(x != 0 || ulength > 250 || ulength == 0 || plength != 4 || blength > 10 || blength == 0 || bIsDigits == 0 || pIsDigits == 0 || uIsLetters == 0){
    sprintf(send, "Usage: create-user <user-name> <pin> <balance>\n");
    free(createuser);
    free(username);
    free(pin);
    free(balance);
    
    return send;
  }

  
  int pinInt = atoi(pin);
  int balanceInt = atoi(balance);
  
  if(balanceInt <= 0){
    sprintf(send, "Usage: create-user <user-name> <pin> <balance>\n");
    free(createuser);
    free(username);
    free(pin);
    free(balance);
    
    return send;
  }

  username[(strlen(username))]='\0';

  char *oldusername = (char *)malloc(strlen(username) + 7);
  
  strcpy(oldusername, username);
  strcat(username, ".card\0");

  char *cardname = (char *)malloc(strlen(username) + 2);
  strcpy(cardname, username);
  



  if(user_exists(bank, oldusername, usercount)){
    sprintf(send, "Error: user %s already exists\n", oldusername);
    free(createuser);
    free(username);
    free(pin);
    free(balance);
    free(cardname);
    free(oldusername);
    return send;
  }


  FILE *usercard = fopen(cardname, "w");
  if (usercard == NULL){
    sprintf(send, "Error creating card file for user %s\n", oldusername);
    free(createuser);
    free(username);
    free(pin);
    free(balance);
    free(cardname);
    free(oldusername);
    return send;
  }

  char *tag = (char *)calloc(1017, 1);
  char *randStr = rand16();
  char *salted = (char *)calloc(22, 1);
  strcpy(salted, randStr);
  strcat(salted, pin);
  int xl = 0;

  xl = sign(bank->key, salted, strlen(salted)+1, tag);
  replace_char(tag, '\n', 'a'); 

  char *salttag = calloc((xl+strlen(randStr)+2), 1);
  strcpy(salttag, randStr);
  strcat(salttag, tag);


  fprintf(usercard, "%s", salttag);
  fclose(usercard);

  
  if(bank->head == NULL){ 
    users * new_head = malloc(sizeof(users));
    new_head->user = strdup(oldusername);
    new_head->balance = balanceInt;
  
    new_head->next = NULL;
    bank->head = new_head;
    sprintf(send, "Created user %s\n", oldusername);
    
    free(cardname);
    free(oldusername);
    free(createuser);
    free(username);
    free(pin);
    free(balance);
    free(tag);
    free(randStr);
    free(salted);
    return send;
  }
  else{
    users * current = bank->head;
    while(current->next != NULL){
      current = current->next;
    }
    current->next = malloc(sizeof(users));
    current->next->user = strdup(oldusername);
    current->next->balance = balanceInt;
    
    current->next->next = NULL;
    
    (*usercount)++;
  }

  sprintf(send, "Created user %s\n", oldusername);


  free(cardname);
  free(oldusername);
  free(createuser);
  free(username);
  free(pin);
  free(balance);
  free(randStr);
  free(salted);
  free(tag);
  return send;
}

char* bank_process_deposit(Bank *bank, char *command, size_t len, int *usercount){
  char *send = (char *)malloc(280);
  //max length of "create-user" + username + pin + balance + spaces
  if(len > 279){
    sprintf(send, "Usage: deposit <user-name> <amt>\n");
    return send;
  }
  

  int i = 0;
  char *split;


  char *deposit = (char *)malloc(280);
  char *username = (char *)malloc(280);
  char *amount = (char *)malloc(280);

  
  //splits the input on spaces and assigns name, pin, balance 

  split = strtok (command, " \n\r\t\0");
  while(split != NULL){
    if(i == 0){
      deposit = strdup(split);
    }
    if(i == 1){
      username = strdup(split);
    }
    else if(i == 2){
      amount = strdup(split);
    }
   
    split = strtok (NULL, " \n\r\t\0");
    i++;
    
    if(i >= 3){
      break;
    }

  }
  
  if(i!= 3){
    sprintf(send, "Usage: deposit <user-name> <amt>\n");
    free(deposit);
    free(username);
    free(amount);
    return send;
  }
  
  char *cucheck = "deposit";

  int x = strcmp(cucheck, deposit);
  int aIsDigits = only_digits(amount);
  int uIsLetters = only_letters(username);
  
  if(strlen(username) > 250 || strlen(username) == 0 || x != 0 || strlen(amount) > 10 || strlen(amount) == 0 || aIsDigits == 0 || uIsLetters == 0){
    sprintf(send, "Usage: deposit <user-name> <amt>\n");
    free(deposit);
    free(username);
    free(amount);
    return send;
  }


 
  username[(strlen(username))]='\0';
  char *oldusername = (char *)malloc(strlen(username));
  strcpy(oldusername, username);

  strcat(username, ".card\0");

  char *cardname = (char *)malloc(strlen(username));
  strcpy(cardname, username);
  

  if(user_exists(bank, oldusername, usercount) == 0){
    sprintf(send, "No such user\n");
    free(deposit);
    free(username);
    free(amount);
    free(cardname);
    free(oldusername);
    return send;
  }

  
  i = 0;
  int amountI = atoi(amount);
  if (amountI <= 0){
    sprintf(send, "Usage: deposit <user-name> <amt>\n");
    free(deposit);
    free(username);
    free(amount);
    free(cardname);
    free(oldusername);
    return send;
  }


  users * current = bank->head;
  while(current->next != NULL){
    if(strcmp(oldusername, current->user) == 0){
      if(amountI + (current->balance) < current->balance){
	sprintf(send, "Too rich for this program\n");
	free(deposit);
	free(username);
	free(amount);
	free(cardname);
	free(oldusername);
	return send;
      }
      else{
	current->balance = amountI + current->balance;
	sprintf(send, "$%d added to %s's account\n", amountI, oldusername);
	free(deposit);
	free(username);
	free(amount);
	free(cardname);
	free(oldusername);
	return send;
      }
    }
    current = current->next;
  }

  
  if(current->next == NULL){
    if(strcmp(oldusername, current->user) == 0){
      if(amountI + (current->balance) < current->balance){
	sprintf(send, "Too rich for this program\n");
	free(deposit);
	free(username);
	free(amount);
	free(cardname);
	free(oldusername);
	return send;
      }
      else{
	current->balance = amountI + current->balance;
	sprintf(send, "$%d added to %s's account\n", amountI, oldusername);
	free(deposit);
	free(username);
	free(amount);
	free(cardname);
	free(oldusername);
	return send;
      }
    }
    else{
      //should never get here
      sprintf(send, "No such user\n");
      free(deposit);
      free(username);
      free(amount);
      free(cardname);
      free(oldusername);
      return send;
    }
  }

  sprintf(send, "$%d added to %s's account\n", amountI, oldusername);
  free(deposit);
  free(username);
  free(amount);
  free(cardname);
  free(oldusername);
  return send;
}



char* bank_process_balance(Bank *bank, char *command, size_t len, int *usercount){
  //max length of "create-user" + username + pin + balance + spaces
  char *send = (char *)malloc(280);
  if(len > 279){
    sprintf(send, "Usage: balance <user-name>\n");
    return send;
  }
  

  int i = 0;
  char *split;


  char *balance = (char *)malloc(280);
  char *username = (char *)malloc(280);

  
  //splits the input on spaces and assigns name, pin, balance 

  split = strtok (command, " \n\r\t\0");
  while(split != NULL){
    if(i == 0){
      balance = strdup(split);
    }
    if(i == 1){
      username = strdup(split);
    }
   
    split = strtok (NULL, " \n\r\t\0");
    i++;
    
    if(i >= 2){
      break;
    }

  }
  
  if(i!= 2){
    sprintf(send, "Usage: balance <user-name>\n");
    free(balance);
    free(username);
    return send;
  }
  
  char *cucheck = "balance";
  int x = strcmp(cucheck, balance);
  int uIsLetters = only_letters(username);
  
  if(strlen(username) > 250 || strlen(username) == 0 || x != 0 || uIsLetters == 0){
    sprintf(send, "Usage: balance <user-name>\n");
    free(balance);
    free(username);
    return send;
  }


 
  username[(strlen(username))]='\0';
  char *oldusername = (char *)malloc(strlen(username) + 1);
  strcpy(oldusername, username);

  strcat(username, ".card\0");

  char *cardname = (char *)malloc(strlen(username) + 1);
  strcpy(cardname, username);
  

  if(user_exists(bank, oldusername, usercount) == 0){
    sprintf(send, "No such user\n");
    free(balance);
    free(username);
    free(cardname);
    free(oldusername);
    return send;
  }

  
  i = 0;
  int amount = -1;


  users * current = bank->head;
  if(strcmp(current->user, oldusername)==0){
    amount = current->balance;
    sprintf(send, "$%d\n", amount);
  }
  else{
    while(current != NULL){
      if((strcmp(current->user, oldusername) == 0)){
	amount = current->balance;
	sprintf(send, "$%d\n", amount);
	break;
      }
      current = current->next;
    }
  }

  free(balance);
  free(username);
  
  free(cardname);
  free(oldusername);
  return send;
}

char* bank_process_reg(Bank *bank, char *command, size_t len, int *usercount) {
	char *delim = " \n\r\t\0";
	char *array[2]; //index 0 contains "reg" and 1 contains "<user-name>"
	int i = 0;
	char *input = strdup(command);
	char *token = strtok(input, delim);
	while(token != NULL && i < 2) {
	    array[i++] = token;
	    token = strtok(NULL, delim);
	}
	char * send = malloc(6);
	if(user_exists(bank, array[1], usercount) == 0){
		sprintf(send, "true\n");
	} else {
		sprintf(send, "false\n");
	}
	return send;
}

char* bank_process_withdraw(Bank *bank, char *command, size_t len, int *usercount, int locally){
  
 char *send = (char *)malloc(280);

 if(locally){//this function should not ever be called locally
   sprintf(send, "Invalid command\n");
   return send;
 }

  //max length of "create-user" + username + pin + balance + spaces
  if(len > 279){
    sprintf(send, "Usage: withdraw <user-name> <amt>\n");
    return send;
  }
  

  int i = 0;
  char *split;


  char *deposit = (char *)malloc(280);
  char *username = (char *)malloc(280);
  char *amount = (char *)malloc(280);

  
  //splits the input on spaces and assigns name, pin, balance 

  split = strtok (command, " \n\r\t\0");
  while(split != NULL){
    if(i == 0){
      deposit = strdup(split);
    }
    if(i == 1){
      username = strdup(split);
    }
    else if(i == 2){
      amount = strdup(split);
    }
   
    split = strtok (NULL, " \n\r\t\0");
    i++;
    
    if(i >= 3){
      break;
    }

  }
  
  if(i!= 3){
    sprintf(send, "Usage: withdraw <user-name> <amt>\n");
    free(deposit);
    free(username);
    return send;
  }
  
  char *cucheck = "withdraw";

  int x = strcmp(cucheck, deposit);
  int aIsDigits = only_digits(amount);
  int uIsLetters = only_letters(username);
  
  if(strlen(username) > 250 || strlen(username) == 0 || x != 0 || strlen(amount) > 10 || strlen(amount) == 0 || aIsDigits == 0 || uIsLetters == 0){
    sprintf(send, "Usage: withdraw <user-name> <amt>\n");
    free(deposit);
    free(username);
    return send;
  }


 
  username[(strlen(username))]='\0';
  char *oldusername = (char *)malloc(strlen(username));
  strcpy(oldusername, username);

  strcat(username, ".card\0");

  char *cardname = (char *)malloc(strlen(username));
  strcpy(cardname, username);
  

  if(user_exists(bank, oldusername, usercount) == 0){
    sprintf(send, "No such user\n");
    free(cardname);
    free(oldusername);
    free(deposit);
    free(username);
    return send;
  }

  
  i = 0;
  int amountI = atoi(amount);
  if (amountI <= 0){
    sprintf(send, "Usage: withdraw <user-name> <amt>\n");
    free(deposit);
    free(username);
    free(oldusername);
    free(cardname);
    return send;
  }


  users * current = bank->head;
  while(current->next != NULL){
    if(strcmp(oldusername, current->user) == 0){
      if((current->balance) - amountI > current->balance){
	sprintf(send, "Error: too large integer entered\n");
	free(deposit);
	free(username);
	free(amount);
	free(cardname);
	free(oldusername);
	return send;
      }
      else{
	if((current->balance) - amountI < 0){
	  sprintf(send, "Insufficient funds\n");
	  free(deposit);
	  free(username);
	  free(cardname);
	  free(oldusername);
	  return send;
	}

	current->balance = current->balance - amountI;
	sprintf(send, "$%d dispensed\n", amountI);
	free(cardname);
	free(oldusername);
	free(deposit);
	free(username);
	return send;
       
      }
    }
    current = current->next;
  }

  if(current->next == NULL){
    if(strcmp(oldusername, current->user) == 0){
      if((current->balance) - amountI > current->balance){
	sprintf(send, "Error: too large integer entered\n");
	free(deposit);
	free(username);
	free(amount);
	free(cardname);
	free(oldusername);
	return send;
      }
      else{
	if((current->balance) - amountI < 0){
	  sprintf(send, "Insufficient funds\n");
	  free(deposit);
	  free(username);
	  free(cardname);
	  free(oldusername);
	  return send;
	}
	current->balance = current->balance - amountI;
      }
    }
    else{
      //should never get here
      sprintf(send, "No such user\n");
      free(deposit);
      free(username);
      free(amount);
      free(cardname);
      free(oldusername);
      return send;
    }
  }

  sprintf(send, "$%d dispensed\n", amountI);
  free(cardname);
  free(oldusername);
  free(deposit);
  free(username);
  return send;
}

/*char* bank_process_salt(Bank *bank, char *command, size_t len, int *usercount, int locally){
  char *send = (char *)malloc(280);

 if(locally){//this function should not ever be called locally
   sprintf(send, "Invalid command\n");
   return send;
 }

  //max length of "create-user" + username + pin + balance + spaces
  if(len > 279){
    sprintf(send, "Usage: salt <user-name>\n");
    return send;
  }
  

  int i = 0;
  char *split;


  char *saltC = (char *)malloc(280);
  char *username = (char *)malloc(280);
  

  
  //splits the input on spaces and assigns name, pin, balance 

  split = strtok (command, " \n\r\t\0");
  while(split != NULL){
    if(i == 0){
      saltC = strdup(split);
    }
    if(i == 1){
      username = strdup(split);
    }
    
   
    split = strtok (NULL, " \n\r\t\0");
    i++;
    
    if(i >= 2){
      break;
    }

  }
  
  if(i!= 2){
    sprintf(send, "Usage: salt <user-name> \n");
    free(saltC);
    free(username);
    return send;
  }
  
  char *cucheck = "salt";
  if(strcmp(cucheck, salC)!=0 || strlen(username) == 0 || strlen(username) > 250 || only_letters(username) == 0){
    sprintf(send, "Usage: salt <user-name> \n");
    free(saltC);
    free(username);
    return send;
  }

  if(user_exists(bank, username, usercount) == 0){
    sprintf(send, "No such user\n");
    free(cardname);
    free(oldusername);
    free(deposit);
    free(username);
    return send;
  }

}
*/
char* bank_process_local_command(Bank *bank, char *command, size_t len, int *usercount, int locally)
{

  char *send;
  //max length of "create-user" + username + pin + balance + spaces
  if(len > 279){
    send = (char *)malloc(280);
    sprintf(send, "Invalid command\n");
    if(locally){
      printf("%s", send);
    }
    return send;
  }
  char *CU = "create-user";
  char *D = "deposit";
  char *B = "balance";
  char *W = "withdraw";
  char *S = "salt";
  char *R = "reg";
  char substring[12];
  memcpy(substring, &command[0], 11);
  substring[11] = '\0';
  
  if(strcmp(substring, CU) == 0){
    send = bank_process_create_user(bank, command, len, usercount);
    if(locally){
      printf("%s", send);
    }
    return send;
  }

  substring[8] = '\0';
  if(strcmp(substring, W) == 0){
    send = bank_process_withdraw(bank, command, len, usercount, locally);
     if(locally){
      printf("%s", send);
    }
    return send;
  }

  substring[7] = '\0';
  if(strcmp(substring, D) == 0){
    send = bank_process_deposit(bank, command, len, usercount);
    if(locally){
      printf("%s", send);
    }
    return send;
  } 
  if(strcmp(substring, B) == 0){
    send = bank_process_balance(bank, command, len, usercount);
    if(locally){
      printf("%s", send);
    }
    return send;
  }

  /*substring[4] = '\0';
  if(strcmp(substring, S) == 0){
    send = bank_process_salt(bank, command, len, usercount);
    if(locally){
      printf("%s", send);
    }
    return send;
  }
  
  */
  substring[3] = '\0';
  if(strcmp(substring, R) == 0) {
  	send = bank_process_reg(bank, command, len, usercount);
  	return send;
  }
  
  send = (char *)malloc(280);
  sprintf(send, "Invalid command\n");
  if(locally){
    printf("%s", send);
  }
  return send;

}



void bank_process_remote_command(Bank *bank, char *command, size_t len, int *usercount)
{
    // TODO: Implement the bank side of the ATM-bank protocol

	/*
	 * The following is a toy example that simply receives a
	 * string from the ATM, prepends "Bank got: " and echoes 
	 * it back to the ATM before printing it to stdout.
	 */

	/*
    char sendline[1000];
    command[len]=0;
    sprintf(sendline, "Bank got: %s", command);
    bank_send(bank, sendline, strlen(sendline));
    printf("Received the following:\n");
    fputs(command, stdout);
	*/
  char plain[1000];
  char cipher[128] = {0};
  int plain_len = decrypt(command, len, bank->key, plain);
  char *send;
  send = bank_process_local_command(bank, plain, len, usercount, 0);

  int cipher_len = encrypt(send, strlen(send)+1, bank->key, cipher);
  bank_send(bank, cipher, cipher_len);
  free(send);

}
