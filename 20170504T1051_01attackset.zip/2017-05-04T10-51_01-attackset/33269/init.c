#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <time.h>

int randDigit();
char* rand16();

int main(int argc, char* argv[]) {
	srand(time(NULL));
	if(argc != 2) {
		printf("Usage: init <filename>\n");
		return 62;
	} 
	char* bName = malloc(strlen(argv[1]) + 6);
	char* aName = malloc(strlen(argv[1]) + 5);
	sprintf(bName, "%s.bank\0", argv[1]);
	sprintf(aName, "%s.atm\0", argv[1]);
	if(!access(bName, F_OK) || !access(aName, F_OK)) {
		printf("Error: one of the files already exists\n");
		return 63;
	} 
	FILE *aFile = fopen(aName, "w");
	FILE *bFile = fopen(bName, "w");
	if(access(bName, F_OK) || access(aName, F_OK)) {
		printf("Error creating initialization files\n");
		return 64;
	} 
	char* randStr = rand16();
	
	fprintf(aFile, "%s\n", randStr);
	fprintf(bFile, "%s\n", randStr);
	
	fclose(aFile);
	fclose(bFile);
	free(randStr);
	return 0;
}

int randDigit() {
	return rand() % 10;
}

char* rand16() {
  char* str = calloc(17,1);
  int i;
  for(i = 0; i < 16; i++) {
    char tmp[2] = {0};
    sprintf(tmp, "%d\0", randDigit());
    strcat(str, tmp);
  }
  str[16] = '\0';
  return str;
}
