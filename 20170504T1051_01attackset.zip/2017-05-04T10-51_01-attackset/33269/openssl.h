#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>

#ifndef __OPENSSL_H_
#define __OPENSSL_H_

int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key, unsigned char *ciphertext);
void printhex(unsigned char * hex, int len); 
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key, unsigned char *plaintext);
int sign(const unsigned char* key, unsigned char* cipher, int cipher_len, unsigned char* tag);

#endif
