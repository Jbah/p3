#include "atm.h"
#include "ports.h"
#include "openssl.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdarg.h>

ATM* atm_create(char* fname)
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    atm->logged_in = false;
    atm->name = NULL;
	FILE *fp = fopen(fname, "r");
	atm->key = malloc(17);	
	fgets(atm->key, 17, fp);
	fclose(fp);
	
	atm->head = NULL;
    return atm;
}

void free_users(users * head){
  	users * node = head;
  	users * temp = NULL;
  	while(node != NULL) {
   		temp = node;
    	node = temp->next;
    	free(temp);
  	}
}


void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm->name);
        free(atm->key);
        free(atm->head);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}


char* send_to_bank(ATM *atm, char* query) {
  	char recvline[10000];
  	int n;
  	char cipher[128] = {0};
  	char *plain = (char *)malloc(sizeof(char) * 129);

  	int cipher_len = encrypt(query, strlen(query)+1, atm->key, cipher);
  	
  	atm_send(atm, cipher, cipher_len);  	
  	n = atm_recv(atm,recvline,10000);
  	recvline[n]=0;

  	int plain_len = decrypt(recvline, n, atm->key, plain);
  	return plain;
}

void atm_process_command(ATM *atm, char *command)
{
    // TODO: Implement the ATM's side of the ATM-bank protocol

	/*
	 * The following is a toy example that simply sends the
	 * user's command to the bank, receives a message from the
	 * bank, and then prints it to stdout.
	 */

	/*
    char recvline[10000];
    int n;

    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    fputs(recvline,stdout);
	*/
  
  	char *input = (char *) malloc(strlen(command) + 1);
  	strcpy(input, command);  

  	char *delim = " \n\r\t\0"; //Delimeter is a space to separate commands
  	char *funct = strtok(input, delim); //Retrieves the first line, which is the command
	unsigned char m[] = "This is a secret";
  	unsigned char * key = "1234567890123456";
  	unsigned char cipher[128] = {0};
	int cipher_len = encrypt(m, strlen(m)+1, key, cipher);
	
  	if(strcmp(funct, "begin-session") == 0) {
    	begin_session(atm, command);
  	} else if (strcmp(funct, "withdraw") == 0) {
    	withdraw(atm, command);
  	} else if (strcmp(funct, "balance") == 0) {
    	balance(atm, command);
  	} else if (strcmp(funct, "end-session") == 0) {
    	end_session(atm, command);
  	} else {
    	printf("Invalid command\n");
  	}
}

bool valid_username(char *name) 
{
  	int i = 0;
  	while(i < strlen(name)) {
    	if(!(name[i] >= 'a' && name[i] <= 'z') && !(name[i] >= 'A' && name[i] <= 'Z')) {
    		return 0;
    	}
    	i++;
  	}
  	return 1;
}

bool valid_amt(char *amt)
{
  	int i = 0;
  	while(i < strlen(amt)) {
    	if(!(amt[i] >= '0' && amt[i] <= '9')) {
    		return 0;
    	} 
    	i++;
  	}
  	return 1;
}

char* concat3(const char* str1, const char* str2, const char* str3) {
  	int len = strlen(str1) + strlen(str2) + strlen(str3);
  	char* res = malloc(len + 3);
  	sprintf(res, "%s %s %s", str1, str2, str3);
  	return res;
}

char* concat2(char* str1, char* str2) {
	int len = strlen(str1) + strlen(str2);
	char* res = malloc(2 + len);
  	sprintf(res, "%s %s", str1, str2);
	return res;
}

void add_user(ATM *atm, char *user, int count) {
	if(atm->head == NULL) { 
    	users * new_head = malloc(sizeof(users));
    	new_head->name = strdup(user);
    	new_head->count = count;
  
    	new_head->next = NULL;
    	atm->head = new_head;
  	}
  	else {
    	users * current = atm->head;
    	while(current->next != NULL){
      		current = current->next;
    	}
    	current->next = malloc(sizeof(users));
    	current->next->name = strdup(user);
    	current->next->count = count;
    
    	current->next->next = NULL;
  	}
}

void increment_count(ATM *atm, char *user, int count) {
	users * current = atm->head;
	while(current != NULL) {
		if(strcmp(current->name, user) == 0) {
			current->count += count;
			return;
		}
		current = current->next;
	}
	add_user(atm, user, count);
}

int getCount(ATM *atm, char *name) {
	users * current = atm->head;
	while(current != NULL) {
		if(strcmp(current->name, name) == 0) {
			return current->count;
		}
		current = current->next;
	}
	return -1;
}

void replace_char(char* str, char find, char replace) {
	int len = strlen(str);
	int i = 0;
	for(i = 0; i < len; i++) {
		if(str[i] == find) {
			str[i] = replace;
		}
	}
}

void begin_session(ATM *atm, char *command)
{
	char *delim = " \n\r\t\0";
	char *array[2]; //index 0 contains "begin-session" and 1 contains "<user-name>"
  	int i = 0;
  	char *input = (char *) malloc(strlen(command) + 1);
  	strcpy(input, command);

  	char *token = strtok(input, delim);
  	while(token != NULL && i < 2) {
    	array[i++] = token;
    	token = strtok(NULL, delim);
  	}

  	if(atm->logged_in) {
    	printf("A user is already logged in\n");
    	free(input);
    	return;
  	} else if (i != 2 || !valid_username(array[1])  || token != NULL) {
    	printf("Usage: begin-session <user-name>\n");
    	free(input);
    	return;
  	}  

	char *query = concat2("reg", array[1]);
  	char *recvline = send_to_bank(atm, query);
	if(strcmp(recvline, "true\n") == 0) {
		printf("No such user\n");
		free(input);
		free(query);
		free(recvline);
		return;
	}
  	free(query);
  	free(recvline);
  	
  	char *fname = malloc(6 + strlen(array[1]));
  	strcpy(fname, array[1]);
  	strcat(fname, ".card");  

  	FILE *fp = fopen(fname, "r");
  	if(fp == NULL)  {//card does not exist 
	  printf("Unable to access %s's card\n", array[1]);
    	return;
  	} 
  	
  	if(getCount(atm, array[1]) == 10) {
	  //printf("User %s's account is locked\n", array[1]);
	  	printf("Not authorized\n");
  		return;
  	}
	int xl = 0;
  	
	char *tag = NULL;
	char *salt = NULL;
	char *salt1 = NULL;
  	char *buff = malloc(1017);
  	

  	char user_input[1000];
  	printf("PIN? ");
  	fflush(stdout);
  	if(fgets(user_input, 10000,stdin) != NULL) {
	    fgets(buff, 1000, fp); // Reads contents of the card file into buff
	  	user_input[strlen(user_input)-1] = '\0'; //Removes newline at end
    	
	  	tag = malloc(1017);
	  	salt =  malloc(1017);
	  	salt1 = malloc(1017);
	  	strncpy(salt, buff, 16);
	  	salt[16]='\0';
	  	strcat(salt, user_input);
	  	xl = sign(atm->key, salt,(strlen(salt)+1), tag);
	  	replace_char(tag, '\n', 'a');
	  	
		tag[xl] = '\0';
	 
	  	strncpy(salt1, buff, 16);
		salt1[16]='\0';
	  	strcat(salt1, tag);
	  	if(strcmp(buff, salt1) != 0) {
	  		increment_count(atm, array[1], 1);
	  		printf("Not authorized\n");
	  		int attempts = 10 - getCount(atm, array[1]);
	  		//printf("%d attempts left\n", attempts);
	  	} else {
	  		increment_count(atm, array[1], 0);
	    	printf("Authorized\n");
	    	atm->logged_in = true;
	    	atm->name = malloc(1 + strlen(array[1]));
	    	strcpy(atm->name, array[1]);
		}
  	}
	free(buff);
	free(tag);
	free(salt);
	free(salt1);
  	free(fname);
  	fclose(fp);
 	return;
}

void withdraw(ATM *atm, char *command)
{
	char *delim = " \n\r\t\0";
	char *array[2]; //index 0 contains "withdraw" and 1 contains "<amt>"
	int i = 0;
	char *input = strdup(command);
	char *token = strtok(input, delim);
	while(token != NULL && i < 2) {
	    array[i++] = token;
	    token = strtok(NULL, delim);
	}

	if(!atm->logged_in) {
    	printf("No user logged in\n");
    	return;
  	} else if (i != 2 || !valid_amt(array[1]) || token != NULL) {
    	printf("Usage: withdraw <amt>\n");
    	return;
  	} 
  	char *query = concat3("withdraw", atm->name, array[1]);
  	char *recvline = send_to_bank(atm, query);
  	printf("%s", recvline);
  	free(query);
  	free(recvline);
  	return;
}

void balance(ATM *atm, char *command)
{
  	char *delim = " \n\r\t\0";
  	char *array[1]; //index 0 contains "balance"
  	int i = 0;
  	char *input = strdup(command);

  	char *token = strtok(input, delim);
  	while(token != NULL && i < 1) {
    	array[i++] = token;
    	token = strtok(NULL, delim);
  	}
	free(input);
  	if(!atm->logged_in) {
    	printf("No user logged in\n");
    	return;
  	} else if (i != 1 || token != NULL) {
    	printf("Usage: balance\n");
    	return;
  	} 

  	//TODO actually use the input received
  	char *query = concat2("balance", atm->name);
  	char *recvline = send_to_bank(atm, query);
  	printf("%s", recvline);
  	free(query);
  	free(recvline);
  	return;
}

void end_session(ATM *atm, char *command)
{
  	char *delim = " \n\r\t\0";
  	char *array[1]; //index 0 contains "end-session"
  	int i = 0;
  	char *input = (char *) malloc(strlen(command) + 1);
  	strcpy(input, command);

	char *token = strtok(input, delim);
  	while(token != NULL && i < 1) {
    	array[i++] = token;
    	token = strtok(NULL, delim);
  	}

  	if(!atm->logged_in) {
    	printf("No user logged in\n");
    	return;
  	} else if (i != 1 || token != NULL) {
    	printf("Usage: end-session\n");
    	return;
  	} 
	printf("User logged out\n");
  	free(atm->name);
  	free(input);
  	atm->logged_in = false;
  	atm->name = NULL;
  	return;
}

