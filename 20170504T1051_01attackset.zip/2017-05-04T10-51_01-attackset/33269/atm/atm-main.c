/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

static const char prompt[] = "ATM: ";

int main(int argv, char* argc[])
{
    char user_input[1000];
	
    ATM *atm = atm_create(argc[1]);

    printf("%s", prompt);
    fflush(stdout);

    while (fgets(user_input, 10000,stdin) != NULL)
    {
        atm_process_command(atm, user_input);
        if(!atm->logged_in) {        
        	printf("%s", prompt);
        } else {
        	printf("ATM (%s): ", atm->name);
        }
        fflush(stdout);
    }
	return EXIT_SUCCESS;
}
