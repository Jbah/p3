import os
import random
import sys

init_error = "Error creating initialization files"
file_exists_error = "Error: one of the files already exists"
usage_error = "Usage: init <filename>"
success = "Successfully initialized bank state"

if len(sys.argv) != 2:
    print usage_error
    sys.exit(62)

args = sys.argv[1].split("/")
path = args[0]
init_file = args[1]
bank_path = path + "/" + init_file + ".bank"
atm_path = path + "/" + init_file + ".atm"

if not os.path.exists(path):
    print init_error
    sys.exit(64)

if os.path.isfile(bank_path) or os.path.isfile(atm_path):
    print file_exists_error
    sys.exit(63)

bank_file = open(bank_path, "w")
atm_file = open(atm_path, "w")

if not (bank_file or atm_file):
    print init_error
    sys.exit(64)

key = os.urandom(32).encode('base64')
iv = os.urandom(32).encode('base64')
start = str(random.randint(0, 4049068363));

atm_file.write(key)
atm_file.write(iv)
atm_file.close()

bank_file.write(key)
bank_file.write(iv)
bank_file.write(start);
bank_file.close()

print "Successfully initialized bank state"
sys.exit(0)
