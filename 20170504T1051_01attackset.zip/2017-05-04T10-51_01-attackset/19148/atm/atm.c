#if !defined(MIN_USER_NAME_LENGTH)
#define MIN_USER_NAME_LENGTH 1
#endif

#if !defined(MAX_USER_NAME_LENGTH)
#define MAX_USER_NAME_LENGTH 250
#endif

#if !defined(PIN_LENGTH)
#define PIN_LENGTH 4
#endif

#if !defined(MIN_ACCOUNT_VALUE)
#define MIN_ACCOUNT_VALUE 0
#endif

#if !defined(MAX_ACCOUNT_VALUE)
#define MAX_ACCOUNT_VALUE 2147483648
#endif

#if !defined(BUFFER_SIZE)
#define BUFFER_SIZE 1000
#endif

#include "atm.h"
#include "ports.h"
#include "security.h"
#include "validators.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

ATM* atm_create(char *init_file_path) {
  ATM *atm;
  char *iv;
  char *key;
  char line[BUFFER_SIZE];
  FILE *init = fopen(init_file_path, "r");

  memset(init_file_path, 0, strlen(init_file_path));

  if (init == NULL) {
    return NULL;
  }

  atm = (ATM *)malloc(sizeof(ATM));
  if(atm == NULL) {
    perror("Could not allocate ATM");
    exit(1);
  }

  // Set up the network state
  atm->sockfd = socket(AF_INET, SOCK_DGRAM, 0);

  bzero(&atm->rtr_addr, sizeof(atm->rtr_addr));
  atm->rtr_addr.sin_family = AF_INET;
  atm->rtr_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
  atm->rtr_addr.sin_port = htons(ROUTER_PORT);

  bzero(&atm->atm_addr, sizeof(atm->atm_addr));
  atm->atm_addr.sin_family = AF_INET;
  atm->atm_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
  atm->atm_addr.sin_port = htons(ATM_PORT);
  bind(atm->sockfd, (struct sockaddr *)&atm->atm_addr, sizeof(atm->atm_addr));

  // Set up the protocol state
  atm->curr_user_name = NULL;

  fgets(line, sizeof(line), init);
  key = strtok(line, "\n");
  atm->key = (unsigned char *)malloc(strlen(key) + 1);
  strcpy(atm->key, key);

  fgets(line, sizeof(line), init);
  iv = strtok(line, "\n");
  atm->iv = (unsigned char *)malloc(strlen(iv) + 1);
  strcpy(atm->iv, iv);

  fclose(init);

  return atm;
}

void atm_free(ATM *atm) {
  if(atm != NULL) {
    close(atm->sockfd);
    free(atm->iv);
    free(atm->key);
    free(atm);
  }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len) {
  // Returns the number of bytes sent; negative on error
  return sendto(atm->sockfd, data, data_len, 0,
    (struct sockaddr*)&atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len) {
  // Returns the number of bytes received; negative on error
  return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

void atm_process_command(ATM *atm, char *command) {
  char buffer[BUFFER_SIZE];
  char c_text[BUFFER_SIZE];
  char c_len_char[BUFFER_SIZE];
  char card[BUFFER_SIZE];
  char card_file_name[BUFFER_SIZE];
  char confirm_tag[BUFFER_SIZE];
  char hashed_card[BUFFER_SIZE];
  char hashed_pin[BUFFER_SIZE];
  char line_buffer[BUFFER_SIZE];
  char message[BUFFER_SIZE];
  char p_text[BUFFER_SIZE];
  char pin_buffer[BUFFER_SIZE];
  char recv_line[BUFFER_SIZE];
  char send_line[BUFFER_SIZE];
  char t_len_char[BUFFER_SIZE];
  char tag[BUFFER_SIZE];
  char *bank_response = NULL;
  char *pin = NULL;
  char *user_command = NULL;
  char *user_name = NULL;
  char *user_amount = NULL;
  FILE *fp = NULL;
  int len = 0;
  int c_len = 0;
  int m_len = 0;
  int p_len = 0;
  int t_len = 0;
  int ct_len = 0;

  memset(buffer , 0, BUFFER_SIZE);
  memset(c_text , 0, BUFFER_SIZE);
  memset(c_len_char , 0, BUFFER_SIZE);
  memset(card , 0, BUFFER_SIZE);
  memset(card_file_name , 0, BUFFER_SIZE);
  memset(confirm_tag , 0, BUFFER_SIZE);
  memset(hashed_card , 0, BUFFER_SIZE);
  memset(hashed_pin , 0, BUFFER_SIZE);
  memset(line_buffer , 0, BUFFER_SIZE);
  memset(message , 0, BUFFER_SIZE);
  memset(p_text , 0, BUFFER_SIZE);
  memset(pin_buffer , 0, BUFFER_SIZE);
  memset(recv_line , 0, BUFFER_SIZE);
  memset(send_line , 0, BUFFER_SIZE);
  memset(t_len_char , 0, BUFFER_SIZE);
  memset(tag , 0, BUFFER_SIZE);

  if (command == NULL) {
    printf("Invalid command");
  } else {
    len = strlen(command);

    if (len > BUFFER_SIZE - 1) {
      memcpy(line_buffer, command, BUFFER_SIZE - 1);
    } else {
      memcpy(line_buffer, command, len);
    }

    memset(command, 0, len + 1);

    user_command = strtok(line_buffer, " \n");

    if (user_command == NULL
        || (strcmp(user_command, "begin-session") != 0
            && strcmp(user_command, "withdraw") != 0
            && strcmp(user_command, "balance") != 0
            && strcmp(user_command, "end-session") != 0)) {
      printf("Invalid command");
    } else {
      if (strcmp(user_command, "begin-session") == 0) {
        if (atm->curr_user_name != NULL) {
          printf("A user is already logged in");
        } else {
          user_name = strtok(NULL, " \n");

          if (!valid_user_name(user_name)
              || strtok(NULL, " \n") != NULL) {
            printf("Usage: begin-session <user-name>");
          } else {
            strcpy(send_line, "begin-session ");
            strcat(send_line, user_name);
            c_len = encrypt(send_line, strlen(send_line), atm->key, atm->iv, c_text);
            t_len = sign(atm->key, c_text, c_len, tag);
            m_len = construct_message(c_text, c_len, tag, t_len, message);
            atm_send(atm, message, m_len);

            len = atm_recv(atm, recv_line, BUFFER_SIZE);
            recv_line[len] = 0;

            memset(c_text, 0, BUFFER_SIZE);
            memset(tag, 0, BUFFER_SIZE);
            deconstruct_message(recv_line, c_text, c_len_char, tag, t_len_char);
            c_len = strtoul(c_len_char, NULL, 10);
            t_len = strtoul(t_len_char, NULL, 10);
            ct_len = sign(atm->key, c_text, c_len, confirm_tag);

            if (strcmp(tag, confirm_tag) != 0) {
              printf("Tampering detected");
            } else {
              p_len = decrypt(c_text, c_len, atm->key, atm->iv, p_text);
              p_text[p_len] = 0;
              bank_response = p_text;

              if (strcmp(bank_response, "fail") == 0) {
                printf("No such user");
              } else if (strcmp(bank_response, "success") == 0) {
                strcpy(card_file_name, user_name);
                strcat(card_file_name, ".card");

                fp = fopen(card_file_name, "r");
                if (fp == NULL) {
                  printf("Unable to access %s’s card", user_name);
                } else {
                  fgets(card, BUFFER_SIZE, fp);
                  hash_fun(card, hashed_card);

                  printf("PIN? ");
                  fgets(pin_buffer, BUFFER_SIZE, stdin);
                  pin = strtok(pin_buffer, " \n");
                  hash_fun(pin, hashed_pin);

                  if (!valid_pin(pin)) {
                    printf("Not authorized");
                  } else {
                    memset(send_line, 0, BUFFER_SIZE);
                    strcpy(send_line, "authorize ");
                    strcat(send_line, user_name);
                    strcat(send_line, " ");
                    strcat(send_line, hashed_card);
                    strcat(send_line, " ");
                    strcat(send_line, hashed_pin);

                    memset(c_text, 0, BUFFER_SIZE);
                    memset(tag, 0, BUFFER_SIZE);
                    memset(message, 0, BUFFER_SIZE);
                    c_len = encrypt(send_line, strlen(send_line), atm->key, atm->iv, c_text);
                    t_len = sign(atm->key, c_text, c_len, tag);
                    m_len = construct_message(c_text, c_len, tag, t_len, message);
                    atm_send(atm, message, m_len);

                    memset(recv_line, 0, BUFFER_SIZE);
                    len = atm_recv(atm, recv_line, BUFFER_SIZE);
                    recv_line[len] = 0;

                    memset(c_len_char, 0, BUFFER_SIZE);
                    memset(t_len_char, 0, BUFFER_SIZE);
                    memset(c_text, 0, BUFFER_SIZE);
                    memset(tag, 0, BUFFER_SIZE);
                    memset(confirm_tag, 0, BUFFER_SIZE);
                    deconstruct_message(recv_line, c_text, c_len_char, tag, t_len_char);
                    c_len = strtoul(c_len_char, NULL, 10);
                    t_len = strtoul(t_len_char, NULL, 10);
                    ct_len = sign(atm->key, c_text, c_len, confirm_tag);

                    if (strcmp(tag, confirm_tag) != 0) {
                      memset(p_text, 0, BUFFER_SIZE);
                      p_len = decrypt(c_text, c_len, atm->key, atm->iv, p_text);
                      p_text[p_len] = 0;
                      bank_response = p_text;
                      printf("Tampering detected");
                    } else {
                      memset(p_text, 0, BUFFER_SIZE);
                      p_len = decrypt(c_text, c_len, atm->key, atm->iv, p_text);
                      p_text[p_len] = 0;
                      bank_response = p_text;

                      if (strcmp(bank_response, "fail") == 0) {
                        printf("Not authorized");
                      } else if (strcmp(bank_response, "success") == 0) {
                        atm->curr_user_name = (char *)malloc(strlen(user_name) + 1);
                        strcpy(atm->curr_user_name, user_name);
                        printf("Authorized");
                      }
                    }
                  }
                }
                fclose(fp);
              }
            }
          }
        }
      } else if (strcmp(user_command, "withdraw") == 0) {
        if (atm->curr_user_name == NULL) {
          printf("No user logged in");
        } else {
          user_amount = strtok(NULL, " \n");

          if (!valid_value(user_amount)
              || strtok(NULL, " \n") != NULL) {
            printf("Usage: withdraw <amt>");
          } else {
            strcpy(send_line, "withdraw ");
            strcat(send_line, atm->curr_user_name);
            strcat(send_line, " ");
            strcat(send_line, user_amount);

            c_len = encrypt(send_line, strlen(send_line), atm->key, atm->iv, c_text);
            t_len = sign(atm->key, c_text, c_len, tag);
            m_len = construct_message(c_text, c_len, tag, t_len, message);
            atm_send(atm, message, m_len);

            len = atm_recv(atm, recv_line, BUFFER_SIZE);
            recv_line[len] = 0;

            memset(c_text, 0, BUFFER_SIZE);
            memset(tag, 0, BUFFER_SIZE);
            deconstruct_message(recv_line, c_text, c_len_char, tag, t_len_char);
            c_len = strtoul(c_len_char, NULL, 10);
            t_len = strtoul(t_len_char, NULL, 10);
            ct_len = sign(atm->key, c_text, c_len, confirm_tag);

            if (strcmp(tag, confirm_tag) != 0) {
              printf("Tampering detected");
            } else {
              p_len = decrypt(c_text, c_len, atm->key, atm->iv, p_text);
              p_text[p_len] = 0;
              bank_response = p_text;

              if (strcmp(bank_response, "fail") == 0) {
                printf("Insufficient funds");
              } else if (strcmp(bank_response, "success") == 0) {
                printf("$%s dispensed", user_amount);
              }
            }
          }
        }
      } else if (strcmp(user_command, "balance") == 0) {
        if (atm->curr_user_name == NULL) {
          printf("No user logged in");
        } else if(strtok(NULL, " \n") != NULL) {
          printf("Usage: balance");
        } else {
          strcpy(send_line, "balance ");
          strcat(send_line, atm->curr_user_name);

          c_len = encrypt(send_line, strlen(send_line), atm->key, atm->iv, c_text);
          t_len = sign(atm->key, c_text, c_len, tag);
          m_len = construct_message(c_text, c_len, tag, t_len, message);
          atm_send(atm, message, m_len);

          len = atm_recv(atm, recv_line, BUFFER_SIZE);
          recv_line[len] = 0;

          memset(c_text, 0, BUFFER_SIZE);
          memset(tag, 0, BUFFER_SIZE);
          deconstruct_message(recv_line, c_text, c_len_char, tag, t_len_char);
          c_len = strtoul(c_len_char, NULL, 10);
          t_len = strtoul(t_len_char, NULL, 10);
          ct_len = sign(atm->key, c_text, c_len, confirm_tag);

          if (strcmp(tag, confirm_tag) != 0) {
            printf("Tampering detected");
          } else {
            p_len = decrypt(c_text, c_len, atm->key, atm->iv, p_text);
            p_text[p_len] = 0;

            bank_response = strtok(p_text, " \n");
            user_amount = strtok(NULL, " \n");

            if (strcmp(bank_response, "success") == 0) {
              printf("$%s", user_amount);
            }
          }
        }
      } else {
        if (atm->curr_user_name == NULL) {
          printf("No user logged in");
        } else if (strtok(NULL, " \n") != NULL) {
          printf("Usage: end-session");
        } else {
          free(atm->curr_user_name);
          atm->curr_user_name = NULL;
          printf("User logged out");
        }
      }
    }
  }
}
