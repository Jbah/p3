#include "atm.h"
#include <stdio.h>
#include <stdlib.h>

#if !defined(BUFFER_SIZE)
#define BUFFER_SIZE 1000
#endif

static const char prompt[] = "ATM: ";

int main(int argc, char**argv) {
  char user_input[BUFFER_SIZE];

  if (argc == 1) {
    printf("Error opening ATM initialization file\n");
    return(64);
  }

  ATM *atm = atm_create(argv[1]);
  if (atm == NULL) {
    printf("Error opening ATM initialization file\n");
    return(64);
  }

  printf("%s", prompt);
  fflush(stdout);

  while (fgets(user_input, BUFFER_SIZE, stdin) != NULL) {
    atm_process_command(atm, user_input);
    if (atm->curr_user_name == NULL) {
      printf("%s", prompt);
    } else {
      printf("ATM (%s): ", atm->curr_user_name);
    }
    fflush(stdout);
  }
  return EXIT_SUCCESS;
}
