#ifndef __VALIDATORS_H__
#define __VALIDATORS_H__

#include <stdbool.h>
#include <string.h>

bool valid_user_name(const char *user_name);
bool valid_pin(const char *pin);
bool valid_value(const char *char_value);

#endif
