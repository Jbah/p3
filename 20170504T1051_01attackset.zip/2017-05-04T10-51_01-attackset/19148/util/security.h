#ifndef __SECURITY_H__
#define __SECURITY_H__

int construct_message(unsigned char *c_text, int c_len,
  unsigned char *tag, int t_len, char *message);
void deconstruct_message(unsigned char *message, unsigned char *c_text,
  unsigned char *c_len, unsigned char *tag, unsigned char *t_len);
int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key,
  unsigned char *iv, unsigned char *ciphertext);
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
  unsigned char *iv, unsigned char *plaintext);
int sign(const unsigned char* key, unsigned char* cipher, int cipher_len,
  unsigned char* tag);

#endif
