#if !defined(MIN_USER_NAME_LENGTH)
#define MIN_USER_NAME_LENGTH 1
#endif

#if !defined(MAX_USER_NAME_LENGTH)
#define MAX_USER_NAME_LENGTH 250
#endif

#if !defined(PIN_LENGTH)
#define PIN_LENGTH 4
#endif

#if !defined(MIN_ACCOUNT_VALUE)
#define MIN_ACCOUNT_VALUE 0
#endif

#if !defined(BUFFER_SIZE)
#define BUFFER_SIZE 1000
#endif

#include <ctype.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

bool valid_user_name(const char *user_name) {
  int i;
  int length;

  if (user_name == NULL) {
    return(false);
  }

  length = strlen(user_name);

  if (length < MIN_USER_NAME_LENGTH || length > MAX_USER_NAME_LENGTH) {
    return(false);
  }

  for (i = 0; i < length; i++) {
    if (!isalpha((int)user_name[i])) {
      return(false);
    }
  }

  return(true);
}

bool valid_pin(const char *pin) {
  int i;
  int length;

  if (pin == NULL) {
    return(false);
  }

  length = strlen(pin);

  if (length != PIN_LENGTH) {
    return(false);
  }

  for (i = 0; i < length; i++) {
    if (!isdigit((int)pin[i])) {
      return(false);
    }
  }

  return(true);
}

bool valid_value(const char *char_value) {
  long value;
  char *leftover;

  if (char_value == NULL || char_value[0] == '-') {
    return(false);
  }

  value = strtoul(char_value, &leftover, 10);

  if (strlen(leftover) > 0) {
    return(false);
  }

  return(true);
}
