#include "user.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

User* user_create(char *card, char *pin, long balance) {
  User *user = (User *)malloc(sizeof(User));

  if(user == NULL) {
    perror("Could not allocate User");
    exit(1);
  }

  user->card = (char *)malloc(sizeof(card));
  if(user->card == NULL) {
    perror("Could not allocate User");
    free(user);
    exit(1);
  }
  strcpy(user->card, card);

  user->pin = (char *)malloc(sizeof(pin));
  if(user->pin == NULL) {
    perror("Could not allocate User");
    free(user->card);
    free(user);
    exit(1);
  }
  strcpy(user->pin, pin);

  user->balance = balance;

  return user;
}

void user_free(User *user) {
  free(user->card);
  free(user->pin);
  free(user);
}

void update_balance(User *user, long balance) {
  user->balance = balance;
}
