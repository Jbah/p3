#include "security.h"
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <string.h>

#if !defined(BUFFER_SIZE)
#define BUFFER_SIZE 1000
#endif

int construct_message(unsigned char *c_text, int c_len, unsigned char *tag,
  int t_len, char *message) {
  char buffer[BUFFER_SIZE];

  memset(buffer, 0, BUFFER_SIZE);
  sprintf(buffer, "%d-%d-", c_len, t_len);
  strcat(buffer, c_text);
  strcat(buffer, tag);
  strcpy(message, buffer);

  return strlen(message);
}

void deconstruct_message(unsigned char *message, unsigned char *c_text,
  unsigned char *c_len, unsigned char *tag, unsigned char *t_len) {
  unsigned char buffer[BUFFER_SIZE];
  unsigned char *str = NULL;
  int shift = 0;

  memset(buffer, 0, BUFFER_SIZE);
  strcpy(buffer, message);

  str = strtok(buffer, "-");
  strcpy(c_len, str);
  str = strtok(NULL, "-");
  strcpy(t_len, str);

  shift = strlen(c_len) + strlen(t_len) + 2;
  str = buffer;
  memcpy(c_text, str + shift, strtoul(c_len, NULL, 10));
  shift += strtoul(c_len, NULL, 10);
  memcpy(tag, str + shift, strtoul(t_len, NULL, 10));
}

int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key,
  unsigned char *iv, unsigned char *ciphertext) {
  EVP_CIPHER_CTX *ctx;
  int len = 0;
  int ciphertext_len = 0;

  if(!(ctx = EVP_CIPHER_CTX_new())) {
    return -1;
  }
  if(EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv) != 1) {
    return -1;
  }
  if(EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext_in, plaintext_len) != 1) {
    return -1;
  }
  ciphertext_len = len;

  if(EVP_EncryptFinal_ex(ctx, ciphertext + len, &len) != 1) {
    return -1;
  }
  ciphertext_len += len;

  /* Clean up */
  EVP_CIPHER_CTX_free(ctx);

  return ciphertext_len;
}

/*
* Decrypt "cipher" with "key" into "plain"
*/
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
  unsigned char *iv, unsigned char *plaintext) {
  EVP_CIPHER_CTX *ctx;
  int len;
  int plaintext_len;

  if(!(ctx = EVP_CIPHER_CTX_new())) {
    return -1;
  }
  if(EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv) != 1) {
    return -1;
  }
  if(EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len) != 1) {
    return -1;
  }
  plaintext_len = len;
  if(EVP_DecryptFinal_ex(ctx, plaintext + len, &len) != 1) {
    return -1;
  }
  plaintext_len += len;

  /* Clean up */
  EVP_CIPHER_CTX_free(ctx);

  return plaintext_len;
}

/*
* Sign "cipher" with "key"
*/
int sign(const unsigned char* key, unsigned char* cipher, int cipher_len,
  unsigned char* tag) {
  int len = 0;
  HMAC_CTX ctx;

  HMAC_CTX_init(&ctx);
  HMAC_Init_ex(&ctx, key, strlen(key), EVP_sha1(), NULL);
  HMAC_Update(&ctx, cipher, cipher_len);
  HMAC_Final(&ctx, tag, &len);

  HMAC_CTX_cleanup(&ctx);
  return len;
}

// Found on stackoverflow:
// http://stackoverflow.com/questions/7666509/hash-function-for-string
void hash_fun(unsigned char *str, unsigned char* output) {
  unsigned long hash = 5381;
  int c;

  while (c = *str++) {
    hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
  }

  sprintf(output, "%lu", hash);
}
