#ifndef __USER_H__
#define __USER_H__

#include <string.h>

typedef struct _User {
  char *card;
  char *pin;
  long balance;
} User;

User* user_create(char *card, char *pin, long balance);
void user_free(User *user);
void update_balance(User *user, long amt);

#endif
