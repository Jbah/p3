#if !defined(MIN_USER_NAME_LENGTH)
#define MIN_USER_NAME_LENGTH 1
#endif

#if !defined(MAX_USER_NAME_LENGTH)
#define MAX_USER_NAME_LENGTH 250
#endif

#if !defined(PIN_LENGTH)
#define PIN_LENGTH 4
#endif

#if !defined(MIN_ACCOUNT_VALUE)
#define MIN_ACCOUNT_VALUE 0
#endif

#if !defined(MAX_ACCOUNT_VALUE)
#define MAX_ACCOUNT_VALUE 2147483648
#endif

#if !defined(BUFFER_SIZE)
#define BUFFER_SIZE 1000
#endif

#include "bank.h"
#include "hash_table.h"
#include "list.h"
#include "ports.h"
#include "security.h"
#include "user.h"
#include "validators.h"
#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

Bank* bank_create(char *init_file_path) {
  Bank *bank;
  char *iv;
  char *key;
  char *start;
  char line[BUFFER_SIZE];
  FILE *init = fopen(init_file_path, "r");

  memset(init_file_path, 0, strlen(init_file_path));


  if (init == NULL) {
    return NULL;
  }

  bank = (Bank*) malloc(sizeof(Bank));
  if(bank == NULL) {
    perror("Could not allocate Bank");
    exit(1);
  }

  // Set up the network state
  bank->sockfd = socket(AF_INET, SOCK_DGRAM, 0);

  bzero(&bank->rtr_addr, sizeof(bank->rtr_addr));
  bank->rtr_addr.sin_family = AF_INET;
  bank->rtr_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
  bank->rtr_addr.sin_port = htons(ROUTER_PORT);

  bzero(&bank->bank_addr, sizeof(bank->bank_addr));
  bank->bank_addr.sin_family = AF_INET;
  bank->bank_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
  bank->bank_addr.sin_port = htons(BANK_PORT);
  bind(bank->sockfd, (struct sockaddr *)&bank->bank_addr, sizeof(bank->bank_addr));

  // Set up the protocol state
  bank->users_table = hash_table_create(100);

  fgets(line, sizeof(line), init);
  key = strtok(line, "\n");
  bank->key = (unsigned char *)malloc(strlen(key) + 1);
  strcpy(bank->key, key);

  fgets(line, sizeof(line), init);
  iv = strtok(line, "\n");
  bank->iv = (unsigned char *)malloc(strlen(iv) + 1);
  strcpy(bank->iv, iv);

  fgets(line, sizeof(line), init);
  start = strtok(line, "");
  bank->start = strtoul(start, NULL, 10);

  fclose(init);

  return bank;
}

void bank_free(Bank *bank) {
  if(bank != NULL) {
    close(bank->sockfd);
    hash_table_free(bank->users_table); // Added
    free(bank->iv);
    free(bank->key);
    free(bank);
  }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len) {
  // Returns the number of bytes sent; negative on error
  return sendto(bank->sockfd, data, data_len, 0,
    (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len) {
  // Returns the number of bytes received; negative on error
  return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

void bank_process_local_command(Bank *bank, char *command, size_t len) {
  char card_buffer[BUFFER_SIZE] = "";
  char card_file_name[BUFFER_SIZE] = "";
  char hashed_card[BUFFER_SIZE] = "";
  char hashed_pin[BUFFER_SIZE] = "";
  char line_buffer[BUFFER_SIZE] = "";
  char *card = NULL;
  char *pin = NULL;
  char *user_command = NULL;
  char *user_name = NULL;
  char *user_amount = NULL;
  FILE *fp = NULL;
  long amount = 0;
  long balance = 0;
  User *user = NULL;

  memset(card_buffer , 0, BUFFER_SIZE);
  memset(card_file_name , 0, BUFFER_SIZE);
  memset(hashed_card , 0, BUFFER_SIZE);
  memset(hashed_pin , 0, BUFFER_SIZE);
  memset(line_buffer , 0, BUFFER_SIZE);

  if (command == NULL) {
    printf("Invalid command");
  } else {
    if (len > BUFFER_SIZE - 1) {
      memcpy(line_buffer, command, BUFFER_SIZE - 1);
    } else {
      memcpy(line_buffer, command, len);
    }

    memset(command, 0, len + 1);

    user_command = strtok(line_buffer, " \n");
    user_name = strtok(NULL, " \n");

    if (user_command == NULL
        || (strcmp(user_command, "create-user") != 0
            && strcmp(user_command, "deposit") != 0
            && strcmp(user_command, "balance") != 0)) {
      printf("Invalid command");
    } else {
      if (strcmp(user_command, "create-user") == 0) {
        pin = strtok(NULL, " \n");
        user_amount = strtok(NULL, " \n");

        if (!valid_user_name(user_name)
            || !valid_pin(pin)
            || !valid_value(user_amount)
            || strtoul(user_amount, NULL, 10) > MAX_ACCOUNT_VALUE
            || strtok(NULL, " \n") != NULL) {
          printf("Usage: create-user <user-name> <pin> <balance>");
        } else {
          user = hash_table_find(bank->users_table, user_name);

          if (user != NULL) {
            printf("Error: user %s already exists", user_name);
          } else {
            strcpy(card_buffer, user_name);
            strcat(card_buffer, ".card");

            fp = fopen(card_buffer, "w");

            if (fp == NULL) {
              printf("Error creating card file for user %s", user_name);
            } else {
              memset(card_buffer, 0, BUFFER_SIZE);
              sprintf(card_buffer, "%lu", bank->start);
              card = strtok(card_buffer, " \n");
              fputs(card, fp);
              bank->start++;
            }

            fclose(fp);

            balance = strtoul(user_amount, NULL, 10);
            hash_fun(card, hashed_card);
            hash_fun(pin, hashed_pin);
            user = user_create(hashed_card, hashed_pin, balance);
            hash_table_add(bank->users_table, user_name, (void *)user);
            printf("Created user %s", user_name);
          }
        }
      } else if (strcmp(user_command, "deposit") == 0) {
        user_amount = strtok(NULL, " \n");

        if (!valid_user_name(user_name)
            || !valid_value(user_amount)
            || strtok(NULL, " \n") != NULL) {
          printf("Usage: deposit <user-name> <amt>");
        } else {
          user = (User *)hash_table_find(bank->users_table, user_name);

          if (user == NULL) {
            printf("No such user");
          } else {
            amount = strtoul(user_amount, NULL, 10);
            balance = user->balance;
            balance += amount;

            if (balance > MAX_ACCOUNT_VALUE
                || amount > MAX_ACCOUNT_VALUE) {
              printf("Too rich for this program");
            } else {
              update_balance(user, balance);
              printf("$%s added to %s's account", user_amount, user_name);
            }
          }
        }
      } else {
        if (!valid_user_name(user_name)
            || strtok(NULL, " \n") != NULL) {
          printf("Usage: balance <user-name>");
        } else {
          user = (User *)hash_table_find(bank->users_table, user_name);

          if (user == NULL) {
            printf("No such user");
          } else {
            printf("$%lu", user->balance);
          }
        }
      }
    }
  }
}

void bank_process_remote_command(Bank *bank, char *command, size_t len) {
  char buffer[BUFFER_SIZE];
  char c_text[BUFFER_SIZE];
  char c_len_char[BUFFER_SIZE];
  char confirm_tag[BUFFER_SIZE];
  char message[BUFFER_SIZE];
  char p_text[BUFFER_SIZE];
  char send_line[BUFFER_SIZE];
  char t_len_char[BUFFER_SIZE];
  char tag[BUFFER_SIZE];
  char *atm_command = NULL;
  char *card = NULL;
  char *pin = NULL;
  char *user_amount = NULL;
  char *user_name = NULL;
  FILE *fp = NULL;
  long balance = 0;
  int c_len = 0;
  int ct_len = 0;
  int m_len = 0;
  int p_len = 0;
  int t_len = 0;
  User *user = NULL;

  memset(buffer , 0, BUFFER_SIZE);
  memset(c_text , 0, BUFFER_SIZE);
  memset(c_len_char , 0, BUFFER_SIZE);
  memset(confirm_tag , 0, BUFFER_SIZE);
  memset(message , 0, BUFFER_SIZE);
  memset(p_text , 0, BUFFER_SIZE);
  memset(send_line , 0, BUFFER_SIZE);
  memset(t_len_char , 0, BUFFER_SIZE);
  memset(tag , 0, BUFFER_SIZE);

  deconstruct_message(command, c_text, c_len_char, tag, t_len_char);
  c_len = strtoul(c_len_char, NULL, 10);
  t_len = strtoul(t_len_char, NULL, 10);
  ct_len = sign(bank->key, c_text, c_len, confirm_tag);

  if (strcmp(tag, confirm_tag) != 0) {
    p_len = decrypt(c_text, c_len, bank->key, bank->iv, p_text);
    p_text[p_len] = 0;

    strcpy(send_line, "corrupted");
  } else {
    p_len = decrypt(c_text, c_len, bank->key, bank->iv, p_text);
    p_text[p_len] = 0;

    memset(command, 0, len + 1);

    atm_command = strtok(p_text, " \n");

    if (strcmp(atm_command, "begin-session") == 0) {
      user_name = strtok(NULL, " \n");
      user = (User *)hash_table_find(bank->users_table, user_name);

      if (user == NULL) {
        strcpy(send_line, "fail");
      } else {
        strcpy(send_line, "success");
      }
    } else if (strcmp(atm_command, "authorize") == 0) {
      user_name = strtok(NULL, " \n");
      card = strtok(NULL, " \n");
      pin = strtok(NULL, " \n");

      user = (User *)hash_table_find(bank->users_table, user_name);

      if (strcmp(card, user->card) != 0
          || strcmp(pin, user->pin) != 0) {
        strcpy(send_line, "fail");
      } else {
        strcpy(send_line, "success");
      }
    } else if (strcmp(atm_command, "balance") == 0) {
      user_name = strtok(NULL, " \n");
      user = (User *)hash_table_find(bank->users_table, user_name);

      sprintf(buffer, "%lu", user->balance);

      strcpy(send_line, "success ");
      strcat(send_line, buffer);
    } else if (strcmp(atm_command, "withdraw") == 0) {
      user_name = strtok(NULL, " \n");
      user_amount = strtok(NULL, " \n");

      user = (User *)hash_table_find(bank->users_table, user_name);
      balance = user->balance;
      balance -= strtoul(user_amount, NULL, 10);

      if (balance < MIN_ACCOUNT_VALUE) {
        strcpy(send_line, "fail");
      } else {
        update_balance(user, balance);
        strcpy(send_line, "success");
      }
    } else {
      strcpy(send_line, "corrupted");
    }
  }

  memset(c_text, 0, BUFFER_SIZE);
  memset(tag, 0, BUFFER_SIZE);

  c_len = encrypt(send_line, strlen(send_line), bank->key, bank->iv, c_text);
  t_len = sign(bank->key, c_text, c_len, tag);
  m_len = construct_message(c_text, c_len, tag, t_len, message);
  bank_send(bank, message, m_len);
}
