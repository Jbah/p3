/*
* The main program for the Bank.
*
* You are free to change this as necessary.
*/

#include <string.h>
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>
#include "bank.h"
#include "ports.h"

#if !defined(BUFFER_SIZE)
#define BUFFER_SIZE 1000
#endif

static const char prompt[] = "BANK: ";

int main(int argc, char**argv) {
  int n;
  char sendline[BUFFER_SIZE];
  char recvline[BUFFER_SIZE];

  if (argc == 1) {
    printf("Error opening bank initialization file\n");
    return(64);
  }

  Bank *bank = bank_create(argv[1]);
  if (bank == NULL) {
    printf("Error opening bank initialization file\n");
    return(64);
  }

  printf("%s", prompt);
  fflush(stdout);

  while(1) {
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(0, &fds);
    FD_SET(bank->sockfd, &fds);
    select(bank->sockfd+1, &fds, NULL, NULL, NULL);

    if(FD_ISSET(0, &fds)) {
      fgets(sendline, BUFFER_SIZE, stdin);
      bank_process_local_command(bank, sendline, strlen(sendline));
      printf("%s", prompt);
      fflush(stdout);
    } else if(FD_ISSET(bank->sockfd, &fds)) {
      n = bank_recv(bank, recvline, BUFFER_SIZE);
      bank_process_remote_command(bank, recvline, n);
    }
  }

  return EXIT_SUCCESS;
}
