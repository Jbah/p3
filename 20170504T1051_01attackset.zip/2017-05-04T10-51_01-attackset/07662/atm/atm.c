#include "atm.h"
#include "ports.h"
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include "encryptize.h" 
#include <time.h>

int isNumeric(char *in, int length) {

	if (length <= 0 || in == NULL) {
	//	printf("First clause failed.\n");		
		return -1;
	}

	int i;

	for (i = 0; i < length; i++){
		if (isdigit(in[i]) == 0)
			return 1;
	}

	return 0;
}

ATM* atm_create(int argc, char **argv)
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

	// setting up timeout 

	struct timeval tv;
	tv.tv_sec = 5; // five second timeout
	tv.tv_usec = 0;

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

	setsockopt(atm->sockfd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tv, sizeof(struct timeval));

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state

	// seeding random number generator.
	srand(time(NULL));

	// getting symmetric key from file

	// attempting to open file
	FILE *file = fopen(argv[1], "r");
	if (file == NULL) {
		printf("Error opening atm initialization file\n");
		exit(64);
	}

	fread(&(atm->s_key), sizeof(unsigned char), 100, file);
	fclose(file);

	atm->s_key[strlen(atm->s_key)-1] = '\0';
	atm->logged_user = NULL;
	atm->pin_process = 0;

    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm);
	//free(atm->balance);
	//atm->balance = NULL;
	atm = NULL;
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len) {

	unsigned char cipher[128] = {0};
	// just the first 16 chars of the secret key

	int cipher_len = encrypt((unsigned char *)data, strlen(data) + 1, atm->s_key, cipher);
	//printf("line 120\n");


	return sendto(atm->sockfd, cipher, cipher_len, 0,
		  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

// Returns the number of bytes received; negative on error
ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len) {

	char recd[max_data_len];
	int numreceived = recv(atm->sockfd, recd, max_data_len+1, 0);

	//printf("Well i just heard |%s|\n", recd);

	if (numreceived <= 0) {
		return -1;
	}

	//printf("Line 106\n");

	int plain_len = decrypt(recd, numreceived, atm->s_key, data);

	//printf("Line 118: the decrypted message is <<%s>>\n", data);

	return plain_len;
	
}


int say_and_hear(ATM *atm, char *msg, int len, char **result, int maxresultlen) {

	//printf("Line 134, In say and hear w/ msg <<%s>>\n", msg);

	int randomlen = 20;
	int bufflen = len + randomlen + 5;

	char buff[bufflen];
	unsigned char randum[randomlen];

	int j = 0;

	for (; j < randomlen-1; j++) {
		randum[j] = (rand() % 93) + 33; //just alphanumeric and what not.
		while ((randum[j] == '+') || (randum[j] == ':')) {
			randum[j] = (rand() % 93) + 33;
		}
	}

	randum[randomlen-1] = '\0';

	buff[0] = '\0'; 
	
	sprintf(buff, "%s+", randum);
	strcat(buff, msg);

	if (atm_send(atm, buff, strlen(buff)) < 0) {
		perror("Line 109"); //do something!!!
		return -1;
	}

	//printf("im here at line 111\n");

	char heard[bufflen];

	if (atm_recv(atm, heard, bufflen) <= 0) {
		//printf("Line 175. atm_recv less than or equal to zero.\n");
		return -1;
	}

	//printf("line 171. say and hear. heard <<%s>>\n", heard);

	char *workwithme = strdup(heard);
	char *response = strsep(&workwithme, "+");

	// printf("challenge is \t<<%s>>\nresponse is \t<<%s>>\n", randum, response);

	if (strcmp(randum, response) != 0) {
		//printf("Mangeled message!\n");
		return -1;
	}

	*result = workwithme;
 
	//printf("result is %s\n", *result);

	return strlen(workwithme); 
 
}

void begin_session(ATM *atm, char *command) {

	if (atm->logged_user != NULL) {
		printf("A user is already logged in\n");
		return;
	}

	char *username = strsep(&command, " ");

	if (strlen(username) >= MAXBUFF || (strcmp(username, "\n") == 0)) {
		printf("Usage: begin-session <user-name>\n");
		return;
	}

	username[strlen(username)-1] = '\0'; //trimming off newline

	char *leftovers = strsep(&command, " "); 

	if (leftovers != NULL) {
		printf("Usage: begin-session <user-name>\n");
		return;
	}

	char buff[strlen(username) + strlen("acc:") + strlen("\n")];

	sprintf(buff, "acc:%s\n", username);
 
	//printf("Line 227: BUFF IS <<%s>>\n", buff);

	char *old;

	if (say_and_hear(atm, buff, strlen(buff), &old, 10) <= 0) {
		printf("Error communicating with bank. Please try again\n");  
		return;
	}

	old[4] = '\0';

	//printf("im here at line 215. old is %s\n", old);

	if (strncmp(old, "good", 4) != 0) {
		printf("No such user\n");
		return;
	}

	atm->logged_user = strdup(username);
	atm->pin_process = 1;


}

void pin_fail(ATM *atm) {

	free(atm->logged_user);
	atm->logged_user = NULL;
	atm->pin_process = 0;

}

void handle_pin_enter(ATM *atm, char *command) {

	//printf("Im here, and heard <<%s>>\n", command);
	char filename[strlen("./") + strlen(atm->logged_user) + strlen(".card")];

	sprintf(filename, "./%s.card", atm->logged_user);
	//printf("filename is %s\n", filename);

	FILE *file = fopen(filename, "r");
	if (file == NULL) {
		printf("Unable to access %s's card\n", atm->logged_user);
		pin_fail(atm);
		return;
	}

	if (strlen(command) != 5) {
		printf("Not authorized\n");
		pin_fail(atm);
		return;
	}

	command[4] = '\0'; // trimming newline


	char recd[18];

	int data_len = fread(recd, sizeof(unsigned char), 18, file);

	//printf("Line 202; the data from the file is %s\n", recd);
	fclose(file);

	char data[data_len];

	decrypt(recd, data_len, atm->s_key, data);

	if (strcmp(data, command) != 0) {
		printf("Not authorized\n");
		pin_fail(atm);
		return;
	}

	atm->pin_process = 0;
	printf("Authorized\n");
}


// if there is an overflow or something, the atoi result wont be the same as the num
int int_in_range(char *remainder) {

	char str[10];

	// stripping off the leading zeros
	int i = 0;
	while ((remainder[0] == '0') && (i < 10)) {
		remainder++;
		i++;
	}

	int bal = atoi(remainder);

	sprintf(str, "%d", bal);

	//printf("Line 124. remainder is %s, bal is %d, str is %s\n", remainder, bal, str);

	return strcmp(remainder, str);

}

void withdraw(ATM *atm, char *command) {

	// 0. determine if a user is already logged in

	if (atm->logged_user == NULL) {
		printf("No user logged in\n");
		return;
	}

	// 1. determine if command is valid

	// 1.3 determine if there's any excess

	int i = 0;

	char *runner = command;

	for (i=0; runner[i]; i++) {
		if (runner[i] == ' ') { 
			printf("Usage: withdraw <amt>\n");
			return;		
		}
	}
	command[strlen(command)-1] = '\0';

	//printf("Line 365. command is <<%s>>\n", command);

	// 1.1 determine if a number
	if (isNumeric(command, strlen(command)) != 0) {
		printf("Usage: withdraw <amt>\n");
		return;
	}

	// 1.2 determine if command is in range
	if (int_in_range(command) != 0) {
		printf("Usage: withdraw <amt>\n");
		return;
	}

	// 2. tell the bank the value the user wants to withdraw.
	// "wtd:username:amt"

	char words[strlen(atm->logged_user) + strlen("wtd::") + strlen(command)];

	sprintf(words, "wtd:%s:%s\n", atm->logged_user, command);

	//printf("Line 374, words is <<%s>>\n", words);


	char* result;

	if (say_and_hear(atm, words, strlen(words), &result, 10) < 0) {
		printf("Error communicating with bank. Please try again\n");
		return;
	}

	//printf("Line 396. I just heard <<%s>> from the bank.\n", result);
	
	if (strncmp(result, "ins", strlen("ins")) == 0) {
		printf("Insufficent funds\n");
	} else if (strncmp(result, "Success", strlen("Success")) == 0) {
		printf("$%s dispensed\n", command);
	} else {
		printf("Error communicating with bank. Please try again\n");
	}



}

void balance(ATM *atm) {

	char buff[strlen("bal:") + strlen(atm->logged_user)];

	sprintf(buff, "bal:%s\n", atm->logged_user);

	char *gimmie;
	
	if (say_and_hear(atm, buff, strlen(buff), &gimmie, 10) <= 0) {
		printf("Error communicating with bank.\n");
		return;
	}

	// let's print the balance.

	printf("$%s\n", gimmie);
	return;
	
	
}

void atm_process_command(ATM *atm, char *command) {

	//printf("line 279, command is <<%s>>\n", command);

	if (atm->pin_process == 1) {
		//printf("Ln 248. Handling pin enter\n");
		handle_pin_enter(atm, command);
		return;
	} else if (strcmp(command, "balance\n") == 0) {

		if (atm->logged_user == NULL) {
			printf("No user logged in\n");
			return;
		}
		balance(atm);
		return;
	}  else if (strcmp(command, "end-session\n") == 0) {

		if (atm->logged_user == NULL) {
			printf("No user logged in\n");
			return;
		} else {
			atm->logged_user = NULL;
		//	printf("LIne 471:: atm logged user is <<%s>>\n", atm->logged_user);
			printf("User logged out\n"); 
			return;
		}
	}

	// printf("Line 75\n");
	char *found = strsep(&command, " ");

	//printf("Line 237. logged user is <<%s>>\n", atm->logged_user);

	if (strcmp(found, "begin-session") == 0) {
		begin_session(atm, command);
	} else if (strcmp(found, "withdraw") == 0) {
		withdraw(atm, command);
	} else if (strcmp(found, "balance") == 0) {
		printf("Usage: balance\n");
	} else {
		printf("Invalid command\n");
	}

	return;
}
