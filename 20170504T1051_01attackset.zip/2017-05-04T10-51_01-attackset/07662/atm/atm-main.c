/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>

char prompt[300] = "ATM: ";

int main(int argc, char** argv)
{
    char user_input[MAXBUFF];

    ATM *atm = atm_create(argc, argv);

    printf("%s", prompt);
    fflush(stdout);

    while (fgets(user_input, MAXBUFF ,stdin) != NULL) {

	//printf("just heard the following <<%s>>\n", user_input);

        atm_process_command(atm, user_input);


	// I know this is could be done more efficently
	if ((atm->logged_user != NULL) && (atm->pin_process == 0)) {

		char newprompt[strlen(atm->logged_user) + strlen("ATM (): ")];
		sprintf(newprompt, "ATM (%s): ", atm->logged_user);
		printf("%s", newprompt);
		fflush(stdout);
		continue; 

	}
	if (atm->pin_process == 0) {
		printf("%s", prompt);
	} else {
		printf("PIN? ");
	}
  
        fflush(stdout);
    }
	return EXIT_SUCCESS;
}
