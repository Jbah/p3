#include "bank.h"
#include "ports.h"
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>



// checks to see if the string is [a-zA-Z]+
int isAlphabetic(char *in, int length) { 

	if (length <= 0 || in == NULL)
		return -1;

	int i;

	for (i = 0; i < length; i++){
		if (isalpha(in[i]) == 0)
			return 1;
	}

	return 0;

}

// only difference between this and isAlphabetic is that this is that
// isalpha is swapped with isdigit
int isNumeric(char *in, int length) {

	if (length <= 0 || in == NULL)
		return -1;

	int i;

	for (i = 0; i < length; i++){
		if (isdigit(in[i]) == 0)
			return 1;
	}

	return 0;
}

Bank* bank_create(int argc, const char **argv)
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as needed


	// getting symmetric key from file

	// attempting to open file
	FILE *file = fopen(argv[1], "r");
	if (file == NULL) {
		printf("Error opening bank initialization file\n");
		exit(64);
	}


	fread(&(bank->s_key), sizeof(unsigned char), 100, file);

	bank->s_key[strlen(bank->s_key)-1] = '\0';

	//bank->s_key[strlen(bank->s_key)-2] = '\0';

	fclose(file);
	// if readThisMuch != 100...

	// 10,000 bins, no way there's going to be that many users...
	bank->ht = sm_new(10000);


    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
        free(bank);
	bank = NULL;
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len) {
  	// Returns the number of bytes sent; negative on error

	unsigned char cipher[300] = {0};  // MAXBUFF is 300 but c compains if i have MAXBUFF in there
	int cipher_len = encrypt((unsigned char *)data, data_len+1, bank->s_key, cipher);

	//printf("line 120\n");

	return sendto(bank->sockfd, cipher, cipher_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len) {
    // Returns the number of bytes received; negative on error

	char *recd = malloc(sizeof(char)*max_data_len);
	int numreceived = recv(bank->sockfd, recd, max_data_len, 0);
	int plain_len = decrypt(recd, numreceived, bank->s_key, data);

	free(recd);
	recd = NULL;
	return plain_len;
}


// if there is an overflow or something, the atoi result wont be the same as the num
int int_in_range(char *remainder) {

	//printf("Line 142, remainder is |%s|\n", remainder);

	// stripping off the zeros
	int i = 0;
	while ((remainder[0] == '0') && (i < 10)) {
		remainder++;
		i++;
	}

	char str[10];
	int bal = atoi(remainder);

	sprintf(str, "%d", bal);

	//printf("Line 124. remainder is %s, bal is %d, str is %s\n", remainder, bal, str);

	return strcmp(remainder, str);

}

void create_user(Bank *bank, char *command) {

	char *username = strsep(&command, " ");

	if ((isAlphabetic(username, strlen(username)) != 0) || (strlen(username) >= MAXBUFF)) {
		printf("Usage: create-user <user-name> <pin> <balance>\n");
		return;		
	}

	char value[MAXBUFF];
	
	int res = sm_get(bank->ht, username, value, sizeof(value));

	if (res != 0) {
		printf("Error: user %s already exists\n", username);
		return;		
	}
	

	char *pinstr = strsep(&command, " "); 
	if (pinstr == NULL) {
		printf("Usage: create-user <user-name> <pin> <balance>\n");
		return;		
	}

	// converting pinstr to integer
	if (strlen(pinstr) != 4) {
		printf("Usage: create-user <user-name> <pin> <balance>\n");
		return;		
	}

	// strlen(pinstr) will always be 5 at this point
	if (isNumeric(pinstr, 4) != 0) {
		printf("Usage: create-user <user-name> <pin> <balance>\n");
		return;		
	}

	char *remainder = strsep(&command, " ");
	remainder[strlen(remainder)-1] = '\0';


	char *extra = strsep(&command, " ");
	if (extra != NULL) {
		printf("Usage: create-user <user-name> <pin> <balance>\n");
		return;
	}

	if (isNumeric(remainder, strlen(remainder)) != 0) {
		printf("Usage: create-user <user-name> <pin> <balance>\n");
		return;		
	}


	if (int_in_range(remainder) != 0) {
		printf("Usage: create-user <user-name> <pin> <balance>\n");
		return;		
	}

	//printf("Line 220: Pinstr is <<%s>>\n", pinstr);

	unsigned char cipher[MAXBUFF];
	cipher[0] = '\0';

	int cipher_len = encrypt((unsigned char *)pinstr, strlen(pinstr)+1, bank->s_key, cipher);
	//printf("line 120\n"

	char dest[strlen("./") + strlen(username) + strlen(".card")];
	strcpy(dest, "./");
	strcat(dest, username);
	strcat(dest, ".card");
	
	FILE *card = fopen(dest, "w");
	if (card == NULL) {
		printf("Error creating card file for user %s\n", username);
		return;		
	}

	fwrite(cipher, sizeof(unsigned char), cipher_len, card);
	fclose(card);

	// adding the user and their pin to the hash. 
	sm_put(bank->ht, username, remainder);

	printf("Created user %s\n", username);
	return;		
	
}

void deposit(Bank *bank, char *command) {

	char val[MAXBUFF], *username, *add_me_str, *extra;
	username = strsep(&command, " ");

	if ((strlen(username) >= MAXBUFF) || isAlphabetic(username, strlen(username)) != 0) {
		printf("Usage: deposit <user-name> <amt>\n");
		return;
	}

	int res = sm_get(bank->ht, username, val, sizeof(val));

	//printf("Line 225 %s -> %s\n", username,  val);
	
	if (res == 0) {
		printf("No such user\n");
		return;		
	}
	add_me_str = strsep(&command, " ");
	if (strlen(add_me_str) > 10) {
		printf("Usage: deposit <user-name> <amt>\n");
		return;
	}
	add_me_str[strlen(add_me_str)-1] = '\0'; // stripping off the newline at the end

	if (isNumeric(add_me_str, strlen(add_me_str)) != 0) {
		printf("Usage: deposit <user-name> <amt>\n");
		return;
	}
	//	printf("Line 224: add me str is %s\n", add_me_str);

	extra = strsep(&command, " ");
	if (extra != NULL) {
		printf("Usage: deposit <user-name> <amt>\n");
		return;
	}

	if (int_in_range(add_me_str) != 0) {
		printf("Too rich for this program\n");
		return;
	}

	int bal = atoi(val);
	int addMe = atoi(add_me_str);

	char resultString[10]; // max int is 10 digits so no value will be more than that

	if (addMe >= MAXINT-bal) {
		printf("Too rich for this program\n");
		return;
	}

	sprintf(resultString, "%d", bal + addMe);

	sm_put(bank->ht, username, resultString);

	printf("$%s added to %s's account\n", add_me_str, username); 
	
}

void balance(Bank *bank, char *command) {
	
	if (strlen(command) >= MAXBUFF) {
		printf("Usage: balance <username>\n");
		return;
	}

	char val[MAXBUFF], *username, *extra;
	username = strsep(&command, " ");
	username[strlen(username)-1] = '\0'; // stripping off the newline at the end

	extra = strsep(&command, " ");
	if (extra != NULL) {
		printf("Usage: balance <username>\n");
		return;
	}

	if (isAlphabetic(username, strlen(username)) != 0) {
		printf("Usage: balance <username>\n");
		return;
	}

	int res = sm_get(bank->ht, username, val, sizeof(val));

	//printf("%s -> %s\n", username,  val);
	
	if (res == 0) {
		printf("No such user\n");
		return;		
	}

	printf("$%s\n", val);
	
}

void bank_process_local_command(Bank *bank, char *command, size_t len){

	if (strlen(command) >= MAXBUFF) {
		printf("Invalid command: null\n");
		return;
	}

	// printf("Line 75\n");
	char *found = strsep(&command, " ");

	// seemingly doesn't arise
	if (found == NULL) {
		printf("Invalid command: null\n");
		return;
	}

    	// 1) get first word of command
	if (strcmp("create-user", found) == 0) {

		create_user(bank, command);

	} else if (strcmp("deposit", found) == 0) {
		//printf("%s -> %s\n", "j",  hash_table_find(bank->ht, "j"));
		deposit(bank, command);
	
	} else if (strcmp("balance", found) == 0) {
		balance(bank, command);
	}

	else {
		printf("Invalid command\n");
	}

	return;

	
}

void bank_process_remote_command(Bank *bank, char *buff, size_t len) {

	//printf("Line 345: length is %d, got %s\n", len, buff);
	
	// if challenge isn't right length (19) or no plus sign present, DROP!
	if (strlen(buff) < 21) {		
		return;
	}

	if (buff[19] != '+') {
		return;
	}

	char *challenge = strsep(&buff, "+");
	char *command = strsep(&buff, "\n");

	//printf("Line 387 challenge is <<%s>>\n", challenge);

	//printf("Line 351 command be %s\n", command);

	char *type = strsep(&command, ":");
	char *username = strsep(&command, ":");

	//printf("Line 391 username is |%s|\n", username);

	char val[10], money[strlen(username) + 10 + strlen(challenge)];

	sprintf(money, "%s+", challenge); 

	int res = sm_get(bank->ht, username, val, sizeof(val));

	// return the account information
	if (strncmp(type, "acc", 3) == 0) {

		if (res == 0) {
			strcat(money, "fail\n");
		} else {
			strcat(money, "good\n");

		}


	} else if (strncmp(type, "bal", 3) == 0) {
		if (res == 0) {
			strcat(money, "fail\n");
		} else {
			//char temp[10];
			//sprintf(temp, "%d\n", res);
			strcat(money, val);
			//printf("line 423, temp is <<%s>>\n", temp);
		}
	} else if (strncmp(type, "wtd", 3) == 0){
		char *request = strsep(&command, ":");
		int want = atoi(request);
		int have = atoi(val);

		//printf("Line 430. Want is %d\nand have is %d\n", want, have);
		if (want > have) {
			strcat(money, "ins");
		}
		else {
			char resultString[10];
			sprintf(resultString, "%d", have - want);
			sm_put(bank->ht, username, resultString);
			strcat(money, "Success");
		}
	} else {
		sprintf(money, "fail\n");
	}

	//printf("Line 444: imm saying %s", money);
	bank_send(bank, money, strlen(money));
}
