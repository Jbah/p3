#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

//Local function used to generate a public private key pair.
//Defined after main.
//void generateKeyPair(char *keyPair[]);
char* generateKey();


int main(int argc, char**argv){
	
	FILE *bank,*atm;
	char *pathToATM, *pathToBank;
	char *symmetrickey;
	

   //check number of arguments
   if(argc != 2){
		printf("Usage: init <filename>\n");
		return 62;
   }
   
   	pathToATM = calloc(strlen(argv[1])+5,sizeof(char));
	pathToBank = calloc(strlen(argv[1])+6,sizeof(char));
	
	//create path to ATM and Bank files
	//use strncpy to protect against buffer overflow
	if(pathToATM != NULL || pathToBank != NULL){
		strncpy(pathToATM,argv[1],strlen(argv[1]));
	   	strcat(pathToATM, ".atm");
	   	strncpy(pathToBank,argv[1],strlen(argv[1]));
	   	strcat(pathToBank, ".bank");
	}
	
	//check if files already exist
	if(access(pathToATM, F_OK) != -1 || access(pathToBank, F_OK) != -1) {
    	printf("Error: one of the files already exists\n");
		return 63;
	}
	
	if((atm = fopen(pathToATM, "w"))==NULL || (bank = fopen(pathToBank, "w"))==NULL){
		printf("Error creating initialization files\n");
		return 64;
   }
   
 //Was going to use this but had trouble with asymmetric crypto and ran out of time  
/*   generateKeyPair(bankKeys);
   generateKeyPair(atmKeys);
   
   	for(i = 0; i < 2; i++){
   	//first put the private keys in the owner's file
   	//then put public keys in the opposite's file
   		if(i == 0){
   			fputs("My bank private key: \n", bank);
			fputs(bankKeys[i], bank);
			fputs("My atm private key: \n", atm);
			fputs(atmKeys[i], atm);
		} else {
			fputs("Bank's public key: \n", atm);
			fputs(bankKeys[i], atm);
			fputs("ATM's public key: \n", bank);
			fputs(atmKeys[i], bank);
		}
		free(bankKeys[i]);
		free(atmKeys[i]);
  	 */
  	 
  	symmetrickey = generateKey();
  	
	fputs(symmetrickey,bank);
	fputs(symmetrickey,atm);
  	 
  	 if(fclose(bank) != 0 || fclose(atm) != 0){
  	 	printf("Error creating initialization files\n");
  	 	return 64;
  	 }
  	 
  	 free(pathToBank);
  	 free(pathToATM);
  	 
  	 printf("Successfully initialized bank state\n");
  	 return 0;
	
}


char* generateKey(){
	FILE *keyFile;
	char *tempKey;
	char *keyLine = NULL;
	size_t len = 0;
	ssize_t read;
	
	tempKey = malloc(25 * sizeof(char));
	if(tempKey == NULL){
		printf("Unable to allocate memory for key");
		exit(1);
	}

	system("openssl rand -base64 16 > keyFile");
	
	keyFile = fopen("keyFile","r");
	
	if (keyFile == NULL) {
		printf("Unable to open key file");
		exit(1);
	}

	while((read = getline(&keyLine, &len, keyFile)) != -1) {
		strcat(tempKey, keyLine);
	}

	fclose(keyFile);
	system("rm keyFile");

	
	return tempKey;
}

 //Was going to use this but had trouble with asymmetric crypto and ran out of time  
/*
void generateKeyPair(char *keyPair[]){
	FILE *publicKeyFile, *privateKeyFile;
	char *publicKey, *privateKey;
	char *keyLine = NULL;
	size_t len = 0;
	ssize_t read;
	
	publicKey = malloc(4098 * sizeof(char));
	privateKey = malloc(4098 * sizeof(char));
	
	if(publicKey == NULL || privateKey == NULL) {
		printf("Unable to allocate memory for keys");
		exit(1);
	}
	
	system("openssl genrsa -out private.pem 2048 &> /dev/null");
	system("openssl rsa -in private.pem -out public.pem -pubout &> /dev/null");
	
	privateKeyFile = fopen("private.pem", "r");
	publicKeyFile = fopen("public.pem", "r");
	
	if(publicKeyFile == NULL || privateKeyFile == NULL){
		printf("Unable to open one of the key files");
		exit(1);
	}
	
	while((read = getline(&keyLine, &len, privateKeyFile)) != -1) {
		strcat(privateKey, keyLine);
	}
	
	fclose(privateKeyFile);
	system("rm private.pem");
	
	keyPair[0] = malloc(strlen(privateKey));
	strncpy(keyPair[0], privateKey, strlen(privateKey));
	
	while((read = getline(&keyLine, &len, publicKeyFile)) != -1) {
		strcat(publicKey, keyLine);
	}
	
	fclose(publicKeyFile);
	system("rm public.pem");
	keyPair[1] = malloc(strlen(publicKey));
	strncpy(keyPair[1], publicKey, strlen(publicKey));
	
}
*/













