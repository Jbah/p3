#include "bank.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <openssl/sha.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <string.h>

//longest message allowed by main is
#define MAX_COMMAND_LEN 1000

Bank* bank_create()
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as needed

	//create lists
	bank->usernameToPin = list_create();
	bank->usernameToBalance = list_create();

	
    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
    	fclose(bank->bankFile);
        close(bank->sockfd);
        list_free(bank->usernameToPin);
        list_free(bank->usernameToBalance);
        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

void bank_process_local_command(Bank *bank, char *commandIn, size_t len)
{
    // TODO: Implement the bank's local commands
    
    //to store the arguments
    char command[12];
    char username[251];
    //not sure what third and fourth arg will be, balance/amount/pin all possible
    char thirdarg[11];
    char fourtharg[11];


    
    //set initial values
    memset(command, 0x00, 12);
    memset(username, 0x00, 251);
    memset(thirdarg, 0x00, 11);
    memset(fourtharg, 0x00, 11);
    
    int args = numArgs(commandIn);
    
    
    //check if command is longer than the max length for a valid command would be
    if(strlen(commandIn) > MAX_COMMAND_LEN + 1) {
    	printf("Invalid command\n");
    	return;
    }
    
    //split the command up
    sscanf(commandIn, "%s %s %s %s", command, username, thirdarg, fourtharg);
    
    //check that command fits the correct parameters
    if(command == NULL || strlen(command) < 1 || strlen(command) > 12) {
    	printf("Invalid command\n");
    	return;
    }
    
    //command is create-user
    if(strcmp(command, "create-user") == 0) {
		int balance = balance = strtol(fourtharg, NULL, 10);
    	
    	//check other args, third arg is pin and fourth arg is balance
    	if(username == NULL || strlen(username) < 1 || strlen(username) > 251
    	|| thirdarg == NULL || strlen(thirdarg) !=4 
    	|| fourtharg == NULL || strlen(fourtharg) < 1 || strlen(fourtharg) > 10 ||
    	balance > 2147483647 || balance < 0 || args > 4) {
    		printf("Usage: create-user <user-name> <pin> <balance>\n");
    		return;
    	}
    	
    	//check username is valid
    	if(check_alphabetic_username(username) == 0) {
    		printf("Usage: create-user <user-name> <pin> <balance>\n");
    		return;
    	}
    	
    	//check that user does not already exist
    	if(check_user_doesnt_exist(username) == 0) {
    		printf("Error: user %s already exists\n", username);
    		return;
    	}
    	
    	//check that pin is valid
    	if(check_numeric_pin(thirdarg) == 0){
    		printf("Usage: create-user <user-name> <pin> <balance>\n");
    		return;
    	}
    	
    	//check that amount is valid
    	if(check_balamt(fourtharg) == 0){
    		printf("Usage: create-user <user-name> <pin> <balance>\n");
    		return;
    	}
    	
    	//everything is good, create the user
    	//hash pin with a salt
    	char saltypin[strlen(thirdarg) + 5];
    	memset(saltypin, 0x00, (strlen(thirdarg)+5));
    	strncpy(saltypin, "C414S", 5);
    	strncat(saltypin, thirdarg, strlen(thirdarg));
    	
    	unsigned char hash[SHA_DIGEST_LENGTH];
    	memset(hash, 0x00, SHA_DIGEST_LENGTH);
    	size_t hashlength = strlen(saltypin);
    	SHA1(saltypin, hashlength, hash);
    	
    	//create the card file name. username.card
		int len = strlen(username) + 6;
		char ufile[len]; 
		memset(ufile, 0x00, len);
		strncpy(ufile, username, strlen(username));
		strncat(ufile, ".card", 5);
		FILE *fpcard = fopen(ufile, "w");
		if(fpcard == NULL) {
			printf("Error creating %s user card file\n", username);
			//undo changed
			remove(ufile);
			return;
		}
		
		//add hashed pin to file
		fprintf(fpcard, "%s\n", hash);
		fclose(fpcard);
    	
    	//printf("adding to list username %s with pin %s\n", username, hash);
    	//add username and hashed pin to list
    	list_add_char(bank->usernameToPin, username, hash);
    	//printf(" hash: %s\n",  (unsigned char*)list_find(bank->usernameToPin, username));
		//fflush(stdout);
    	
    	
    	//add entry with username and balance
    	//convert balance to int
    	list_add_int(bank->usernameToBalance, username, &balance);
    	
    	printf("Created user %s\n", username);
    	return;
    }
    //command is deposit
    else if(strcmp(command, "deposit") == 0) {
    	
    	//check args
    	if(username == NULL || strlen(username) < 1 || strlen(username) > 250
    	|| thirdarg == NULL || strlen(thirdarg) < 1 || args > 3) {
    		printf("Usage: deposit <user_name> <amt>\n");
    		return;
    	}
    	
    	//check username is valid
    	if(check_alphabetic_username(username) == 0){
    		printf("Usage: deposit <user_name> <amt>\n");
    		return;
    	}
    	
    	//check username exists
    	if(check_user_doesnt_exist(username) == 1){
    		printf("No such user\n");
    		return;
    	}
    	
    	if(check_balamt(thirdarg) == -1){
    		printf("Too rich for this program\n");
    		return;
    	}
    	
    	if(check_balamt(thirdarg) == 0){
    	    printf("Usage: deposit <user_name> <amt>\n");
    		return;
    	}
    	
    	
    	int balance = *((int *) list_find(bank->usernameToBalance, username));
    	int depamt = strtol(thirdarg, NULL, 10);
    	long sum = balance + depamt;
    	if(sum > 2147483647 || (sum - depamt != balance)) {
    		printf("Too rich for this program\n");
    		return;
    	}
    	
    	int newbal = (int) sum;
    	list_del(bank->usernameToBalance, username);
    	list_add_int(bank->usernameToBalance, username, &newbal);
    	
    	printf("$%s added to %s's account\n", thirdarg, username);
    	return;
    }
    //command is balance
    else if(strcmp(command, "balance") == 0) {
    	
    	if(username == NULL || strlen(username) > 250 || strlen(username) < 1 || args > 2){
    		printf("Usage: balance <user_name>\n"); 
			return;
    	}
    
    	//check username is valid
    	if(check_alphabetic_username(username) == 0){
    		printf("Usage: balance <user_name>\n");
    		return;
    	}
    	
    	//check username exists
    	if(check_user_doesnt_exist(username) == 1){
    		printf("No such user\n");
    		return;
    	}	
    	
    	int balance = *((int *) list_find(bank->usernameToBalance, username));
    	printf("$%d\n", balance);
    }
    //command is invalid
    else {
    	printf("Invalid command\n");
    	return;
    }
}

void bank_process_remote_command(Bank *bank, char *commandIn, size_t len)
{

    /*char sendline[1000];
    commandIn[len]=0;
    sprintf(sendline, "Bank got: %s", commandIn);
    bank_send(bank, sendline, strlen(sendline));
    printf("Received the following:\n");
    fputs(commandIn, stdout);
    */

    /*unsigned char decryptCmd[300];
    memset(decryptCmd, 0x00, 300);
    int dlen = decrypt((unsigned char*) commandIn, strlen(commandIn)+1, getKey(bank), decryptCmd);
    printf("encrypted command %s \n", commandIn);
    printf("decrypted command: %s \n", decryptCmd);*/
    

    //receive command
    //will have to be decrypted
    
    char resp[1000];
    char command[14];
    char username[251];
    char thirdarg[11];
    
    int args = numArgs(commandIn);
    
    memset(resp, 0x00, 1000);
    memset(command, 0x00, 14);
    memset(username, 0x00, 251);
    
    
    //add more here as go
    //sscanf((char*)decryptCmd, "%s %s", command, username);
     sscanf(commandIn, "%s %s %s", command, username, thirdarg);
     
    // printf("command: %s username: %s pin: %s", command, username, thirdarg);
     //fflush(stdout);
    
    if(strcmp(command, "check-user")== 0){
    	//user does not exist
    	if(check_user_doesnt_exist(username) == 1 || args > 2){
    		//will have to encrypt eventually
    		strncpy(resp, "nope", 4);
    	}
    	else { //user does exist
    		strncpy(resp, "yes", 3);
    	}
    	/*//encrypt message
		unsigned char cipher[128];
		memset(cipher, 0x00, 128);
	
		int clen = my_encrypt((unsigned char*) resp, strlen(resp) + 1, getKey(bank), cipher);
    	bank_send(bank, (char *)cipher, strlen(cipher));*/
    	bank_send(bank, resp, strlen(resp));
		return;
    }
    else if(strcmp(command, "pin")==0){
    	char pin[5];
    	strncpy(pin, thirdarg, 4);
    	
        char saltypin2[strlen(pin) + 5];
    	unsigned char hash2[SHA_DIGEST_LENGTH];
    	
    	//check things that would make bank respond invalid
    	if(check_user_doesnt_exist(username)==1 ||
    	strlen(pin) != 4 || pin == NULL || 
    	check_numeric_pin(pin)==0 || args > 3){
    		strncpy(resp, "nope", 4);
    		//TO DO encrypt this
    		bank_send(bank, resp, strlen(resp));
    		return;
    	}

    	//hash pin with a salt
    	memset(saltypin2, 0x00, (strlen(pin)+5));
    	strncpy(saltypin2, "C414S", 5);
    	strncat(saltypin2, pin, strlen(pin));
    	

    	memset(hash2, 0x00, SHA_DIGEST_LENGTH);
    	size_t hashlength = sizeof(saltypin2);
    	SHA1((unsigned char *)saltypin2, hashlength, hash2);

    	//check if hashes match
    	if(strcmp(hash2, list_find(bank->usernameToPin, username))==0){
    		strncpy(resp, "yes", 3);
    		//TO DO encrypt this
    		bank_send(bank, resp, strlen(resp));
    		return;	
    	}
    	else {
    		strncpy(resp, "nope", 4);
    		//TO DO encrypt this
    		bank_send(bank, resp, strlen(resp));
    		return;
    	}
    	
    }

    else if(strcmp(command, "withdraw")==0){
    	
    	int amt = strtol(thirdarg, NULL, 10);
    	
    	//check things that would make command invalid
    	if(username == NULL|| strlen(username) < 1 || strlen(username) >250 ||
    	check_user_doesnt_exist(username)==1 ||
    	thirdarg == NULL || strlen(thirdarg) < 1 || strlen(thirdarg) > 10 ||
    	check_balamt(thirdarg) == 0 ||
    	amt > 2147483647 || amt < 0 || args > 3){
    		strncpy(resp, "problem", 7);
    		//TO DO encrypt this
    		bank_send(bank, resp, strlen(resp));
    		return;
    	}
    	
    	//get balance and convert amount to int
    	int balance = *((int *) list_find(bank->usernameToBalance, username));
    	long newbal = balance - amt;
    	
    	
    	if(amt < 0 || newbal < 0) {
    	    strncpy(resp, "nope", 4);
    		//TO DO encrypt this
    		bank_send(bank, resp, strlen(resp));
    		return;
    	}
    	
    	int dep = (int) newbal;
    	list_del(bank->usernameToBalance, username);
    	list_add_int(bank->usernameToBalance, username, &dep);
    
    		 strncpy(resp, "yes", 3);
    		//TO DO encrypt this
    		bank_send(bank, resp, strlen(resp));
    		return;
    }
    else if(strcmp(command, "balance")==0){
    	if(username == NULL|| strlen(username) < 1 || strlen(username) >250 || args > 2){
    		strncpy(resp, "problem", 7);
    		//TO DO encrypt this
    		bank_send(bank, resp, strlen(resp));
    		return;
    	}
    	//get balance and convert amount to int
    	int balance = *((int *) list_find(bank->usernameToBalance, username));
    	char strbal[11];
    	memset(strbal, 0x00, 11);
    	sprintf(strbal, "%d", balance);
    	
    	strncpy(resp, strbal, 11);
    	bank_send(bank, resp, strlen(resp));
    	return;
    }

}

//checks if all of the characters of a username are alphabetic using ctype.h isalpha method
//returns 1 on success and 0 on failure as is the C convention
int check_alphabetic_username(char *username){
	int i;
	for(i = 0; i<strlen(username); i++) {
		if (!isalpha(username[i])) {
			return 0;
		}
	}
	return 1;
}

//checks if a user already exists by seeing if a .card file exists for that username
//0 if it exists, 1 if it does not
int check_user_doesnt_exist(char *username){
	//create the card file name. username.card
	int len = strlen(username) + 6;
	char ufile[len]; 
	memset(ufile, 0x00, len);
	strncpy(ufile, username, strlen(username));
	strncat(ufile, ".card", 5);
	
	//check if file exists in same way as in init.c
	if(access(ufile, F_OK) != -1){
		return 0;
	}
	return 1;
}

//checks if values in pin are valid using isdigit from ctype.h
int check_numeric_pin(char *pin){
	int i;
	for(i = 0; i<strlen(pin); i++){
		if(!isdigit(pin[i])){
			return 0;
		}
	}
	return 1;
}

//checks that the balance or amount entered is all digits and not too large or too small
int check_balamt(char *balamt){
	long amount;
	
	//check the digits by reusing check_numeric_pin
	if(check_numeric_pin(balamt) == 0){
		return 0;
	}
	
	amount = strtol(balamt, NULL, 10);
	
	//return -1 if too rich for program
	if(amount > 2147483647) {
		return -1;
	}
	
	if(amount < 0) {
		return 0;
	}
	
	return 1;
}

//got this code from 
//http://stackoverflow.com/questions/12698836/counting-words-in-a-string-c-programming
int numArgs(const char *sentence)
{
    int count=0,i,len;
    char lastC;
    len=strlen(sentence);
    if(len > 0)
    {
        lastC = sentence[0];
    }
    for(i=0; i<=len; i++)
    {
        if((sentence[i]==' ' || sentence[i]=='\0') && lastC != ' ')
        {
            count++;
        }
        lastC = sentence[i];
    }
    return count;
}

char* getKey(Bank *bank){
	FILE *keyFile = bank->bankFile;
	char *tempKey;
	char *keyLine = NULL;
	size_t len = 0;
	ssize_t read;
	
	tempKey = malloc(25 * sizeof(char));
	if(tempKey == NULL){
		printf("Unable to allocate memory for key");
		exit(1);
	}
	
	if (keyFile == NULL) {
		printf("Unable to open key file, shouldn't get here");
		exit(1);
	}

	while((read = getline(&keyLine, &len, keyFile)) != -1) {
		strcat(tempKey, keyLine);
	}
	
	return tempKey;
}


/* CRYPTO CODE FROM AWESOME TA */

/*
 * Encrypt "plaintext_in" with "key" into "ciphertext"
 * "ciphertext" must be a char[] with enough space to hold the output
 * Uses IV of all zeroes
 *
 * Returns the length of "ciphertext" or -1 on error
 */
int my_encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key, 
        unsigned char *ciphertext) {
    EVP_CIPHER_CTX *ctx;
    unsigned char iv[16] = {0};
    int len = 0;
    int ciphertext_len = 0;

    if(!(ctx = EVP_CIPHER_CTX_new())) {
        return -1;
    }
    if(EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv) != 1) {
        return -1;
    }
    if(EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext_in, plaintext_len) != 1) {
        return -1;
    }
    ciphertext_len = len;

    if(EVP_EncryptFinal_ex(ctx, ciphertext + len, &len) != 1) {
        return -1;
    }
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

/*
 * Decrypt "cipher" with "key" into "plain"
 */
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
        unsigned char *plaintext) {
    EVP_CIPHER_CTX *ctx;
    unsigned char iv[16] = {0};
    int len;
    int plaintext_len;

    if(!(ctx = EVP_CIPHER_CTX_new())) {
        return -1;
    }
    if(EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv) != 1) {
        return -1;
    }
    if(EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len) != 1) {
        return -1; 
    }
    plaintext_len = len;
    if(EVP_DecryptFinal_ex(ctx, plaintext + len, &len) != 1) {
        return -1; 
    }
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}

/*
 * Sign "cipher" with "key"
 */
int sign(const unsigned char* key, unsigned char* cipher, int cipher_len, 
        unsigned char* tag) {
    int len = 0;
    HMAC_CTX ctx;

    HMAC_CTX_init(&ctx);
    HMAC_Init_ex(&ctx, key, strlen(key), EVP_sha1(), NULL);
    HMAC_Update(&ctx, cipher, cipher_len);
    HMAC_Final(&ctx, tag, &len);
    
    HMAC_CTX_cleanup(&ctx);
    return len;
}


