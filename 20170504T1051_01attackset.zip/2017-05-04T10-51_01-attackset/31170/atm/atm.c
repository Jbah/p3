#include "atm.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <string.h>
#include <openssl/sha.h>

//longest message allowed by main is 1000
#define MAX_LINE_LEN 1000

ATM* atm_create()
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    atm->loggedIn = 0;
    atm->failed = 0;
    memset(atm->user, 0x00, 251);

    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
    	fclose(atm->atmFile);
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

void atm_process_command(ATM *atm, char *commandIn)
{
    // TODO: Implement the ATM's side of the ATM-bank protocol

	
    /*char recvline[10000];
    int n;

    atm_send(atm, commandIn, strlen(commandIn));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    fputs(recvline,stdout);
    */
	


	/*
	 * The following is a toy example that simply sends the
	 * user's command to the bank, receives a message from the
	 * bank, and then prints it to stdout.
	 */
	 
	 char command[14];
	 char secondarg[250];
	 
	 memset(command,0x00,14);
	 memset(secondarg,0x00,250);
	 
	 int args = numArgs(commandIn);
	 
	if (strlen(commandIn) > MAX_LINE_LEN + 1){
	   	printf("Invalid command\n");
		return;
	}
	
	sscanf(commandIn, "%s %s", command, secondarg); 
	
	
	if (command == NULL || strlen(command) > 14) { 
		printf("Invalid command\n");
		return;
	}
	
	if(strcmp(command, "begin-session") == 0){
        
        if(atm->loggedIn == 1){
            printf("A user is already logged in\n");
            return;
        }

        if(secondarg == NULL || strlen(secondarg) < 1 || strlen(secondarg) > 250 || args > 2){
            atm->failed = atm->failed + 1;
            printf("Usage: begin-session <user-name>\n");
            return;
        }
		
		if(check_alphabetic_username(secondarg) == 0){
		 	atm->failed = atm->failed + 1;
			printf("Usage: begin-session <user-name>\n");
            return;
		}
		
		// set up msg to send
		int msglen = strlen(secondarg) + 12;
		char msg[msglen];
		memset(msg, 0x00, msglen);
		strncpy(msg, "check-user ", 11);
		strncat(msg, secondarg, strlen(secondarg));
		
		//set up msg to receive
		char recmsg[1000];
		memset(recmsg, 0x00, 1000);
		
		/*//set up cipher text
		unsigned char cipher[300];
		memset(cipher, 0x00, 300);
		
		int clen = my_encrypt((unsigned char*)msg, strlen(msg)+1, getKey(atm), cipher);
		
		atm_send(atm, (char*)cipher, sizeof(cipher));*/
		atm_send(atm, msg, msglen);
		atm_recv(atm, recmsg, 1000);
		
		/*unsigned char plain[300];
		memset(plain, 0x00, 300);
		
		int dlen = decrypt(recmsg, strlen(recmsg) + 1, getKey(atm), plain);*/
		
		//printf("decrypted msg %s\n", plain);
		if(strcmp(recmsg, "nope")==0){ //user does not exist
		    atm->failed = atm->failed + 1;
			printf("No such user\n");
			return;
		}
		else if(strcmp(recmsg, "yes")== 0){ //user does exist
			//get stored pin from card file
			//create the card file name. username.card
			int len = strlen(secondarg) + 6;
			char ufile[len]; 
			memset(ufile, 0x00, len);
			strncpy(ufile, secondarg, strlen(secondarg));
			strncat(ufile, ".card", 5);
			FILE *fpcard = fopen(ufile, "r");
			if(fpcard == NULL) {
				atm->failed = atm->failed + 1;
				printf("Unable to access %s's card\n", secondarg);
			}
			char *tempKey;
			char *keyLine = NULL;
			size_t len2 = 0;
			ssize_t read;
		
			tempKey = malloc(25 * sizeof(char));
			if(tempKey == NULL){
				printf("Unable to allocate memory for key\n");
				exit(1);
			}
			while((read = getline(&keyLine, &len2, fpcard)) != -1) {
				strcat(tempKey, keyLine);
			}		
			fclose(fpcard);
		
			//remove new line from key from card	
			int len3 = strlen(tempKey);
			if (len3 > 0 && tempKey[len3-1] == '\n')
  				  tempKey[len3-1] = 0;
			
			//get pin input
			char pin[5];
			memset(pin, 0x00, 5);
			char input[1000];
			memset(input, 0x00, 1000);
			printf("PIN? ");
			fgets(input, 1000, stdin);
			
			if(strlen(input)-1 != 4){
				atm->failed = atm->failed + 1;
				printf("Not authorized\n");
				return;
			}
			
			strncpy(pin, input, 4);
			
			if(check_numeric_pin(pin) == 0){
				atm->failed = atm->failed + 1;
				printf("Not authorized\n");
				return;
			}
			
			char saltypin2[strlen(pin) + 5];
    		unsigned char hash2[SHA_DIGEST_LENGTH];
    		
    		//hash pin with a salt
    		memset(saltypin2, 0x00, (strlen(pin)+5));
    		strncpy(saltypin2, "C414S", 5);
    		strncat(saltypin2, pin, strlen(pin));
    	
	
    		memset(hash2, 0x00, SHA_DIGEST_LENGTH);
    		size_t hashlength = strlen(saltypin2);
    		SHA1(saltypin2, hashlength, hash2);
						
			if(strcmp(tempKey, hash2) != 0){
				atm->failed = atm->failed + 1;
				printf("Not authorized\n");
				return;
			}
			
			//check if pin is same as stored by bank
			char msg2[262];
			memset(msg2, 0x00, 262);
			
			//set up message to send pin
			strncpy(msg2, "pin ", 4);
			strncat(msg2, secondarg, strlen(secondarg));
			strncat(msg2, " ", 1);
			strncat(msg2, pin, 4);
			
			//TO DO: encrypt msg2
			atm_send(atm, msg2, sizeof(msg2));
			atm_recv(atm, recmsg, 1000);
			
			//TO DO: decrypt recmsg
			if(strlen(recmsg) > 4){
				printf("Not authorized\n");
				return;
			}
			
			if(strcmp(recmsg, "nope") == 0){
				printf("Not authorized\n");
				return;
			}
			
			else{ //authorized
				printf("Authorized\n");			
			}
			
			atm->loggedIn = 1;
			strncpy(atm->user, secondarg, strlen(secondarg));
			atm->failed = 0;
			return;
		}
		else{//shouldn't get here
			
		}
	}
	else if(strcmp(command, "withdraw")==0){
		if(atm->loggedIn == 0){
			printf("No user logged in\n");
			return;
		}
		
		char amt[11];
		memset(amt, 0x00, 11);
		
		strncpy(amt, secondarg, 10);

		if(amt == NULL || strlen(amt) < 1 || strlen(amt) >10 || args > 2){
			printf("Usage: withdraw <amt>\n");
			return;
		}
		
		if(check_numeric_pin(amt)==0){
			printf("Usage: withdraw <amt>\n");
			return;
		}
		
		// set up msg to send
		int msglen = strlen(atm->user) + strlen(amt) + 11;
		char msg[msglen];
		memset(msg, 0x00, msglen);
		strncpy(msg, "withdraw ", 9);
		strncat(msg, atm->user, strlen(atm->user));
		strncat(msg, " ", 1);
		strncat(msg, amt, strlen(secondarg));
		
		//set up msg to receive
		char recmsg[1000];
		memset(recmsg, 0x00, 1000);
		
		/*//set up cipher text
		unsigned char cipher[300];
		memset(cipher, 0x00, 300);
		
		int clen = my_encrypt((unsigned char*)msg, strlen(msg)+1, getKey(atm), cipher);
		
		atm_send(atm, (char*)cipher, sizeof(cipher));*/
		atm_send(atm, msg, msglen);
		atm_recv(atm, recmsg, 1000);
		
		/*unsigned char plain[300];
		memset(plain, 0x00, 300);
		
		int dlen = decrypt(recmsg, strlen(recmsg) + 1, getKey(atm), plain);*/
		
		//printf("decrypted msg %s\n", plain);
		
		if(strcmp(recmsg, "problem")==0){
			printf("Usage: withdraw <amt>\n");
			return;
		}
		else if(strcmp(recmsg, "nope")==0){ //user does not exist
			printf("Insufficient funds\n");
			return;
		}
		else if(strcmp(recmsg, "yes") == 0) {
			printf("$%s dispensed\n", amt);
			return;
		}
		else {
			//should never get here
			//printf("should never get here");
			return;
		}
	}
	else if(strcmp(command, "balance")==0){
		if(atm->loggedIn == 0){
			printf("No user logged in\n");
			return;
		}
		
		if(args > 1){
			printf("Usage: balance\n");
			return;
		}
		
		// set up msg to send
		int msglen = strlen(atm->user) + 9;
		char msg[msglen];
		memset(msg, 0x00, msglen);
		strncpy(msg, "balance ", 8);
		strncat(msg, atm->user, strlen(atm->user));
		
		//set up msg to receive
		char recmsg[1000];
		memset(recmsg, 0x00, 1000);
		
		/*//set up cipher text
		unsigned char cipher[300];
		memset(cipher, 0x00, 300);
		
		int clen = my_encrypt((unsigned char*)msg, strlen(msg)+1, getKey(atm), cipher);
		
		atm_send(atm, (char*)cipher, sizeof(cipher));*/
		atm_send(atm, msg, msglen);
		atm_recv(atm, recmsg, 1000);
		
		/*unsigned char plain[300];
		memset(plain, 0x00, 300);
		
		int dlen = decrypt(recmsg, strlen(recmsg) + 1, getKey(atm), plain);*/
		
		//printf("decrypted msg %s\n", plain);
		
		if(strcmp(recmsg, "nope")==0){
			printf("Usage: balance\n");
			return;
		}
		printf("$%s\n", recmsg);
		return;
	}
	else if(strcmp(command, "end-session")==0){
		if(atm->loggedIn == 0){
			printf("No user logged in\n");
			return;
		}
		atm->loggedIn = 0;
		printf("User logged out\n");
		return;
	}
	else{
		printf("Invalid command\n");
		return;
	}
}

//checks if all of the characters of a username are alphabetic using ctype.h isalpha method
//returns 1 on success and 0 on failure as is the C convention
int check_alphabetic_username(char *username){
	int i;
	for(i = 0; i<strlen(username); i++) {
		if (!isalpha(username[i])) {
			return 0;
		}
	}
	return 1;
}

//checks if values in pin are valid using isdigit from ctype.h
int check_numeric_pin(char *pin){
	int i;
	for(i = 0; i<strlen(pin); i++){
		if(!isdigit(pin[i])){
			return 0;
		}
	}
	return 1;
}

/*
//get working without encryption then fix
//return 0 if user exists, 1 if does not exist
int check_with_bank_user_exists(ATM *atm, char *username){
	//get key
	unsigned char* tempKey = (unsigned char*) getKey(atm);
	
	//set up send message
	char msg[strlen(username)+12];
	memset(msg, 0x00, strlen(username)+12);
	strncpy(msg, "check-user ", 11);
	strncat(msg, username, strlen(username));
	
	printf("message %s\n", msg);
	
	//encrypt message
	unsigned char cipher[128];
	memset(cipher, 0x00, 128);
	
	int clen = my_encrypt(msg, strlen(msg) + 1, tempKey, cipher);

	printf("encrypted msg %s\n", cipher);

	//set up receive message
	//1000 for now but will have to be changed after encryption added
	char rec[1000];
	memset(rec, 0x00, 1000);
	
	unsigned char recipher[128];
	memset(recipher, 0x00, 128);
	
	atm_send(atm, cipher, strlen(cipher));
	atm_recv(atm, recipher, 1000);
	
	printf("received cipher %s\n", recipher);
	
	//decrypt
	int dreclen = decrypt(recipher, strlen(recipher)+1, tempKey, rec);
	printf("decrypted received cipher %s\n", rec);
	
	if(strcmp(rec, "nope") == 0){
		return 0;
	}
	
	if(strcmp(rec, "yes") == 0){
		return 1;
	}
	//should never get here
	return 2;
}*/

//got this code from 
//http://stackoverflow.com/questions/12698836/counting-words-in-a-string-c-programming
int numArgs(const char *sentence)
{
    int count=0,i,len;
    char lastC;
    len=strlen(sentence);
    if(len > 0)
    {
        lastC = sentence[0];
    }
    for(i=0; i<=len; i++)
    {
        if((sentence[i]==' ' || sentence[i]=='\0') && lastC != ' ')
        {
            count++;
        }
        lastC = sentence[i];
    }
    return count;
}


/*CRYPTO CODE FROM AWESOME TA*/

char* getKey(ATM *atm){
	FILE *keyFile = atm->atmFile;
	char *tempKey;
	char *keyLine = NULL;
	size_t len = 0;
	ssize_t read;
	
	tempKey = malloc(25 * sizeof(char));
	if(tempKey == NULL){
		printf("Unable to allocate memory for key");
		exit(1);
	}
	
	if (keyFile == NULL) {
		printf("Unable to open key file, shouldn't get here");
		exit(1);
	}

	while((read = getline(&keyLine, &len, keyFile)) != -1) {
		strcat(tempKey, keyLine);
	}
	
	return tempKey;
}


/*
 * Encrypt "plaintext_in" with "key" into "ciphertext"
 * "ciphertext" must be a char[] with enough space to hold the output
 * Uses IV of all zeroes
 *
 * Returns the length of "ciphertext" or -1 on error
 */
int my_encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key, 
        unsigned char *ciphertext) {
    EVP_CIPHER_CTX *ctx;
    unsigned char iv[16] = {0};
    int len = 0;
    int ciphertext_len = 0;

    if(!(ctx = EVP_CIPHER_CTX_new())) {
        return -1;
    }
    if(EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv) != 1) {
        return -1;
    }
    if(EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext_in, plaintext_len) != 1) {
        return -1;
    }
    ciphertext_len = len;

    if(EVP_EncryptFinal_ex(ctx, ciphertext + len, &len) != 1) {
        return -1;
    }
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

/*
 * Decrypt "cipher" with "key" into "plain"
 */
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
        unsigned char *plaintext) {
    EVP_CIPHER_CTX *ctx;
    unsigned char iv[16] = {0};
    int len;
    int plaintext_len;

    if(!(ctx = EVP_CIPHER_CTX_new())) {
        return -1;
    }
    if(EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv) != 1) {
        return -1;
    }
    if(EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len) != 1) {
        return -1; 
    }
    plaintext_len = len;
    if(EVP_DecryptFinal_ex(ctx, plaintext + len, &len) != 1) {
        return -1; 
    }
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}

/*
 * Sign "cipher" with "key"
 */
int sign(const unsigned char* key, unsigned char* cipher, int cipher_len, 
        unsigned char* tag) {
    int len = 0;
    HMAC_CTX ctx;

    HMAC_CTX_init(&ctx);
    HMAC_Init_ex(&ctx, key, strlen(key), EVP_sha1(), NULL);
    HMAC_Update(&ctx, cipher, cipher_len);
    HMAC_Final(&ctx, tag, &len);
    
    HMAC_CTX_cleanup(&ctx);
    return len;
}
