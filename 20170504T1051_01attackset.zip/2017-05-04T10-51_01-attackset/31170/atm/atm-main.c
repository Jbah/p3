/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>

static const char prompt[] = "ATM: ";

int main(int argc, char**argv)
{
    char user_input[1000];

    ATM *atm = atm_create();
    
    if(argv[1] == NULL || argc != 2){
      printf("“Error opening ATM initialization file”\n");
      return 64;
    }
    
    atm->atmFile = fopen(argv[1], "r");
	if(atm->atmFile == NULL){
      printf("Error opening ATM initialization file\n");
      return 64;
    }

    printf("%s", prompt);
    fflush(stdout);

    while (fgets(user_input, 10000,stdin) != NULL && atm->failed <= 10)
    {
        atm_process_command(atm, user_input);
		if (atm->loggedIn == 1) {
			printf("ATM (%s): ", atm->user);
		} else {
     	   	printf("%s", prompt);
		}        
		fflush(stdout);
    }
    
    atm_free(atm);
	return EXIT_SUCCESS;
}
