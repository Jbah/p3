#ifndef __COMMON_H__
#define __COMMON_H__

#include <openssl/bn.h>
#include <openssl/rsa.h>
#include <stdio.h>


#define BEGIN '\1'
#define LOGIN '\2'
#define WITHDRAW '\3'
#define BALANCE '\4'
#define END '\5'

#define FAIL '\0'
#define SUCCESS '\1'

#define NONCE_SIZE 8

typedef struct InitFile
{
    RSA* ownKey;
    RSA* otherKey;
} InitFile;

InitFile* parseInitFile(FILE *fp, InitFile* ans);
BIGNUM* bignum_base64_decode(const char* base64bignum);
void fail(const char* msg);
int is_number(char *str);
int is_alpha(char *str);

int validate_username(char *str);

int serialize_rsa(RSA* rsa, char* buff, int len);

int parse_args(char *command, char ***args, int argc_len);
DH *get_dh2236();

int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key, 
        unsigned char *ciphertext);
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
        unsigned char *plaintext);

void print_openssl_err(void);
int verify_nonce(char* data, unsigned long nonce);

#endif
