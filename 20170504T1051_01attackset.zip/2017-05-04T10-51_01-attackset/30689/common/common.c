#ifndef __COMMON_C_
#define __COMMON_C_

#include <common/common.h>
#include <stdio.h>
#include <string.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/rand.h>
#include <openssl/err.h>

/*
following two functions taken from http://stackoverflow.com/questions/10742451/how-to-create-a-rsa-public-key-from-a-unsigned-char-modulus-and-exponent-65537
*/

unsigned char *base64_decode(const char* base64data, int* len) {
   BIO *b64, *bmem;
   size_t length = strlen(base64data);
   unsigned char *buffer = (unsigned char *)malloc(length);
   b64 = BIO_new(BIO_f_base64());
   BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
   bmem = BIO_new_mem_buf((void*)base64data, length);
   bmem = BIO_push(b64, bmem);
   *len = BIO_read(bmem, buffer, length);
   BIO_free_all(bmem);
   return buffer;
}

BIGNUM* bignum_base64_decode(const char* base64bignum) {
   BIGNUM* bn = NULL;
   int len;
   unsigned char* data = base64_decode(base64bignum, &len);
   if (len) {
       bn = BN_bin2bn(data, len, NULL);
   }
   free(data);
   return bn;
}

/*
End borrowed code
*/

InitFile* parseInitFile(FILE *fp, InitFile* ans){
    char buff[10000];
    char* cursor;
    int done=0;
    int n;
    int size;
    int buffRemaining;
    BIO* bo;

    buffRemaining=sizeof(buff)-1;
    cursor=buff;
    size=0;

    /*
    Since we only get 1 file, we combined the keys. First, read the private key PEM into memory
    */
    done=0;
    while(done<2){
        if(buffRemaining == 0){
            return NULL;
        }
        if(fgets(cursor, buffRemaining, fp) == NULL){
            return NULL;
        }
        if(cursor[0]=='-'){
            done++;
        }
        n=strlen(cursor); //fgets does not return this information, for some reason.
        size+=n;
        buffRemaining -= n;
        cursor+=n;
    }
    //At this point, buff should the PEM data for our private key
    //Usefule doc:
    //https://www.openssl.org/docs/man1.0.2/crypto/pem.html
    bo = BIO_new ( BIO_s_mem());
    BIO_write(bo, buff, size);
    ans->ownKey = PEM_read_bio_RSAPrivateKey(bo, NULL, NULL, NULL);
    BIO_free(bo);


    //Now do the same to get the other's public key
    buffRemaining=sizeof(buff)-1;
    cursor=buff;
    size=0;
    
    done=0;
    while(done<2){
        if(buffRemaining == 0){
            return NULL;
        }
        if(fgets(cursor, buffRemaining, fp) == NULL){
            return NULL;
        }
        if(cursor[0]=='-'){
            done++;
        }
        n=strlen(cursor); //fgets does not return this information, for some reason.
        size+=n;
        buffRemaining -= n;
        cursor+=n;
    }
    bo = BIO_new ( BIO_s_mem());
    BIO_write(bo, buff, size);
    /*
    Using PEM_read_bio_RSAPublicKey just returns null.
    http://openssl.6102.n7.nabble.com/read-rsa-keys-td25041.html suggests using PEM_read_bio_RSA_PUBKEY, which works
    */
    ans->otherKey = PEM_read_bio_RSA_PUBKEY(bo, NULL, NULL, NULL);
    BIO_free(bo);

    /*
    FILE *out = fopen("/dev/stdout","w");
    printf("My Key: \n");
    RSA_print_fp(out, ans->ownKey,4);
    printf("Other Key: \n");
    RSA_print_fp(out, ans->otherKey,4);
    */

    return ans;
}

void fail(const char* msg){
    printf("Error: %s",msg);
    print_openssl_err();
    exit(-1);
}

int is_number(char *str){
    if(str == NULL){
        return 0;
    }
    while(*str != '\0'){
        char c = *str;
        if(!((c>='0')&&(c<='9'))){
            return 0;
        }
        str++;
    }
    return 1;
}

int is_alpha(char *str){
    if(str == NULL){
        return 0;
    }
    while(*str != '\0'){
        char c = *str;
        int lower = (c>='a')&&(c<='z');
        int upper = (c>='A')&&(c<='Z');
        if(!(upper || lower)){
            return 0;
        }
        str++;
    }
    return 1;
}

int serialize_rsa(RSA* rsa,char* buff, int len){
    BIO* bp = BIO_new(BIO_s_mem());
    PEM_write_bio_RSAPrivateKey(bp, rsa, NULL, NULL, 0, NULL, NULL);
    return BIO_read(bp, buff, len);
}

int validate_username(char *str){
    int works = is_alpha(str);
    works &= strlen(str)<=250;
    return works;
}


int parse_args(char *command, char ***args_, int argc_len){
    char **args=*args_;
    int argc=0;
    /*  
    Command is currently a space deliminated list of words. Replace those spaces with null,
    and store pointers to each individual word in args. Args is null terminated.
    */
    if(*command != '\0'){
        args[argc++]=command;
    }
    while((*command != '\0')&&argc<argc_len){
        if(*command == ' '){
            *command = '\0';
            char x = *(command+1);
            if(x!=' ' && x!='\n'){
                args[argc++]=command+1;
            }   
        }
        command++;
        if (*command == '\n'){
            *command='\0';
        }
    }
    if(argc<argc_len){
        args[argc]=NULL;
    }else{
        argc--;
        args[argc_len-1]=NULL;
    }   
        
    return argc;
}

//https://wiki.openssl.org/index.php/Diffie-Hellman_parameters
DH *get_dh2236()
    {
    static unsigned char dh2236_p[]={
        0x0F,0x52,0xE5,0x24,0xF5,0xFA,0x9D,0xDC,0xC6,0xAB,0xE6,0x04,
        0xE4,0x20,0x89,0x8A,0xB4,0xBF,0x27,0xB5,0x4A,0x95,0x57,0xA1,
        0x06,0xE7,0x30,0x73,0x83,0x5E,0xC9,0x23,0x11,0xED,0x42,0x45,
        0xAC,0x49,0xD3,0xE3,0xF3,0x34,0x73,0xC5,0x7D,0x00,0x3C,0x86,
        0x63,0x74,0xE0,0x75,0x97,0x84,0x1D,0x0B,0x11,0xDA,0x04,0xD0,
        0xFE,0x4F,0xB0,0x37,0xDF,0x57,0x22,0x2E,0x96,0x42,0xE0,0x7C,
        0xD7,0x5E,0x46,0x29,0xAF,0xB1,0xF4,0x81,0xAF,0xFC,0x9A,0xEF,
        0xFA,0x89,0x9E,0x0A,0xFB,0x16,0xE3,0x8F,0x01,0xA2,0xC8,0xDD,
        0xB4,0x47,0x12,0xF8,0x29,0x09,0x13,0x6E,0x9D,0xA8,0xF9,0x5D,
        0x08,0x00,0x3A,0x8C,0xA7,0xFF,0x6C,0xCF,0xE3,0x7C,0x3B,0x6B,
        0xB4,0x26,0xCC,0xDA,0x89,0x93,0x01,0x73,0xA8,0x55,0x3E,0x5B,
        0x77,0x25,0x8F,0x27,0xA3,0xF1,0xBF,0x7A,0x73,0x1F,0x85,0x96,
        0x0C,0x45,0x14,0xC1,0x06,0xB7,0x1C,0x75,0xAA,0x10,0xBC,0x86,
        0x98,0x75,0x44,0x70,0xD1,0x0F,0x20,0xF4,0xAC,0x4C,0xB3,0x88,
        0x16,0x1C,0x7E,0xA3,0x27,0xE4,0xAD,0xE1,0xA1,0x85,0x4F,0x1A,
        0x22,0x0D,0x05,0x42,0x73,0x69,0x45,0xC9,0x2F,0xF7,0xC2,0x48,
        0xE3,0xCE,0x9D,0x74,0x58,0x53,0xE7,0xA7,0x82,0x18,0xD9,0x3D,
        0xAF,0xAB,0x40,0x9F,0xAA,0x4C,0x78,0x0A,0xC3,0x24,0x2D,0xDB,
        0x12,0xA9,0x54,0xE5,0x47,0x87,0xAC,0x52,0xFE,0xE8,0x3D,0x0B,
        0x56,0xED,0x9C,0x9F,0xFF,0x39,0xE5,0xE5,0xBF,0x62,0x32,0x42,
        0x08,0xAE,0x6A,0xED,0x88,0x0E,0xB3,0x1A,0x4C,0xD3,0x08,0xE4,
        0xC4,0xAA,0x2C,0xCC,0xB1,0x37,0xA5,0xC1,0xA9,0x64,0x7E,0xEB,
        0xF9,0xD3,0xF5,0x15,0x28,0xFE,0x2E,0xE2,0x7F,0xFE,0xD9,0xB9,
        0x38,0x42,0x57,0x03,
        };
    static unsigned char dh2236_g[]={
        0x02,
        };
    DH *dh;

    if ((dh=DH_new()) == NULL) return(NULL);
    dh->p=BN_bin2bn(dh2236_p,sizeof(dh2236_p),NULL);
    dh->g=BN_bin2bn(dh2236_g,sizeof(dh2236_g),NULL);
    if ((dh->p == NULL) || (dh->g == NULL))
        { DH_free(dh); return(NULL); }
    return(dh);
    }


/*
Encrypt/decrypt modified from https://piazza.com/class/iybqoaumb1p69g?cid=608
The IV is now the first 16 bytes of the ciphertext
*/
/*
 * Encrypt "plaintext_in" with "key" into "ciphertext"
 * "ciphertext" must be a char[] with enough space to hold the output
 * Uses IV of all zeroes
 *
 * Returns the length of "ciphertext" or -1 on error
 */
int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key, 
        unsigned char *ciphertext) {
    EVP_CIPHER_CTX *ctx;
    unsigned char* iv = ciphertext;
    unsigned char* ctxt=ciphertext+16;
    if(!RAND_bytes(iv,16)){
        fail("Error generating iv");
    }

    int len = 0;
    int ciphertext_len = 0;

    if(!(ctx = EVP_CIPHER_CTX_new())) {
        return -1;
    }
    if(EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv) != 1) {
        return -1;
    }
    if(EVP_EncryptUpdate(ctx, ctxt, &len, plaintext_in, plaintext_len) != 1) {
        return -1;
    }
    ciphertext_len = len;

    if(EVP_EncryptFinal_ex(ctx, ctxt + len, &len) != 1) {
        return -1;
    }
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len+16;
}

/*
 * Decrypt "cipher" with "key" into "plain"
 */
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
        unsigned char *plaintext) {
    EVP_CIPHER_CTX *ctx;
    ciphertext_len-=16;
    unsigned char* iv = ciphertext;
    ciphertext+=16;
    int len;
    int plaintext_len;
    if(!(ctx = EVP_CIPHER_CTX_new())) {
        return -1;
    }
    if(EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv) != 1) {
        return -1;
    }
    if(EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len) != 1) {
        return -1; 
    }
    plaintext_len = len;
    if(EVP_DecryptFinal_ex(ctx, plaintext + len, &len) != 1) {
        return -1; 
    }
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}

void print_openssl_err(){
    ERR_load_crypto_strings();
    printf("\n");
    FILE *f = fopen("/dev/stdout","w");
    ERR_print_errors_fp(f);
    fclose(f);
    printf("\n");
}

int verify_nonce(char* data, unsigned long nonce){
    unsigned long *l = (unsigned long*) data;
    return *l == nonce;
}

#endif
