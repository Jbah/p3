#include "bank.h"
#include "ports.h"
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>
#include <common/common.c>
#include <openssl/err.h>
#include <openssl/rand.h>
#include <openssl/dh.h>
#include <openssl/bn.h>

#define BALANCE_MAX 2147483648u
#define MAX_LOGINS 5
#define LOGIN_COOLDOWN 3600

Bank* bank_create(FILE *initFile)
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);
    
    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    if(parseInitFile(initFile, &bank->initFile)==NULL){
        fail("Error parseing init file");
    }
    bank->users = hash_table_create(7);
    bank->session_key = NULL;
    bank->logged_in = NULL;
    RAND_poll();
    RAND_load_file("/dev/random",32);
    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_send_e(Bank *bank, unsigned char *data, size_t data_len)
{
    if(bank->session_key == NULL){
        fail("calling bank_send_e without session key");
    }
    data_len += sizeof bank->nonce;
    unsigned char* data_ = malloc(data_len);
    memcpy(data_ + sizeof bank->nonce, data, data_len - sizeof bank->nonce);
    ((unsigned long*)data_)[0] = bank->nonce++;
    unsigned char ctxt[data_len+256];
    int ctxt_len = encrypt(data_, data_len, bank->session_key, ctxt);
    if(ctxt_len == -1){
        fail("error encrypting");
    }

    return bank_send(bank, (char*)ctxt, ctxt_len);
}
        

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

ssize_t bank_recv_e(Bank *bank, unsigned char *data, size_t max_data_len){
    unsigned char ctxt[max_data_len+16];
    int ctxt_size = bank_recv(bank, (char *) ctxt, sizeof ctxt);      
    if(ctxt_size<0){
        return ctxt_size;
    }   
    int ptxt_size = decrypt(ctxt, ctxt_size, bank->session_key, data);

    return ptxt_size;
}
ssize_t bank_recv_ev(Bank *bank, unsigned char *data, size_t max_data_len){
    ssize_t size = bank_recv_e(bank, data, max_data_len);
    if(size < NONCE_SIZE || !verify_nonce((char*)data, bank->nonce++)){
        fail("protocol error, nonce");
    }
    return size;
}

void bank_process_local_command(Bank *bank, char *command, size_t len)
{
    char *args[5];
    char **t=args; //Having an intermidiate variable here avoids type warnings.
    int argc=parse_args(command,&t,sizeof args);
    if(argc <= 0){
        return;
    }

    if(strcmp("create-user",args[0])==0){
        create_user(bank, argc, args);
    }
    else if(strcmp("deposit",args[0])==0){
        deposit(bank, argc, args);
    } else if (strcmp("balance", args[0])==0){
        balance(bank, argc, args);
    } else{
        printf("Invalid command\n");
    }
}

void create_user(Bank* bank, int argc, char **args){
    const char *usage_error = "Usage: create-user <user-name> <pin> <balance>\n";
    if (argc != 4){
        printf("%s",usage_error);
        return;
    }
    char *user_name_=args[1];
    char *s_pin=args[2];
    char *s_balance=args[3];

    //validate username
    if(!validate_username(user_name_)){
        printf("%s",usage_error);
        return;
    }  

    //validate pin
    if(strlen(s_pin)!=4){
        printf("%s",usage_error);
        return;
    }
    if(!is_number(s_pin)){
        printf("%s",usage_error);
        return;
    }
    
    //initial validation of ammount. Maximum amount is 10 digits, which is between max_int and max_long
    if(strlen(s_balance)>10){
        printf("%s",usage_error);
        return;
    }
    if(!is_number(s_balance)){
        printf("%s",usage_error);
        return;
    }
    unsigned long l_balance = atol(s_balance);
    if(l_balance > BALANCE_MAX){
        printf("%s",usage_error);
        return;
    }
    unsigned int balance = (unsigned int) l_balance;

    User* u = hash_table_find(bank->users, user_name_);
    if(u != NULL){
        printf("Error: user %s already exists\n", user_name_);
        return;
    }

    u = malloc(sizeof *u);
    u->balance=balance;
    u->pass = calloc(260,1);
                            //use calloc because RAND_bytes uses the buffers as an additional source of entropy
                            //which is harmless, unless the buffer is not initialized, in which case the 
                            //compiler is allowed to go crazy.
    for(int i=0; i<4; i++){
        u->pass[i]=s_pin[i];
    }
    RAND_bytes(u->pass+4, 256);
    BIGNUM* e = BN_new();
    int ret = BN_set_word(e, RSA_F4);
    if(ret != 1){
        fail("Error generating user card\n");
    }
    u->pk = RSA_new();
    ret = RSA_generate_key_ex(u->pk, 4096, e, NULL);
    if(ret != 1){
        fail("Error generating user card\n");
    }
    char card[10000];
    int card_size=0;
    char card_path[512];
    card_path[0]='.';
    card_path[1]='/';
    card_path[2]='\0';
    strcpy(card_path,user_name_);//User_name is at most 250 characters
    strcat(card_path,".card");
    FILE *f = fopen(card_path,"w");
    if(f == NULL){
        printf("Error creating card file for user %s\n", user_name_);
        RSA_free(u->pk);
        free(u->pass);
        free(u);
        return;
    }
    memcpy(card, u->pass+4, 256);
    card_size+=256;
    int n = serialize_rsa(u->pk, card+256, sizeof(card)-256);
    if(n<0){
        fail("Error generating user card\n");
    }
    card_size+=n;
    fwrite(card, sizeof(card[0]), card_size,f);
    fclose(f);

    char *user_name = calloc(260,1);
    strncpy(user_name, user_name_,260);
    user_name[259]='\0';
    u->name=user_name;
    hash_table_add(bank->users, user_name, u);
    u->login_attempts=MAX_LOGINS;
    u->login_reset=0;
    printf("Created user %s\n", user_name);

}

void deposit(Bank* bank, int argc, char** args){
    const char* usage_error = "Usage: deposit <user-name> <amt>\n";
    int works = 1;
    if(argc != 3){
        printf("%s",usage_error);
        return;
    }
    char* username = args[1];
    char* s_amt = args[2];

    works &= validate_username(username);
    works &= is_number(s_amt);
    works &= strlen(s_amt)<=10;
    unsigned long l_amt = atol(s_amt);
    works &= l_amt <= BALANCE_MAX;
    if(!works){
        printf("%s",usage_error);
        return;
    }
   
    User* u = hash_table_find(bank->users, username);
    if(u==NULL){
        printf("No such user\n");
        return;
    }
    unsigned long new_balance = u->balance;
    new_balance += l_amt;
    if(new_balance > BALANCE_MAX){
        printf("Too rich for this program\n");
        return;
    }
    
    u->balance = (unsigned int) new_balance;
    printf("%lu added to %s's account\n", l_amt, username);
    
}

void balance(Bank* bank, int argc, char** args){
    char* usage="Usage: balance <user-name>\n";
    if(argc != 2){
        printf("%s",usage);
        return;
    }
    char* username = args[1];
    if(!validate_username(username)){
        printf("%s",usage);
        return;
    }
    User* u = hash_table_find(bank->users, username);
    if(u == NULL){
        printf("No such user\n");
        return;
    }
    printf("$%lu\n",u->balance);

}

void session_init(Bank *bank, char* command, size_t len){
    unsigned char buff[10000];
    unsigned char ctxt[10000];
    int buff_size=RSA_private_decrypt(len, (unsigned char*) command, buff, bank->initFile.ownKey, RSA_PKCS1_OAEP_PADDING);
    if(buff_size == -1){
        char msg[1024];
        ERR_load_crypto_strings();
        ERR_error_string(ERR_get_error(), msg);
        printf("Error decrypting message: %s\n", msg);
    } else if(buff[0] != BEGIN){
        printf("Protocal error. Recieved RSA encrypted packet that was not BEGIN\n");
    } else{
        BIGNUM *atmPK = BN_bin2bn(buff+1,buff_size-1, NULL);
        DH *dh = get_dh2236();
        DH_generate_key(dh);
        buff_size=BN_bn2bin(dh->pub_key, buff);
        int n = RSA_public_encrypt(buff_size, buff, ctxt, bank->initFile.otherKey, RSA_PKCS1_OAEP_PADDING);
        if(n==-1){
            char msg[1024];
            ERR_load_crypto_strings();
            ERR_error_string(ERR_get_error(), msg);
            printf("Error decrypting message: %s\n", msg);
            fail("failed encrypted diffie helman pk");
        }   
        bank_send(bank,(char *) ctxt, n); 

        free(bank->session_key);
        bank->session_key = malloc(DH_size(dh));
        bank->session_key_size=DH_compute_key(bank->session_key, atmPK, dh);

        if(!RAND_bytes((unsigned char *)(&bank->nonce), NONCE_SIZE)){
            printf("%s\n",ERR_error_string(ERR_get_error(),NULL));
            fail("Error generating nonce\n");
        }
        bank_send_e(bank,(unsigned char*) "", 0);
    }
}

void login(Bank *bank, char* cmd, int cmd_size){
    char username[260]={'\0'};
    strncpy(username, cmd+1,cmd_size-1);
    username[259]='\0';
    User* u = hash_table_find(bank->users, username);
    unsigned char msg;
    if(u == NULL){
        msg = FAIL;
        bank_send_e(bank, &msg, 1);
        free(bank->session_key);
        bank->session_key = NULL;
        return;
    }
    msg = SUCCESS;
    bank_send_e(bank, &msg, 1);

    char buff_[1000];
    char* buff = buff_+NONCE_SIZE;
    char pass[260];
    int size = bank_recv_ev(bank,(unsigned char*) buff_, sizeof buff_);
    size-=NONCE_SIZE;
    if (size == 1){
        if (*buff != FAIL){
            fail("Protocol error, invalid password response");
        }
        free(bank->session_key);
        bank->session_key=NULL;
        return;
    }
    if(size != 260){
        fail("Protocol error, login pass wrong size");
    }
    memcpy(pass,buff,size);

    unsigned char challange[32];
    if(!RAND_bytes(challange, sizeof challange)){
        fail("Error generating challange");
    }
    bank_send_e(bank, challange, sizeof challange);
    size = bank_recv_ev(bank, (unsigned char*) buff_, sizeof buff_);
    int sigsize = size-8;

    
    int works=1;
    if(u->login_attempts<=0){
        works=0;
        time_t now = time(NULL);
        if(u->login_reset < now){
            u->login_attempts=MAX_LOGINS;
        }
    }else{
        if(u->login_attempts==1){
            u->login_reset = time(NULL) + LOGIN_COOLDOWN;
        }
        u->login_attempts--;
    }
    works &= RSA_verify(NID_sha1, challange, sizeof challange,(unsigned char*) buff, sigsize, u->pk);
    works &= memcmp(pass, u->pass,260)==0;
    if(!works){
        msg = FAIL;
        bank_send_e(bank, &msg, 1);
        free(bank->session_key);
        bank->session_key = NULL;
    }else{
        msg = SUCCESS;
        bank_send_e(bank, &msg, 1);
        bank->logged_in = u;

        u->login_reset=0;
        u->login_attempts=MAX_LOGINS;
    }

}

void logout(Bank *bank, char* cmd, int cmd_size)
{
    bank->logged_in = NULL;
    free(bank->session_key);
    bank->session_key=NULL;
}

void withdraw(Bank *bank, char *cmd, int cmd_size){
    if(cmd_size != 1+NONCE_SIZE){
        fail("Protocol error, bad withdraw request");
    }
    char* tmp = cmd+1;
    unsigned long* amnt = (unsigned long*)tmp;
    unsigned char msg=FAIL;
    if(bank->logged_in == NULL){
        msg=FAIL;
    }else if(*amnt <= bank->logged_in->balance){
        msg=SUCCESS;
        bank->logged_in->balance-=*amnt;
    }
    bank_send_e(bank,&msg,1);
}

void balance_r(Bank *bank, char* cmd, int cmd_size){
    if(cmd_size != 1){
        fail("Protocol error, bad balance request");
    }
    unsigned long* ans = &(bank->logged_in->balance);
    unsigned char* msg = (unsigned char*) ans;
    bank_send_e(bank,msg,NONCE_SIZE);
}

void bank_process_remote_command(Bank *bank, char *command, size_t len)
{
    if(bank->session_key == NULL){
        session_init(bank, command, len);
        return;
    }
    char ptxt[len+256];
    int ptxt_size = decrypt((unsigned char*) command, len, bank->session_key, (unsigned char*) ptxt);
    if(ptxt_size < NONCE_SIZE || !verify_nonce(ptxt, bank->nonce++)){
        fail("Protocol error, nonce");
    }
    char* cmd=ptxt+NONCE_SIZE;
    int cmd_size=ptxt_size-NONCE_SIZE;
    if(cmd[0] == LOGIN){
        login(bank, cmd, cmd_size);
    } else if(cmd[0] == END){
        logout(bank, cmd, cmd_size);
    } else if(cmd[0] == WITHDRAW){
        withdraw(bank, cmd, cmd_size);
    } else if(cmd[0] == BALANCE){
        balance_r(bank, cmd, cmd_size);
    }
}
