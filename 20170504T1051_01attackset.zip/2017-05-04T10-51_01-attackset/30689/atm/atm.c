#include "common/common.c"
#include "atm.h"
#include "ports.h"
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#include <unistd.h>
#include <openssl/rsa.h>
#include <openssl/evp.h>
#include <openssl/engine.h>
#include <openssl/dh.h>

#define BALANCE_MAX 2147483648u

ATM* atm_create(FILE *initFile)
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    if(parseInitFile(initFile, &atm->initFile)==NULL){
        fail("Error parsing input file");
    }
    atm->session_key=NULL;
    atm->login_str[0]='\0';
    atm->logged_in=0;

    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_send_e(ATM *atm, unsigned char *data, size_t data_len){
    if(atm->session_key == NULL){
        fail("calling atm_send_e without session key");
    }
    data_len += sizeof atm->nonce;
    unsigned char* data_ = malloc(data_len);
    memcpy(data_ + sizeof atm->nonce, data, data_len - sizeof atm->nonce);
    ((unsigned long*)data_)[0] = atm->nonce++;
    unsigned char ctxt[data_len+256];
    int ctxt_len = encrypt(data_, data_len, atm->session_key, ctxt);
    if(ctxt_len == -1){
        fail("error encrypting");
    }

    return atm_send(atm, (char*)ctxt, ctxt_len);
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

ssize_t atm_recv_e(ATM *atm, unsigned char *data, size_t max_data_len){
    unsigned char ctxt[max_data_len+16];
    int ctxt_size = atm_recv(atm, (char *) ctxt, sizeof ctxt);
    if(ctxt_size<0){
        return ctxt_size;
    }
    int ptxt_size = decrypt(ctxt, ctxt_size, atm->session_key, data);

    return ptxt_size;
}

ssize_t atm_recv_ev(ATM *atm, unsigned char *data, size_t max_data_len){
    ssize_t size = atm_recv_e(atm, data, max_data_len);
    if(size < NONCE_SIZE || !verify_nonce((char*)data, atm->nonce++)){
        fail("protocol error, nonce");
    }
    return size;
}

int validate_logged_in(ATM *atm){
    if(!atm->logged_in){
        printf("No user logged in\n");
        return 0;
    }
    return 1;
}

void end_session(ATM *atm, int argc, char** args){
    unsigned char msg = END;
    if(!validate_logged_in(atm)){
        return;
    }
    atm_send_e(atm, &msg, 1);
    atm->logged_in=0;
    atm->login_str[0]='\0';
    free(atm->session_key);
    atm->session_key=NULL;
    printf("User logged out\n");
}

void withdraw(ATM *atm, int argc, char** args){
    if(!validate_logged_in(atm)){
        return;
    }
    unsigned char msg[1 + NONCE_SIZE];
    msg[0]=WITHDRAW;
    unsigned char* tmp = msg+1;
    unsigned long* m = (unsigned long*) tmp;
    char* s_amnt=args[1];
    if(argc != 2 || strlen(s_amnt)>10 || !is_number(s_amnt)){
        printf("Usage: withdraw <amt>\n");
        return;
    }
    long amnt = atol(s_amnt);
    if(amnt> BALANCE_MAX){
        printf("Usage: withdraw <amt>\n");
        return;
    }
    *m = amnt;
    atm_send_e(atm, msg, sizeof msg);

    unsigned char buffer[1000];
    int size=atm_recv_ev(atm,buffer,sizeof buffer);
    unsigned char* buff = buffer+ NONCE_SIZE;
    size-=8;
    if(size!=1){
        fail("Protocol error, invalid response for withdrawal");
    }
    if(*buff == FAIL){
        printf("Insufficient funds\n");
    }else if(*buff == SUCCESS){
        printf("$%lu dispensed\n",amnt);
    }else{
        fail("Protocol error, invalid responce for withdrawal");
    }
}

void balance(ATM *atm, int argc, char** args){
    if(!validate_logged_in(atm)){
        return;
    }
    if(argc != 1){
        printf("Usage: balance\n");
        return;   
    }
    unsigned char msg = BALANCE;
    atm_send_e(atm, &msg, 1);
    char buffer[1000];
    int size = atm_recv_ev(atm, (unsigned char*) buffer, sizeof buffer);
    char* tmp = buffer+8;
    unsigned long* ans = (unsigned long*) tmp;
    if(size != NONCE_SIZE + NONCE_SIZE){
        fail("Protocol error, wrong size response to balance queuery");
    }
    printf("$%lu\n",*ans);
}

void atm_process_command(ATM *atm, char *command)
{
    char *args[5];
    char **t=args; //Having an intermidiate variable here avoids type warnings.
    int argc=parse_args(command,&t,sizeof args);
    if(argc <= 0){
        return;
    }
    
    if(strcmp("begin-session",args[0])==0){
        begin_session(atm, argc, args);
    } else if(strcmp("end-session",args[0])==0){
        end_session(atm, argc, args);
    } else if(strcmp("withdraw",args[0])==0){
        withdraw(atm, argc, args);
    } else if(strcmp("balance",args[0])==0){
        balance(atm, argc, args);
    } else{
        printf("Invalid command\n");
    }
}

void session_init(ATM* atm){
    //We start with a diffie-helman key exchange
    //See https://wiki.openssl.org/index.php/Diffie_Hellman#Generating_a_Shared_Secret
    //Using the above evp method runs into problems, as I could not find a suitable engine.

    //https://www.openssl.org/docs/man1.0.2/crypto/dh.html

    DH *dh = get_dh2236();
    DH_generate_key(dh);

    unsigned char buff[10000];
    int buff_size=0;
    
    buff[0]=BEGIN;
    buff_size++;

    buff_size+=BN_bn2bin(dh->pub_key, buff+1);


    unsigned char ctxt[10000];
    int n = RSA_public_encrypt(buff_size, buff, ctxt, atm->initFile.otherKey, RSA_PKCS1_OAEP_PADDING);
    if(n==-1){
        char msg[1024];
        ERR_load_crypto_strings();
        ERR_error_string(ERR_get_error(), msg);
        printf("Error decrypting message: %s\n", msg);
        fail("failed encrypted diffie helman pk");
    }
    atm_send(atm, (char*) ctxt, n);
    n=atm_recv(atm, (char *)ctxt, sizeof ctxt);
    buff_size = RSA_private_decrypt(n,ctxt, buff, atm->initFile.ownKey, RSA_PKCS1_OAEP_PADDING);
    if(buff_size==-1){
        char msg[1024];
        ERR_load_crypto_strings();
        ERR_error_string(ERR_get_error(), msg);
        printf("Error decrypting message: %s\n", msg);
        fail("failed encrypted diffie helman pk");
    }
    BIGNUM *bankPK = BN_bin2bn(buff, buff_size, NULL);
    free(atm->session_key);
    atm->session_key=malloc(DH_size(dh));
    atm->session_key_size=DH_compute_key(atm->session_key, bankPK, dh);

    atm_recv_e(atm, buff, sizeof buff);
    unsigned long* l = (unsigned long*) buff;
    atm->nonce = *l;
    atm->nonce++;
}

void begin_session(ATM *atm, int argc, char** args){
    char* usage = "Usage: begin-session <user-name>\n";
    if(argc!=2){
        printf("%s",usage);
        return;
    }
    char* username = args[1];
    if(!validate_username(username)){
        printf("%s\n",usage);
        return;
    }
    if(atm->session_key != NULL){
        printf("A user is already logged in\n");
        return;
    }

    session_init(atm);

    //Verify that user is registered
    char buffer[10000];
    buffer[0]=LOGIN;
    strcpy(buffer+1,username);
    atm_send_e(atm, (unsigned char*) buffer, strlen(buffer)+1);

    int size=atm_recv_ev(atm, (unsigned char*) buffer, sizeof buffer);
    char* buff=buffer + NONCE_SIZE;
    int buff_size = size-NONCE_SIZE;
    if(buff_size!=1){
        fail("Protocal error, invalid response to username query.");
    }
    if(*buff == FAIL){
        printf("No such user\n");
        free(atm->session_key);
        atm->session_key = NULL;
        return;
    }else if(*buff != SUCCESS){
        fail("Protocol error, invalid response to username query.");
    }
    
    char cardPass[256];
    RSA* cardKey;
    //Attempt to read card
    char cardName[1000];
    strcpy(cardName,username);//username is maxed at 250 characters, so this is safe
    strcat(cardName,".card");
    FILE *f = fopen(cardName,"r");
    int haveCard=0;
    int n=0;
    if(f!=NULL){
        n = fread(cardPass,1,256,f);
    }
    if(f == NULL){
        printf("Unable to open %s's card\n", username);
        printf("Can't open file\n");
    }else if(n!=256){
        printf("%d\n",n);
        printf("Err: %d\n",ferror(f));
        printf("Unable to open %s's card\n", username);
        printf("Invalid file (no pass)\n");
    } else{
        size = fread(buffer,1,sizeof buffer, f);
        BIO* bo = BIO_new(BIO_s_mem());
        BIO_write(bo,buffer,size);
        cardKey = PEM_read_bio_RSAPrivateKey(bo, NULL, NULL, NULL);
        BIO_free(bo);
        fclose(f);
        if(cardKey == NULL){
            printf("Unable to open %s's card\n", username);
            printf("Invalid file (no key)\n");
        }else{
            //Get pin
            printf("PIN? ");
            fflush(stdout);
            char pin[10];
            fgets(pin, 10, stdin); 
            if(strlen(pin)==5 && pin[4]=='\n'){
                pin[4]='\0';
            }
            if(strlen(pin)!=4 || !is_number(pin)){
                printf("Not authorized\n");
            }else{
                char pass[300]={0};
                memcpy(pass,pin, 4);
                memcpy(pass+4,cardPass,256);
                atm_send_e(atm,(unsigned char*)pass,260);
                haveCard=1;
            }
        }
    }
    if(!haveCard){
        unsigned char msg = FAIL;
        atm_send_e(atm,&msg, 1);
        free(atm->session_key);
        atm->session_key=NULL;
        return;
    }
    //do challenge.
    size=atm_recv_ev(atm,(unsigned char*) buffer, sizeof buffer);
    buff = buffer+NONCE_SIZE;
    size -= NONCE_SIZE;
    if(size != 32){
        fail("protocol error, wronge challenge size");
    }


    int sig_size = RSA_size(cardKey);
    unsigned char sig[sig_size];
    unsigned int siglen;
    if(!RSA_sign(NID_sha1, (unsigned char*) buff, size, sig, &siglen, cardKey)){
        fail("Error signing challange");
    }
    atm_send_e(atm, sig, (size_t) siglen);

    //See if we are logged in
    size = atm_recv_ev(atm, (unsigned char*) buffer, sizeof buffer);
    size -= NONCE_SIZE;
    buff = buffer+NONCE_SIZE;
    if(size!=1){
        fail("Protocol error, wrong size when told if login successful");
    }
    if(buff[0] == FAIL){
        printf("Not authorized\n");
        free(atm->session_key);
        atm->session_key=NULL;
        return;
    }if(buff[0] != SUCCESS){
        fail("protocol error, invalid status for login attempt.");
    }
    printf("Authorized\n");
    sprintf(atm->login_str," (%.250s)",username);
    atm->logged_in=1;
}


