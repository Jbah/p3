/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>

static const char prompt[] = "ATM: ";

int main(int argc, char **argv)
{
    char user_input[1000];
    FILE *initFile;

    if(argc != 2){
        printf("Error opening ATM initialization file");
        exit(64);
    }
    initFile=fopen(argv[1],"r");
    if(initFile == NULL){
        printf("Error opening ATM initialization file");
        exit(64);
    }

    ATM *atm = atm_create(initFile);

    printf("%s", prompt);
    fflush(stdout);

    while (fgets(user_input, 10000,stdin) != NULL)
    {
        atm_process_command(atm, user_input);
        printf("ATM%s: ",atm->login_str);
        fflush(stdout);
    }
	return EXIT_SUCCESS;
}
