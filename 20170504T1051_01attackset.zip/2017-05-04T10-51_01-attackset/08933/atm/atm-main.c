/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



int main(int argc, char**argv)
{
    char user_input[1000];
    char prompt[275];
    FILE *atmFile;
    if(argc>1) {
      atmFile = fopen(argv[1],"r");
      if(!atmFile) {
	printf("Error opening ATM initialization file\n");
	return 64;
      }
    }

    ATM *atm = atm_create();
    char type[4];
    fgets(type,5,atmFile);
    if(strcmp(type,"atmm")!=0) {
      printf("Error opening ATM initialization file\n");
      return 64;
    }
    fgets(atm->key,129,atmFile);
    fclose(atmFile);
    sprintf(prompt,"ATM: ");
    printf("%s", prompt);
    fflush(stdout);

    while (fgets(user_input, 10000,stdin) != NULL)
      {
        atm_process_command(atm, user_input);
	if(strlen(atm->user)>0) {
	  sprintf(prompt,"ATM %s: ",atm->user);
	}
	else {
	  sprintf(prompt,"ATM: ");
	}
        printf("%s", prompt);
        fflush(stdout);
    }
	return EXIT_SUCCESS;
}
