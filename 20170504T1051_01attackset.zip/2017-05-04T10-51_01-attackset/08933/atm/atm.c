#include "atm.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "list.h"
#include <stdio.h>
#include <ctype.h>
#include <limits.h>
#include "crypto.h"

ATM* atm_create()
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    // TODO set up more, as needed

    return atm;
}

static int isAlpha(char *str) {
   int i;
   for(i=0;i<strlen(str);i++) {
     if(!isalpha(str[i])) {
       return 0;
     }
   }
   if(strlen(str)>250) {
     return 0;
   }
   return 1;
} 


static int isNum(char *str) {
   int i;
   for(i=0;i<strlen(str);i++) {
     if(isalpha(str[i])||str[i]=='-') {
       return 0;
     }
   }
  char max[10];
  sprintf(max,"%d",INT_MAX);
  
  if((strlen(str)==10&&strcmp(str,max)>0)||strlen(str) > 10) {
    return 0;
  }

   return 1;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
  char encData[10000];
   int len;
   len = encrypt(data,strlen(data)+1,atm->key,encData);
  
  return sendto(atm->sockfd, encData, len, 0,
		(struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
  char encData[10000];
  ssize_t s;
   s = recvfrom(atm->sockfd, encData, 10000, 0, NULL, NULL);
   char tempData[10000];
    decrypt(encData,s,atm->key,tempData);
    strncpy(data,tempData,max_data_len);
    return s;
}

void atm_process_command(ATM *atm, char *command)
{  
  //remove newline char
  command[strcspn(command,"\n")]='\0';

  char *comm = strtok(command, " ");
  char *arg1 = strtok(NULL, " ");
  if(!comm) {
    return;
  }
  if(strcmp(comm,"begin-session")==0) {
    atm_begin_session(atm, arg1);
  }
  else if(strcmp(comm,"withdraw")==0) {
    atm_withdraw(atm,arg1);
  }
  else if(strcmp(comm,"balance")==0) {
    if(arg1&&strlen(arg1)>0) {
      printf("Usage: balance\n");
    }
    else {
      atm_balance(atm);
    }
  }
  else if(strcmp(comm,"end-session")==0) {
    if(strlen(atm->user) < 1) {
      printf("No user logged in\n");
    }
    else {
      atm->user[0]=0;
      printf("User logged out\n");
    }
  }
   else {
     printf("Invalid command\n");
   }
	
}

void atm_begin_session(ATM *atm, char *user) {
  char comm[275];
  char recvline[10000];
  int n;
  char fPath[10000];
  sprintf(fPath,"./%s.card",user);
  FILE *card = fopen(fPath,"r");
  sprintf(comm,"registered %s\n",user);
  atm_send(atm,comm,strlen(comm));
  n = atm_recv(atm,recvline,10000);
  recvline[n]=0;
  if(strlen(atm->user)>0) {
    printf("A user is already logged in\n");
  }
  else if(!user || !isAlpha(user)) {
    printf("Usage: begin-session <user-name>\n");
  }
  else if(strcmp(recvline,"false")==0){
      printf("No such user\n");
  }
  else if(!card) {
    printf("Unable to access %s's card\n",user);
  }
  else {
    //check card file for correct user cipher
    printf("PIN?\n");
    char userPin[10000];
    int p;
    //fread(userPin, 5, 1, stdin);
    fgets(userPin,10000,stdin);
    if(strlen(userPin)>5) {
      printf("Not authorized\n");
    }
    else {
      userPin[4]=0;
      char realPin[5];
      char sendLine[275];
      sprintf(sendLine,"pin %s\n", user);
      atm_send(atm,sendLine,strlen(sendLine));
      p = atm_recv(atm, realPin,4);
      realPin[4]=0;

      if(strcmp(realPin,userPin)==0) {
	printf("Authorized\n");
	strcpy(atm->user,user);
      }
      else {
	printf("Not authorized\n");
      }
    }
    fclose(card);
  }
  
  //dont forget to  remove when close session
}

void atm_withdraw(ATM *atm, char *amt) {
  
  if(strlen(atm->user)<1) {
    printf("No user logged in\n");
  }
  else if(!isNum(amt)) {
    printf("Usage: withdraw <amt>\n");
  }
  else {
    long lAmt = strtol(amt,NULL,10);
    char sendLine[275];
    char userBal[11];
    int n;
    sprintf(sendLine,"balance %s\n", atm->user);
    atm_send(atm,sendLine,strlen(sendLine));
    n = atm_recv(atm,userBal,10);
    userBal[n]=0;
    long lBal = strtol(userBal,NULL,10);
    if(lBal<lAmt) {
      printf("Insufficient funds\n");
    }
    else {
      printf("$%s dispensed\n",amt);
      char sendLine2[300];
      sprintf(sendLine2,"withdraw %s %s\n", amt,atm->user);
      atm_send(atm,sendLine2,strlen(sendLine2));
    }
  }
}

void atm_balance(ATM *atm) {
  if(strlen(atm->user)<1) {
    printf("No user logged in\n");
  }
  else {
    char sendLine[275];
    char bal[10000];
    int n;
    sprintf(sendLine, "balance %s\n", atm->user);
    atm_send(atm,sendLine,strlen(sendLine));
    n = atm_recv(atm,bal,10);
    bal[n]=0;
    printf("$%s\n",bal);
  }
}
