/* 
 * The main program for Init.
 */

#include <string.h>
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>
#include "bank.h"
#include "ports.h"
#include <unistd.h>
#include <time.h>

//http://stackoverflow.com/questions/15767691/whats-the-c-library-function-to-generate-random-string "Seb"
void rand_str(char *dest, size_t length) {
    char charset[] = "0123456789"
                     "abcdefghijklmnopqrstuvwxyz"
                     "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    srand(time(NULL));
    while (length-- > 0) {
        size_t index = (double) rand() / RAND_MAX * (sizeof charset - 1);
        *dest++ = charset[index];
    }
    *dest = '\0';
}

int main(int argc, char**argv)
{
  if(argc!= 2) {
    printf("Usage: init <filename>\n");
    return 62;
  }
  else {
    char bankPath[10000];
    char atmPath[10000];
    char key[129];
    rand_str(key,128);
    key[128]=0;

    sprintf(bankPath,"%s.bank",argv[1]);
    sprintf(atmPath,"%s.atm",argv[1]);

    //if either file can be opened/exists
    if(access(bankPath,F_OK) != -1 || access(atmPath,F_OK) != -1) {
      printf("Error: one of the files already exists\n");
      return 63;
    }
    else {
      FILE *bank = fopen(bankPath, "w");
      if(bank) {
	//write stuff
	fputs("bank\n",bank);
	fputs(key,bank);
	fclose(bank);
      }
      else {
	printf("Error creating initialization files\n");
	return 64;
      }
      FILE *atm = fopen(atmPath, "w");
      if(atm) {
	//write stuff
	fputs("atmm\n",atm);
	fputs(key,atm);
	fclose(atm);
      }
      else {
	printf("Error creating initialization files\n");
	return 64;
      }
    }
    
  }

  return 0;
}
