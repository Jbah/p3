#include "bank.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "list.h"
#include <stdio.h>
#include <ctype.h>
#include <limits.h>
#include "crypto.h"

Bank* bank_create()
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    bank->userPin = list_create();
    bank->userBal = list_create();

    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
        free(bank);
    }
}

static int isAlpha(char *str) {
   int i;
   for(i=0;i<strlen(str);i++) {
     if(!isalpha(str[i])) {
       return 0;
     }
   }
   if(strlen(str)>250) {
     return 0;
   }
   return 1;
} 


static int isNum(char *str) {
   int i;
   for(i=0;i<strlen(str);i++) {
     if(isalpha(str[i])||str[i]=='-') {
       return 0;
     }
   }
  char max[10];
  sprintf(max,"%d",INT_MAX);
  
  if((strlen(str)==10&&strcmp(str,max)>0)||strlen(str) > 10) {
    return 0;
  }

   return 1;
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
  char encData[10000];
  int len;
  len = encrypt(data,strlen(data)+1,bank->key,encData);
  return sendto(bank->sockfd, encData, len, 0,
		(struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
  char encData[10000];
  ssize_t s;
  s = recvfrom(bank->sockfd, encData, 10000, 0, NULL, NULL);
  char tempData[10000];
  decrypt(encData,s,bank->key,tempData);
  strncpy(data,tempData,max_data_len);
    return s;
}

void bank_process_local_command(Bank *bank, char *command, size_t len)
{

  //remove newline char
  command[strcspn(command,"\n")]='\0';

  char *comm = strtok(command, " ");
  char *arg1 = strtok(NULL, " ");
  char *arg2 = strtok(NULL, " ");
  char *arg3 = strtok(NULL, " ");
    // TODO: Implement the bank's local commands
  if(strcmp(comm,"create-user")==0) {
     bank_create_user(bank, arg1, arg2, arg3);
   }
   else if(strcmp(comm,"deposit")==0) {
     bank_deposit(bank, arg1,arg2);
   }
   else if(strcmp(comm,"balance")==0) {
     bank_balance(bank, arg1);
   }
   else if(strcmp(comm,"registered")==0) {
     
   }
   else {
     printf("Invalid command\n");
   }
}

void bank_balance(Bank *bank, char *user) {
  if(!user||!isAlpha(user)) {
    printf("Usage: balance <user-name>\n");
  }
  else if(!list_find(bank->userBal,user)) {
    printf("No such user\n");
  }
  else {
    printf("$%s\n", (char*)list_find(bank->userBal,user));
  }
}

void bank_deposit(Bank *bank, char *user, char *bal) {

  int num = isNum(bal);


  long lBal = strtol(bal,NULL,10);
  if(!user||!bal||!isAlpha(user)|| !num) {
    printf("Usage: deposit <user-name> <amt>\n");
  }
  else if(!list_find(bank->userBal,user)) {
    printf("No such user\n");
  }
  else {
    long oldBal = strtol(list_find(bank->userBal,user),NULL,10);
    if(lBal > INT_MAX - oldBal) {
      printf("Too rich for this program\n");
    } 
    else {
      int newBal = ((int) oldBal) + ((int) lBal);
      sprintf(list_find(bank->userBal,user),"%d", newBal);
      printf("$%s added to %s's account\n",bal,user);
    }
    
  }
  
  
}


void bank_create_user(Bank *bank, char *user, char *pin, char *bal) {
 
  if(!(user&&pin&&bal&&isAlpha(user)&&isNum(bal)&&isNum(pin)&&strlen(pin)==4)) {
        printf("Usage: create-user <user-name> <pin> <balance>\n");
   }
   else if(list_find(bank->userBal,user)) {
     printf("Error: user %s already exists\n", user);
   }
   else {
     char *userCpy = malloc(strlen(user));
     char *pinCpy = malloc(strlen(pin));
     char *balCpy = malloc(strlen(bal));
     strcpy(userCpy,user);
     strcpy(pinCpy,pin);
     strcpy(balCpy,bal);
     list_add(bank->userPin, userCpy, pinCpy);
     list_add(bank->userBal, userCpy, balCpy);

     //create card file
     char fname[250];
     sprintf(fname,"./%s.card",user); 
     FILE *fptr = fopen(fname, "w");
     if(!fptr) {
       printf("Error creating card file for user %s\n", user);
       list_del(bank->userPin, user);
       list_del(bank->userBal, user);
     }
     else {
       printf("Created user %s\n", user);
       char userCT[10000];
       char pinCT[10000];

       encrypt(user,strlen(user),bank->key,userCT);
       encrypt(pin,strlen(pin),bank->key,pinCT);

       fprintf(fptr,"%s\n",userCT);
       fprintf(fptr,"%s", pinCT);
       fclose(fptr);
     }
   }
   //fflush(stdout);
}



void bank_process_remote_command(Bank *bank, char *command, size_t len)
{ 
    command[len]=0;
//remove newline char
  command[strcspn(command,"\n")]='\0';
  char *comm = strtok(command, " ");
  char *arg1 = strtok(NULL, " ");
  char *arg2 = strtok(NULL, " ");
 
  if(strcmp(comm,"registered")==0) {
    if(list_find(bank->userBal,arg1)) {
      bank_send(bank,"true",strlen("true"));
    }
    else {
      bank_send(bank,"false",strlen("false"));      
    }
  }
  else if(strcmp(comm,"pin")==0) {
    bank_send(bank,list_find(bank->userPin,arg1),4);
  }
  else if(strcmp(comm,"balance")==0) {
    char *bal = list_find(bank->userBal,arg1);
    bank_send(bank,bal,strlen(bal));
  }
  else if(strcmp(comm,"withdraw")==0) {
    char *bal = list_find(bank->userBal,arg2);
    long lBal = strtol(bal,NULL,10);
    long lAmt = strtol(arg1,NULL,10);
    long newBal = lBal-lAmt;
    sprintf(bal,"%li",newBal);
  }
  else {
    printf("Invalid command\n");
  }	
}
