import fileinput
import hashlib
import base64
import os

with open("hashes.txt") as f, open('output.txt','a') as o:
    hashes = f.readlines()
    if os.stat('output.txt').st_size == 0:
        for line in hashes:
            o.write(line)

#from shutil import copyfile
#copyfile("input2.txt","cracked1.txt")

def compare(str):
    for var in hashes:
        var = var.strip()
        str = str.strip()
        if var == str:
            return True

def process(str):
    str = str.strip()
    var = "CMSC414" + str + "Spring17"
    var1 = base64.b64encode(hashlib.sha3_256(var.encode('utf-8')).digest())

    if compare(var1.decode()):
        with open('output.txt') as f:
            cracked = f.readlines()
            f.close()
        with open('output.txt', 'w') as f:
            for line in cracked:
                if line.strip() == var1.decode():
                    f.write(str+'\n')
                    print('match: cracked' + str)
                else:
                    f.write(line)

    return


for line in fileinput.input():
    process(line)
