/*
  TOCTOU - access() creates window of opportunity for explotation

 */

#include <stdio.h>
#include <unistd.h>  // contains access()
#include <string.h>  // string methods


int main(int argc, char *argv[]) {
  char *atm_file;
  char *bank_file;
  
  // Check number of command line arguments
  if (argc != 1) {
    printf("Usage: init <filename>");
    fflush(stdout);
    return 62;
  }

  // Check if either files already exist
  atm_file = strcat(argv[1],".atm");
  bank_file = strcat(arg[2].".bank");
  if ( (access(atm_file,F_OK) == 0) || (access(bank_file,F_OK) == 0) ) {
    printf("Error: one of the file already exists");
    fflush(stdout);
    return 63;
  }


  // Fails for some other reason
  if (0) {
    
    printf("Error creating initialization files");
    fflush(stdout);
    return 64;
  }




  printf("Successfully initialized bank state");
  fflush(stdout);
  return 0;
}

