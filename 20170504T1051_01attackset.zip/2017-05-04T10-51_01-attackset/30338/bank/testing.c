

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>      // contains isdigit() & isalpha()
#include <limits.h>     // contains INT_MIN & INT_MAX

// old: true=0,false=1;
#define TRUE 1
#define FALSE 0
#define MAX_LENGTH 250




/******************************************************************
 *
 *                             TESTS
 *
 ******************************************************************/
// Valid numbers: ([-]{0,1}[0-9]+)
void test_isNumber() {
  printf("test_isNumber()\n");

  printf("  Valid Inputs:\n");
  printf("    %d : 123\n",isNumber("123"));
  printf("    %d : -1\n",isNumber("-1"));
  printf("    %d : -9000\n",isNumber("-9000"));
  printf("    %d : 2147483647\n", isNumber("2147483647"));
  printf("    %d : -2147483647\n",isNumber("-2147483647"));
  printf("    %d : -9999999999\n",isNumber("-9999999999"));

  printf("  Invalid Inputs:\n");
  printf("    %d : abc123\n", isNumber("abc123"));
  printf("    %d : __abc__\n",isNumber("  abc  "));
  printf("    %d : &^$#@*\n", isNumber("&^$#@*"));
  printf("    %d : 12345!\n", isNumber("12345!"));
  printf("\n");
}

// Test
void test_validUsername() {
  printf("test_validUsername()\n");
  int i;

  const char *valid_names[] = { "jaycarmich","abcdefghijklmn","qwerty",
    "spaceyzzzzzz","hero","longggggggggggggggggggggggggggggggggggggggggg" };
  const char *invalid_names[] = { "12345","jay__5","","jaycarmichael!","   ","  lebron" };

  for (i = 0; i < 6; i++) {
    printf("    %d : %s\n",validUsername(valid_names[i]),valid_names[i]);
    printf("    %d : %s\n",validUsername(invalid_names[i]),invalid_names[i]);    
  }
  printf("\n");
}


/*
 * Test validPin():
 *  - four-digits, [0-9][0-9][0-9][0-9]
 */
void test_validPin() {
  printf("test_validPin()\n");
  int i;

  const char *valid_pins[] = { "1234","9999","0000","2244" };
  const char *invalid_pins[] = { "1","12","123","12345","123a","_123","","abcd" };

  printf("  Valid Inputs:\n");
  for (i = 0; i < 4; i++) {
    printf("    %d : %s\n",validPin(valid_pins[i]),valid_pins[i]);   
  }

  printf("  Invalid Inputs:\n");
  for (i = 0; i < 8; i++) {
    printf("    %d : %s\n",validPin(invalid_pins[i]),invalid_pins[i]);
  }
  printf("\n");
}


/*
 *
 */
void test_validBalance() {
  printf("test_validBalance()\n");
  int i;

  const char *valid_balances[] = { "0","1000","9999","2147483647" };
  const char *invalid_balances[] = { "-1","0a","abc","100000a","-2147483649","2147483648" };

  printf("  Valid Inputs:\n");
  for (i = 0; i < 4; i++) {
    printf("    %d : %s\n",validBalance(valid_balances[i]),valid_balances[i]);
  }

  printf("  Invalid Inputs:\n");
  for (i = 0; i < 6; i++) {
    printf("    %d : %s\n",validBalance(invalid_balances[i]),invalid_balances[i]);
  }
  printf("\n");
}


/*
 *
 */
void test_tooRich() {
  printf("test_tooRich()\n");
  
  printf("  Valid Deposits:\n");
  printf("    %d : 2 = 1+1\n",tooRich("1","1"));
  printf("    %d : 400 = 100+300\n",tooRich("100","300"));
  printf("    %d : 2147483647 = 2147483646+1\n",tooRich("2147483646","1"));
  //printf("    %d : 1+1=2\n",tooRich("1","1"));
  
  printf("  Invalid Deposits:\n");
  printf("    %d : 2147483648 = 2147483646+2\n",tooRich("2147483646","2"));
  printf("    %d : 4294967292 = 2147483646+2147483646\n",tooRich("2147483646","2147483646"));
  //printf("    %d : \n",tooRich("",""));
  //printf("    %d : \n",tooRich("",""));

  printf("\n");
}



/*
 * Staging point for running tests.
 */
void start_tests() {
  test_isNumber();
  test_validUsername();
  test_validPin();
  test_validBalance();
  test_tooRich();
}




/**************************************************************************************
 *
 *                               Validation Functions
 *
 **************************************************************************************/
/*
 * Check for integer ([-]{0,1}[0-9]+)
 *  - non-empty string
 *  - positive or negative 
 *  - all digits [0-9]
 */
int isNumber(char str[]) {
  int i;

  // Check for empty strings
  if (strlen(str) == 0) {
    //printf("empty string!\n");
    return FALSE;
  }

  // Check for first index to be number or minus-sign
  if ( (isdigit(str[0]) == 0) && (str[0] != '-') ) {
    //printf("first index invalid: %c\n",str[0]);
    return FALSE;
  }
  
  // Iterate over each index to check for number
  for (i = 1; i < strlen(str); i++) {
    if (isdigit(str[i]) == 0) {
      //printf("invalid digit: %c\n",str[i]);
      return FALSE;
    }
  }   
   return TRUE;
}


/*
 * Adds deposit to user's balance to check if it overfills
 *  the maximum capacity of the bank - (int type).
 */
int tooRich(char balance[],char deposit[]) {
 long long bal = strtoll(balance,NULL,10);
 long long dep = strtoll(deposit,NULL,10);
 long long total = bal + dep;

 printf(" total: %lld + %lld = %lld\n",bal,dep,total);

 // Check if deposit overfills banks capacity (int)
 if ( (total < 0) || (total > INT_MAX) ) {
   //printf("deposit too large: %lld\n",total);
   return TRUE;
 }
 //printf("valid deposit!\n");
 return FALSE;
}



/**************************************************************************************
 *
 *                               Utility Functions
 *
 **************************************************************************************/
/*
 * Check for valid usernames:
 *  - character limit [1-250] 
 *  - all valid characters [a-zA-Z]
 */
int validUsername(char username[]) {
  int i;

  if (strlen(username) > MAX_LENGTH) {
    //printf("username too long: %d\n",strlen(username));
    return FALSE;
  }
  for (i = 0; i < strlen(username); i++) {
    if (isalpha(username[i]) == 0) {
      //printf("invalid character: %c\n",(char)username[i]);
      return FALSE;
    }
  }
  //printf("valid users!\n");
  return TRUE;
}


/*
 * Check for valid pin number:
 *  - four digit number [0-9][0-9][0-9][0-9]
 */
int validPin(char str[]) {
  int i;

  // Four digits
  if (strlen(str) != 4) {
    //printf("must be 4-digit number: %s\n",str);
    return FALSE;
  }

  // Check for 4-digit number
  for (i = 0; i < 4; i++) {
    if (isdigit(str[i]) == 0) {
      //printf("invalid pin: %s\n",str);
      return FALSE;
    }
  }
  //printf("valid pin!\n");
  return TRUE;
}


/*
 * Check for valid initial balance
 *  - non-negative integer [0-9]+ represented as 'int'
 */
int validBalance(char str[]) {
  long long big = strtoll(str,NULL,10);

  // Check if argument is valid number
  if ( isNumber(str) != TRUE ) {
    //printf("invalid number!\n");
    return FALSE;
  }

  // Check for positive and non-overflow integer
  if ( (big < 0) || (big > INT_MAX) ) {
    //printf("not positive or integer overflow: %lld\n",big);
    return FALSE;
  }
  //printf("valid balance!\n");
  return TRUE;
}


/*
 * Check if user already exists in bank
 */
int userAlreadyExists(char username[]) {
  
  // check here
  printf("unimplemented: userAlreadyExists(username)\n");
  

  return TRUE;
}



/**************************************************************************************
 *
 *                               Command Functions
 *
 **************************************************************************************/
/*
 * Creates the user within bank if inputs are valid and user does not
 *  already exist within the system.
 */
int create_user(char username[],char pin[],char balance[]) {

  // Check for valid inputs and if user already exists
  if ( (!validUsername(username)) || (!validPin(pin)) || (!validBalance(balance)) ) {
    printf("Usage: create-user <user-name> <pin> <balance>\n");
    return FALSE;
  } else if (userAlreadyExists(username)) {
    printf("Error: user %s already exists\n",username);
    return FALSE;
  }

  // 1) add user <user-name> with balance <balance>

  // 2) create file <user-name>.card in current directory
  if (0 /*unable to create file*/) {
    // roll-back any changes made to bank
    printf("Error creating card file for user %s\n",username);
    return FALSE;
  }

  printf("Created user %s\n",username);
  return TRUE;
}


/*
 * Deposits amount into user's account if bank has space.
 */
int deposit(char username[],char amt[]) {
  int money;

  // Check for valid input and if user exists in bank
  if ( (!validUsername(username)) || (!validBalance(amt)) ) {
    printf("Usage: deposit %s %s\n",username,amt);
    return FALSE;
  } else if (!userAlreadyExists(username)) {
    printf("No such user\n");
    return FALSE;
  }

  // Check if depositing this amount would cause integer overflow
  if (tooRich(username,amt)) {
    printf("Too rich for this program\n");
    return FALSE;
  }

  printf("atoi(amt): %d\n",atoi(amt)); 
  printf("atoi(amt)+100: %d\n",(atoi(amt)+100));

  // Deposit amount into user's bank account
  money = atoi(amt) + 100;  // getBalance(username);

  printf("%d added to %s's account\n",money,username);
  return TRUE;
}


/*
 * Retrieves the user's account balance and displays.
 */
int balance(char username[]) {
  int balance;

  // Check for valid input and if user exists
  if (!validUsername(username)) {
    printf("Usage: balance %s\n",username);
    return FALSE;
  } else if (!userAlreadyExists(username)) {
    printf("No such user\n");
    return FALSE;
  }

  // Retrieve user's balance and display
  //balance = 

  printf("$%d\n",balance);
  return TRUE;
}



/******************************************************************
 *
 *                             MAIN
 *
 ******************************************************************/
int main(int argc, char *argv[]) {

  // Run tests
  //start_tests();

  // Command: create-user <user-name> <pin> <balance>
  //create_user(argv[1],argv[2],argv[3]);
  
  // Command: deposit <user-name> <amt>
  deposit(argv[1],argv[2]);

  // Command: balance <user-name>
  //validBalance(argv[1]]);

  return 0;
}




