/*
 * 
 * The main program for the Bank.
 *
 */
#include <string.h>
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>

#include "bank.h"
#include "ports.h"
#include "list.h"
#include "utils.h"

#include <unistd.h>

#define MAX_COMMAND_LENGTH 300



static const char prompt[] = "BANK: ";

int main(int argc, char**argv) {

   int n;
   char sendline[MAX_COMMAND_LENGTH + 1];
   char recvline[MAX_COMMAND_LENGTH + 1];
   char *bankfn = NULL;
   FILE *bankfp;

   // Check if bank file can be opened
   
   
   if((bankfn = (char *)malloc(sizeof(char) * (strlen(argv[1]) + 1))) == NULL) {
     // printf("Malloc error\n");
     return EXIT_FAILURE;
   }

   strncpy(bankfn, argv[1], strlen(argv[1]));
   
   if((bankfp = fopen(bankfn, "r+")) == NULL) {
     printf("Error opening bank initialization file\n");
     return 64;
   }
   


   Bank *bank = bank_create();


   ///////////////////////////////////////////////////
   //char *command = "create-user jaycarmichael 2244 1000";
   //strncpy(recvline,command,strlen(command));

   //bank_process_remote_command(bank,recvline,strlen(recvline));
   //return 0;
   ///////////////////////////////////////////////////   


   //unsigned char cipher[512];

   printf("%s", prompt);
   fflush(stdout);

   while (1) {
     fd_set fds;                   // set of file descriptors 
     FD_ZERO(&fds);                // clears fd_set
     FD_SET(0, &fds);              // add a descriptor too fd_set
     FD_SET(bank->sockfd, &fds);   
     select(bank->sockfd+1, &fds, NULL, NULL, NULL);
     

     memset(sendline, (int)'\0', MAX_COMMAND_LENGTH);
     memset(recvline, (int)'\0', MAX_COMMAND_LENGTH);

     // Handle local command
     if (FD_ISSET(0, &fds)) {
       fgets(sendline,MAX_COMMAND_LENGTH,stdin);

       // printf("local-received: %s\n",sendline); // TODO - testing
       // if (strcmp(sendline,"x") == 0) { return EXIT_SUCCESS; }// TODO - testing

       bank_process_local_command(bank, sendline, strlen(sendline));
       printf("%s", prompt);
       fflush(stdout);

     // Handle remote command
     } else if (FD_ISSET(bank->sockfd, &fds)) {
       n = bank_recv(bank, recvline, MAX_COMMAND_LENGTH);  // length of received data

       bank_process_remote_command(bank, recvline, n);
     }
   }

   return EXIT_SUCCESS;
}
