#include <time.h>
#include <math.h>
#include <unistd.h>

#include "bank.h"
#include "ports.h"
#include "list.h"
#include "hash_table.h"
#include "utils.h"
#include "strmap.h"
#include "rhash/rhash_sha3.h"
#include "crypto.h"


#define MAX_USERS 1000
#define MAX_BAL_DIGITS 10       // # of digits in INT_MAX
#define SALT_LEN 10



/*
 * Check if user already exists in bank.
 */
int userAlreadyExists(Bank *bank,char username[]) {
  if (sm_exists(bank->users,username) == 1) {
    return TRUE;
  }
  return FALSE;
}


char* pin_hash(FILE *cardfp, char *pin, time_t curr_time) {

  sha3_ctx hash_ctx;
  char *saltpin;
  char *saltedpin;
  unsigned char *pinhash;


  if((saltpin = (char *)calloc((SALT_LEN + 1), sizeof(char))) == NULL ||
     (saltedpin = (char *)calloc((SALT_LEN + 4 + 1), sizeof(char))) == NULL ||
     (pinhash = (unsigned char *)calloc((32 + 1), sizeof(unsigned char))) == NULL) {
    return NULL;
  }


  snprintf(saltpin, SALT_LEN, "%lld", (long long) sqrt(curr_time));

  strncpy(saltedpin,saltpin,SALT_LEN);
  strncat(saltedpin,pin,strlen(pin));

  rhash_sha3_256_init(&hash_ctx);
  rhash_sha3_update(&hash_ctx, (const unsigned char *)saltedpin, strlen(saltedpin));
  rhash_sha3_final(&hash_ctx, pinhash);
  
  fprintf(cardfp,"%s\n",saltpin);

  return (char *)pinhash;
}

char* user_hash(FILE *cardfp, char *username, time_t curr_time) {

  sha3_ctx hash_ctx;
  unsigned char *userhash;
  char *saltuser;
  char *salteduser;


  if((saltuser = (char *)calloc((SALT_LEN + 1), sizeof(char))) == NULL ||
     (salteduser = (char *)calloc((SALT_LEN + MAX_LENGTH + 1), sizeof(char))) == NULL ||
     (userhash = (unsigned char *)calloc((32 + 1), sizeof(unsigned char))) == NULL) {
    return NULL;
  }
 

  snprintf(saltuser, SALT_LEN, "%lld", (long long) (curr_time * log(curr_time)));
  strncpy(salteduser,saltuser,SALT_LEN);
  strncat(salteduser,username,MAX_LENGTH);

  rhash_sha3_256_init(&hash_ctx);
  rhash_sha3_update(&hash_ctx, (const unsigned char *)salteduser, strlen(salteduser));
  rhash_sha3_final(&hash_ctx, userhash);
  
  fprintf(cardfp, "%s\n",saltuser);

  return (char *)userhash;


}

int checkPin(Bank *bank, char *username, char *pin) {

  FILE *cardfp;
  char *cardfn;
  char *cardft = ".card";
  char *pinsalt;

  sha3_ctx hash_ctx;
  unsigned char *pinhash;
  char *saltedpin;

  char *truepinhash;

  sleep(2);

  if(validPin(pin) == FALSE || validUsername(username) == FALSE) {
    return FALSE;
  }

  if((cardfn = (char *)calloc(strlen(username) + strlen(cardft) + 1, sizeof(char))) == NULL ||
     (pinsalt = (char *)calloc((32 + 1), sizeof(char))) == NULL) {
    return FALSE;
  }

  strncpy(cardfn, username, strlen(username));
  strncat(cardfn, cardft, strlen(cardft));

  if((cardfp = fopen(cardfn, "r")) == NULL) {
    return FALSE;
  }

  fgets(pinsalt, 32, cardfp);
  *(pinsalt + strlen(pinsalt) - 1) = '\0';


  if((saltedpin = (char *)calloc((SALT_LEN + MAX_LENGTH + 1),sizeof(char))) == NULL ||
     (pinhash = (unsigned char *)calloc((32 + 1), sizeof(unsigned char))) == NULL ||
     (truepinhash = (char *)calloc((32 + 1), sizeof(char))) == NULL) {
    return FALSE;
  }
 
  strncpy(saltedpin,pinsalt,SALT_LEN);
  strncat(saltedpin,pin,4);

  rhash_sha3_256_init(&hash_ctx);
  rhash_sha3_update(&hash_ctx, (const unsigned char *)saltedpin, strlen(saltedpin));
  rhash_sha3_final(&hash_ctx, pinhash);
  

  sm_get(bank->users,username,truepinhash,33);

  return strncmp((char *)pinhash,(char *)truepinhash,32) == 0;
}


char* calc_user_hash(char *username) {
  
  FILE *cardfp;
  char *cardfn;
  char *usersalt;

  sha3_ctx hash_ctx;
  unsigned char *userhash;
  char *salteduser;



  if((cardfn = (char *)calloc((strlen(username) + 5 + 1), sizeof(char))) == NULL ||
     (usersalt = (char *)calloc((32 + 1), sizeof(char))) == NULL) {
    return NULL;
  }

  strncpy(cardfn, username, strlen(username));
  strncat(cardfn, ".card", 5);

  if((cardfp = fopen(cardfn, "r")) == NULL) {
    return NULL;
  }

  fgets(usersalt, 32, cardfp);
  fgets(usersalt, 32, cardfp);
  *(usersalt + strlen(usersalt) - 1) = '\0';


  if((salteduser = (char *)calloc((SALT_LEN + MAX_LENGTH + 1),sizeof(char))) == NULL ||
     (userhash = (unsigned char *)calloc((32 + 1), sizeof(unsigned char))) == NULL) {
    return NULL;
  }
 
  strncpy(salteduser,usersalt,SALT_LEN);
  strncat(salteduser,username,MAX_LENGTH);

  rhash_sha3_256_init(&hash_ctx);
  rhash_sha3_update(&hash_ctx, (const unsigned char *)salteduser, strlen(salteduser));
  rhash_sha3_final(&hash_ctx, userhash);
  

  return (char *)userhash;
}





/**************************************************************************************
 *
 *                               Command Functions
 *
 **************************************************************************************/
/*
 * Creates the user within bank if inputs are valid and user does not
 *  already exist within the system.
 */
int create_user(Bank *bank,char username[],char pin[],char balance[]) {

  FILE *cardfp;
  char *cardfn;
  char *pinhash;
  char *userhash;
  time_t curr_time;

  // Check for valid inputs and if user already exists
  if ( (validUsername(username) == FALSE) || (validPin(pin) == FALSE) || (validBalance(balance) == FALSE) ) {
    printf("Usage: create-user <user-name> <pin> <balance>\n");
    return FALSE;
  } else if (userAlreadyExists(bank,username) == TRUE) {
    printf("Error: user %s already exists\n", username);
    return FALSE;
  }

  /* Create username.card string */
  if((cardfn = (char *)calloc((strlen(username) + 5 + 1), sizeof(char))) == NULL) {
    return FALSE;
  }
  strncpy(cardfn, username, strlen(username));
  strncat(cardfn, ".card", 5);

  // 1) create file <user-name>.card in current directory
  //      - if unable: roll-back changes made to bank
  //           - Roll-back not needed since we check for file creation 
  //             before adding to the hash table
  //    TODO: Not sure if it creates it in the cwd
  if ((cardfp = fopen(cardfn, "w")) == NULL) {
    printf("Error creating card file for user %s\n", username);
    return FALSE;
  }


  // Generate salt based on system time 
  curr_time = time(0);

  if((pinhash = pin_hash(cardfp, pin,curr_time)) == NULL) {
    return FALSE;
  }

  if((userhash = user_hash(cardfp, username,curr_time)) == NULL) {
    return FALSE;
  }


 

  


  // 2) add user <user-name> with balance <balance>
  //    TODO: Modify so that we add a user's salt instead of the pin
  //          Hash nonce+username+salt to use as balances key
  sm_put(bank->users,username,pinhash);
  sm_put(bank->balances,userhash,balance);
  


  printf("Created user %s\n", username);
  fflush(cardfp);
  fclose(cardfp);
  return TRUE;
}


/*
 * Deposits amount into user's account if bank has space.
 *   Watch out for IO, maybe also getBalance() synch
 */
int deposit(Bank *bank,char username[],char amt[]) {
  char *new_balance;
  char *old_balance;
  char *userhash;
  

  // Check for valid input and if user exists in bank
  if ( (validUsername(username) == FALSE) || (validBalance(amt) == FALSE) ) {
    printf("Usage: deposit <user-name> <amt>\n");
    return FALSE;
  } else if (userAlreadyExists(bank,username) == FALSE) {
    printf("No such user\n");
    return FALSE;
  }

  if((old_balance = (char *)malloc(sizeof(char) * (MAX_BAL_DIGITS + 1))) == NULL ||
     (new_balance = (char *)malloc(sizeof(char) * (MAX_BAL_DIGITS + 1))) == NULL ||
     (userhash = (char *)malloc(sizeof(char) * (32 + 1))) == NULL) {
    return FALSE;
  }

  if((userhash = calc_user_hash(username)) == NULL) {
    return FALSE;
  }

  if(sm_get(bank->balances, userhash, old_balance, MAX_BAL_DIGITS + 1) == 0) {
    printf("user hash failed\n");
  }

  // Check if depositing this amount would cause integer overflow
  if (tooRich(old_balance,amt) == TRUE) {
    printf("Too rich for this program\n");
    return FALSE;
  }

  // printf("atoi(amt): %d\n",atoi(amt)); 
  // printf("atoi(amt)+100: %d\n",(atoi(amt)+100));

  // Deposit amount into user's bank account 

  snprintf(new_balance, MAX_BAL_DIGITS, "%d",(atoi(amt) + atoi(old_balance)));

  sm_put(bank->balances, userhash, new_balance);

  printf("$%d added to %s's account\n",atoi(amt),username);
  return TRUE;
}


/*
 * Retrieves the user's account balance and displays.
 */
int balance(Bank *bank,char username[]) {
  char *balance;
  char *userhash;

  // Check for valid input and if user exists
  if (validUsername(username) == FALSE) {
    printf("Usage: balance <user-name>\n");
    return -1;
  } else if (userAlreadyExists(bank,username) == FALSE) {
    printf("No such user\n");
    return -1;
  }

  if((balance = (char*)calloc((MAX_BAL_DIGITS + 1), sizeof(char))) == NULL ||
     (userhash = (char *)calloc((32 + 1), sizeof(char))) == NULL) {
    return -1;
  }
  
  if((userhash = calc_user_hash(username)) == NULL) {
    return -1;
  }

  // Retrieve user's balance and display
  if(sm_get(bank->balances, userhash, balance, MAX_BAL_DIGITS + 1) == 0) {
    return -1;
  }

  return atoi(balance);
}

int withdraw(Bank *bank, char *username, char *amt) {

  char *userhash;
  char *oldbal;
  char *newbal;
  

  if((userhash = calc_user_hash(username)) == NULL) {
    return -1;
  }

  if((oldbal = (char *)calloc(MAX_BAL_DIGITS + 1, sizeof(char))) == NULL ||
     (newbal = (char *)calloc(MAX_BAL_DIGITS + 1, sizeof(char))) == NULL) {
    return -1;
  }

  sm_get(bank->balances,userhash,oldbal,MAX_BAL_DIGITS + 1);

  snprintf(newbal, MAX_BAL_DIGITS, "%d", atoi(oldbal) - atoi(amt));
  
  sm_put(bank->balances,userhash,newbal);

  return TRUE;
  
  
}






/**************************************************************************************
 *
 *                                Receiver Functions
 *
 **************************************************************************************/
Bank* bank_create() {
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL) {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr*)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state and necessary variables
    //////////////////////////////////////////////////////////
 
    // Create hash table to hold users
    bank->users = sm_new(MAX_USERS);
    bank->balances = sm_new(MAX_USERS);
 
    //////////////////////////////////////////////////////////    
    return bank;
}


/*
 * May also need to free list of users.
 */
void bank_free(Bank *bank) {
    if(bank != NULL) {
        close(bank->sockfd);
        free(bank);
	sm_delete(bank->users);
	sm_delete(bank->balances);
    }
}


// Returns the number of bytes sent; negative on error
ssize_t bank_send(Bank *bank, char *data, size_t data_len) {
    return sendto(bank->sockfd,data,data_len,0,
                  (struct sockaddr*)&bank->rtr_addr,sizeof(bank->rtr_addr));
}


/*
 * Returns the number of bytes received; negative on error
 */ 
ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len) {
  /*
  char *key = "123456789";  // Cipher-key
          // Will contain plain-text
  unsigned char cipher[512] = {0};

  // Read cipher-text and determine size
  ssize_t cipher_len = recvfrom(bank->sockfd,cipher,512,0,NULL,NULL);
  printf("cipher:  (%s)\n",cipher);
  printf("cipher_len: %d\n",(int)strlen(cipher));

  unsigned char plain[512] = {0};
  int plain_len = decrypt(cipher,cipher_len+1,key,plain);
  printf("plain_len: %d\n",(int)plain_len);
  printf("decrypted: %s\n",plain);

  fflush(stdout);
  return 1;
  */
  return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}



// TODO: Implement the bank's local commands
void bank_process_local_command(Bank *bank, char *command, size_t len) {

  char *arg1, *arg2, *arg3, *arg4;


  if(*(command + len - 1) == '\n') {
    *(command + len - 1) = '\0';
  }
  arg1 = strtok(command, " ");
  arg2 = strtok(NULL, " ");
  arg3 = strtok(NULL, " ");
  arg4 = strtok(NULL, " ");

  if(strncmp(arg1, "create-user", strlen("create-user")) == 0 &&
     arg2 != NULL && arg3 != NULL && arg4 != NULL) {
    create_user(bank, arg2, arg3, arg4);
  } else if(strncmp(arg1, "deposit", strlen("deposit")) == 0 &&
     arg2 != NULL && arg3 != NULL) {
    deposit(bank, arg2, arg3);
  } else if(strncmp(arg1, "balance", strlen("balance")) == 0 &&
     arg2 != NULL) {
    printf("$%d\n",balance(bank, arg2));
  } else {
    printf("Invalid command\n");
  }

}


// TODO: Implement the bank side of the ATM-bank protocol
/*
* The following is a toy example that simply receives a
* string from the ATM, prepends "Bank got: " and echoes 
* it back to the ATM before printing it to stdout.
*/
void bank_process_remote_command(Bank *bank, char *command, size_t len) {

  // printf("Received: %s\n",command);

  // Parse commands based on spaces
  char *arg1, *arg2, *arg3, *arg4;
  
  int response;
  char *msg;


  if(*(command + len - 1) == '\n') {
    *(command + len - 1) = '\0';
  }

  // Get first command
  arg1 = strtok(command," ");
  arg2 = strtok(NULL," ");
  arg3 = strtok(NULL," ");
  arg4 = strtok(NULL," ");
  // printf("parsed: (%s,%s,%s,%s)\n",arg1,arg2,arg3,arg4);

  if((msg = (char *)calloc(2, sizeof(char))) == NULL) {
    return;
  }



  if ( strncmp(arg1,"userAlreadyExists",strlen("userAlreadyExists")) == 0 &&
       arg2 != NULL) {
    response = userAlreadyExists(bank,arg2);
    snprintf(msg, sizeof(int), "%d", response);
    bank_send(bank, msg, strlen(msg));

  } else if ( strncmp(arg1,"checkPin",strlen("checkPin")) == 0 &&
       arg2 != NULL && arg3 != NULL) {
    response = checkPin(bank,arg2,arg3);
    snprintf(msg, sizeof(int), "%d", response);
    bank_send(bank, msg, strlen(msg));

  } else if ( strncmp(arg1,"withdraw",strlen("withdraw")) == 0) {
    withdraw(bank, arg2, arg3);

  } else if ( strncmp(arg1,"balance",strlen("balance")) == 0 &&
       arg2 != NULL) {
    response = balance(bank,arg2);
    snprintf(msg, sizeof(int) * (MAX_BAL_DIGITS + 1), "%d", response);
    bank_send(bank, msg, strlen(msg));
  
    // other
  } else {
    printf("Invalid command\n");
  }
}





