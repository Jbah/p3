


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "utils.h"

#define OK 0
#define ERR_ARGS 16
#define ERR_USAGE 62
#define ERR_FILE_EXISTS 63
#define ERR_INIT 64
#define ANSI_F_SLASH 47




int MALLOC_STR(char **str, int strlen) {
        if(*str != NULL) {
                return ERR_ARGS;
        }

        if((*str = (char *)malloc(sizeof(char) * (strlen + 1))) == NULL) {
                printf("Error creatiing initialization files\n");
                return ERR_INIT;
        }
        return OK;
}



int parse_filepath(char *fullpath, char **bankfp, char **atmfp) {
	char *last_fslash = NULL;		// Last forward slash in input filepath
	char *bfiletype = ".bank";		// To append		
	char *afiletype = ".atm";		
	int fp_length;					// Lengths of strings
	int bft_length;
	int aft_length;

	fp_length = strlen(fullpath);
	bft_length = strlen(bfiletype);
	aft_length = strlen(afiletype);

	if(MALLOC_STR(&last_fslash, 1) != OK) {
		return ERR_INIT;
	}

	/* Find that last slash */
	last_fslash = strrchr(fullpath, ANSI_F_SLASH);

	/* Check if slash returned something, then if it's the last char */
	/* Accounts for case where directory path is given but not the init-filename
	 * 		Ex. <path2>/
	 */
	if(last_fslash != NULL && *(last_fslash + 1) == '\0') {
		return ERR_ARGS;
	}

	strncpy(*bankfp, fullpath, fp_length);
	strncat(*bankfp, bfiletype, bft_length);
	strncpy(*atmfp, fullpath, fp_length);
	strncat(*atmfp, afiletype, aft_length);

	return OK;
}

int main(int argc, char **argv) {

	char *atmfn = NULL;
	int error = 0;
	int fp_length;
	FILE *bankf;
	FILE *atmf;
	char *filepath = NULL;
	char *bankfn = NULL;

	/* Arg check */
	if(argc != 2) {
		printf("Usage: init <filename>\n");
		return ERR_USAGE;
	}

	fp_length = strlen(argv[1]);

	/* Securely retrieve the input filepath - Check for Buffer Overflow*/
	if(MALLOC_STR(&filepath, fp_length) != OK) {
		return ERR_INIT;
	}
	strncpy(filepath, argv[1], fp_length);

	/* The 5 and 4 come from needing to append ".bank" and ".atm" */
	if(MALLOC_STR(&bankfn, fp_length + 5) != OK  || MALLOC_STR(&atmfn, fp_length + 4) != OK) {
		return ERR_INIT;
	}


	/* Retrieve paths for .bank/.atm files */
	error = parse_filepath(filepath, &bankfn, &atmfn);
	if(error != OK || strlen(bankfn) == 0 || strlen(atmfn) == 0) {
		printf("Error creating initialization files\n");
		return ERR_INIT;
	}



	/* Check if .bank/.atm files exist without opening or creating them */
	if(access(bankfn, F_OK) != -1 || access(atmfn, F_OK) != -1) {
		printf("Error creating initialization files\n");
		return ERR_FILE_EXISTS;
	}

	/* Create .bank/.atm files */
	if((bankf = fopen(bankfn, "w")) == NULL || (atmf = fopen(atmfn, "w")) == NULL) {
		printf("Error creating initialization files\n");
		return ERR_INIT;
	}



	/* TODO: Write crypto stuff to .bank/.atm files */




	printf("Successfully initialized bank state\n");

	fflush(bankf);
	fflush(atmf);
	fclose(bankf);
	fclose(atmf);


	return OK;
}
