
#ifndef UTILS_H
#define UTILS_H

#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include <stdio.h>
#include <ctype.h>      // contains isdigit() & isalpha()
#include <limits.h>     // contains INT_MIN & INT_MAX

#define TRUE 1
#define FALSE 0
#define MAX_LENGTH 250


int isNumber(char str[]);
int tooRich(char balance[],char deposit[]);
int validUsername(char username[]);
int validPin(char str[]);
int validBalance(char str[]);

#endif
