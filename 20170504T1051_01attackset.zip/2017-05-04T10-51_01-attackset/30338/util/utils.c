

#include "utils.h"


/*
 * Check for integer ([-]{0,1}[0-9]+)
 *  - non-empty string
 *  - positive or negative 
 *  - all digits [0-9]
 */
int isNumber(char str[]) {
  int i;

  // Check for empty strings
  if (strlen(str) == 0) {
    //printf("empty string!\n");
    return FALSE;
  }

  // Check for first index to be number or minus-sign
  if ( (isdigit(str[0]) == 0) && (str[0] != '-') ) {
    //printf("first index invalid: %c\n",str[0]);
    return FALSE;
  }
  
  // Iterate over each index to check for number
  for (i = 1; i < strlen(str); i++) {
    if (isdigit(str[i]) == 0) {
      //printf("invalid digit: %c\n",str[i]);
      return FALSE;
    }
  }   
   return TRUE;
}


/*
 * Adds deposit to user's balance to check if it overfills
 *  the maximum capacity of the bank - (int type).
 */
int tooRich(char balance[],char deposit[]) {
 long long bal = strtoll(balance,NULL,10);
 long long dep = strtoll(deposit,NULL,10);
 long long total = bal + dep;

 printf(" total: %lld + %lld = %lld\n",bal,dep,total);

 // Check if deposit overfills banks capacity (int)
 if ( (total < 0) || (total > INT_MAX) ) {
   //printf("deposit too large: %lld\n",total);
   return TRUE;
 }
 //printf("valid deposit!\n");
 return FALSE;
}


/*
 * Another method checking for integer overflows.
 */
int overFlowCheck(char x[],char y[]) {
  int num1, num2, sum;

  num1 = atoi(x);
  num2 = atoi(y);
  sum = num1 + num2;

  if ( (num1 < 0) && (num2 < 0) && (sum > 0) ) {
    return TRUE;
  } else if ( (num1 > 0) && (num2 > 0) && (sum < 0) ) {
    return TRUE;
  } 

  return FALSE;
}


/*
 * Check for valid usernames:
 *  - character limit [1-250] 
 *  - all valid characters [a-zA-Z]
 */
int validUsername(char username[]) {
  int i;

  if (strlen(username) > MAX_LENGTH) {
    //printf("username too long: %d\n",strlen(username));
    return FALSE;
  }
  for (i = 0; i < strlen(username); i++) {
    if (isalpha(username[i]) == 0) {
      //printf("invalid character: %c\n",(char)username[i]);
      return FALSE;
    }
  }
  //printf("valid users!\n");
  return TRUE;
}


/*
 * Check for valid pin number:
 *  - four digit number [0-9][0-9][0-9][0-9]
 */
int validPin(char str[]) {
  int i;

  // Four digits
  if (strlen(str) != 4) {
    //printf("must be 4-digit number: %s\n",str);
    return FALSE;
  }

  // Check for 4-digit number
  for (i = 0; i < 4; i++) {
    if (isdigit(str[i]) == 0) {
      //printf("invalid pin: %s\n",str);
      return FALSE;
    }
  }
  //printf("valid pin!\n");
  return TRUE;
}


/*
 * Check for valid initial balance
 *  - non-negative integer [0-9]+ represented as 'int'
 */
int validBalance(char str[]) {
  long long big = strtoll(str,NULL,10);

  // Check if argument is valid number
  if ( isNumber(str) != TRUE ) {
    //printf("invalid number!\n");
    return FALSE;
  }

  // Check for positive and non-overflow integer
  if ( (big < 0) || (big > INT_MAX) ) {
    //printf("not positive or integer overflow: %lld\n",big);
    return FALSE;
  }
  //printf("valid balance!\n");
  return TRUE;
}
