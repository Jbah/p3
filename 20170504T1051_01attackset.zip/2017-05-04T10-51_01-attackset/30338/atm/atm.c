#include "atm.h"
#include "ports.h"
#include "list.h"
#include "utils.h"
#include "crypto.h"

#include <string.h>
#include <stdlib.h>
#include <unistd.h>



/*
 * Get current user logged into atm or null if none exist.
 */
char* getCurrentUser(ATM *atm) {
  // return atm->currentUser;
  if (atm->currentUser != NULL) {
    return atm->currentUser; 
  }
  return NULL;
}



/*
 * Check if user already exists in bank system.
 */
int userAlreadyExists(ATM *atm, char username[]) {

  ssize_t nbytessent = 0;
  char *command = "userAlreadyExists ";
  char *msg;
  char *response;


  if((msg = (char *)calloc(strlen(command) + strlen(username) + 1, sizeof(char))) == NULL ||
     (response = (char *)calloc(2, sizeof(char))) == NULL) {
    return FALSE;
  }

  strncpy(msg, command, strlen(command));
  strncat(msg, username, strlen(username));

  nbytessent = atm_send(atm, msg, strlen(msg));
  atm_recv(atm, response, 1);

  if(*response == '1') {
    return TRUE;
  }
  
  return FALSE;
}


/**************************************************************************************
 *
 *                               Command Functions
 *
 **************************************************************************************/
/*
 * If possible, makes current user for atm.
 */
int beginSession(ATM *atm,char username[]) {
  char pin[6];
  char *currentUser = atm->currentUser;
  char *command = "checkPin ";
  char *msg;
  char *response;

  // Check if user is already logged in
  if (currentUser != NULL) {
    printf("A user is already logged in\n");
    return FALSE;

  // Check for valid username
  } else if ((username == NULL) || (!validUsername(username))) {
    printf("begin-session <username>\n");
    return FALSE;

  // Check if user exists in database 
  } else if (userAlreadyExists(atm, username) == FALSE) {
    printf("No such user\n");
    return FALSE;
  }

  // One size larger to check for oversized pin entry
  // Problems occur if entire stdin buffer is not read
  printf("PIN? ");
  fgets(pin,6,stdin);
  pin[strcspn(pin,"\n")] = '\0';


  if(pin == NULL || validPin(pin) == FALSE) {
    printf("Not authorized\n");
    return FALSE;
  }

  if((msg = (char *)calloc(strlen(command) + strlen(username) + 1 + 4 + 1, sizeof(char))) == NULL ||
     (response = (char *)calloc(2, sizeof(char))) == NULL) {
    return FALSE;
  }

  strncpy(msg, command, strlen(command));
  strncat(msg, username, strlen(username));
  strncat(msg, " ", 1);
  strncat(msg, pin, 4);

  atm_send(atm, msg, strlen(msg));
  atm_recv(atm, response, 2);
  
  if(*response != '1') {
    printf("Not authorized\n");
    return FALSE;
  }

  // Set the current user of the atm struct
  atm->currentUser = (char*)calloc(strlen(username),sizeof(char));
  strncpy(atm->currentUser,username,strlen(username));
  printf("Authorized\n");  
  return TRUE;
}



/*
 * Displays the current balance of the logged in user.
 */
int balance(ATM *atm) {
  char *command = "balance ";
  char *msg;
  char *response;

  if (atm->currentUser == NULL) {
    printf("No user logged in\n");
    return FALSE;
  }

  // Query bank for user's balance
  if((msg = (char *)calloc(strlen(command) + strlen(atm->currentUser) + 1, sizeof(char))) == NULL ||
     (response = (char *)calloc(10 + 1, sizeof(char))) == NULL) {
    return FALSE;
  }

  strncpy(msg, command, strlen(command));
  strncat(msg, atm->currentUser, strlen(atm->currentUser));

  atm_send(atm,msg,strlen(msg));
  atm_recv(atm,response,11);


  return atoi(response);
}


/*
 * Subtracts withdrawl amount from balance of current user.
 */
int withdraw(ATM *atm,char amt[]) {
  char *command = "withdraw ";
  char *msg;

  // Check if user is logged in
  if (atm->currentUser == NULL) {
    printf("No user logged in\n");
    return FALSE;

  // Check for valid amount to deposit
  } else if ((amt == NULL) || (!validBalance(amt))) {
    printf("Usage: withdraw <amt>\n");
    return FALSE;
  }

  if((msg = (char *)calloc(strlen(command) + strlen(atm->currentUser) + 1 + strlen(amt) + 1, sizeof(char))) == NULL) {
    return FALSE;
  }

  

  // Check if user has sufficient funds
  if (balance(atm) < atoi(amt)) {
    printf("Insufficient funds\n");
    return FALSE;
  }

  // Amount is withdrawn

  strncpy(msg, command, strlen(command));
  strncat(msg, atm->currentUser, strlen(atm->currentUser));
  strncat(msg, " ", 1);
  strncat(msg, amt, strlen(amt));

  atm_send(atm, msg, strlen(msg));

  printf("$%d dispensed\n",atoi(amt));
  return TRUE;
}



/*
 * Ends session of currently logged in user.
 */
int endSession(ATM *atm) {

  if (atm->currentUser == NULL) {
    printf("No user logged in\n");
    return FALSE;
  }

  // Log user out
  free(atm->currentUser);
  atm->currentUser = NULL;
  
  printf("User logged out\n");
  return TRUE;
}




/**************************************************************************************
 *
 *                             Interaction Functions
 *
 **************************************************************************************/
ATM* atm_create() {
  ATM *atm = (ATM*) malloc(sizeof(ATM));
  if(atm == NULL) {
    perror("Could not allocate ATM");
    exit(1);
  }
  
  // Set up the network state
  atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);
  
  bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
  atm->rtr_addr.sin_family = AF_INET;
  atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
  atm->rtr_addr.sin_port=htons(ROUTER_PORT);
  
  bzero(&atm->atm_addr, sizeof(atm->atm_addr));
  atm->atm_addr.sin_family = AF_INET;
  atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
  atm->atm_addr.sin_port = htons(ATM_PORT);
  bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));
  
  // Set up the protocol state
  atm->currentUser = NULL;

  return atm;
}


// May need to free currentUser also
void atm_free(ATM *atm) {
  if(atm != NULL) {
    close(atm->sockfd);
    free(atm);
  }
}



/**************************************************************************************
 *
 *                             Send / Receive Functions
 *
 **************************************************************************************/
// Returns the number of bytes sent; negative on error
ssize_t atm_send(ATM *atm, char *data, size_t data_len) {
  /*
  printf("atm_send(atm,%s,%d)\n",data,data_len);

  // Holds cipher-text 
  unsigned char cipher[512] = {0};
  char *key = "123456789";// TODO - get from atm init file

  unsigned char tag[512] = {0};

  printf("encrypting(%d): %s\n",strlen(data)+1,data);
  int cipher_len = encrypt(data,strlen(data)+1,key,cipher);
  printf("sending encrypted(%d):  (%s)\n",cipher_len,cipher);  //,printhex(cipher,cipher_len));
  
  unsigned char plain[512] = {0};
  int plain_len = decrypt(cipher,cipher_len+1,key,plain);printf("plain_len: %d\n",plain_len);
  printf("testing decrypt: %s\n",plain);
  
  return sendto(atm->sockfd,cipher,cipher_len+1,0,(struct sockaddr*)&atm->rtr_addr,sizeof(atm->rtr_addr));
  */
  return sendto(atm->sockfd,data,data_len,0,(struct sockaddr*)&atm->rtr_addr,sizeof(atm->rtr_addr));
}


// Returns the number of bytes received; negative on error
ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len) {

  // decrypt data

  //return actual message
  return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}



/**************************************************************************************
 *
 *                             Process Function
 *
 **************************************************************************************/
/*
 * TODO: Implement the ATM's side of the ATM-bank protocol
 */
void atm_process_command(ATM *atm,char *command) {


  //atm_send(atm, command, strlen(command));

  // Parse commands based on spaces
  char *arg1, *arg2;
  const char t[2] = " ";

  // Removes trailing (or first occurence) of newline
  command[strcspn(command,"\n")] = '\0';

  // Get first command
  arg1 = strtok(command,t);
  arg2 = strtok(NULL,t);
  //printf("parsed: (%s,%s,%s,%s)\n",arg1,arg2,arg3,arg4);

  // Check for empty input
  if (arg1 == NULL) {
    printf("invalid command\n");

  // Command: begin-session <user-name>
  } else if ( strncmp(arg1,"begin-session",strlen("begin-session")) == 0 ) {
    beginSession(atm,arg2);

  // Command: withdraw <atm>
  } else if ( strncmp(arg1,"withdraw",strlen("withdraw")) == 0 ) {
    withdraw(atm,arg2);

  // Command: balance
  } else if ( strncmp(arg1,"balance",strlen("balance")) == 0 ) {
    printf("$%d\n",balance(atm));
  
  // Command: end-session
  } else if (strncmp(arg1,"end-session",strlen("end-session")) == 0) {
    endSession(atm);

    // other
  } else {
    printf("invalid command\n");
  }
}




 /*
    char recvline[10000];
    int n;

    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    fputs(recvline,stdout);
	*/
