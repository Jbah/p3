/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */
#include "atm.h"
#include <stdio.h>
#include <stdlib.h>

#define MAX_COMMAND_LENGTH 300

static const char prompt[] = "ATM: ";


int main() {

  // Adjust this size
  char *user_input;
 
  user_input = (char *)calloc(MAX_COMMAND_LENGTH + 1, sizeof(char));

  ATM *atm = atm_create();
  char *username = NULL;
  
  printf("%s", prompt);
  fflush(stdout);
  
  while (fgets(user_input,300,stdin) != NULL) {
    atm_process_command(atm,user_input);
    username = atm->currentUser;

    if (username != NULL){
      printf("ATM (%s): ",username);
    } else {
      printf("%s",prompt);
    }
    fflush(stdout);
  }
  return EXIT_SUCCESS;
}
