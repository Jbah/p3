#include "atm.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include "util/utilities.h"

ATM* atm_create()
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    atm->sync = 0;

    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        atm->login = 0;
        memset(atm->user,0x00,sizeof(atm->user));
        fclose(atm->fp);
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

void atm_process_command(ATM *atm, char *command)
{
    char *tok, *key;
    long temp;
    char *a1 = malloc(14);
    char a2[251];
    int a3;
    char *end;
    char pin_temp[11];
    char pin[5];
    int i;
    char *sendline = malloc(300);
	char *recvline = malloc(10000);
    char *encrypted = malloc(2048);
    char check[256];
    char buf[17];
    char *salt = malloc(17);
    char *decTest = malloc(300);
    char *dec = malloc(300);//longest recieved value



    
    if(atm->fp == NULL){
         printf("Error opening initialization file\n");
         exit(64);
     }

    if(!atm->login){
        tok = strtok(command, " ");
        if(tok == NULL || strlen(tok)>13){
            printf("Usage: begin-session <user-name>\n");
            return;
        }

        strncpy(a1,tok,strlen(tok));
        //printf("%s\n",tok);

        if(strcmp(a1,"withdraw")==0 || strcmp(a1,"balance")==0 || strcmp(a1,"end-session")==0 )
        {
            printf("No user logged in\n");
            return;
        }

	//printf("%s\n", a1);

        if(strcmp(a1,"begin-session")!=0)
        {
            printf("Usage: begin-session <user-name>\n");
            return;
        }

        tok = strtok(NULL," ");
        if(tok == NULL || strlen(tok)>250){
            printf("Usage: begin-session <user-name>\n");
            return;
        }
        strncpy(a2,tok,250);
        a2[strcspn(a2, "\n")] = 0;
        for(i = 0; i < strlen(a2);i++){
            if(a2[i]<=64 || a2[i]>=123){
                if(a2[i]!='\n'){
                    printf("Invalid command\n");
                    return;
                }
            }
            if(a2[i]>=91 && a2[i]<=96){
                if(a2[i]!='\n'){
                    printf("Invalid command\n");
                    return;
                }
            }
        }
        //printf("%s\n",a2);

        //ATMSEND VERIFICATION FOR user-name
        strncpy(check,a2,250);
        strcat(check,".card");
        //printf("check: %s\n",check);

        if (access(check, F_OK) == -1){
            printf("Unable to access <%s>'s card\n",a2);
            return;
        }

        memset(salt,0x00,sizeof(salt));
        salt = getRandKey();
	    //printf("%s\n", salt);

        strncat(sendline, salt, 16); 
        strncat(sendline, " u ", 3);
    	strncat(sendline, a2, strlen(a2));             
    	//printf("%s\n", sendline);
    	key = fgets(buf, sizeof(buf), atm->fp);
    	//printf("%s\n",key);

    	int n = encrypt(sendline, strlen(sendline) + 1, key, encrypted);
    	atm_send(atm, encrypted, n);
    	n = atm_recv(atm,recvline,10000);
    	decrypt(recvline,n, key, dec);
    	printf("%s\n", dec);
    	//Start here
        decTest = strtok(dec, " \n");
        if(strcmp(decTest, salt)!=0){
            printf("Not authorized\n");
            return;
        }
        memset(decTest,0x00,sizeof(decTest));
        decTest = strtok(NULL," \n");
        if(strcmp(decTest,"v")!=0){
            printf("No such user exists\n");
            return;
        }



        printf("PIN? \n");
        fflush(stdout);
        memset(pin,0x00,sizeof(pin));
        fgets(pin_temp, 10, stdin);
        for(i = 0; i < 4;i++){
            if(pin_temp[i]<=47 || pin_temp[i]>=58){
                printf("Invalid command\n");
                return;
            }
        }

        strncpy(pin,pin_temp,4);

        memset(salt,0x00,sizeof(salt));
        memset(sendline,0x00,sizeof(sendline));
        memset(buf,0x00,sizeof(buf));
        memset(sendline,0x00,sizeof(sendline));
        memset(encrypted,0x00,sizeof(encrypted));
        memset(recvline,0x00,sizeof(recvline));
        memset(dec,0x00,sizeof(dec));
        salt = getRandKey();
        //printf("%s\n", salt);

        strncat(sendline, salt, 16); 
        strncat(sendline, " v ", 3);
        strncat(sendline, a2, strlen(a2));
        strncat(sendline, pin, strlen(pin));             
        //printf("%s\n", sendline);
        key = fgets(buf, sizeof(buf), atm->fp);
        //printf("%s\n",key);

        int n = encrypt(sendline, strlen(sendline) + 1, key, encrypted);
        atm_send(atm, encrypted, n);
        n = atm_recv(atm,recvline,10000);
        decrypt(recvline,n, key, dec);
        printf("%s\n", dec);
        //Start here
        decTest = strtok(dec, " \n");
        if(strcmp(decTest, salt)!=0){
            printf("Not authorized\n");
            return;
        }
        memset(decTest,0x00,sizeof(decTest));
        decTest = strtok(NULL," \n");
        if(strcmp(decTest,"v")!=0){
            printf("Not authorized\n");
            return;
        }
        printf("Authorized\n");
        atm->login = 1;
        strncpy(atm->user, a2, sizeof(a2));

        
        //ATMSEND LOGIN VERIFICATION

    }
    else{
        tok = strtok(command," \n");

        if(tok == NULL || strlen(tok)>13){
            printf("Invalid command\n");
            return;
        }
        //printf("%s%s\n",tok,"kid");

        strncpy(a1,tok,13);
        printf("%s\n",a1);

        if(strcmp(a1,"begin-session")==0)
        {
            printf("A user is already logged in\n");
            return;
        }

        if(strcmp(a1,"withdraw")!=0 && strcmp(a1,"balance")!=0 && strcmp(a1,"end-session")!=0 )
        {
            printf("test");
            printf("Invalid command\n");
            return;
        }

        if(strcmp(a1,"end-session")==0)
        {
            atm->login = 0;
            memset(atm->user,0x00,251);
            printf("User logged out\n");
            return;
        }

        if(strcmp(a1,"balance")==0){
            memset(salt,0x00,sizeof(salt));
            memset(sendline,0x00,sizeof(sendline));
            memset(buf,0x00,sizeof(buf));
            memset(sendline,0x00,sizeof(sendline));
            memset(encrypted,0x00,sizeof(encrypted));
            memset(recvline,0x00,sizeof(recvline));
            memset(dec,0x00,sizeof(dec));
            salt = getRandKey();
            //printf("%s\n", salt);

            strncat(sendline, salt, 16); 
            strncat(sendline, " b ", 3);
            strncat(sendline, a2, strlen(a2));             
            //printf("%s\n", sendline);
            key = fgets(buf, sizeof(buf), atm->fp);
            //printf("%s\n",key);

            int n = encrypt(sendline, strlen(sendline) + 1, key, encrypted);
            atm_send(atm, encrypted, n);
            n = atm_recv(atm,recvline,10000);
            decrypt(recvline,n, key, dec);
            printf("%s\n", dec);
            //Start here
            decTest = strtok(dec, " \n");
            if(strcmp(decTest, salt)!=0){
                printf("Not authorized\n");
                return;
            }
            memset(decTest,0x00,sizeof(decTest));
            decTest = strtok(NULL," \n");
            if(strcmp(decTest,"v")!=0){
                printf("Not authorized\n");
                return;
            }
            memset(decTest,0x00,sizeof(decTest));
            decTest = strtok(NULL," \n");
            printf("$%S",decTest);
        }


        if(strcmp(a1,"withdraw")==0){
            tok = strtok(NULL," ");
            if(tok == NULL || strlen(tok)>10){
                printf("Invalid command\n");
                return;
            }
            //strncpy(str,tok,12)
            for(i = 0; i < strlen(tok);i++){
                if(tok[i]<=47 || tok[i]>=58){
                    if(tok[i]!='\n'){
                        printf("regex: (%c)", tok[i]);
                        printf("Invalid command\n");
                        return;
                    }
                }
            }

            temp = strtol(tok,&end,10);
            if(temp>=2147483648){
                printf("Invalid command\n");
                return;
            }
            sscanf(tok,"%d",&a3);
            printf("%d\n",a3);

            // ATM SEND WITHDRAW TO BANK

            memset(salt,0x00,sizeof(salt));
            memset(sendline,0x00,sizeof(sendline));
            memset(buf,0x00,sizeof(buf));
            memset(sendline,0x00,sizeof(sendline));
            memset(encrypted,0x00,sizeof(encrypted));
            memset(recvline,0x00,sizeof(recvline));
            memset(dec,0x00,sizeof(dec));
            salt = getRandKey();
            //printf("%s\n", salt);

            strncat(sendline, salt, 16); 
            strncat(sendline, " v ", 3);
            strncat(sendline, a2, strlen(a2));
            strncat(sendline, a3, strlen(a3));         
            //printf("%s\n", sendline);
            key = fgets(buf, sizeof(buf), atm->fp);
            //printf("%s\n",key);

            int n = encrypt(sendline, strlen(sendline) + 1, key, encrypted);
            atm_send(atm, encrypted, n);
            n = atm_recv(atm,recvline,10000);
            decrypt(recvline,n, key, dec);
            printf("%s\n", dec);
            //Start here
            decTest = strtok(dec, " \n");
            if(strcmp(decTest, salt)!=0){
                printf("Not authorized\n");
                return;
            }
            memset(decTest,0x00,sizeof(decTest));
            decTest = strtok(NULL," \n");
            if(strcmp(decTest,"v")!=0){
                printf("Not authorized\n");
                return;
            }
            printf("$%d dispensed\n", a3);
        }


    }
	
	void sendMessage(char *mess){

	}



    // TODO: Implement the ATM's side of the ATM-bank protocol

	/*
	 * The following is a toy example that simply sends the
	 * user's command to the bank, receives a message from the
	 * bank, and then prints it to stdout.
	 */

	/*
    char recvline[10000];
    int n;

    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    fputs(recvline,stdout);
	*/
}
