#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <malloc.h>
#include <stdio.h>
#include <util/validate.h>
#include <util/hash_table.h>
#include <util/list.h>
#include <util/encryption.h>

#define KEY_LEN 16

int main(int argc, char *argv[]) {
	int ret = 0;
	int filenameLen;
	char *filename;
	char *bankFilename;
	char *atmFilename;
	FILE *bankFile;
	FILE *atmFile;

	unsigned char key[KEY_LEN];


	if (argc != 2) {
		printf("Usage: init <filename>\n");
		return 62;
	}

	filenameLen = strlen(argv[1]);
	filename = argv[1];

	bankFilename = malloc(filenameLen + 6);
	memcpy(bankFilename, filename, filenameLen);
	memcpy(bankFilename + filenameLen, ".bank", 5);
	bankFilename[filenameLen + 5] = '\0';

	atmFilename = malloc(filenameLen + 5);
	memcpy(atmFilename, filename, filenameLen);
	memcpy(atmFilename + filenameLen, ".atm", 4);
	atmFilename[filenameLen + 4] = '\0';

	if (access(bankFilename, F_OK) != -1 ||
		access(atmFilename, F_OK) != -1) {
		printf("Error: one of the files already exists\n");
		ret = 63;
		goto done;
	}

	bankFile = fopen(bankFilename, "w");
	if (bankFile == NULL) {
		printf("Error creating initialization files\n");
		ret = 64;
		goto done;
	}


	atmFile = fopen(atmFilename, "w");
	if (atmFile == NULL) {
		printf("Error creating initialization files\n");
		ret = 64;
		fclose(bankFile);
		goto done;
	}

	RAND_bytes(key,sizeof(key));

	fprintf(bankFile,"%s",key);
	fprintf(atmFile,"%s",key);

	done:
	free(bankFilename);
	free(atmFilename);
	
	return ret;
}
