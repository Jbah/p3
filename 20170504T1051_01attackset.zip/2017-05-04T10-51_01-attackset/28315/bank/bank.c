#include "bank.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <limits.h>
#include <util/validate.h>
#include <util/hash_table.h>
#include <util/list.h>
#include <util/encryption.h>

#define KEY_LEN 16

Bank* bank_create(unsigned char *key) {
    Bank *bank = (Bank*) malloc(sizeof(Bank));
	memset(bank, '\0', sizeof(Bank));

    if(bank == NULL) {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    memcpy(bank->key, key, KEY_LEN + 1);

    // Set up the protocol state
	bank->accounts = hash_table_create(100); //Allow 100 users
	bank->sessionIds = list_create();
	srand(time(NULL));

    return bank;
}

void bank_free(Bank *bank) {
    if(bank != NULL) {
        close(bank->sockfd);
		
		//TODO

        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len) {
    int encrypted_length;
    int cipher_length;
    int tag_length = 20;
    unsigned char cipher[data_len + 1];
    unsigned char tag[tag_length + 1];
    unsigned char encrypted[data_len + 16 + tag_length + 1];
  
	memset(cipher, '\0', data_len + 1);
	memset(tag, '\0', tag_length + 1);
	memset(encrypted, '\0', data_len + 16 + tag_length + 1);

	bank->stateCounter += 1;
	
	cipher_length = encrypt(data,data_len,bank->key,cipher);
	tag_length = sign(bank->key,cipher,cipher_length,tag);

	memcpy(encrypted,cipher,cipher_length);
	memcpy(encrypted+cipher_length,tag,tag_length);

	encrypted_length = cipher_length + tag_length;

    return sendto(bank->sockfd, encrypted, encrypted_length, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len) {
	ssize_t bytesIn;
	int message_length;
	int cipher_length_d;
	int tag_length_d = 20;
	int tag_length_v = 20;
	unsigned char tag_d[tag_length_d + 1];
	unsigned char tag_v[tag_length_v + 1];
	unsigned char fullMessage[max_data_len];

	memset(tag_d, '\0', tag_length_d + 1);
	memset(tag_v, '\0', tag_length_v + 1);
	memset(fullMessage, '\0', max_data_len + 1);

	bytesIn = recvfrom(bank->sockfd, fullMessage, max_data_len, 0, NULL, NULL);

	cipher_length_d = bytesIn - tag_length_d;
	unsigned char cipher_d[cipher_length_d + 1];
	memset(cipher_d, '\0', cipher_length_d + 1);

	memcpy(cipher_d, fullMessage, cipher_length_d);
	memcpy(tag_d, fullMessage + cipher_length_d, tag_length_d);

	tag_length_v = sign(bank->key, cipher_d, cipher_length_d, tag_v);

	bank->stateCounter += 1;
	if(memcmp(tag_d, tag_v, tag_length_d) == 0){		message_length = decrypt(cipher_d, cipher_length_d, bank->key, data);
	} else {
	  	memcpy(data, "Bad", 3);
	}

	return bytesIn;
}

void create_user(Bank *bank, char *args) {
	if (args == NULL) {
		printf("Usage: create-user <user-name> <pin> <balance>\n");
		return;
	}

	char cardFilename[MAX_USERNAME_LEN + 6];
	char userStr[MAX_USERNAME_LEN];
	char pinStr[MAX_USERNAME_LEN];
	char balanceStr[MAX_USERNAME_LEN];
	char *currArgs = args;
	char *newArgs;

	/* Obtain and validate username */
	if (!Split_Plaintext(userStr, &newArgs, currArgs, ' ') || 
		!Validate_User(userStr))
		goto invalid;

	/* Obtain and validate pin */
	currArgs = newArgs;
	if (!Split_Plaintext(pinStr, &newArgs, currArgs, ' ') ||
		!Validate_Pin(pinStr))
		goto invalid;

	/* Obtain and validate balance*/
	currArgs = newArgs;
	if (strchr(currArgs, ' ') != NULL || !Validate_Amount(currArgs))
		goto invalid;
	strcpy(balanceStr, currArgs);

	/* If valid command & args, check if the user is already in the base */
	if (hash_table_find(bank->accounts, userStr) != NULL) {
		printf("Error: user %s already exists\n", userStr);
		return;
	}

	/* Check if the card file already exists */
	memcpy(cardFilename, userStr, strlen(userStr));
	memcpy(cardFilename + strlen(userStr), ".card", 5);
	cardFilename[strlen(userStr) + 5] = '\0';

	/* Attempt to create a new cardfile */
	struct File *cardFile;
	if (access(cardFilename, F_OK) != -1 || 
		(cardFile = fopen(cardFilename, "wb")) == NULL) {
		printf("Error creating card file for user %s\n", userStr);
		return;
	}

	/* Assign balance for the account */
	Account *account = malloc(sizeof(Account));
	char *temp;
	unsigned long balance = strtoul(balanceStr, &temp, 10);
	account->balance = strtoul(balanceStr, &temp, 10);

	/* Assign pin salt for the account */
	unsigned char salt[PIN_SALT_LEN + 1];
	memset(salt, '\0', PIN_SALT_LEN + 1);
	RAND_bytes(salt, PIN_SALT_LEN);	
	memcpy(account->salt, salt, PIN_SALT_LEN);

	/* Add the account to the table of users */
	hash_table_add(bank->accounts, userStr, account);

	/* Append salt to pin, hash the result, and write the digest to file */
	unsigned char cardStr[5 + PIN_SALT_LEN];
	memcpy(cardStr, pinStr, 4);
	memcpy(cardStr + 4, account->salt, PIN_SALT_LEN);
	cardStr[4 + PIN_SALT_LEN] = '\0';

	unsigned char cardStrDigest[SHA256_DIGEST_LEN + 1];
	hash_text(cardStr, &cardStrDigest);
	fwrite(cardStrDigest, 1, SHA256_DIGEST_LEN, cardFile);
	fclose(cardFile);

	printf("Created user %s\n", userStr);
	return;

	invalid:
	printf("Usage: create-user <user-name> <pin> <balance>\n");
}

void deposit(Bank *bank, char *args) {
	if (args == NULL) {
		printf("Usage: deposit <user-name> <amt>\n");
		return;
	}

	char userStr[MAX_USERNAME_LEN];
	char amountStr[MAX_USERNAME_LEN];
	char *currArgs = args;
	char *newArgs;

	/* Obtain and validate username */
	if (!Split_Plaintext(userStr, &newArgs, currArgs, ' ') || 
		!Validate_User(userStr))
		goto invalid;	

	/* Obtain and validate amount */
	currArgs = newArgs;
	if (strchr(currArgs, ' ') != NULL || !Validate_Amount(currArgs))
		goto invalid;
	strcpy(amountStr, currArgs);

	/* Attempt to find the account */
	Account *account = hash_table_find(bank->accounts, userStr);
	if (account == NULL) {
		printf("No such user\n");
		return;
	}

	/* Attempt to add the new amount to the current balance */
	unsigned long amount = strtoul(amountStr, &newArgs, 10);
	unsigned long newBalance = amount + account->balance;
	if (newBalance > LONG_MAX || newBalance < account->balance) {
		printf("Too rich for this program\n");
		return;
	}

	account->balance = newBalance;
	printf("$%lu added to %s's account\n", amount, userStr);
	return;
	
	invalid:
	printf("Usage: deposit <user-name> <amt>\n");
}

void balance(Bank *bank, char *user) {
	/* Obtain and validate the username */
	if (user == NULL || !Validate_User(user)) {
		printf("Usage: balance <user-name>\n");
		return;
	}	

	/* Attempt to find the account */
	Account *account = hash_table_find(bank->accounts, user);
	if (account == NULL) {
		printf("No such user\n");
		return;
	} 

	printf("$%lu\n", account->balance);
}

/* Case handler for ATM request for begin-session (phase 1) */
void begin_session_prompt_pin(Bank *bank, Message *message) {
	/* Ignore if the bank is already handling some other user, even if
	   that user isn't authenticated yet */
	if (strcmp(bank->user, "") != 0)
		return;

	/* Also ignore if someone is trying to login with a session ID
	   that's already been used. Assume with high prob it's a replay attack */
	char keyAndVal[20];
	sprintf(keyAndVal, "%lu", message->stateCounter);
	if (list_find(bank->sessionIds, keyAndVal) != NULL)
		return;
	
	unsigned char plaintext[MAX_PLAINTEXT_LEN];

	/* Fail if user does not exist in the table */
	if (hash_table_find(bank->accounts, message->user) == NULL) {
		Form_Plaintext(plaintext, message->stateCounter + 1, SENDER_BANK, 
				   	   message->user, BEGIN_SESSION_NO_USER, 0);

	/* Otherwise, prompt for a pin */
	} else {
		strcpy(bank->user, message->user);
		bank->stateCounter= message->stateCounter;
		Form_Plaintext(plaintext, bank->stateCounter + 1, SENDER_BANK, 
					   bank->user, BEGIN_SESSION_PROMPT_PIN, 0);
	}

    bank_send(bank, plaintext, strlen(plaintext));	
}

/* Case handler for ATM request for begin-session (phase 2) */
void begin_session_process_pin(Bank *bank, Message *message) {
	if (strcmp(bank->user, message->user) != 0 && bank->authenticated)
		return;

	/* Assume that ATM is telling bank to purposefully fail */
	if (message->amount > 9999)
		goto mismatch;

	Account *account = hash_table_find(bank->accounts, bank->user);

	/* Retrieve the name of the cardfile */
	char cardFilename[MAX_USERNAME_LEN + 6];
	memcpy(cardFilename, bank->user, strlen(bank->user));
	memcpy(cardFilename + strlen(bank->user), ".card", 5);
	cardFilename[strlen(bank->user) + 5] = '\0';

	/* Retrieve the salted pin */
	unsigned char cardStr[5 + PIN_SALT_LEN];
	sprintf(cardStr, "%04lu%s", message->amount, account->salt);

	/* Compute the hash of the salted pin, see if it matches the cardfile */
	unsigned char cardStrDigest[SHA256_DIGEST_LEN + 1];
	hash_text(cardStr, &cardStrDigest);
	struct File *cardFile;
	if (access(cardFilename, F_OK) == -1 || 
		(cardFile = fopen(cardFilename, "rb")) == NULL) {
		memset(bank->user, '\0', MAX_USERNAME_LEN);
		return;
	}

	unsigned char fileCardStrDigest[SHA256_DIGEST_LEN + 1];
	memset(fileCardStrDigest, '\0', SHA256_DIGEST_LEN + 1);
	fread(fileCardStrDigest, 1, SHA256_DIGEST_LEN, cardFile);
	fclose(cardFile);

	unsigned char plaintext[MAX_PLAINTEXT_LEN];
	memset(plaintext, '\0', MAX_PLAINTEXT_LEN);

	/* If the hashes do not match, notify ATM of mismatch */
	if (strcmp(cardStrDigest, fileCardStrDigest) != 0) {
		mismatch:
		Form_Plaintext(plaintext, bank->stateCounter + 1, SENDER_BANK, 
				   	   bank->user, BEGIN_SESSION_FAIL, 0);
		memset(bank->user, '\0', MAX_USERNAME_LEN);

	/* Otherwise, notify the ATM of the success */
	} else {
		Form_Plaintext(plaintext, bank->stateCounter + 1, SENDER_BANK,
					   bank->user, BEGIN_SESSION_SUCCESS, 0);
		bank->authenticated = 1;

		/* Save the session id */
		char keyAndVal[20];
		sprintf(keyAndVal, "%lu", bank->stateCounter - 2);
		list_add(bank->sessionIds, keyAndVal, keyAndVal);
	}

    bank_send(bank, plaintext, strlen(plaintext));
}

/* Case handler for ATM request for withdraw */
void withdraw(Bank *bank, Message *message) {
	Account *account = hash_table_find(bank->accounts, bank->user);
	unsigned char *plaintext[MAX_PLAINTEXT_LEN];
	
	/* Insufficient funds , notify ATM of failure */
	if (message->amount > account->balance) {
		Form_Plaintext(plaintext, bank->stateCounter + 1, SENDER_BANK, 
					   bank->user, WITHDRAW_FAIL, 0); 	

	/* Decrease balance, notify ATM of success */
	} else {
		Form_Plaintext(plaintext, bank->stateCounter + 1, SENDER_BANK, 
					   bank->user, WITHDRAW_SUCCESS, message->amount); 	
		account->balance -= message->amount;
	}

    bank_send(bank, plaintext, strlen(plaintext));	
}

/* Case handler for ATM request for balance */
void balance_respond(Bank *bank, Message *message) {
	/* Send response to the ATM */
	Account *account = hash_table_find(bank->accounts, bank->user);
	unsigned char *plaintext[MAX_PLAINTEXT_LEN];
	Form_Plaintext(plaintext, bank->stateCounter + 1, SENDER_BANK, 
				   bank->user, BALANCE_SUCCESS, account->balance); 	
    bank_send(bank, plaintext, strlen(plaintext));	
}

/* Case handler for ATM request for end-session */
void end_session(Bank *bank, Message *message) {
	/* Bank logs the user out */
	strcpy(bank->user, "");
	bank->authenticated = 0;
}

/* Calls the appropriate case handler for local bank commands */
void bank_process_local_command(Bank *bank, char *command, size_t len) {
	char commandType[MAX_USERNAME_LEN];
	char *args;
	
	/* Remove newline character */
	char *pos = strchr(command, '\n');
	*pos = '\0';

	/* Try splitting to find command type. If split fails, assume
       that the entirety of the command could be the command type, which 
	   will fail in the respective handler */
	int ret = Split_Plaintext(commandType, &args, command, ' ');
	if (!ret) {
		strcpy(commandType, command);
		args = NULL;
	}

	/* Switch to appropriate case handler */
	if (strcmp(commandType, "create-user") == 0)
		create_user(bank, args);
	else if (strcmp(commandType, "deposit") == 0)
		deposit(bank, args); 
	else if (strcmp(commandType, "balance") == 0)
		balance(bank, args);
	else 
		printf("Invalid command\n");	
}

/* Attempts to verify the signature and decrypt the ciphertext.
   If plaintext is validly structured, call the appropriate case
   handler for the ATM request */
void bank_process_remote_command(Bank *bank, char *command, size_t len) {

	/*TODO: Since command should be of the form Sign(plaintext)|Enc(plaintext), 
      check the signature against the ciphertext. If signature verification succeeds, 
	  decrypt the ciphertext and save it into the plaintext. If signature verification
      fails, just ignore the message (i.e. return from the method). */

	unsigned char plaintext[MAX_PLAINTEXT_LEN];
	memset(plaintext, '\0', MAX_PLAINTEXT_LEN);
	memcpy(plaintext, command, strlen(command));

	Message *message = malloc(sizeof(Message));

	/* Attempt to extract message. Ignore if contents are garbled */
	if (!Extract_Message(plaintext, message)) {
		bank->stateCounter -= 1;
		free(message);
		return;
	}

	/* Ignore if 
	   1) Bank is trying to handle some user, and message with
	      different user or state counter comes in (state counter is
          only meaningful once the bank starts handling a user) 
       2) The sender is not the ATM */ 
	if ((strcmp(bank->user, "") != 0 && (strcmp(bank->user, message->user) != 0
		 || message->stateCounter != bank->stateCounter)) 
		 || message->sender != SENDER_ATM) {
		free(message);
		return;
	}

	if (message->req == BEGIN_SESSION)
		begin_session_prompt_pin(bank, message);
	else if (message->req == BEGIN_SESSION_PROVIDE_PIN)
		begin_session_process_pin(bank, message);
	else if (message->req == WITHDRAW)
		withdraw(bank, message); 
	else if (message->req == BALANCE)
		balance_respond(bank, message);
	else if (message->req == END_SESSION)
		end_session(bank, message);

	free(message);

	//printf("Bank got: %s\n", plaintext);
}
