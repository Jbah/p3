/*
 * The Bank takes commands from stdin as well as from the ATM.  
 *
 * Commands from stdin be handled by bank_process_local_command.
 *
 * Remote commands from the ATM should be handled by
 * bank_process_remote_command.
 *
 * The Bank can read both .card files AND .pin files.
 *
 * Feel free to update the struct and the processing as you desire
 * (though you probably won't need/want to change send/recv).
 */

#ifndef __BANK_H__
#define __BANK_H__

#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <util/hash_table.h>
#include <util/list.h>
#include <util/validate.h>

#define PIN_SALT_LEN 246
#define KEY_LEN 16

typedef struct _Account {
	unsigned long balance;
	char salt[PIN_SALT_LEN];
} Account;

typedef struct _Bank {
    // Networking state
    int sockfd;
    struct sockaddr_in rtr_addr;
    struct sockaddr_in bank_addr;

    unsigned char key[KEY_LEN + 1];

    // Protocol state
	HashTable *accounts;
	List *sessionIds;
	char user[MAX_USERNAME_LEN];
	int authenticated;
	unsigned long stateCounter;
} Bank;

Bank* bank_create(unsigned char *key);
void bank_free(Bank *bank);
ssize_t bank_send(Bank *bank, char *data, size_t data_len);
ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len);
void bank_process_local_command(Bank *bank, char *command, size_t len);
void bank_process_remote_command(Bank *bank, char *command, size_t len);

#endif

