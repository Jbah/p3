#ifndef __ENCRYPTION_H__
#define __ENCRYPTION_H__

#define SHA256_DIGEST_LEN 32

int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key, 
            unsigned char *ciphertext);
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
            unsigned char *plaintext);
int sign(const unsigned char* key, unsigned char* cipher, int cipher_len, 
         unsigned char* tag);
void hash_text(unsigned char *plaintext, unsigned char *digest);
void printhex(unsigned char * hex, int len);

#endif

