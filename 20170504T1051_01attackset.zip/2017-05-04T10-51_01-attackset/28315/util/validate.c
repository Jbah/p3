#include <string.h>
#include <limits.h>
#include <stdlib.h>
#include <unistd.h>
#include <malloc.h>
#include <time.h>
#include <stdio.h>
#include "validate.h"
#include <openssl/dh.h>

/* Attempt to extract the first argument in the plaintext, and 
   save the location of the remainder of the plaintext

   -arg - Address of buffer that will contain first arg
   -remainder - Address of pointer that will point to plaintext remainder
*/
int Split_Plaintext(char *arg, char **remainder, char *plaintext, 
				    char delimiter) {
	/* Fail if no delimiter, or if the delimiter is at the start */
	char *pipeP = strchr(plaintext, delimiter);
	if (pipeP == NULL || pipeP == plaintext) {
		*remainder = NULL;
		return INVALID;
	}

	/* Extract the first arg from the plaintext, and set
       pointer for the remainder of the plaintext */
	int argLen = pipeP - plaintext;
	if (argLen > 250)
		return INVALID;

	memset(arg, '\0', MAX_USERNAME_LEN);
	memcpy(arg, plaintext, argLen);
	*remainder = pipeP + 1;

	return VALID;
}

/* Given a string that supposedly represents a number, returns VALID
   if the string only contains digit characters */
int Digits_Only(char *numStr) {
	int numStrLen = strlen(numStr);
	int asciiVal;
	int i;

	for (i = 0; i < numStrLen; i++) {
		asciiVal = (int)numStr[i];
		if (asciiVal < 48 || asciiVal > 57)
			return INVALID;
	}

	return VALID;
}

/* Given a username, returns VALID if the username only contains
   uppercase/lowercase letters, and has max length of 250 */
int Validate_User(char *user) {
	int userLen = strlen(user);
	if (userLen == 0 || userLen > 250)
		return INVALID;

	int i, asciiVal;
	for (i = 0; i < userLen; i++) {
		asciiVal = (int)user[i];
		if (!((asciiVal >= 65 && asciiVal <= 90) || //Uppercase
			  (asciiVal >= 97 && asciiVal <= 122))) //Lowercase
			return INVALID; 
	}

	return VALID;
}

/* Given a pin string, returns VALID if the pin only
   contains 4 digits */
int Validate_Pin(char *pin) {
	int pinLen = strlen(pin);
	if (pinLen != 4 || !Digits_Only(pin))
		return INVALID;
	return VALID;
}

/* Given an amount string, returns VALID if the amount only
   contains digits, and is within range */
int Validate_Amount(char *amountStr) {
	/* Test for digits only, and reasonable length */
	int amountLen = strlen(amountStr);
	if (amountLen == 0 || amountLen > 10 || !Digits_Only(amountStr))
		return INVALID;

	/* Test for large overflow */
	if (amountLen == 10) {
		char firstDigitStr[2];
		memcpy(firstDigitStr, amountStr, 1);
		firstDigitStr[1] = '\0';

		int firstDigit = atoi(firstDigitStr);	
		if (firstDigit >= 3)
			return INVALID;
	}

	/* Test for minor overflow */
	char *temp;
	unsigned long amount = strtoul(amountStr, &temp, 10);
	if (amount < 0 || amount > LONG_MAX)	
		return INVALID;

	return VALID;
}

/* Given a sender string, returns VALID if the sender only contains 
   digits, and is in range of the senders */
int Validate_Sender(char *sender) {
	int senderLen = strlen(sender);
	if (senderLen != 1 || !Digits_Only(sender))
		return INVALID;
	if (atoi(sender) >= MAX_SENDER)
		return INVALID;
	return VALID;
}

/* Given a request string, returns VALID if the request only contains 
   digits, and is in range of the requests */
int Validate_Request(char *req) {
	int reqLen = strlen(req);
	if (reqLen == 0 || reqLen > 2 || !Digits_Only(req))
		return INVALID;
	if (atoi(req) >= MAX_REQUEST)
		return INVALID;
	return VALID;
}

/* Given the arguments to a Message, returns VALID if 
   each of the arguments satisfies their respective conditions */
int Validate_Args(unsigned long stateCounter, enum Sender sender,
				  char *user, enum Request req, unsigned long amount) {
	/* Validate state counter */
	if (stateCounter < 0)
		return INVALID;

	/* Validate sender */
	if (sender < 0 || sender >= MAX_SENDER)
		return INVALID;

	/* Validate username */
	if (!Validate_User(user))
		return INVALID;

	/* Validate request */
	if (req < 0 || req >= MAX_REQUEST)
		return INVALID;

	/* Validate amount */
	if (amount < 0 || amount > LONG_MAX)
		return INVALID;

	return VALID;
}

/* Given Message arguments that must be encapsulated within a packet, 
   forms a plaintext out of those arguments. Returns VALID if 
   each of the arguments fulfills their respective conditions 

   -plaintext - location of buffer to write plaintext to */
int Form_Plaintext(unsigned char *plaintext, unsigned long stateCounter, 	
				   enum Sender sender, char *user, enum Request req, 
				   unsigned long *amount) {
	/* Form plaintext <stateCounter>|<sender>|<user>|<req>|<amount>|<salt> */
	unsigned char salt[201];
	memset(salt, '\0', 201);
	RAND_bytes(salt, 200);
	memset(plaintext, '\0', MAX_PLAINTEXT_LEN);
	sprintf(plaintext, "%lu|%d|%s|%d|%lu|%s", stateCounter, sender, 
			user, req, amount, salt);
	return VALID;
}

/* Given a plaintext, attempts to extract the arguments out of the 
   plaintext and fill the Message with the arguments. Returns VALID
   if the plaintext was validly structured and contains valid arguments 

   -plaintext - plaintext to check structure and validity of
   -message - location of Message struct to fill in */
int Extract_Message(unsigned char *plaintext, Message *message) {
	/* Fields that will allow extraction of args from plaintext */
	char *currPlaintext = plaintext;
	char *newPlaintext;
	char arg[MAX_USERNAME_LEN];
	char args[MAX_USERNAME_LEN * 5];
	char user[MAX_USERNAME_LEN];

	/* Obtain the arguments of the plaintext, disregard salt */
	int i;
	for (i = 0; i < 5; i++) {
		/* Fail if pipe at bad position, or number arg contains non-digits */
		if (!Split_Plaintext(arg, &newPlaintext, currPlaintext, '|') || 
			(i != 2 && !Digits_Only(arg))) {
			return INVALID;
		}	
		strcpy(&args[i * MAX_USERNAME_LEN], arg);
		currPlaintext = newPlaintext;	
	}
	
	/* Construct the args that will form the Message */
	char *temp;
	unsigned long stateCounter = strtoul(&args[0], &temp, 10);
	enum Sender sender = atoi(&args[1 * MAX_USERNAME_LEN]);
	strcpy(user, &args[2 * MAX_USERNAME_LEN]);
	enum Request req = atoi(&args[3 * MAX_USERNAME_LEN]);
	unsigned long amount = strtoul(&args[4 * MAX_USERNAME_LEN], &temp, 10);

	/* Validate the args */
	if (!Validate_Args(stateCounter, sender, user, req, amount))
		return INVALID;

	/* Finally, construct the Message */
	memset(message, '\0', sizeof(Message));
	message->stateCounter = stateCounter;
	message->sender = sender;
	strcpy(message->user, user);
	message->req = req;
	message->amount = amount;

	return VALID;
}

void Print_Message(Message *message) {
	printf("State counter: %lu\n", message->stateCounter);
	printf("Sender: %u\n", message->sender);
	printf("User: %s\n", message->user);
	printf("Request: %u\n", message->req);
	printf("Amount: %lu\n", message->amount);
}

/* --------------------------------------------------------
   Example of usage
   -------------------------------------------------------- */

/*
	unsigned int stateCounter = 200;
	enum Sender sender = SENDER_BANK;
	char *user = malloc(MAX_USERNAME_LEN);
	enum Request req = BEGIN_SESSION;
	unsigned int amount = 0;

	strcpy(user, "Alice");

	char *plaintext = malloc(600);
	memset(plaintext, '\0', 600);
	Form_Plaintext(plaintext, stateCounter, sender, user, req, amount);
	printf("Plaintext: %s\n", plaintext);
	
	Message *message = malloc(sizeof(Message));
	Extract_Message(plaintext, message);	
	Print_Message(message);

	free(user);
	free(plaintext);
	free(message);
*/
