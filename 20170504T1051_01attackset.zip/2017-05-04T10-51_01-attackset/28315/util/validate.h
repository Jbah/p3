#ifndef __VALIDATE_H__
#define __VALIDATE_H__

#include <openssl/dh.h>

#define MAX_PLAINTEXT_LEN 1000
#define MAX_CIPHERTEXT_LEN 1000
#define MAX_USERNAME_LEN 250
#define INVALID 0
#define VALID 1

enum Request {
	BEGIN_SESSION,	
	BEGIN_SESSION_NO_USER,
	BEGIN_SESSION_PROMPT_PIN,
	BEGIN_SESSION_PROVIDE_PIN,
	BEGIN_SESSION_SUCCESS,
	BEGIN_SESSION_FAIL,

	WITHDRAW,
	WITHDRAW_SUCCESS,
	WITHDRAW_FAIL,		

	BALANCE,
	BALANCE_SUCCESS,

	END_SESSION,

	MAX_REQUEST //Num of valid Requests
};

enum Sender {
	SENDER_ATM,
	SENDER_BANK,

	MAX_SENDER	//Num of valid Senders
};

typedef struct {
	unsigned long stateCounter;
	enum Sender sender;
	char user[MAX_USERNAME_LEN + 1];
	enum Request req;
	unsigned long amount;
} Message; 

int Split_Plaintext(char *arg, char **remainder, char *plaintext, 
				    char delimiter);
int Digits_Only(char *numStr);
int Validate_User(char *user);
int Validate_Pin (char *pin);
int Validate_Amount(char *amountStr);
int Validate_Sender(char *sender);
int Validate_Request(char *req);
int Validate_Args(unsigned long stateCounter, enum Sender sender,
				  char *user, enum Request req, unsigned long amount);
int Form_Plaintext(unsigned char *plaintext, unsigned long stateCounter, 
				   enum Sender sender, char *user, enum Request req, 
				   unsigned long *amount);
int Extract_Message(unsigned char *plaintext, Message *message);
void Print_Message(Message *message);

#endif


