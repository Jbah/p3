/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>

#define KEY_LEN 16

static const char prompt[] = "ATM: ";

int main(int argc, char**argv) {
    char user_input[1000];
    char key[KEY_LEN + 1];
    FILE *atmFile;
    char *atmFilename;

    /* Attempt to open the atm file */
	atmFilename = argv[1];
	atmFile = fopen(atmFilename, "r");
	if (atmFile == NULL) {
		printf("Error opening ATM initialization file\n");
		return 64;
	}

	memset(key, '\0', KEY_LEN + 1);
	fgets(key, KEY_LEN + 1,atmFile);

    memset(user_input, '\0', 1000);

    ATM *atm = atm_create(key);

    printf("%s", prompt);
    fflush(stdout);

    while (fgets(user_input, 1000,stdin) != NULL) {
        atm_process_command(atm, user_input);
		if(strcmp(atm->user, "") != 0 && atm->authenticated)
			printf("ATM (%s): ", atm->user);
		else
			printf("%s", prompt);
        fflush(stdout);
		memset(user_input, '\0', 1000);
    }

	return EXIT_SUCCESS;
}
