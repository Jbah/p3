#include "atm.h"
#include "ports.h"
#include <limits.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <util/validate.h>
#include <util/hash_table.h>
#include <util/list.h>
#include <util/encryption.h>

#define KEY_LEN 16

ATM* atm_create(unsigned char *key) {
    ATM *atm = (ATM*) malloc(sizeof(ATM));
	memset(atm, '\0', sizeof(ATM));

    if(atm == NULL) {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    memcpy(atm->key, key, KEY_LEN + 1);

    return atm;
}

void atm_free(ATM *atm) {
    if(atm != NULL) {
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len) {
	int encrypted_length;
	int cipher_length;
	int tag_length = 20;
	int message_length;
	unsigned char cipher[data_len + 1];
	unsigned char tag[tag_length + 1];
	unsigned char encrypted[data_len + 16 + tag_length + 1];

	memset(cipher, '\0', data_len + 1);
	memset(tag, '\0', tag_length + 1);
	memset(encrypted, '\0', data_len + 16 + tag_length + 1);

	atm->stateCounter += 1;
		
	cipher_length = encrypt(data,data_len,atm->key,cipher);
	tag_length = sign(atm->key,cipher,cipher_length,tag);

	memcpy(encrypted,cipher,cipher_length);
	memcpy(encrypted+cipher_length,tag,tag_length);

	encrypted_length = cipher_length + tag_length;

    return sendto(atm->sockfd, encrypted, encrypted_length, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len) {
	ssize_t bytesIn;
	int message_length;
	int cipher_length_d;
	int tag_length_d = 20;
	int tag_length_v = 20;
	unsigned char tag_d[tag_length_d + 1];
	unsigned char tag_v[tag_length_v + 1];
	unsigned char fullMessage[max_data_len];

	memset(tag_d, '\0', tag_length_d + 1);
	memset(tag_v, '\0', tag_length_v + 1);
	memset(fullMessage, '\0', max_data_len + 1);

	bytesIn = recvfrom(atm->sockfd, fullMessage, max_data_len, 0, NULL, NULL);

	cipher_length_d = bytesIn - tag_length_d;
	unsigned char cipher_d[cipher_length_d + 1];
	memset(cipher_d, '\0', cipher_length_d + 1);

	memcpy(cipher_d, fullMessage, cipher_length_d);
	memcpy(tag_d, fullMessage + cipher_length_d, tag_length_d);
	
	tag_length_v = sign(atm->key,cipher_d,cipher_length_d,tag_v);

	atm->stateCounter += 1;
	if(memcmp(tag_d, tag_v, tag_length_d) == 0){
	  	message_length = decrypt(cipher_d, cipher_length_d, atm->key, data);		
	} else {
	  	memcpy(data, "Bad", 3);
	}

	return bytesIn;
}

/* Given a bank response, verify the signature and decrypt
   into the plaintext */
void Verify_And_Decrypt(unsigned char *plaintext, unsigned char *bankResponse) {
	/*TODO: Since bankResponse should be of the form Sign(plaintext)|Enc(plaintext), 
      check the signature against the ciphertext. If signature verification succeeds, 
	  decrypt the ciphertext and save it into the plaintext. If signature verification
      fails, then save the plaintext as "" (my code will take care of the rest) */

	strcpy(plaintext, bankResponse);
}

/* Will loop and wait for a valid message to come in. A valid message
   is validly structured, and contains the expected state counter, 
   sender, user, and request (response type). All other messages
   are ignored, as they will be treated as attacks */
Message *Wait_For_Valid_Message(ATM *atm, unsigned char *plaintext, 
							    enum Request req1, enum Request req2) {
	int success = 0;
	unsigned char bankResponse[MAX_CIPHERTEXT_LEN];

	Message *message = malloc(sizeof(Message));
	while (!success) {
		memset(plaintext, '\0', MAX_PLAINTEXT_LEN);
		memset(bankResponse, '\0', MAX_CIPHERTEXT_LEN);
		atm_recv(atm, bankResponse, MAX_CIPHERTEXT_LEN);

		/* State counter should only stay increased for a valid
		   message */
		Verify_And_Decrypt(plaintext, bankResponse);
		if (Extract_Message(plaintext, message) && 
			strcmp(message->user, atm->user) == 0 &&
			message->stateCounter == atm->stateCounter && 
			message->sender == SENDER_BANK && 
			(message->req == req1 || message->req == req2))
			success = 1;
		else
			atm->stateCounter -= 1;

		/*
		printf("message->user: %s\n", message->user);
		printf("message->stateCounter: %lu\n", message->stateCounter);
		printf("user: %s\n", atm->user);
		printf("state counter: %lu\n", atm->stateCounter); */
	}

	//printf("%s\n", plaintext);
	return message;
}

/* Handler for begin-session */
void begin_session(ATM *atm, char *user) {
	/* Check if a user is already logged in */
	if (strcmp(atm->user, "") != 0 && atm->authenticated) {
		printf("A user is already logged in\n");
		return;
	}

	/* Obtain and validate username */
	if (user == NULL || !Validate_User(user)) {
		printf("Usage: begin-session <user-name>\n");
		return;
	}

	/* Generate a pseudorandom state counter */
	int numIters = ULONG_MAX / SHRT_MAX - 1;	
	int i;
	unsigned long stateCounter = 0;
	for (i = 0; i < numIters; i++)
		stateCounter += rand();
	
	atm->stateCounter = stateCounter;

	/* --------Send initial login request to the bank---------- */
	unsigned char plaintext[MAX_PLAINTEXT_LEN];
	Form_Plaintext(plaintext, atm->stateCounter + 1, SENDER_ATM, 
				   user, BEGIN_SESSION, 0); 	
    atm_send(atm, plaintext, strlen(plaintext));	
		
	int receivedBankMessage = 0;
	unsigned char ciphertext[MAX_CIPHERTEXT_LEN];
	memset(ciphertext, '\0', MAX_CIPHERTEXT_LEN);

	/* ---------------- Get response from the bank ---------------- */
	strcpy(atm->user, user);
	Message *message = Wait_For_Valid_Message(atm, plaintext, 
		BEGIN_SESSION_NO_USER, BEGIN_SESSION_PROMPT_PIN);

	/* Fail if the bank has no such user */
	if (message->req == BEGIN_SESSION_NO_USER) {
		printf("No such user\n");
		memset(atm->user, '\0', MAX_USERNAME_LEN);
		free(message);
		return;
	} 

	/* Verify that the card file exists and can be opened */
	char cardFilename[strlen(user) + 6];	
	memcpy(cardFilename, user, strlen(user));
	memcpy(cardFilename + strlen(user), ".card", 5);
	cardFilename[strlen(user) + 5] = '\0';

	struct File *cardFile;
	if (access(cardFilename, F_OK) == -1 ||
		(cardFile = fopen(cardFilename, "r")) == NULL) {
		printf("Unable to access %s's card\n", user);
		memset(atm->user, '\0', MAX_USERNAME_LEN);
		free(message);
		return;
	}

	/* Ask for pin, and validate format */
	printf("PIN? ");
    fflush(stdout);

	char pin[1000];
	fgets(pin, 1000,stdin);
	char *pos = strchr(pin, '\n');
	*pos = '\0';
	
	/* If invalid pin, purposefully fail, so that bank can reset too */
	if (!Validate_Pin(pin))
		strcpy(pin, "10000");

	/* ---------------------Send pin to bank----------------- */
	Form_Plaintext(plaintext, atm->stateCounter + 1, SENDER_ATM, 
				   user, BEGIN_SESSION_PROVIDE_PIN, (unsigned long)atoi(pin)); 	
    atm_send(atm, plaintext, strlen(plaintext));	

	/* ---------------- Get response from the bank ---------------- */
	free(message);
	message = Wait_For_Valid_Message(atm, plaintext, 
		BEGIN_SESSION_FAIL, BEGIN_SESSION_SUCCESS);
	
	if (message->req == BEGIN_SESSION_FAIL) {	
		printf("Not authorized\n");
		memset(atm->user, '\0', MAX_USERNAME_LEN);
	} else {
		printf("Authorized\n");
		atm->authenticated = 1;
	}

	free(message);
}

/* Handler for withdraw */
void withdraw(ATM *atm, char *amountStr) {
	/* Verify that some user is logged in */
	if (strcmp(atm->user, "") == 0 || !atm->authenticated) {
		printf("No user logged in\n");
		return;
	}

	/* Verify that the amount is valid */
	if (amountStr == NULL || !Validate_Amount(amountStr)) {
		printf("Usage: withdraw <amt>\n");
		return;
	}	

	/* ---------------Send withdraw to the bank----------------- */
	char *temp;
	unsigned char *plaintext[MAX_PLAINTEXT_LEN];
	unsigned long amount = strtoul(amountStr, &temp, 10);
	Form_Plaintext(plaintext, atm->stateCounter + 1, SENDER_ATM, 
				   atm->user, WITHDRAW, amount); 	
    atm_send(atm, plaintext, strlen(plaintext));	

	/* ---------------Retrieve response from the bank--------------- */
	Message *message = Wait_For_Valid_Message(atm, plaintext, 
		WITHDRAW_FAIL, WITHDRAW_SUCCESS);

	if (message->req == WITHDRAW_SUCCESS)
		printf("$%lu dispensed\n", message->amount);
	else 
		printf("Insufficient funds\n");

	free(message);	
}

/* Handler for balance */
void balance(ATM *atm, char *args) {
	/* Verify that some user is logged in */
	if (strcmp(atm->user, "") == 0 || !atm->authenticated) {
		printf("No user logged in\n");
		return;
	}

	if (args != NULL) {
		printf("Usage: balance\n");
		return;
	}

	/* ---------------Send balance request to the bank----------------- */
	unsigned char *plaintext[MAX_PLAINTEXT_LEN];
	Form_Plaintext(plaintext, atm->stateCounter + 1, SENDER_ATM, 
				   atm->user, BALANCE, 0); 	
    atm_send(atm, plaintext, strlen(plaintext));	

	/* ---------------Retrieve response from the bank--------------- */
	Message *message = Wait_For_Valid_Message(atm, plaintext, 
		BALANCE_SUCCESS, BALANCE_SUCCESS);
	printf("$%lu\n", message->amount);
	free(message);
}

/* Handler for end-session */
void end_session(ATM *atm, char *args) {
	/* Verify that some user is logged in */
	if (strcmp(atm->user, "") == 0 || !atm->authenticated) {
		printf("No user logged in\n");
		return;
	}

	if (args != NULL) {
		printf("Usage: end-session\n");
		return;
	}

	/* ---------------Inform bank that user is logging out--------- */
	unsigned char *plaintext[MAX_PLAINTEXT_LEN];
	Form_Plaintext(plaintext, atm->stateCounter + 1, SENDER_ATM, 
				   atm->user, END_SESSION, 0); 	
    atm_send(atm, plaintext, strlen(plaintext));	

	/* ATM logs out */
	strcpy(atm->user, "");
	atm->authenticated = 0;
}

/* Hub that will switch to the appropriate case handler for command type */
void atm_process_command(ATM *atm, char *command) {
	char commandType[MAX_USERNAME_LEN];
	char *args;
	
	/* Remove newline character */
	char *pos = strchr(command, '\n');
	*pos = '\0';

	/* Try splitting to find command type. If split fails, assume
       that the entirety of the command could be the command type, which 
	   will fail in the respective handler */
	int ret = Split_Plaintext(commandType, &args, command, ' ');
	if (!ret) {
		strcpy(commandType, command);
		args = NULL;
	}

	/* Switch to appropriate case handler */
	if (strcmp(commandType, "begin-session") == 0)
		begin_session(atm, args);
	else if (strcmp(commandType, "withdraw") == 0)
		withdraw(atm, args);
	else if (strcmp(commandType, "balance") == 0)
		balance(atm, args);
	else if (strcmp(commandType, "end-session") == 0)
		end_session(atm, args);
	else
		printf("Invalid command\n");
}
