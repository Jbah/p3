#include "atm.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <limits.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/rsa.h>
#include <openssl/evp.h>
#include <openssl/bio.h>
#include <openssl/err.h>

ATM* atm_create()
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    atm->in_sess = 0;
    atm->tries = 0;
    return atm;
}

void atm_get_keys(ATM *atm) {
    int i;
    char* line = NULL;
    size_t len = 0;
    atm->bank_pub = malloc(4096);
    atm->priv_k = malloc(4096);
    memset(atm->bank_pub, 0, 4096);
    memset(atm->priv_k, 0, 4096);
    for (i = 0; i < 27; i++) {
        getline(&line, &len, atm->keys);
        strncat(atm->priv_k, line, len);
    }
    for (i = 0; i < 9; i++) {
        getline(&line, &len, atm->keys);
        strncat(atm->bank_pub, line, len);
    }
}

RSA* createRSA(unsigned char * key,int public)
{
    RSA *rsa= NULL;
    BIO *keybio ;
    keybio = BIO_new_mem_buf(key, -1);
    if (keybio==NULL)
    {
        printf( "Failed to create key BIO");
        return 0;
    }
    if(public)
    {
        rsa = PEM_read_bio_RSA_PUBKEY(keybio, &rsa,NULL, NULL);
    }
    else
    {
        rsa = PEM_read_bio_RSAPrivateKey(keybio, &rsa,NULL, NULL);
    }
    if(rsa == NULL)
    {
        printf( "Failed to create RSA");
    }
 
    return rsa;
}

int public_encrypt(unsigned char * data,int data_len,unsigned char * key, unsigned char *encrypted)
{
    RSA * rsa = createRSA(key,1);
    int result = RSA_public_encrypt(data_len,data,encrypted,rsa,RSA_PKCS1_PADDING);
    return result;
}

char random_char() {
    return 'A' + (random() %26);
}

int encrypt_name(unsigned char * data,int data_len,unsigned char * key, unsigned char *encrypted) {
    RSA *rsa =createRSA(key, 1);
    char buf[257];
    int i;
    memset(buf, 0, 257);
    strncpy(buf, data, data_len);
    srand(time(NULL));
    if (data_len < 256) {
        strncat(buf, "|", 1);
        for(i = data_len + 1; i < 256 - data_len -1; i++) {
            char a = random_char();
            buf[i] = a;
        }
    }
    int result = RSA_public_encrypt(256, buf, encrypted, rsa, RSA_NO_PADDING);
    return result;
}

int private_encrypt(unsigned char * data,int data_len,unsigned char * key, unsigned char *encrypted)
{
    RSA * rsa = createRSA(key,0);
    int result = RSA_private_encrypt(data_len,data,encrypted,rsa,RSA_NO_PADDING);
    return result;
}

int public_decrypt(unsigned char * enc_data,int data_len,unsigned char * key, unsigned char *decrypted)
{
    RSA * rsa = createRSA(key,1);
    int  result = RSA_public_decrypt(data_len,enc_data,decrypted,rsa,RSA_NO_PADDING);
    return result;
}

int private_decrypt(unsigned char * enc_data,int data_len,unsigned char * key, unsigned char *decrypted)
{
    RSA * rsa = createRSA(key,0);
    int  result = RSA_private_decrypt(data_len,enc_data,decrypted,rsa,RSA_PKCS1_PADDING);
    return result;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

void atm_process_command(ATM *atm, char *command)
{
    // TODO: Implement the ATM's side of the ATM-bank protocol
    char arg1[14];
    char arg2[251];
    char t1[1001];
    char t2[1001];
    char t3[1001];

    memset(arg1, 0, 14);
    memset(arg2, 0, 251);
    memset(t1, 0, 1001);
    memset(t2, 0, 1001);
    memset(t3, 0, 1001);
    sscanf(command, "%s %s", t1, t2);
    if(strlen(t1) > 13 || strlen(t1) < 1) {
        printf("Invalid command\n");
        return;
    }

    strncpy(arg1, t1, strlen(t1));
    if(strcmp(arg1, "begin-session") == 0){
        if(atm->in_sess == 1) {
            printf("A user is already logged in\n");
            return;
        }

        if(strlen(t2) < 1 || strlen(t2) > 250 || strlen(t3) > 1) {
            printf("Usage: begin-session <user-name>\n");
            return;
        }

        strncpy(arg2, t2, strlen(t2));
        if(check_uname(arg2) == 0) {
            printf("Usage: begin-session <user-name>\n");
            return;
        }

        char ret[256];
        unsigned char r2[4098]={};
        unsigned char com[4098]={};
        unsigned char cipher[4098]={};
        unsigned char c2[4098]={};
        //int e_len = public_encrypt(msg, strlen(msg), atm->bank_pub, cipher);
		//atm_send(atm, cipher, e_len);

        int e_len = public_encrypt("v", 1, atm->bank_pub, cipher);
        int e2_len = private_encrypt(cipher, 256, atm->priv_k, c2);
        atm_send(atm, c2, e2_len);
        memset(cipher, 0, 4098);
        memset(c2, 0, 4098);
        e_len = encrypt_name(arg2, strlen(arg2), atm->bank_pub, cipher);
        e2_len = private_encrypt(cipher, 256, atm->priv_k, c2);
        atm_send(atm, c2, e2_len);

		  atm_recv(atm, ret, 256);
        public_decrypt(ret, 256, atm->bank_pub, r2);
        private_decrypt(r2, 256, atm->priv_k, com);

        if(strcmp(com, "n") == 0) {
            printf("No such user\n");
            return;
        }
        
        atm_recv(atm, ret, 256);
        memset(com, 0, 4098);
        memset(r2, 0, 4098);
        public_decrypt(ret, 256, atm->bank_pub, r2);
        private_decrypt(r2, 256, atm->priv_k, com);
		  printf("%s\n",com);
        if(strcmp(com, "n") == 0) {
            printf("Unable to access %s's card\n", arg2);
            return;
        }


        char pin[5];
        char input[1001];
        memset(pin, 0, 5);
        memset(input, 0, 1001);
        printf("PIN? ");
        fgets(input, 1001, stdin);
        if(strlen(input) != 5 || input[4] != '\n'){
            printf("Not authorized\n");
            atm->tries += 1;
            if (atm->tries > 2) {
                printf("Too many tries\n");
                atm->tries = 0;
                sleep(10);
            }
            return;
        }

        strncpy(pin, input, 4);

        if (valid_pin(pin) == 0) {
            printf("Not authorized\n");
            atm->tries += 1;
            if (atm->tries > 2) {
                printf("Too many tries\n");
                atm->tries = 0;
                sleep(10);
            }
            return;
        }

        memset(cipher, 0, 4098);
        memset(c2, 0, 4098);
        //e_len = public_encrypt(msg2, strlen(msg2), atm->bank_pub, cipher);
        e_len = public_encrypt("cp", 2, atm->bank_pub, cipher);
        e2_len = private_encrypt(cipher, 256, atm->priv_k, c2);
        atm_send(atm, c2, e2_len);
        memset(cipher, 0, 4098);
        memset(c2, 0, 4098);
        e_len = encrypt_name(arg2, strlen(arg2), atm->bank_pub, cipher);
        e2_len = private_encrypt(cipher, 256, atm->priv_k, c2);
        atm_send(atm, c2, e2_len);
        memset(cipher, 0, 4098);
        memset(cipher, 0, 4098);
        e_len = public_encrypt(pin, strlen(pin), atm->bank_pub, cipher);
        e2_len = private_encrypt(cipher, 256, atm->priv_k, c2);
        atm_send(atm, c2, e2_len);

        atm_recv(atm, ret, 256);
        memset(com, 0, 4098);
        memset(r2, 0, 4098);
        public_decrypt(ret, 256, atm->bank_pub, r2);
        private_decrypt(r2, 256, atm->priv_k, com);

        if(strcmp(com, "n")==0) {
            printf("Not authorized\n");
            atm->tries += 1;
            if (atm->tries > 2) {
                printf("Too many tries\n");
                atm->tries = 0;
                sleep(10);
            }
            return;
        }
        printf("Authorized\n");
        atm->tries = 0;
        memset(atm->user, 0, 251);
        strncpy(atm->user, arg2, strlen(arg2));
        atm->in_sess=1;

        return;
    }
    if (strcmp(arg1, "withdraw") == 0) {
        if(atm->in_sess == 0) {
            printf("No user logged in\n");
            return;
        }
        if (strlen(t2) < 1 || strlen(t3) > 1) {
            printf("Usage: withdraw <amt>\n");
            return;
        }
        if (strlen(t2) > 10) {
            if(all_digits(t2) == 1) {
                printf("Insufficient funds\n");
                return;
            }
            printf("Usage: withdraw <amt>\n");
            return;
        }

        strncpy(arg2, t2, strlen(t2));
        if(valid_bal(arg2) == 0) {
            if(all_digits(arg2) == 1) {
                printf("Insufficient funds\n");
                return;
            }
            printf("Usage: withdraw <amt>\n");
            return;
        }
        char ret[256];

        unsigned char cipher[4098]={};
        unsigned char c2[4098]={};

        int e_len = public_encrypt("w", 1, atm->bank_pub, cipher);
        int e2 = private_encrypt(cipher, 256, atm->priv_k, c2);
        atm_send(atm, c2, e2);
        memset(cipher, 0, 4098);
        memset(c2, 0, 4098);
        e_len = encrypt_name(atm->user, strlen(atm->user), atm->bank_pub, cipher);
        e2 = private_encrypt(cipher, 256, atm->priv_k, c2);
        atm_send(atm, c2, e2);
        memset(c2, 0, 4098);
        memset(cipher, 0, 4098);
        e_len = public_encrypt(arg2, strlen(arg2), atm->bank_pub, cipher);
        e2 = private_encrypt(cipher, 256, atm->priv_k, c2);
        atm_send(atm, c2, e2);

        unsigned char com[4098]={};
        unsigned char r2[4098]={};

        atm_recv(atm, ret, 256);
        public_decrypt(ret, 256, atm->bank_pub, r2);
        private_decrypt(r2, 256, atm->priv_k, com);

        if (strcmp(com, "n") == 0) {
            printf("Insufficient funds\n");
            return;
        }

        printf("$%s dispensed\n", arg2);
        return;
    }
    if (strcmp(arg1, "balance") == 0) {
        if(atm->in_sess == 0) {
            printf("No user logged in\n");
            return;
        }

        if (strlen(t2) > 1) {
            printf("Usage: balance\n");
            return;
        }

        char ret[256];
        unsigned char cipher[4098]={};
        unsigned char c2[4098]={};
        int e_len = public_encrypt("b", 1, atm->bank_pub, cipher);
        int e2 = private_encrypt(cipher, 256, atm->priv_k, c2);
        atm_send(atm, c2, e2);
        memset(cipher, 0, 4098);
        e_len = encrypt_name(atm->user, strlen(atm->user), atm->bank_pub, cipher);
        e2 = private_encrypt(cipher, 256, atm->priv_k, c2);
        atm_send(atm, c2, e_len);
        atm_recv(atm, ret, 256);

        unsigned char com[4098]={};
        unsigned char r2[4098]={};
        public_decrypt(ret, 256, atm->bank_pub, r2);
        private_decrypt(r2, 256, atm->priv_k, com);
        char c[2];
        char val[11];
        if(com[0] == 'y') {
            sscanf(com, "%s %s", c, val);
            printf("$%s\n", val);
            return;
        }
    }

    if (strcmp(arg1, "end-session") == 0) {
        if(atm->in_sess == 0) {
            printf("No user logged in\n");
            return;
        }

        memset(atm->user, 0, 251);
        atm->in_sess = 0;
        atm->tries = 0;
        printf("User logged out\n");
        return;
    }
    printf("Invalid command\n");
    return;
	/*
	 * The following is a toy example that simply sends the
	 * user's command to the bank, receives a message from the
	 * bank, and then prints it to stdout.
	 */

	/*
    char recvline[10000];
    int n;

    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    fputs(recvline,stdout);
	*/
}

int check_uname(char *uname) {
    if(uname == NULL) {
        return 0;
    }
    int i;
    for(i = 0; i < strlen(uname); i++) {
        if(uname[i] > 'z' || uname[i] < 'A')
            return 0;
        if(uname[i] > 'Z' && uname[i] < 'a')
            return 0; 
    }
    return 1;
}

int valid_pin(char *pin) {
    if(all_digits(pin) == 0) {
        return 0;
    }
    long d = strtol(pin, NULL, 10);
    if (d< 0 || d > 9999) {
        return 0;
    }
    return 1;
}

int valid_bal(char *bal) {
    if(all_digits(bal) == 0) {
        return 0;
    }
    long money = strtol(bal, NULL, 10);

    if (money == INT_MAX && strcmp(bal, "2147483647") != 0) {
        return 0;
    }

    if (money < 0 || money > INT_MAX) {
        return 0;
    }

    return 1;
}

int all_digits(char *num) {
    int i;
    for(i = 0; i < strlen(num); i++) {
        if(num[i]<'0' || num[i] > '9'){
            return 0;
        }
    }

    return 1;
}
