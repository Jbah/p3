#include "bank.h"
#include "ports.h"
#include <limits.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <openssl/sha.h>

Bank* bank_create()
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    bank->usr = list_create();
    bank->pin = list_create();
    bank->time = list_create();
    return bank;
}

RSA* createRSA(unsigned char * key,int public)
{
    RSA *rsa= NULL;
    BIO *keybio ;
    keybio = BIO_new_mem_buf(key, -1);
    if (keybio==NULL)
    {
        printf( "Failed to create key BIO");
        return 0;
    }
    if(public)
    {
        rsa = PEM_read_bio_RSA_PUBKEY(keybio, &rsa,NULL, NULL);
    }
    else
    {
        rsa = PEM_read_bio_RSAPrivateKey(keybio, &rsa,NULL, NULL);
    }
    if(rsa == NULL)
    {
        printf( "Failed to create RSA");
    }
 
    return rsa;
}

int public_encrypt(unsigned char * data,int data_len,unsigned char * key, unsigned char *encrypted)
{
    RSA * rsa = createRSA(key,1);
    int result = RSA_public_encrypt(data_len,data,encrypted,rsa,RSA_PKCS1_PADDING);
    return result;
}
int private_decrypt(unsigned char * enc_data,int data_len,unsigned char * key, unsigned char *decrypted)
{
    RSA * rsa = createRSA(key,0);
    int  result = RSA_private_decrypt(data_len,enc_data,decrypted,rsa,RSA_PKCS1_PADDING);
    return result;
}
int decrypt_name(unsigned char * enc_data,int data_len,unsigned char * key, unsigned char *decrypted) {
    RSA * rsa = createRSA(key,0);
    int  result = RSA_private_decrypt(data_len,enc_data,decrypted,rsa,RSA_NO_PADDING);
    char *a = strchr(decrypted, '|');
    *a = 0;
    return result;
}

int public_decrypt(unsigned char * enc_data,int data_len,unsigned char * key, unsigned char *decrypted)
{
    RSA * rsa = createRSA(key,1);
    int  result = RSA_public_decrypt(data_len,enc_data,decrypted,rsa,RSA_NO_PADDING);
    return result;
}

int private_encrypt(unsigned char * data,int data_len,unsigned char * key, unsigned char *encrypted)
{
    RSA * rsa = createRSA(key,0);
    int result = RSA_private_encrypt(data_len,data,encrypted,rsa,RSA_NO_PADDING);
    return result;
}

void bank_get_keys(Bank *bank) {
    int i;
    char* line = NULL;
    size_t len = 0;
    bank->atm_pub = malloc(4096);
    bank->priv_k = malloc(4096);
    memset(bank->atm_pub, 0, 4096);
    memset(bank->priv_k, 0, 4096);
    for (i = 0; i < 27; i++) {
        getline(&line, &len, bank->keys);
        strncat(bank->priv_k, line, len);
    }
    for (i = 0; i < 9; i++) {
        getline(&line, &len, bank->keys);
        strncat(bank->atm_pub, line, len);
    }
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
        list_free(bank->usr);
        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

void bank_process_local_command(Bank *bank, char *command, size_t len)
{
    // TODO: Implement the bank's local commands

    char arg1[12];
    char arg2[251];
    char arg3[11];
    char arg4[11];

    char t1[1001];
    char t2[1001];
    char t3[1001];
    char t4[1001];
    char t5[1001];

    memset(arg1, 0, 12);
    memset(arg2, 0, 251);
    memset(arg3, 0, 11);
    memset(arg4, 0, 11);
    memset(t1, 0, 1001);
    memset(t2, 0, 1001);
    memset(t3, 0, 1001);
    memset(t4, 0, 1001);
    memset(t5, 0, 1001);

    sscanf(command, "%s %s %s %s %s", t1, t2, t3, t4, t5);

    if(strlen(t1) < 1) {
        printf("Invalid command\n");
        return;
    }

    if(strlen(t1) > 11) {
        printf("Invalid command\n");
        return;
    }
    //create user
    strncpy(arg1, t1, strlen(t1));
    if(strcmp(arg1, "create-user") == 0) {
        if (strlen(t2) < 1 || strlen(t3) < 1 || strlen(t4) < 1 || strlen(t5) > 1) {
            printf("Usage: create-user <user-name> <pin> <balance>\n");
            return;
        }

        if (strlen(t2) > 250) {
            printf("Usage: create-user <user-name> <pin> <balance>\n");
            return;
        }

        strncpy(arg2, t2, strlen(t2));
        if (check_uname(arg2) == 0) {
            printf("Usage: create-user <user-name> <pin> <balance>\n");
            return;
        }

        if(list_find(bank->usr, arg2) != NULL) {
            printf("Error: user %s already exists\n", arg2);
            return;
        }

        if(strlen(t3) != 4) {
            printf("Usage: create-user <user-name> <pin> <balance>\n");
            return;
        }

        strncpy(arg3, t3, strlen(t3));
        if(valid_pin(arg3) == 0) {
            printf("Usage: create-user <user-name> <pin> <balance>\n");
            return;
        }

        if(strlen(t4) > 10) {
            printf("Usage: create-user <user-name> <pin> <balance>\n");
            return;
        }

        strncpy(arg4, t4, strlen(t4));
        if(valid_bal(arg4) == 0) {
            printf("Usage: create-user <user-name> <pin> <balance>\n");
            return;
        }

        //create card
        char *fname = malloc(strlen(arg2) + 6);
        memset(fname, 0x00, strlen(arg2)+6);
        strncpy(fname, arg2, strlen(arg2));
        strncat(fname, ".card", 5);
        time_t t = time(NULL);
        char time_str[11];
        sprintf(time_str, "%d", (int)t);

        char *hstring = malloc(strlen(arg2) + strlen(arg3) + strlen(time_str) + 1);
        memset(hstring, 0, strlen(arg2) + strlen(arg3) + strlen(time_str) + 1);
        strncat(hstring, arg2, strlen(arg2));
        strncat(hstring, arg3, strlen(arg3));
        strncat(hstring, time_str, strlen(time_str));
        unsigned char hash[SHA_DIGEST_LENGTH];
        SHA1(hstring, strlen(hstring), hash);
        FILE *cardfp = fopen(fname, "w");
        int i;
        for(i = 0; i < 20; i++){
            fprintf(cardfp, "%02x", hash[i]);
        }

        if(cardfp == NULL) {
            printf("Error creating card file for user %s\n", arg2);
            remove(fname);
            return;
        }
        fclose(cardfp);

        list_add(bank->usr, arg2, arg4);
        list_add(bank->pin, arg2, arg3);
        list_add(bank->time, arg2, time_str);
        printf("Created user %s\n", arg2);
        return;
    }
    //deposit
    if (strcmp(arg1, "deposit") == 0) {
        if (strlen(t2) < 1 || strlen(t3) < 1 || strlen(t4) > 1) {
            printf("Usage: deposit <user-name> <amt>\n");
            return;
        }

        if (strlen(t2) > 250) {
            printf("Usage: deposit <user-name> <amt>\n");
            return;
        }

        strncpy(arg2, t2, strlen(t2));
        if (check_uname(arg2) == 0) {
            printf("Usage: deposit <user-name> <amt>\n");
            return;
        }

        if(list_find(bank->usr, arg2) == NULL) {
            printf("No such user\n");
            return;
        }

        if(strlen(t3) > 10) {
            if(all_digits(t3) == 1) {
                printf("Too rich for this program\n");
                return;
            }
            printf("Usage: deposit <user-name> <amt>\n");
            return;
        }

        strncpy(arg3, t3, strlen(t3));
        if(valid_bal(arg3) == 0) {
            printf("Usage: deposit <user-name> <amt>\n");
            return;
        }

        int amt = strtol(arg3, NULL, 10);
        int cur_amt = strtol(list_find(bank->usr, arg2), NULL, 10);

        int new_val = amt + cur_amt;
        if (new_val < amt) {
            printf("Too rich for this program\n");
            return;
        }

        list_del(bank->usr, arg2);
        char str_amt[11];
        sprintf(str_amt, "%d", new_val);
        list_add(bank->usr, arg2, str_amt);
        printf("$%s added to %s's account\n", arg3, arg2);
        return;

    }

    if (strcmp(arg1, "balance") == 0) {
        if (strlen(t2) < 1 || strlen(t3) > 1) {
            printf("Usage: balance <user-name>\n");
            return;
        }

        if (strlen(t2) > 250) {
            printf("Usage: balance <user-name>\n");
            return;
        }

        strncpy(arg2, t2, strlen(t2));
        if (check_uname(arg2) == 0) {
            printf("Usage: balance <user-name>\n");
            return;
        }

        if(list_find(bank->usr, arg2) == NULL) {
            printf("No such user\n");
            return;
        }

        printf("$%s\n", (char*)list_find(bank->usr, arg2));
        return;

    }
    printf("Invalid command\n");
    return;
    //balance
}

void bank_send_y(Bank *bank){
    unsigned char cipher[4098]={};
    unsigned char c2[4098]={};
    int e_len = public_encrypt("y", 1, bank->atm_pub, cipher);
    int e2 = private_encrypt(cipher, 256, bank->priv_k, c2);
    bank_send(bank, c2, e2);
}
void bank_send_n(Bank *bank){
    unsigned char cipher[4098]={};
    unsigned char c2[4098]={};
    int e_len = public_encrypt("n", 1, bank->atm_pub, cipher);
    int e2 = private_encrypt(cipher, 256, bank->priv_k, c2);
    bank_send(bank, c2, e2);
}

void bank_process_remote_command(Bank *bank, char *command, size_t len)
{
    // TODO: Implement the bank side of the ATM-bank protocol

    unsigned char com[4098]={};
    unsigned char coom[4098]={};
    public_decrypt(command, 256, bank->atm_pub, coom);
    private_decrypt(coom, 256, bank->priv_k, com);

    if(strcmp(com, "v") == 0) {
        unsigned char ret[256]={};
        unsigned char r2[256]={};
        unsigned char name[256]={};
        bank_recv(bank, ret, 256);
        public_decrypt(ret, 256, bank->atm_pub, r2);
        decrypt_name(r2, 256, bank->priv_k, name);
        if(list_find(bank->usr, name) == NULL) {
			   bank_send_n(bank);
            return;
        }
        bank_send_y(bank);

        char cardfname[strlen(name)+6];
        memset(cardfname, 0, strlen(name)+6);
        strncat(cardfname, name, strlen(name));
        strncat(cardfname, ".card", 5);

        FILE *cardfp = fopen(cardfname, "r");
        if (cardfp == NULL) {
            bank_send_n(bank);
            return;
        }
       
        char *fcontent = malloc(41);
        memset(fcontent, 0, 41);
        fread(fcontent, 1, 41, cardfp);
	     fclose(cardfp);	
        char *pin = list_find(bank->usr, name);
        char *time = list_find(bank->time, name);

        char *hstring = malloc(strlen(name) + strlen(pin) + strlen(time) + 1);
        memset(hstring, 0, strlen(name) + strlen(pin) + strlen(time) + 1);
        strncat(hstring, name, strlen(name));
        strncat(hstring, pin, strlen(pin));
        strncat(hstring, time, strlen(time));
        unsigned char hash[SHA_DIGEST_LENGTH];
        SHA1(hstring, strlen(hstring), hash);
        char *compstr = malloc(41);
        memset(compstr, 0, 41);
        int i;
        char s[3];
        for(i = 0; i < 20; i++){
            sprintf(s, "%02x", hash[i]);
            s[2] = 0;
            strncat(compstr, s, 2);
        }
        if(strcmp(compstr, fcontent) != 0) {
			   bank_send_n(bank);
            return;
        }
        bank_send_y(bank);
        return;
    }
    
    if(strcmp(com, "cp") == 0) {
        unsigned char ret[4098]={};
        unsigned char r2[4098]={};
        unsigned char name[4098]={};
        unsigned char pin[4098]={};
        bank_recv(bank, ret, 256);
        public_decrypt(ret, 256, bank->atm_pub, r2);
        decrypt_name(r2, 256, bank->priv_k, name);

        bank_recv(bank, ret, 256);
        memset(r2,0,4098);
        public_decrypt(ret, 256, bank->atm_pub, r2);
        private_decrypt(r2, 256, bank->priv_k, pin);
        
		  char *p = list_find(bank->pin, name);
        if(p == NULL || strcmp(p, pin) != 0) {
            bank_send_n(bank);
            return;
        }
        bank_send_y(bank);
        return;
    }

    if(strcmp(com, "b") == 0) {
        unsigned char ret[4098]={};
        unsigned char r2[4098]={};
        unsigned char name[4098]={};
        bank_recv(bank, ret, 256);
        public_decrypt(ret, 256, bank->atm_pub, r2);
        decrypt_name(r2, 256, bank->priv_k, name);

        char *p = list_find(bank->usr, name);
        if (p == NULL) {
            bank_send_n(bank);
            return;
        }
        char resp[strlen(p)+3];
        memset(resp, 0, strlen(p) + 3);
        strncat(resp, "y ", 2);
        strncat(resp, p, strlen(p));

        unsigned char cipher[4098]={};
        unsigned char c2[4098]={};
        int e_len = public_encrypt(resp, strlen(resp), bank->atm_pub, cipher);
        int e2 = private_encrypt(cipher, 256, bank->priv_k, c2);
        bank_send(bank, c2, e_len);
        return;
    }

    if(strcmp(com, "w") == 0) {
        unsigned char ret[4098]={};
        unsigned char r2[4098]={};
        unsigned char name[4098]={};
        unsigned char amt[4098]={};

        bank_recv(bank, ret, 256);
        public_decrypt(ret, 256, bank->atm_pub, r2);
        decrypt_name(r2, 256, bank->priv_k, name);

        memset(ret, 0, 4098);
        memset(r2,0, 4098);
        bank_recv(bank, ret, 256);
        public_decrypt(ret, 256, bank->atm_pub, r2);
        private_decrypt(r2, 256, bank->priv_k, amt);

        char *p = list_find(bank->usr, name);
        if (p == NULL) {
            bank_send_n(bank);
            return;
        }
        int bal = strtol(p, NULL, 10);
        int with = strtol((char *)amt, NULL, 10);
        if (bal < with) {
            bank_send_n(bank);
            return;
        }
        int new_v = bal - with;
        list_del(bank->usr, name);

        char str_amt[11];
        sprintf(str_amt, "%d", new_v);
        list_add(bank->usr, name, str_amt);
        bank_send_y(bank);
        return;
    }
        bank_send_n(bank);
        return;
}

int check_uname(char *uname) {
    if(uname == NULL) {
        return 0;
    }
    int i;
    for(i = 0; i < strlen(uname); i++) {
        if(uname[i] > 'z' || uname[i] < 'A')
            return 0;
        if(uname[i] > 'Z' && uname[i] < 'a')
            return 0; 
    }
    return 1;
}


int valid_pin(char *pin) {
    if(all_digits(pin) == 0) {
        return 0;
    }
    long d = strtol(pin, NULL, 10);
    if (d< 0 || d > 9999) {
        return 0;
    }
    return 1;
}

int valid_bal(char *bal) {
    if(all_digits(bal) == 0) {
        return 0;
    }
    long money = strtol(bal, NULL, 10);

    if (money == INT_MAX && strcmp(bal, "2147483647") != 0) {
        return 0;
    }

    if (money < 0 || money > INT_MAX) {
        return 0;
    }

    return 1;
}

int all_digits(char *num) {
    int i;
    for(i = 0; i < strlen(num); i++) {
        if(num[i]<'0' || num[i] > '9'){
            return 0;
        }
    }

    return 1;
}
