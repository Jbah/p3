#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void genKeys(char *keys[]) {
    char* line = NULL;
    size_t len = 0;
    ssize_t check;
    int i;
    
    for(i = 0; i < 4; i+=2) {
        system("openssl genrsa -out private.pem 2048 &> /dev/null");
        system("openssl rsa -in private.pem -out public.pem -pubout &> /dev/null");

        
        char* private_key;
        char* public_key;
        FILE* secret_fp = fopen("private.pem", "r");
        FILE* public_fp = fopen("public.pem", "r");

        private_key = malloc(4096);
        public_key = malloc(4096);

        while ((check = getline(&line, &len, secret_fp)) != -1) {
            strcat(private_key, line);
        }    
     
        while ((check = getline(&line, &len, public_fp)) != -1) {
            strcat(public_key, line);
        }    
       
        keys[i] = malloc(strlen(private_key));
        strncpy(keys[i], private_key, strlen(private_key));
        keys[i+1] = malloc(strlen(public_key));
        strncpy(keys[i+1], public_key, strlen(public_key));
        
//        free(private_key);
//        free(public_key);
        system("rm private.pem");
        system("rm public.pem");
        fclose(secret_fp);
        fclose(public_fp);
    }


}

int main(int argc, char** argv) {
    if (argc != 2) {
        printf("Usage: init <filename>\n");
        return 62;
    }
    
    int argv_size = strlen(argv[1]);
    
    char* atm = malloc(argv_size+5);
    char* bank = malloc(argv_size+6);

    if (atm != NULL && bank != NULL) {
        strncat(atm, argv[1], argv_size);
        strncat(atm, ".atm", 4);
        strncat(bank, argv[1], argv_size);
        strncat(bank, ".bank", 5);
    }

    if (access(atm, F_OK) != -1 || access(bank, F_OK) != -1) {
        printf("Error: one of the files already exists\n");
        return 63;
    }

    FILE *atm_fp = fopen(atm, "w");
    FILE *bank_fp = fopen(bank, "w");

    char * keys[4];
    //private, pub, pri, pub
    genKeys(keys);
    fputs(keys[0], bank_fp);
    fputs(keys[3], bank_fp);
    
    fputs(keys[2], atm_fp);
    fputs(keys[1], atm_fp);
    

    if (atm_fp == NULL || bank_fp == NULL) {
        printf("Error creating initialization files\n");
        return 64;
    }
    
    free(atm);
    free(bank);
    fclose(atm_fp);
    fclose(bank_fp);
    printf("Successfully initialized bank state\n");
    return 0;
}
