#include "bank.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <crypto.h>
#include <stdio.h>

Bank* bank_create()
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as needed

    bank->numUsers = 0;

    


    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

void bank_process_local_command(Bank *bank, char *command, size_t len)
{
    // TODO: Implement the bank's local commands
    char user[250], pin[4], balance_input[10];
    int balance, found = 0;

    char arg0[1000];
    strncpy(arg0, strtok(command, " "), 25);

    if (strcmp(arg0, "create-user") == 0){
	strncpy(user, strtok(NULL, " "), 250);
	strncpy(pin, strtok(NULL, " "), 4);
	strncpy(balance_input, strtok(NULL, " "), 10);

	int i = 0;
	int usertester = 0;
	while(i < strlen(user)){
	    if((user[i] >= 'a' && user[i] <= 'z') || (user[i] >= 'A' && user[i] <= 'Z')){
		usertester = 1;
	    }
	    i = i + 1;
	}

	i = 0;
	int pintester = 0;
	if(strlen(pin) != 4){
	    pintester = 1;
	}
	while(i < 4){
	    if(pin[i] >= '0' && pin[i] <= '9'){
		pintester = 1;
	    }
	    i++;
	}

	i = 0;
	int balancetester = 0;
	while(i < strlen(balance_input)){
	    if(balance_input[i] >= '0' && balance_input[i] <= '9'){
		balancetester = 1;
	    }
	    i++;
	}

	balance = atoi(balance_input);

	if (strcmp("2147483647", balance_input) < 0 || usertester || pintester || balancetester || balance < 0){
	    printf("Usage: create-user <user-name> <pin> <balance>\n");
	}
	else{
	    
	    for (i = 0; i < bank->numUsers; i++){
		if (strcmp(bank->users[i]->username, user) == 0){
		    found = 1;
		}
	    }
	    if (found == 1){
		printf("Error: user %s already exists\n", user);
	    }
	    else{
		char temp2[260] = "";
		strcat(temp2, user);
		strcat(temp2, ".card");
		FILE * card = fopen(temp2, "w");
		if(card == NULL){
		    printf("Error creating card file for user %s\n", user);
		}
		else{
		    bank->numUsers++;
		    Userinfo * user2 = malloc(sizeof(Userinfo));
		    strncpy(user2->username, user, sizeof(user2->username));
		    user2->balance = balance;
		    bank->users[bank->numUsers-1] = user2;

		    char hashed[200];
		    strcpy(hashed, bank->salt);
		    strcat(hashed, pin);
		    strcat(hashed, bank->pepper);
		    //add encrypt
		    encrypt(hashed, strlen(hashed), bank->key, hashed);
		    

		    fwrite(hashed, 1, sizeof(hashed), card);
		    close(card);
		    printf("Created user %s\n", user);
		}
	    }
	}


	
    }
    else if(strcmp(arg0, "deposit") == 0){
	strncpy(user, strtok(NULL, " "), 250);
	strncpy(balance_input, strtok(NULL, " "), 10);

	int i = 0;
	int usertester = 0;
	while(i < strlen(user)){
	    if((user[i] >= 'a' && user[i] <= 'z') || (user[i] >= 'A' && user[i] <= 'Z')){
		usertester = 1;
	    }
	    i = i + 1;
	}

	
	i = 0;
	int balancetester = 0;
	while(i < strlen(balance_input)){
	    if(balance_input[i] >= '0' && balance_input[i] <= '9'){
		balancetester = 1;
	    }
	    i++;
	}

	balance = atoi(balance_input);

	if (strcmp("2147483647", balance_input) < 0 || usertester || balancetester || balance < 0){
	    printf("Usage: deposit <user-name> <amt>\n");
	}
	else{
	    found = -1;
	    for (i = 0; i < bank->numUsers; i++){
		if (strcmp(bank->users[i]->username, user) == 0){
		    found = i;
		}
	    }
	    if (found < 0){
		printf("No such user\n");
	    }
	    else{
		if(bank->users[found]->balance + balance < bank->users[found]->balance){
		    printf("Too rich for this program\n");
		}
		else{
		    bank->users[found]->balance = bank->users[found]->balance + balance;
		    printf("$%i added to %s's account\n", balance, user);
		}
	    }
	}
	

	
    }
    else if(strcmp(arg0, "balance") == 0){
	strncpy(user, strtok(NULL, " "), 250);
	

	int i = 0;
	int usertester = 0;
	while(i < strlen(user)){
	    if((user[i] >= 'a' && user[i] <= 'z') || (user[i] >= 'A' && user[i] <= 'Z')){
		usertester = 1;
	    }
	    i = i + 1;
	}
	
	if (usertester){
	    printf("Usage: balance <user-name>\n");
	}
	else{
	    found = -1;
	    for (i = 0; i < bank->numUsers; i++){
		if (strcmp(bank->users[i]->username, user) == 0){
		    found = i;
		}
	    }
	    if (found < 0){
		printf("No such user\n");
	    }
	    else{
		printf("$%i", bank->users[found]->balance);
	    }
	}
	
    }
    else{
	printf("Invalid command\n");
    }
    
}

void bank_process_remote_command(Bank *bank, char *command, size_t len)
{
    int i, found;
    decrypt(command, strlen(command), bank->key, command);
    // TODO: Implement the bank side of the ATM-bank protocol
    if(strcmp(command[0], "c") == 0){
	
	strtok(command, " ");
	char user[250];
	char data[16];
	strncpy(user, strtok(NULL, " "), 250);
	
	found = -1;
	for (i = 0; i < bank->numUsers; i++){
	    if (strcmp(bank->users[i]->username, user) == 0){
	        found = 1;
		encrypt("0", 1, bank->key, data);
		bank_send(bank, data, 16);
	    }
	}
	if(found == -1){
            
	    encrypt("1", 1, bank->key, data);
	    bank_send(bank, data, 16);
	}


	

    }

    if(strcmp(command[0], "b") == 0){
	strtok(command, " ");
	char user[250];
	char encrypted[1000];

	strncpy(user, strtok(NULL, " "), 250);
	
	
	for (i = 0; i < bank->numUsers; i++){
	    if (strcmp(bank->users[i]->username, user) == 0){
		char bal2[10];
		sprintf(bal2, "%d", bank->users[i]->balance);
	        encrypt(bal2, strlen(bal2), bank->key, encrypted);
		bank_send(bank, encrypted, strlen(encrypted));
	    }
	}


    }


    
    
    if(strcmp(command[0], "w") == 0){
	strtok(command, " ");
	char bal[10];
	strncpy(bal, strtok(NULL, " "), 10);
	char user[250];
	strncpy(user, strtok(NULL, " "), 250);
	int bal2 = atoi(bal);

	for (i = 0; i < bank->numUsers; i++){
	    if (strcmp(bank->users[i]->username, user) == 0){
	        
		bank->users[i]->balance = bank->users[i]->balance - bal2;
	    }
	}

    }

	/*
	 * The following is a toy example that simply receives a
	 * string from the ATM, prepends "Bank got: " and echoes 
	 * it back to the ATM before printing it to stdout.
	 */

	/*
    char sendline[1000];
    command[len]=0;
    sprintf(sendline, "Bank got: %s", command);
    bank_send(bank, sendline, strlen(sendline));
    printf("Received the following:\n");
    fputs(command, stdout);
	*/
}
