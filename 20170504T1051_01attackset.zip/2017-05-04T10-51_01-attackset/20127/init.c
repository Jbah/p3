#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/rand.h>
#include <openssl/evp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <string.h>
#include <time.h>
#include <unistd.h>


int main(int argc, char **argv) {
    /*unsigned char m[] = "This is a secret";
    unsigned char * key = "1234567890123456";
    unsigned char cipher[128] = {0};
    unsigned char iv[16] = {0};
    unsigned char plain[128] = {0};
    unsigned char tag[128] = {0};


    int cipher_len = encrypt(m, strlen(m)+1, key, cipher);
    printf("ciphertext length: %d\nciphertext: ", cipher_len);
    printhex(cipher, cipher_len);
    int plain_len = decrypt(cipher, cipher_len, key, plain);
    printf("plaintext length: %d\nplaintext: ", plain_len);
    printf("%s\n", plain);

    int tag_len = sign(key, m, strlen(m) + 1, tag);
    printf("tag length: %d\ntag: ", tag_len);
    printhex(tag, tag_len);*/

	char *path = argv[1];
	int len = strlen(path) + 6;
	char temp_atm[len], temp_bank[len];
	FILE * fp_bank;
	FILE * fp_atm;
	strcpy(temp_atm, path);
	strcpy(temp_bank, path);
	int salt, pepper;

	if (argv[2] != NULL){
        	printf("Usage: init %s\n", path);
		return 62;
	}

	if (access(strcat(temp_bank, ".bank"), F_OK) != -1 || access(strcat(temp_atm, ".atm"), F_OK) != -1){
		printf("Error: one of the files already exists\n");
		return 63;
	}

	fp_bank = fopen(temp_bank, "w+");
	fp_atm = fopen(temp_atm, "w+");

	if (fp_bank == NULL || fp_atm == NULL){
		printf("Error creating initialization files\n");
		return 64;
	}

	unsigned char key[16];
	RAND_bytes(key, sizeof(key));

	fwrite(key,1,  sizeof(key), fp_atm);
	fwrite(key,1, sizeof(key), fp_atm);

	fwrite("\n",1, strlen("\n"), fp_atm);
	fwrite("\n", 1,strlen("\n"), fp_bank);

	srand(time(NULL));
        salt = rand() % (900) + 100;
        pepper = rand() % (900) + 100;

	char salt2[3];
	sprintf(salt2, "%d", salt);
	char pepper2[3];
	sprintf(pepper2, "%d", pepper);
	fwrite(salt2,1, sizeof(salt2), fp_bank);
	fwrite("\n",1, strlen("\n"), fp_bank);
	fwrite(pepper2,1, sizeof(pepper2), fp_bank);
	
	
	

	fwrite(salt2,1, sizeof(salt2), fp_atm);
	fwrite("\n",1, strlen("\n"), fp_atm);
	fwrite(pepper2,1, sizeof(pepper2), fp_atm);

	close(fp_atm);
	close(fp_bank);

	printf("Successfully initialized bank state\n");
	return 0;
}
