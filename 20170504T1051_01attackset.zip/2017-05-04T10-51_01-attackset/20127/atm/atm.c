#include "atm.h"
#include "ports.h"
#include <string.h>
#include <stdio.h>

#include <stdlib.h>
#include <unistd.h>
#include <crypto.h>
#include <time.h>

ATM* atm_create()
{
    int salt, pepper;
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM\n");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    atm->login = 0;
    //atm->curuser = "";
    strncpy(atm->curuser, "", 1);

    //atm->key = NULL;
    strncpy(atm->key, NULL, 1);

   

    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

void atm_process_command(ATM *atm, char *command, char* username)
{
    // TODO: Implement the ATM's side of the ATM-bank protocol

    char user[250], pin[250], balance_input[10], send[25], arg0[50];
    int balance, found, user_exists;
    FILE * fp_atm;

    found = 0;

    strncpy(arg0, strtok(command, " "), 50);

    if (strcmp(arg0, "begin-session\n") == 0){

	if(atm->login == 1){
	    printf("A user is already logged in\n");
	}

	strncpy(user, strtok(NULL, " "), 250);

	int i = 0;
	int usertester = 0;
	while(i < strlen(user)){
	    if((user[i] >= 'a' && user[i] <= 'z') || (user[i] >= 'A' && user[i] <= 'Z')){
		usertester = 1;
	    }
	    i = i + 1;
	}

	if (usertester){
	    printf("Usage: begin-session <user-name>\n");
	}
	else{
	    
	    strncpy(send, "c ", 2);
	    strcat(send, user);
	    char data[1000];
	    //encrypt
	    encrypt(send, strlen(send), atm->key, data);
	    atm_send(atm, data, strlen(data));
	    strncpy(data, "", 1);
	    atm_recv(atm, data, sizeof(data));
	    decrypt(data, strlen(data), atm->key, data);
	    if(strcmp(data, "1") == 0){
		printf("No such user\n");
	    }
	    printf("PIN? ");
	        
	    scanf("%4s", pin);

	    i = 0;
	    int pintester = 0;
	    if(strlen(pin) != 4){
	        pintester = 1;
	    }
	    while(i < 4){
	        if(pin[i] >= '0' && pin[i] <= '9'){
	            pintester = 1;
	        }
	        i++;
	    }

	    if(pintester){
	        printf("Not authorized\n");
	    }
	    
	    else{
	        char temp[260] = "";
	        strcat(temp, user);
	        strcat(temp, ".card");
	        FILE * card = fopen(temp, "r");
	       	if(card == NULL){
		    printf("Unable to access %s's card\n", user);
	        }
	        else{
		    char realpin[250]; //will have to change
	            
	            fgets(realpin, 250, card); // will change 4
	            close(card);
		    //hash pin and check against card
		    encrypt(pin, sizeof(pin), atm->key, pin);
	            if(strcmp(realpin, pin) == 0){
	                atm->login = 1;
			strcpy(atm->curuser, user);
			printf("Authorized\n");
			strncpy(username, user, sizeof(user));
	            }
		}
	    
	   }
	    
	}

	    

    }
    else if (strcmp(arg0, "withdraw") == 0){
	if(!(atm->login)){
	    printf("No user logged in\n");
	}
	else{
	    
	    strncpy(balance_input, strtok(NULL, " "), 10);

	    int i = 0;
	    int balancetester = 0;
	    while(i < strlen(balance_input)){
	        if(balance_input[i] >= '0' && balance_input[i] <= '9'){
    		    balancetester = 1;
	        }
	        i++;
	    }

	    balance = atoi(balance_input);

	    if (strcmp("2147483647", balance_input) < 0 || balancetester || balance < 0){
	        printf("Usage:  withdraw <amt>\n");
	    }
	    else{
		char curbal2[10] = "";
		strcat(curbal2, "b ");
		strcat(curbal2, atm->curuser);
		char data[1000];
	   	//encrypt
	   	encrypt(curbal2, strlen(curbal2), atm->key, data);
		atm_send(atm, data, strlen(data));
		atm_recv(atm, data, sizeof(data));
		decrypt(data, strlen(data), atm->key, data);
		int curbal = atoi(data);
		if(balance > curbal){
		    printf("Insufficient funds\n");
		}
		else{
		    printf("$%s dispensed", balance);
		    strcpy(curbal2, "");
		    strcat(curbal2, "w ");
		    strcat(curbal2, balance_input);
		    strcat(curbal2, atm->curuser);
		    //encrypt
	   	    encrypt(curbal2, strlen(curbal2), atm->key, curbal2);
		    atm_send(atm, curbal2, strlen(curbal2));
		}
	    }
	}


    }
    else if (strcmp(arg0, "balance") == 0){
	if(!(atm->login)){
	    printf("No user logged in\n");
	}
	else{
	    char curbal2[255] = "b ";
	    strcat(curbal2, atm->curuser);
   	    //encrypt
	    encrypt(curbal2, strlen(curbal2), atm->key, curbal2);
	    atm_send(atm, curbal2, strlen(curbal2));
	    atm_recv(atm, curbal2, strlen(curbal2));
	    decrypt(curbal2, strlen(curbal2), atm->key, curbal2);
	    printf("$%s\n", curbal2);
	}


    }

    else if (strcmp(arg0, "end-session") == 0){
	if(!(atm->login)){
	    printf("No user logged in\n");
	}
	else{
	    printf("User logged out\n");
	    atm->login = 0;
	    strcpy(atm->curuser, "");
	    strncpy(username, "", 1);
	}


    }

    else{
	printf("Invalid command\n");

    }

	/*
	 * The following is a toy example that simply sends the
	 * user's command to the bank, receives a message from the
	 * bank, and then prints it to stdout.
	 */

	/*
    char recvline[10000];
    int n;

    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    fputs(recvline,stdout);
	*/
}
