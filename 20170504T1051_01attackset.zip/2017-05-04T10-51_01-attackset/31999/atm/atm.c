#include "atm.h"
#include "ports.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <regex.h>
#include <limits.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>

#define USERNAME_LEN 250
#define PIN_LEN 4

#define MAX_LEN 100000

ATM* atm_create()
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    // TODO set up more, as needed

    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

//validate inputs using regular expressions
int validate(char *regexString, char *toValidate){
    regex_t regex;
    int reti;

    reti = regcomp(&regex, regexString, REG_EXTENDED);
    if( reti ){ 
        fprintf(stderr, "Could not compile regex\n"); 
        regfree(&regex);
        return -1; 
    }

    reti = regexec(&regex, toValidate, 0, NULL, 0);
    if(!reti){
        regfree(&regex);
        return 0; //there is a match
    } else {
        regfree(&regex);
        return -1; //no match or something error occured
    }
}

//amount validation for withdrawal
int validate_amount(int amount){
    if(amount<0 || amount > INT_MAX){
        return -1;
    }
    return 0;
}



//capture the message between the salt and pepper
int capture_msg(char* regexString, char* spmsg, char* msg){
    size_t maxGroups = 2;
    regex_t regex;
    regmatch_t capArr[maxGroups];
    if (regcomp(&regex, regexString, REG_EXTENDED)){
        printf("Could not compile regular expression.\n");
        regfree(&regex);
        return 1;
    }

    if (regexec(&regex, spmsg, maxGroups, capArr, 0) == 0){
        char msgCopy[strlen(spmsg) + 1];
        strcpy(msgCopy, spmsg);
        msgCopy[capArr[1].rm_eo] = 0;
        strcpy(msg, msgCopy + capArr[1].rm_so);
        regfree(&regex);
        return 0;
    } else {
        regfree(&regex);
        return 1;
    }  
}

//use to capture the message from bank
void multi_capture(char* regexString, char* source, char arr[4][MAX_LEN+1]){
    size_t maxGroups = 5;

    regex_t regexCompiled;
    regmatch_t groupArray[maxGroups];

    if (regcomp(&regexCompiled, regexString, REG_EXTENDED)){
      printf("Could not compile regular expression.\n");
      return;
    };

    if (regexec(&regexCompiled, source, maxGroups, groupArray, 0) == 0){

        int i;
        for(i=1; i < maxGroups; i++){
            int k;
            int j;
            for(k = groupArray[i].rm_so, j=0; k < groupArray[i].rm_eo; k++, j++){
                arr[i-1][j] = source[k];
            }
            arr[i][groupArray[i].rm_eo] = 0;
        }
       
    }

    regfree(&regexCompiled);
}

/*
 * Encrypt "plaintext_in" with "key" into "ciphertext"
 *
 * Returns the length of "ciphertext" or -1 on error
 */
int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key, 
        unsigned char *ciphertext, unsigned char *iv) {
    EVP_CIPHER_CTX *ctx;
    
    int len = 0;
    int ciphertext_len = 0;

    if(!(ctx = EVP_CIPHER_CTX_new())) {
        return -1;
    }
    if(EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv) != 1) {
        return -1;
    }
    if(EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext_in, plaintext_len) != 1) {
        return -1;
    }
    ciphertext_len = len;

    if(EVP_EncryptFinal_ex(ctx, ciphertext + len, &len) != 1) {
        return -1;
    }
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

/*
 * Decrypt "cipher" with "key" into "plain"
 */
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
        unsigned char *plaintext, unsigned char *iv) {
    EVP_CIPHER_CTX *ctx;
   
    int len;
    int plaintext_len;

    if(!(ctx = EVP_CIPHER_CTX_new())) {
        return -1;
    }
    if(EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv) != 1) {
        return -1;
    }
    if(EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len) != 1) {
        return -1; 
    }
    plaintext_len = len;
    if(EVP_DecryptFinal_ex(ctx, plaintext + len, &len) != 1) {
        return -1; 
    }
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}

/*
 * Sign "cipher" with "key"
 */
int sign(const unsigned char* key, unsigned char* cipher, int cipher_len, 
        unsigned char* tag) {
    unsigned int len = 0;
    HMAC_CTX ctx;

    HMAC_CTX_init(&ctx);
    HMAC_Init_ex(&ctx, key, strlen((char*)key), EVP_sha1(), NULL);
    HMAC_Update(&ctx, cipher, cipher_len);
    HMAC_Final(&ctx, tag, &len);
    
    HMAC_CTX_cleanup(&ctx);
    return len;
}



void atm_process_command(ATM *atm, char *command, char* sessionKey, char* salt, char* pepper, char* iv)
{
    char recvline[MAX_LEN+1];
    char toBank[MAX_LEN+1];
    char cmd[MAX_LEN+1];
    char username[MAX_LEN+1];
    char user_input[MAX_LEN+1];
    char input[MAX_LEN+1];
    char misc[MAX_LEN+1];
    char msg[MAX_LEN+1];
    char msg2[MAX_LEN+1];
    char arr[4][MAX_LEN+1];
    char regexSP[MAX_LEN+1];
    char cipher[MAX_LEN+1] = {0};
    char tag[MAX_LEN+1] = {0};
    char plain[MAX_LEN+1] = {0};
    int num_args;
    int n;
    int bank_reply;
    int amt;
    int cipher_len;
    int tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt, strlen(salt)+1, (unsigned char*)tag);
    int plaintext_len;
    FILE *card;
    char cardname[MAX_LEN+1];
    char multi_reg[MAX_LEN+1] = "^(.+)---(.+)---(.+)---(.+)$";


    //create the regex to extract message from between salt and pepper
    sprintf(regexSP, "^%s(.+)%s$", salt, pepper);
  
    num_args = sscanf(command, "%s %s %s", cmd, username, misc);

    if(num_args > 0){ //check that there is at least one arguments is entered
        if(strcmp(cmd, "begin-session") == 0){
            
            //check that username given is a valid input
            if((num_args == 2) && (validate("^[[:alpha:]]*[[:alpha:]]$", username) == 0) && (strlen(username) <= USERNAME_LEN)){
                

                //check with bank to determine if username exist
                sprintf(msg, "%suser_exist %s%s", salt, username, pepper); //construct command to send to bank
                
                cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                
                sprintf(toBank, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
                //ENCRYPTION HERE --END
              
                atm_send(atm, toBank, strlen(toBank)+1); //send to bank command for user verification
                n = atm_recv(atm,recvline,MAX_LEN+1); //receive reply with number of bytes received
                recvline[n] = 0; //this is needed
               
               
                multi_capture(multi_reg, recvline, arr);

		        if(strcmp(tag, arr[3]) != 0){
                    printf("SOMEONE TAMPERED!!! Invalid command\n");
                    return;
                }
                //decrypt the message
                plaintext_len = decrypt((unsigned char*)arr[2], atoi(arr[1]), (unsigned char*)sessionKey, (unsigned char*)plain, (unsigned char*)iv);


                capture_msg(regexSP, plain, msg2);
          
                sscanf(msg2, "%d", &bank_reply); //get the int value from the recvline
                
                if(bank_reply == 0){ //user exist in bank records
                    msg2[0] = 0;

                    sprintf(cardname, "%s.card", username);
                    card = fopen(cardname, "r");
                    if(card == NULL){
                        printf("Unable to access %s's card\n", username);
                        return;
                    }

                    printf("PIN? "); //prompt for PIN
                    //fflush(stdout);
                    fgets(user_input, (MAX_LEN+1), stdin);
                    user_input[strlen(user_input) - 1] = '\0'; //remove newline character
                    
                    //verify that PIN input is valid
                    if(validate("^[[:digit:]]{3}[[:digit:]]$", user_input) == 0) { //Pin is in valid form
                        //check with bank to determine if username and PIN match

                        sprintf(msg, "%svalidate %s %s%s", salt, username, user_input, pepper); //construct command to sent to bank
                        
                        cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                        
                        sprintf(toBank, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);

                        atm_send(atm, toBank, strlen(toBank)+1);
                        n = atm_recv(atm, recvline, MAX_LEN+1);
                        recvline[n] = 0;

                        multi_capture(multi_reg, recvline, arr);
                      
                        if(strcmp(tag, arr[3]) != 0){
                            printf("SOMEONE TAMPERED!!! Invalid command\n");
                            return;
                        }
                        //decrypt the message
                        plaintext_len = decrypt((unsigned char*)arr[2], atoi(arr[1]), (unsigned char*)sessionKey, (unsigned char*)plain, (unsigned char*)iv);


                        capture_msg(regexSP, plain, msg2);
                        
                        //DECRYPTION HERE --END
                        
                        sscanf(msg2, "%d", &bank_reply);
                        
                        if(bank_reply == 0){ //the user-name and PIN matched
                            
                            printf("Authorized\n");
                            //flush(stdout);

                            //Access to withdraw, balance, and end-session commands are allowed now
                            printf("ATM (%s): ", username); //authorized atm prompt
                            //flush(stdout);

                            fgets(user_input, (MAX_LEN+1), stdin);
                            while(strcmp(user_input, "end-session\n")){ //as long was the user does not enter end-session
                                msg2[0] = 0;
                                num_args = sscanf(user_input, "%s %s %s", cmd, input, misc);
                                
                                if(num_args > 0){ //user enters at least 1 argument
                                    
                                    if(strcmp(cmd, "withdraw") == 0){
                                        
                                        if(num_args == 2){ //correct number of arguments given
                                            //check to see if an int is entered for input

                                            if(validate("^[[:digit:]]*[[:digit:]]$", input) == 0){ //input given is an integer
                                                sscanf(input, "%d", &amt);
                                                
                                                if(validate_amount(amt) == 0){ //amount given is valid
                                                    sprintf(msg, "%swithdraw %s %d%s", salt, username, amt, pepper); //construct command to sent to bank
                                                   
                                                    cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                                                    
                                                    sprintf(toBank, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
                                                    
                                                    atm_send(atm, toBank, strlen(toBank)+1); //send to bank command 
                                                    n = atm_recv(atm, recvline, MAX_LEN+1);
                                                    recvline[n] = 0;

                                                    
                                                    multi_capture(multi_reg, recvline, arr);
                                                    
                                                    if(strcmp(tag, arr[3]) != 0){
                                                        printf("SOMEONE TAMPERED!!! Invalid command\n");
                                                        return;
                                                    }
                                                    //decrypt the message
                                                    plaintext_len = decrypt((unsigned char*)arr[2], atoi(arr[1]), (unsigned char*)sessionKey, (unsigned char*)plain, (unsigned char*)iv);

                                                    capture_msg(regexSP, plain, msg2);
                                                    //DECRYPTION HERE --END

                                                    sscanf(msg2, "%d", &bank_reply); //retrieve bank response

                                                    if(bank_reply == 0){ //withdraw transaction completed completed
                                                        printf("$%d dispensed\n", amt);
                                                        //flush(stdout);
                                                    } else { //user has insufficient funds so bank wasn't able to complete transaction
                                                        printf("Insufficient funds\n");
                                                        //flush(stdout);
                                                    }
                                                }   else { //amount inputed is not valid
                                                    printf("Usage: withdraw <amt>\n");
                                                    //flush(stdout);
                                                    }
                                            } else { //input given wasn't valid
                                                printf("Usage: withdraw <amt>\n");
                                                //flush(stdout);
                                                }

                                        } else { //user did not enter an input
                                            printf("Usage: withdraw <amt>\n");
                                            //flush(stdout);
                                        }
                                    } else if(strcmp(cmd, "balance") == 0){
                                        if(num_args == 1){ //num of arguments is one
                                            //ask bank for user balance 
                                            sprintf(msg, "%sbalance %s%s", salt, username, pepper);
                                            
                                            //ENCRYPTION HERE --START
                                            cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                                            //tag_len = sign((unsigned char*)sessionKey, (unsigned char*)cipher, cipher_len, (unsigned char*)tag);
                                            sprintf(toBank, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
                                            //ENCRYPTION HERE --END
                                            
                                            atm_send(atm, toBank, strlen(toBank)+1); 
                                            n = atm_recv(atm, recvline, MAX_LEN+1);
                                            recvline[n] = 0;

                                            //DECRYPTION HERE --START
                                            multi_capture(multi_reg, recvline, arr);
                                            //new_tok(recvline, arr);

                                            //check that the message sent wasn't modified
                                            //sign((unsigned char*)sessionKey, (unsigned char*)arr[2], atoi(arr[1]), (unsigned char*)tag2);
                                            if(strcmp(tag, arr[3]) != 0){
                                                printf("SOMEONE TAMPERED!!! Invalid command\n");
                                                return;
                                            }
                                            //decrypt the message
                                            plaintext_len = decrypt((unsigned char*)arr[2], atoi(arr[1]), (unsigned char*)sessionKey, (unsigned char*)plain, (unsigned char*)iv);

                                            capture_msg(regexSP, plain, msg2);
                                            //DECRYPTION HERE --END
                                            sscanf(msg2, "%d", &bank_reply);

                                            printf("$%d\n", bank_reply);
                                            //flush(stdout);
                                        } else { //given more then the expected inputs for balance
                                            printf("Usage: balance\n");
                                            //flush(stdout);
                                            }
                                    } else if(strcmp(cmd, "begin-session") == 0){ //command was begin-session but a user is already logged in
                                        printf("A user is already logged in\n");
                                        //flush(stdout);
                                    } else { //not one of the valid commands
                                        printf("Invalid command\n");
                                        //flush(stdout);
                                    }
                                } else { //no command was entered
                                    printf("Invalid command\n");
                                    //flush(stdout);
                                }

                                //reprint prompt for authorized atm user
                                printf("ATM (%s): ", username); //authorized atm prompt
                                //flush(stdout);
                                fgets(user_input, (MAX_LEN+1), stdin);
                                //printf("USER INPUT: %s\n", user_input);

                            } //end while
                            //user entered end-session so now logging out
                            printf("User logged out\n");
                            //flush(stdout);

                        } else { // username and PIN does not match
                            if(bank_reply == -99){ //too many attempts on logging in
                                printf("Too many attempts\n");
                            }
                            printf("Not authorized\n");
                            //flush(stdout);
                        }

                    } else { //PIN not in valid form
                        printf("Not authorized\n");
                        //flush(stdout);
                    }

                } else { //user does not exist in bank records
                    printf("No such user\n");
                    //flush(stdout);
                }

            } else { //username is not a valid input
                printf("Usage: begin-session <user-name>\n");
                //flush(stdout);
            }

        } else { 
            //check if the command is withdraw, balance, or end-session
            if((strcmp(cmd, "withdraw") == 0) || (strcmp(cmd, "balance") == 0) || (strcmp(cmd, "end-session") == 0)){
                printf("No user logged in\n");
                //flush(stdout);
            } else { // not the above
                printf("Invalid command\n");
                //flush(stdout);
            }
        }
    } else { //user input no command 
        printf("Invalid command\n");
        //flush(stdout);
    }

}    
    //regex for username: "^[[:alpha:]]*[[:alpha:]]$"
    
    //regex for PIN: "^[[:digit:]]{3}[[:digit:]]$"

    //regex for amount: "^[[:digit:]]*[[:digit:]]$"

    // TODO: Implement the ATM's side of the ATM-bank protocol

    /*
     * The following is a toy example that simply sends the
     * user's command to the bank, receives a message from the
     * bank, and then prints it to stdout.
     */

    /*
    char recvline[10000];
    int n;

    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    fputs(recvline,stdout);
    */


