/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LEN 10000

static const char prompt[] = "ATM: ";

int main(int argc, char *argv[])
{
    char user_input[MAX_LEN+1];
    char sessionkey[MAX_LEN+1];
    char salt[MAX_LEN+1];
    char pepper[MAX_LEN+1];
    char iv[MAX_LEN+1];
    char line[MAX_LEN+1];
    char fcontent[MAX_LEN+1] = {0};

    FILE *atmFile;
    //check to make sure that at least two arguments are provided
    if(argc != 2){
        printf("Error opening ATM initialization file");
        return 64;
    }

    if(validate(".atm$", argv[1]) != 0){
        printf("Error opening ATM initialization file");
        return 64;
    }
    //attempt to open file
    atmFile = fopen(argv[1], "r");
    
    if(atmFile == NULL){ //couldn't open file
        printf("Error opening ATM initialization file");
        return 64;
    }

    //do something with file HERE
    while(fgets(line, MAX_LEN+1, atmFile) != NULL){
        strcat(fcontent, line);
    }

    sscanf(fcontent, "%s\n%s\n%s\n%s", sessionkey, salt, pepper, iv);

    //close file
    fclose(atmFile);
    
    ATM *atm = atm_create();

    printf("%s", prompt);
    fflush(stdout);

    while (fgets(user_input, 10000,stdin) != NULL)
    {
        atm_process_command(atm, user_input, sessionkey, salt, pepper, iv);
        printf("%s", prompt);
        fflush(stdout);
    }
	return EXIT_SUCCESS;
}
