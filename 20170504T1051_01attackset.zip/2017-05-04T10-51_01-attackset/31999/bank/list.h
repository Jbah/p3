/*
 * This is a simple list that stores key-data pairs.
 * It DOES permit multiple entires with the same key.
 * See list_example.c for an example of how to use it.
 * Feel free to change this as you desire.
 */

#ifndef __LIST_H__
#define __LIST_H__

#include <stdint.h>

typedef struct _ListElem
{
    char *user_name; //user names
    char *pin; // pin number
    int balance;
    int attempts;
    struct _ListElem *next;
} ListElem;

typedef struct _List
{
    ListElem *head;
    ListElem *tail;
    uint32_t size;
} List;

List* list_create();
void list_free(List *list);
int list_add(List *list, char *uname, char *pin,int balance);
int list_find(List *list, const char *uname);
void list_del(List *list, const char *key);
uint32_t list_size(const List *list);
int list_bal(List* list, const char *uname);
int list_validate(List *list, const char *uname,const char *pin);
int set_deposit(List*list,const char *uname,int amount);
int list_withdraw(List *list, const char *uname, int amount);
int get_attempts(List *list,const char *uname);
int reset_attempts(List *list, const char *uname);
int update_attempts(List *list,const char *uname);
#endif


