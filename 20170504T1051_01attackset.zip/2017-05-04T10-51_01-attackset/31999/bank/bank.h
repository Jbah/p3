/*
 * The Bank takes commands from stdin as well as from the ATM.  
 *
 * Commands from stdin be handled by bank_process_local_command.
 *
 * Remote commands from the ATM should be handled by
 * bank_process_remote_command.
 *
 * The Bank can read both .card files AND .pin files.
 *
 * Feel free to update the struct and the processing as you desire
 * (though you probably won't need/want to change send/recv).
 */

#ifndef __BANK_H__
#define __BANK_H__

#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include "list.h"

//build a linked list to hold the users 



typedef struct _Bank
{
    // Networking state
    int sockfd;
    struct sockaddr_in rtr_addr;
    struct sockaddr_in bank_addr;
   	List* users; // might have to be List ** users
    // Protocol state
    // TODO add more, as needed
} Bank;

Bank* bank_create();
void bank_free(Bank *bank);
ssize_t bank_send(Bank *bank, char *data, size_t data_len);
ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len);
void bank_process_local_command(Bank *bank, char *command, size_t len);
void bank_process_remote_command(Bank *bank, char *command, size_t len,char* sessionKey,char* salt, char* pepper, char* iv);
int validate_amount(int amount);
int validate(char *regexString, char *toValidate);
int sign(const unsigned char* key, unsigned char* cipher, int cipher_len, unsigned char* tag);
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,unsigned char *plaintext, unsigned char *iv);
int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key, unsigned char *ciphertext, unsigned char *iv);
void new_tok(char *str, char **arr);
char *multi_tok(char *input, char *delimiter);
int capture_msg(char* regexString, char* spmsg, char* msg);
void printhex(unsigned char * hex, int len);

#endif

