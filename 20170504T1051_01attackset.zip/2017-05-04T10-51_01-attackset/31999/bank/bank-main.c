/* 
 * The main program for the Bank.
 *
 * You are free to change this as necessary.
 */

#include <string.h>
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>
#include "bank.h"
#include "ports.h"
#include <regex.h>

#define MAX_LEN 100000
static const char prompt[] = "BANK: ";

//use to capture the message from bank
void multi_capture(char* regexString, char* source, char arr[4][MAX_LEN+1]){
    size_t maxGroups = 5;

  regex_t regexCompiled;
  regmatch_t groupArray[maxGroups];

  if (regcomp(&regexCompiled, regexString, REG_EXTENDED))
    {
      printf("Could not compile regular expression.\n");
      return;
    };

  if (regexec(&regexCompiled, source, maxGroups, groupArray, 0) == 0){
      int i;
        for(i=1; i < maxGroups; i++){
            int k;
            int j;
            for(k = groupArray[i].rm_so, j=0; k < groupArray[i].rm_eo; k++, j++){
                arr[i-1][j] = source[k];
            }
            arr[i][groupArray[i].rm_eo] = 0;
        }
      
    }

  regfree(&regexCompiled);
}



int main(int argc, char**argv)
{
   int n;
   char sendline[1000];
   char recvline[1000];
   char sessionkey[MAX_LEN+1];
   char salt[MAX_LEN+1];
   char pepper[MAX_LEN+1];
   char iv[MAX_LEN+1];
   char line[MAX_LEN+1];
   char fcontent[MAX_LEN+1] = {0};
   //for encryption/decryption
    char arr[4][MAX_LEN+1];
    char regexSP[MAX_LEN+1];
    char msg2[MAX_LEN+1];
    char plain[MAX_LEN+1] = {0};
    char tag2[MAX_LEN+1] = {0};
    int plaintext_len;
    char verify_fail[] ="verification failed!!";
    char multi_reg[] = "^(.+)---(.+)---(.+)---(.+)$";

    
  // try opening the .bank file, if it fails then post an error
  FILE *file;
  Bank *bank;

  if(argc != 2){
    printf("Error opening bank initialization file");
    return 64;
  }

  if(validate(".bank$",argv[1]) != 0){
    printf("Error opening bank initialization file");
    return 64;
  }

    file = fopen(argv[1], "r");
      if(file == NULL) {
        printf("Error opening bank initialization file");
        return 64;
      }
   

while(fgets(line, MAX_LEN+1, file) != NULL){
        strcat(fcontent, line);
    }

    sscanf(fcontent, "%s\n%s\n%s\n%s", sessionkey, salt, pepper, iv);
    fclose(file);
    bank = bank_create();
   
    
   printf("%s", prompt);
   fflush(stdout);

   while(1)
   {
       fd_set fds;
       FD_ZERO(&fds);
       FD_SET(0, &fds);
       FD_SET(bank->sockfd, &fds);
       select(bank->sockfd+1, &fds, NULL, NULL, NULL);

       if(FD_ISSET(0, &fds))
       {
           fgets(sendline, 10000,stdin);
           bank_process_local_command(bank, sendline, strlen(sendline));
           printf("%s", prompt);
           fflush(stdout);
       }
       else if(FD_ISSET(bank->sockfd, &fds))
       {
           sprintf(regexSP, "^%s(.+)%s$", salt, pepper);
	         n = bank_recv(bank, recvline, 10000);
           multi_capture(multi_reg, recvline, arr);
          char plain2[MAX_LEN+1];
	         decrypt((unsigned char*)arr[2], atoi(arr[1]), (unsigned char*)sessionkey, (unsigned char*)plain2, (unsigned char*)iv);
           sign((unsigned char*)sessionkey, (unsigned char*)salt,strlen(salt)+1, (unsigned char*)tag2);

           if(strcmp(tag2, arr[3]) != 0){ 
                bank_process_remote_command(bank,verify_fail,strlen(verify_fail), sessionkey, salt, pepper, iv);
		            msg2[0]=0;
                }
                else{
                  plaintext_len = decrypt((unsigned char*)arr[2], atoi(arr[1]), (unsigned char*)sessionkey, (unsigned char*)plain, (unsigned char*)iv);

                  capture_msg(regexSP, plain, msg2);

                fflush(stdout);
                bank_process_remote_command(bank, msg2, n, sessionkey, salt, pepper, iv);
                msg2[0]=0;
		            fflush(stdout);   
                    }
       }
   }
   
   bank_free(bank);
   
   return EXIT_SUCCESS;
}

