#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "list.h"
#include <stdio.h>

List* list_create()
{
    List *list = (List*) malloc(sizeof(List));
    list->head = list->tail = NULL;
    list->size = 0;

    return list;
}

int list_bal(List *list, const char *username){
    if(list ==NULL){
        return -1;
    }
    ListElem *curr = list->head;
    while(curr != NULL)
    {
        if(strcmp(curr->user_name, username) == 0){
            return curr->balance;
        }
        curr = curr->next;
    }

    return -1;

}


void list_free(List *list)
{
    if(list != NULL)
    {
        ListElem *curr = list->head;
        ListElem *next;
        while(curr != NULL)
        {
            next = curr->next;
            free(curr->user_name);
            free(curr->pin);
            free(curr);
            curr = next;
        }
        free(list);
    }
}

//finds if user name already exists
int list_find(List *list, const char *username){
    //printf("IN LIST_FIND: USERNAME TO FIND: %s\n", username);
    //printf("LIST SIZE: %d\n", list_size(list));
    fflush(stdout);
    if(list == NULL){
        //printf("list is null\n");
        return 1;
    }
    ListElem *curr = list->head;
    //printf("comparing with: %s\n", curr->user_name);
    while(curr != NULL)
    {
        //printf("comparing with: %s\n", curr->user_name);
        if(strcmp(curr->user_name, username) == 0){
            //printf("USER FOUND!");
            return 0;
        }
        curr = curr->next;
    }

    return 1;
}

int list_validate(List *list, const char *username,const char *pin){
    if(list == NULL)
        return 1;

    ListElem *curr = list->head;
    while(curr != NULL)
    {
        if((strcmp(curr->user_name, username) == 0) && (strcmp(curr->pin,pin) == 0))
            return 0;
        curr = curr->next;
    }

    return 1;
}

//don't allow duplicates
int list_add(List *list, char *username, char *pin,int balance)
{
    // the user already exists so return a failure
        if(list_find(list,username) == 0){
            return 1;
        }

    ListElem *elem = (ListElem*) malloc(sizeof(ListElem));
    elem->user_name = malloc(strlen(username)+1);
    strcpy(elem->user_name, username);
    elem->pin = malloc(strlen(pin)+1);
    strcpy(elem->pin, pin);
    elem->balance = balance;
    elem->attempts = 0;
    elem->next = NULL;

    if(list->tail == NULL){
        list->head = elem;
        list->tail = elem;
    }
    else { //add to end of the list
        list->tail->next = elem;
        list->tail = elem;
    }

    list->size++;
    return 0; //successful add
}
                                        //key is username
void list_del(List *list, const char *key)
{
    // Remove the element with key 'key'
    ListElem *curr, *prev;

    curr = list->head;
    prev = NULL;
    while(curr != NULL)
    {
        if(strcmp(curr->user_name, key) == 0)
        {
            // Found it: now delete it

            if(curr == list->tail)
                list->tail = prev;

            if(prev == NULL)
                list->head = list->head->next;
            else
                prev->next = curr->next;

            list->size--;

            free(curr);
            return;
        }

        prev = curr;
        curr = curr->next;
    }
}

int update_attempts(List *list, const char *uname){
    if(list == NULL)
        return -1;

    ListElem *curr = list->head;
    while(curr != NULL)
    {
        if(strcmp(curr->user_name, uname) == 0){
            curr->attempts = curr->attempts + 1;
            return 0;
        }
        curr = curr->next;
    }

    return -1;
}

int get_attempts(List *list, const char *uname){
    if(list == NULL)
        return -1;

    ListElem *curr = list->head;
    while(curr != NULL)
    {
        if(strcmp(curr->user_name, uname) == 0){
            return curr->attempts;
        }
        curr = curr->next;
    }

    return -1;
}

int reset_attempts(List *list, const char *uname){
    if(list == NULL)
        return -1;

    ListElem *curr = list->head;
    while(curr != NULL)
    {
        if(strcmp(curr->user_name, uname) == 0){
            curr->attempts = 0;
            return 0;
        }
        curr = curr->next;
    }

    return -1;
}

int set_deposit(List*list,const char *uname,int amount){
    if(list == NULL)
        return -1;

    ListElem *curr = list->head;
    while(curr != NULL)
    {
        if(strcmp(curr->user_name, uname) == 0){
            curr->balance = curr->balance + amount;
            return 0;
        }
        curr = curr->next;
    }

    return -1;
}

int list_withdraw(List *list,const char *uname, int amount){
    if(list == NULL)
        return -1;

    ListElem *curr = list->head;
    while(curr != NULL)
    {
        if(strcmp(curr->user_name, uname) == 0 && curr->balance>amount){
            curr->balance = curr->balance - amount;
            return 0;
        }
        curr = curr->next;
    }

    return -1;
}
uint32_t list_size(const List *list)
{
    return list->size;
}
