#include "bank.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <ctype.h>
#include <stdio.h>
#include <sys/select.h>
#include <regex.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>

#define MAX_USER 250
#define MAX_LEN 10000

Bank* bank_create()
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bank->users = list_create(); // create linked list to hold users


    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as   needed

    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd); 
        list_free(bank->users); // when bank is freed the list must be freed first
        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

int validate(char *regexString, char *toValidate){
    regex_t regex;
    int reti;
       
    reti = regcomp(&regex, regexString, REG_EXTENDED);
    if( reti ){ 
         
        regfree(&regex);
        return -1; 
    }

    reti = regexec(&regex, toValidate, 0, NULL, 0);
    if(!reti){
        regfree(&regex);
        return 0; //there is a match
    } else {
        regfree(&regex);
       
        return -1; //no match or something error occured
    }
}

void bank_process_remote_command(Bank *bank, char *command, size_t len,char* sessionKey,char* salt, char* pepper, char* iv){
   ;
    //cipher stuff 
    char msg[MAX_LEN+1];
    unsigned char cipher[MAX_LEN+1] = {0};
    unsigned char tag[MAX_LEN+1] = {0};
    int cipher_len;
    int tag_len;
    char commline[MAX_LEN+1];
    char username[MAX_USER+1];
    char input2[MAX_LEN+1]; //use to store either pin or amt
    char success[]="0";
    char attempt_Err[]="-99";
    char fail_sig[]="-1";
    char toATM[MAX_LEN+1];
    int num_args;
    int bal;
    int amount = -9999;
   

    num_args = sscanf(command, "%s %s %s", commline, username, input2);
    

    if(strcmp(commline,"user_exist") == 0){
       
        if(num_args != 2 || (validate("^[[:alpha:]]*[[:alpha:]]$", username) != 0) || (strlen(username) > MAX_USER) ) {
            fflush(stdout);

            sprintf(msg,"%s%s%s",salt,fail_sig,pepper);
           

            cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
            tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt, strlen(salt)+1, (unsigned char*)tag);
            sprintf(toATM, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
            bank_send(bank,toATM,strlen(toATM)+1);
           

        }else{

            if(list_find(bank->users,username) !=0){
                fflush(stdout);
                sprintf(msg,"%s%s%s",salt,fail_sig,pepper);
                cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt, strlen(salt)+1, (unsigned char*)tag);
                sprintf(toATM, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
                bank_send(bank,toATM,strlen(toATM)+1);
            }else{
                fflush(stdout);
                sprintf(msg,"%s%s%s",salt,success,pepper);
                cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt, strlen(salt)+1, (unsigned char*)tag);
                sprintf(toATM, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
                bank_send(bank,toATM,strlen(toATM)+1);
            }
        }

    }else if(strcmp(commline,"validate") == 0){
        if(num_args != 3 || (validate("^[[:alpha:]]*[[:alpha:]]$", username) != 0) || 
            (strlen(username) > MAX_USER) || validate("^[[:digit:]]{3}[[:digit:]]$", input2) != 0) {
            sprintf(msg,"%s%s%s",salt,fail_sig,pepper);
            cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
            tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt,strlen(salt)+1, (unsigned char*)tag);
            sprintf(toATM, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
            bank_send(bank,toATM,strlen(toATM)+1);


        }else{
            if(get_attempts(bank->users,username) < 5 && list_validate(bank->users,username,input2) == 0){
                
                fflush(stdout);
                reset_attempts(bank->users,username); //attempts reset to 0
                sprintf(msg,"%s%s%s",salt,success,pepper);
                cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt, strlen(salt)+1, (unsigned char*)tag);
                sprintf(toATM, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
                bank_send(bank,toATM,strlen(toATM)+1);
            }else{
                if(get_attempts(bank->users,username) >= 5){
                    sprintf(msg,"%s%s%s",salt,attempt_Err,pepper);
                     cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                    tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt, strlen(salt)+1, (unsigned char*)tag);
                    sprintf(toATM, "%d---%d---%s---%s", tag_len,cipher_len, cipher, tag);
                    bank_send(bank,toATM,strlen(toATM)+1);

                }else{
                    

                    sprintf(msg,"%s%s%s",salt,fail_sig,pepper);
                    cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                    tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt, strlen(salt)+1, (unsigned char*)tag);
                    sprintf(toATM, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);

                    bank_send(bank,toATM,strlen(toATM)+1);

                }
                update_attempts(bank->users,username);
            }

        }

    }
     else if(strcmp(commline,"withdraw") == 0){
  
        if(validate("^[[:digit:]]*[[:digit:]]$", input2) == 0){ 
            sscanf(input2, "%d", &amount); 
        }

        if(num_args != 3|| (validate("^[[:alpha:]]*[[:alpha:]]$", username) != 0) || (strlen(username) > MAX_USER) ||
            validate_amount(amount) != 0) {

            sprintf(msg,"%s%s%s",salt,fail_sig,pepper);
            cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
            tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt, strlen(salt)+1, (unsigned char*)tag);
            sprintf(toATM, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
            bank_send(bank,toATM,strlen(toATM)+1);
        }else{
            bal = list_bal(bank->users,username);
            if( bal < amount ){
                fflush(stdout);
                sprintf(msg,"%s%s%s",salt,fail_sig,pepper);
                cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt, strlen(salt)+1, (unsigned char*)tag);
                sprintf(toATM, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
                bank_send(bank,toATM,strlen(toATM)+1);


            }
            else{
	           if( list_withdraw(bank->users,username,amount)!=-1){
                sprintf(msg,"%s%s%s",salt,success,pepper);
                cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt,strlen(salt)+1, (unsigned char*)tag);
                sprintf(toATM, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
                bank_send(bank,toATM,strlen(toATM)+1);
	      }else{
		 sprintf(msg,"%s%s%s",salt,fail_sig,pepper);
                cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt,strlen(salt)+1, (unsigned char*)tag);
                sprintf(toATM, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
                bank_send(bank,toATM,strlen(toATM)+1);
	      }

            }
        }

    }

    else if(strcmp(commline,"balance") == 0){

        if(num_args != 2){
                sprintf(msg,"%s%s%s",salt,fail_sig,pepper);
                cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt, strlen(salt)+1, (unsigned char*)tag);
                sprintf(toATM, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
                bank_send(bank,toATM,strlen(toATM)+1);

        }else{
            bal = list_bal(bank->users,username);
            if(bal == -1){
                sprintf(msg,"%s%s%s",salt,fail_sig,pepper);
                cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt, strlen(salt)+1, (unsigned char*)tag);
                sprintf(toATM, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
                bank_send(bank,toATM,strlen(toATM)+1);
            }else{
               
                sprintf(msg,"%s%d%s",salt,bal,pepper);
                cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
                tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt, strlen(salt)+1, (unsigned char*)tag);
                sprintf(toATM, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
                bank_send(bank,toATM,strlen(toATM)+1);
            }
        }
    }

    else{
            fflush(stdout);
            sprintf(msg,"%s%s%s",salt,fail_sig,pepper);
            cipher_len = encrypt((unsigned char*)msg, strlen(msg)+1, (unsigned char*)sessionKey, (unsigned char*)cipher, (unsigned char*)iv);
            tag_len = sign((unsigned char*)sessionKey, (unsigned char*)salt, strlen(salt)+1, (unsigned char*)tag);
            sprintf(toATM, "%d---%d---%s---%s", tag_len, cipher_len, cipher, tag);
            bank_send(bank,toATM,strlen(toATM)+1);
    }


    /*
    char sendline[1000];
    command[len]=0;
    sprintf(sendline, "Bank got: %s", command);
    bank_send(bank, sendline, strlen(sendline));
    printf("Received the following:\n");
    fputs(command, stdout);
    */
}


void bank_process_local_command(Bank *bank, char *command, size_t len)
{

    char commline[1000];
    char username[MAX_USER+1];
 
    char input1[1000]; //use for pin or amt
    char input2[1000]; //use for balance
    char input3[1000]; //use to check for extra input since max input is 4

    int balance = -9999;
    int amount = -9999;
    int num_args;
    char path[MAX_USER+6];
    FILE *file;
    int bal;
     //add 6 for .card extension
    char ext[6] = ".card";
    
    
    num_args = sscanf(command, "%s %s %s %s %s", commline, username, input1, input2, input3);

    if(strcmp(commline,"create-user") == 0){

        if(validate("^[[:digit:]]*[[:digit:]]$", input2) == 0){ 
            sscanf(input2, "%d", &balance); 
        }
        if(num_args != 4 || (validate("^[[:alpha:]]*[[:alpha:]]$", username) != 0) || (strlen(username) > MAX_USER) || 
            validate("^[[:digit:]]{3}[[:digit:]]$", input1) != 0 || validate_amount(balance) ) {
            printf("Usage: create-user <user-name> <pin> <balance>\n");
        }
        else{

            if(list_add(bank->users,username,input1,balance) != 0){
                printf("Error: user %s already exists\n",username);
            }else{
                memset(path,'\0',sizeof(path)); //null terminates the path
                strncpy(path,username,strlen(username)); //length of user should be valid to copy
                strncat(path,ext,strlen(ext));
                file  = fopen(path, "w"); // create <u_name>.card file
                if(file == NULL) {
                printf("Error creating file for user %s\n",username);
                }
                else{
                    printf("Created user %s\n",username); //SUCCESSFUL ADD/created file 
                }


            }

        }
    }
    else if(strcmp(commline,"deposit") == 0){
        if(validate("^[[:digit:]]*[[:digit:]]$", input1) == 0){ 
            sscanf(input1, "%d", &amount);
        }
        if(num_args != 3 || (validate("^[[:alpha:]]*[[:alpha:]]$", username) != 0) || (strlen(username) > MAX_USER) || validate_amount(amount)){
            printf("Usage: deposit <user-name> <amt>\n"); 
        }
        else{ //valid inputs
            if(list_find(bank->users,username) !=0){
                printf("No such user\n");
            }
            else {//the user was found
                bal = list_bal(bank->users,username);
                if(amount>(INT_MAX-bal)){ 
                    printf("Too rich for this program\n"); 
                }else{
		  set_deposit(bank->users,username,amount);
                    printf("$%d added to %s's acount\n",amount,username);
		}

            }
        }
    }else if(strcmp(commline,"balance") == 0){
       
        if(num_args != 2 || (validate("^[[:alpha:]]*[[:alpha:]]$", username) != 0) || (strlen(username) > MAX_USER) ){
            printf("Usage: balance <user-name>\n");
        }else{
            bal = list_bal(bank->users,username);
            if(bal == -1){
                printf("No such user\n");
            }else{
                printf("$%d\n",bal);
            }
        }
    }
    else{
        printf("Invalid command\n");
    }

    // TODO: Implement the bank's local commands
}

//amount validation      removed validate_bal because it was the same as validate amount
int validate_amount(int amount){
    if(amount<0 || amount>= INT_MAX){
        //printf("amount invalid\n");
        return -1;
    }
    //printf("amount valid\n");
    return 0;
}




//capture the message between the salt and pepper
int capture_msg(char* regexString, char* spmsg, char* msg){
    size_t maxGroups = 2;
    regex_t regex;
    regmatch_t capArr[maxGroups];
    if (regcomp(&regex, regexString, REG_EXTENDED)){
        printf("Could not compile regular expression.\n");
        regfree(&regex);
        return 1;
    }

    if (regexec(&regex, spmsg, maxGroups, capArr, 0) == 0){
        char msgCopy[strlen(spmsg) + 1];
        strcpy(msgCopy, spmsg);
        msgCopy[capArr[1].rm_eo] = 0;
        strcpy(msg, msgCopy + capArr[1].rm_so);
        regfree(&regex);
        return 0;
    } else {
        regfree(&regex);
        return 1;
    }  
}

/*
 * Encrypt "plaintext_in" with "key" into "ciphertext"
 * "ciphertext" must be a char[] with enough space to hold the output
 * Uses IV of all zeroes
 *
 * Returns the length of "ciphertext" or -1 on error
 */
int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key, 
        unsigned char *ciphertext, unsigned char *iv) {
    EVP_CIPHER_CTX *ctx;
    //unsigned char iv[16] = {0};
    int len = 0;
    int ciphertext_len = 0;

    if(!(ctx = EVP_CIPHER_CTX_new())) {
        return -1;
    }
    if(EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv) != 1) {
        return -1;
    }
    if(EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext_in, plaintext_len) != 1) {
        return -1;
    }
    ciphertext_len = len;

    if(EVP_EncryptFinal_ex(ctx, ciphertext + len, &len) != 1) {
        return -1;
    }
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

/*
 * Decrypt "cipher" with "key" into "plain"
 */
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
        unsigned char *plaintext, unsigned char *iv) {
    EVP_CIPHER_CTX *ctx;
    //unsigned char iv[16] = {0};
    int len;
    int plaintext_len;

    if(!(ctx = EVP_CIPHER_CTX_new())) {
        return -1;
    }
    if(EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv) != 1) {
        return -1;
    }
    if(EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len) != 1) {
        return -1; 
    }
    plaintext_len = len;
    if(EVP_DecryptFinal_ex(ctx, plaintext + len, &len) != 1) {
        return -1; 
    }
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}

/*
 * Sign "cipher" with "key"
 */
int sign(const unsigned char* key, unsigned char* cipher, int cipher_len, 
        unsigned char* tag) {
    unsigned int len = 0;
    HMAC_CTX ctx;

    HMAC_CTX_init(&ctx);
    HMAC_Init_ex(&ctx, key, strlen((char*)key), EVP_sha1(), NULL);
    HMAC_Update(&ctx, cipher, cipher_len);
    HMAC_Final(&ctx, tag, &len);
    
    HMAC_CTX_cleanup(&ctx);
    return len;
}




