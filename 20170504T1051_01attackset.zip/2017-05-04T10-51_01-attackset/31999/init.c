#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#define MAX_LEN 1000
void rand_str(char *dest, size_t length) { 
       
  char charset[] = /*"0123456789012345699039203232"*/ "abcdefghijklmnopqrstuvwxyz";
                     //"ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    while (length-- > 0) {
        size_t index = (double) rand() / RAND_MAX * (sizeof charset - 1);
        *dest++ = charset[index];
    }
    *dest = '\0';
}

int main(int argc, char *argv[]){
	int pl = strlen(argv[1]) + 1;
	char bankfp[pl + 5]; //bank file path length plus .bank length (+5) + \0
	char atmfp[pl + 4]; //atm file path length plus .atm length (+4) + \0 
	FILE *fpBank;
	FILE *fpATM;
	char sessionKey[MAX_LEN+1];
	char salt[MAX_LEN+1];
	char pepper[MAX_LEN+1];
	char iv[MAX_LEN+1];
	char output[MAX_LEN+1];


	if(argc == 2){
	        strncpy(bankfp, argv[1],strlen(bankfp));
		strcat(bankfp, ".bank");
	

		strncpy(atmfp, argv[1],strlen(atmfp)); 
		strcat(atmfp, ".atm");
		
		
		//check to see if bank file exist at this path
		fpBank = fopen(bankfp, "r");
		fpATM = fopen(atmfp, "r");

		if((fpBank == NULL) && (fpATM == NULL)){
			//printf("does not exist. YAY\n");

			//create files
			fpBank = fopen(bankfp, "w");
			fpATM = fopen(atmfp, "w");

			//check if there is error in file creation of either files
			if((fpBank == NULL) || (fpATM == NULL)){
				printf("Error creating initialization files");
				fclose(fpBank);
				fclose(fpATM);
				return 64;
			}
			//write something to file HERE 
			srand(time(0));
			rand_str(sessionKey, 16);
			rand_str(salt, 16);
			rand_str(pepper,16);
			rand_str(iv,16);

			sprintf(output, "%s\n%s\n%s\n%s", sessionKey, salt, pepper, iv);

			fputs(output, fpBank);
			fputs(output, fpATM);


			//close files 
			fclose(fpBank);
			fclose(fpATM);
			printf("Successfully initialized bank state\n");
			return 0;

		} else {
			printf("Error: one of the files already exists\n");
			return 63;
		}


	} else {
		printf("Usage: init <filename>");
		return 62;
	}
}
