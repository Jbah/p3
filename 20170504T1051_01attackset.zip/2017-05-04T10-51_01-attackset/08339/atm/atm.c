#include "atm.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

// We added these
#include <regex.h>
#define MAX_LEN 100

ATM* atm_create()
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // our edit
    atm->in_use = 0;

    // Set up the protocol state
    // TODO set up more, as needed

    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}


// void atm_process_command(ATM *atm, char *command, size_t len)
void atm_process_command(ATM *atm, char *command) {   //----> the old method header

  char task[MAX_LEN + 1];
  char task2[MAX_LEN + 1];
  char task3[MAX_LEN + 1];
  char warning3[MAX_LEN + 1];
  char user[251];
  int result = 0; // stores return value of begin_Session(..)
  
  char response[MAX_LEN + 1];
  char response2[MAX_LEN + 1];
  char response3[1000];

  char request[MAX_LEN + 1]; 
  char request2[1000];
  char request3[1000];

  int n;
  FILE* fptr;
  char card[MAX_LEN + 1];
  char pin[5];
  char cardPin[5];
  char userPrompt[MAX_LEN + 1] = "ATM ";
  char amount[MAX_LEN + 1];

  // -------------------read command and extract the task and its inputs------------------------

  sscanf(command, " %s ", task); /* CHECK!!! might need to use different scanner that accepts size_t */
  task[MAX_LEN] = '\0'; /* add a null termination character for security? */ 
 

  /* -------------------------------begin session command : dependent on in_use == 0 --------------------------*/
  
  //if the atm is not in use
  if (atm->in_use == 0) {  

    if (strcmp(task, "begin-session") == 0) {
    
	// -------------------------checking task ----------------------------

      sscanf(command, " %s %s ",task, user);

	//-------------------------validating user name----------------------------

        if ( valid_user(atm,user) == 1) {

	  printf("Usage: begin-session <user-name>\n");

	}
	else {
	  //---------------------check if this user is in the bank-----------------------
	 	 
	  strcpy(request, "exist? ");
	  strcat(request, user);

	  // puts(request); // good up to here: "exist? alice"

	  atm_send(atm, request, strlen(request)); // send request to bank
	  n = atm_recv(atm, response, MAX_LEN + 1);  // receive response from bank
	  response[n]=0;
	  // fputs(response,stdout); // check response

	  
	  if ( strcmp(response, "yes") == 0 ) { // if user is in bank then procees
	    
	    // ------------------------------accessing user's card------------------
	    strcpy(card, user);
	    strcat(card, ".card");
	 
	     fptr = fopen(card, "r"); 

	     if (fptr == NULL) { // if there's an error opening card

	       printf("Unable to access <user-name>'s card");
	     }
	     else {

	       printf("PIN? ");
	       fgets(pin, 5, stdin); // reading in pin from the user
	       pin[4] = '\0';
	      
	       if ( valid_pin(atm, pin) == 1 ) { // if incorect pin format
		 
		 printf("Not authorized\n");
	       }

	       //----------------------check if pin matches the card----------
	       else {

		 fgets(cardPin, 5, fptr);
		 cardPin[4] = '\0';

		 //printf("pin from the card %s\n", cardPin);
		 
		 if ( strcmp(pin, cardPin) == 0 ) { // if they match
		   printf("Authorized\n");

		   //-----PRINT PROMPT---------
		   atm->in_use = 1;		   
   		   strcat(userPrompt,"(");
   		   strcat(userPrompt, user);
  		   strcat(userPrompt,")");
   		   strcat(userPrompt,": ");

		   atm->flag = 0;
  		   while ( (atm->in_use == 1) && (fgets(request2, 10000,stdin) != NULL) ) {  //&& (atm->in_use == 1)

		     begin_session(atm, request2, user); 
		     atm->flag = 1;
		     if (atm->in_use == 1) {
		       printf("%s", userPrompt);
		       fflush(stdout);
		     }
		   }
		   //------INNER while loop-------
		        
	  			   
		 } // matches with if ( pins match)				  
			      
	       else {                     // if they don't match
		 printf("Not authorized\n");
	       }
	     }
	     
	  }
	}
      else { 
	printf("No such user\n");
      }

	}
      }   
      
    // if the user did NOT type "begin session"
    else {

      printf("No user logged in\n");
    }

  }

  // if the atm is in use
  else {

  }     
}




// Aux function: make sure username has valid structure
  int valid_amount(ATM *atm, char* amount) {

    regex_t regexAmount; // regex variables
    int retiAmount;
      
    //------------------------validate username structure-------------------

    /* compile regular expression for name input */
    retiAmount = regcomp(&regexAmount, "^[0-9]+$", REG_EXTENDED);
    if (retiAmount) {
    printf("Could not compile regex amount\n");
    return 1; 
    }
    // execute regular expression 
    retiAmount = regexec(&regexAmount, amount, 0, NULL, 0);  

    //checking if valid username
    if ( retiAmount == REG_NOMATCH ) {
      
      return 1;

      //free regex
    }
    regfree(&regexAmount);
    
    return 0; // return 0 on success, 1 on problem
   
  }


// Aux function: make sure username has valid structure
  int valid_user(ATM *atm, char* user) {

    regex_t regexName; // regex variables
    int retiName;
      
    //------------------------validate username structure-------------------

    /* compile regular expression for name input */
    retiName = regcomp(&regexName, "^[a-zA-Z]+$", REG_EXTENDED);
    if (retiName) {
    printf("Could not compile regex name\n");
    return 1; 
    }
    // execute regular expression 
    retiName = regexec(&regexName, user, 0, NULL, 0);  

    //checking if valid username
    if ( retiName == REG_NOMATCH ) {
      
      return 1;

      //free regex
    }
    regfree(&regexName);
    
    return 0; // return 0 on success, 1 on problem
   
  }

 int valid_pin(ATM *atm, char* pin) {

    regex_t regexPin; // regex variables
    int retiPin;
      
    //------------------------validate pin structure-------------------

    /* compile regular expression for pin input */
    retiPin = regcomp(&regexPin, "^[0-9][0-9][0-9][0-9]$", REG_EXTENDED);
    if (retiPin) {
      printf("Could not compile regex pin\n");
      return 1; 
  }

    // printf("Pin in valid_pin(..) is: %s\n", pin);

    // executing regular expression
   retiPin = regexec(&regexPin, pin, 0, NULL, 0);

    //checking if valid pin
    if ( retiPin == REG_NOMATCH ) {
      printf("pin not right format\n");
      return 1;     
    }
    
    regfree(&regexPin);
    
    return 0; // return 0 on success, 1 on problem

   
  }










void begin_session(ATM *atm, char *commd, char *user ) { 

  char task2[MAX_LEN + 1];
  char task3[MAX_LEN + 1];
  char warning3[MAX_LEN + 1];
  //char user[251];

  char response2[MAX_LEN + 1];
  char response3[1000];

  char request2[1000];
  char request3[1000];

  char userPrompt[MAX_LEN + 1] = "ATM ";
  char amount[MAX_LEN + 1];  
  int n;
		     
    sscanf(commd, " %s %s ", task2, amount );
							
    if (strcmp(task2, "withdraw") == 0) {

      if (valid_amount(atm, amount) == 1) {
			  
	printf("Usage: withdraw <amt>\n");
      }

      else {

	strcpy(request2, "withdraw ");
	strcat(request2, user);
	strcat(request2, " ");
	strcat(request2, amount);
	
	atm_send(atm, request2, strlen(request2)); // send request to bank
	n = atm_recv(atm, response2, MAX_LEN + 1);  // receive response from bank
	response2[n]=0;
	
	if ( strcmp(response2, "insufficient") == 0 ) {
	  
	  printf("Insufficient funds\n");
	}
	else {
	  printf("$%s dispensed\n", amount);
	}
      }				
    }
    
    else if (strcmp(task2, "balance") == 0) {
      
      sscanf(request2, " %s %s ", task3, warning3 );
      
      //if (warning3 != NULL) {
//	printf("Usage: balance\n");
  //    }
      
//      else {
	
	strcpy(request3, "balance ");
	strcat(request3, user);
	
	atm_send(atm, request3, strlen(request3)); // send request to bank
	n = atm_recv(atm, response3, MAX_LEN + 1);  // receive response from bank
	response3[n]=0;
	
	printf("$%s\n", response3);			   
//      }			 			   
    }
    else  if (strcmp(task2, "end-session") == 0) {
      atm->in_use = 0;
      printf("User logged out\n");
      return;      
    }			 
    else {
	if (atm->flag == 1) {		
     	   printf("Invalid command %s\n", request2);
	}
    }
     
  
}


