/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include <string.h>
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>
#include "bank.h"
#include "ports.h"
#include "atm.h"

static const char prompt[] = "ATM: ";

int main(int argc, char**argv)
{
    char user_input[1000];
/*** WE ADDED THIS ***/
   int found;
   char *p;
   FILE *fptr;

   fptr = fopen(argv[1], "w+");   /***  check this!!!!! ***/   /*** check if called with more than 1 program ***/
   if (!fptr)
      {
	  printf("Error opening atm initialization file\n");
          return 64;
       }

   /*** make sure bank only processes .atm files ***/
   /* Think will check to see if argument being passed is a .atm */
   found = 0;
   p = strrchr(argv[1], '.');
   if (p == NULL) {
      printf("this is not a .atm file\n");  /* remove later */
      return 64;  /* check if this right return number */ 
   }
   if (p) {
      found = strcmp(p, ".atm"); // if 0, then it matches 
      if (found != 0) {
         printf("this is not a .atm file\n");  /* remove later */
         return 64;  /* check if this right return number */ 
      }
   }
   





/* *********************** GIVEN CODE ******************************************************* */

    ATM *atm = atm_create();

    printf("%s", prompt);
    fflush(stdout);

    while (fgets(user_input, 10000,stdin) != NULL)
    {
        atm_process_command(atm, user_input);
        printf("%s", prompt);
        fflush(stdout);
    }
	return EXIT_SUCCESS;
}
