/* 
 * The main program for the Init.
 *
 * 
 */

#include <string.h>
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <openssl/rand.h>


/* static const char prompt[] = "BANK: "; */

int main(int argc, char**argv)
{
   
   char fname[100];     /* const??? may have to change 100*/
   char fnameb[100];    /* const??? */
   char fnamea[100];    /* const??? */
 //  unsigned char key[100];
   FILE *fptrA;
   FILE *fptrB; 

   /*  If the user fails to provide precisely one argument, 
	then print "Usage:  init <filename>" and return value 62 */
   if ((argv[1] == NULL) || (argc > 2)) {
	printf("Usage:  init <filename>");
	return 62;
   } 
     

   strncpy(fname, argv[1], 99); /* 99 is coming from fname */
   fname[100] = '\0';
   
   strncpy(fnamea, fname, 99); /* 99 is coming from fname */
   fnamea[100] = '\0';
 
   strncpy(fnameb, fname, 99); /* 99 is coming from fname */
   fnameb[100] = '\0';


   strcat(fnameb, ".bank");  
   strcat(fnamea, ".atm");    
   printf("%s\n", fnamea);
   printf("%s\n", fnameb);


   /* F_OK tests existence also (F_OK, W_OK, X_OK). for readable, writeable, executable */
   if ((access(fnameb, F_OK) == 0) || (access(fnamea, F_OK) == 0)) {

        printf("Error:  one of the files already exists\n");
        return 63;
   }
   
 //  RAND_bytes(key, 16);

   /* Creating bank and atm files */
  
   fptrA = fopen(fnamea, "w"); /* changed a+ to w... check tutorials point */  /* mode originally: r" */

   if (!fptrA)
   {
     printf("Error creating initialization files\n"); /* remember to take out the 1 and 2 */
        return 64;
   } 
 /*  else {
	fputs(key, fptrA);
   }
*/
   fptrB = fopen(fnameb, "w");

   if (!fptrB)
   {
	printf("Error creating initialization files\n");
        return 64;
   } 
/*   else {
	fputs(key, fptrA);
   }
*/
   printf("Successfully initialized bank state\n");

   return 0;
}
