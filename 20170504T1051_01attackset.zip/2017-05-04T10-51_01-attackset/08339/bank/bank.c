#include "bank.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <regex.h>
#include <limits.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <openssl/aes.h>
#include <openssl/err.h>

#define MAX_LEN 100

int create_user(Bank *bank, char *command, size_t len);
int deposit(Bank *bank, char *command, size_t len);
int balance(Bank *bank, char *command, size_t len);

Bank* bank_create()
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    /* initialize hashtable */
    bank->ht = hash_table_create(100);  //100 is the number of bins, may need to change    

    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}


/* Supports only the bank's commands: "create-user", "deposit", "balance" */
void bank_process_local_command(Bank *bank, char *command, size_t len)
{
  // TODO: Implement the bank's local commands
  char task[MAX_LEN + 1];
  int createUseri;
  int depositi;
  int balancei;


  /* read the first string in "command" to determine task */
  sscanf(command, " %s ", task); /* CHECK!!! might need to use different scanner that accepts size_t */
  task[len] = '\0'; /* add a null termination character for security? */	

  /* Create-user command */
  if (strcmp(task, "create-user") == 0)  {
    //call create-user
    createUseri = create_user(bank, command, len);  // returns 1 if anything failed (for debugging purposes)
  }
  /* Deposit command */
  else if (strcmp(task, "deposit") == 0) {
    depositi = deposit(bank, command, len);  // returns 1 if anything failed (for debugging purposes)
  }

  /* Balance command */
  else if (strcmp(task, "balance") == 0) {
    balancei = balance(bank, command, len);  // returns 1 if anything failed (for debugging purposes)
    // num = sscanf(command, " %s %s ", task, input1);
  }
  else {
    printf("Invalid command");

  }

}

/* Supports commans from the atm:  */
void bank_process_remote_command(Bank *bank, char *command, size_t len)
{   
    char task[MAX_LEN + 1];   // we added  what we store "exists?" into
    char input1[MAX_LEN + 1];   // we added  what we store "<user-name>", etc. into
     char input2[MAX_LEN + 1];
     int amtInt, *value;
  
    /* read the first string in "command" to determine task */

    char sendline[1000];
    command[len]=0;
	
    // now process command 
    sscanf(command, " %s %s %s ", task, input1, input2); /* withdraw alice amount */
    task[100] = '\0';
    input1[100] = '\0';
    input2[100] = '\0';
    printf("command is: %s", command);

    if (strcmp(task, "exist?") == 0)  {
     
      if (hash_table_find(bank->ht, input1) != NULL) {
        // send "yes" to atm
        sprintf(sendline, "yes");
        bank_send(bank, sendline, strlen(sendline));
      }
      else {  
        // else send "no" to atm
        sprintf(sendline, "no");
        bank_send(bank, sendline, strlen(sendline));
      }
    }

    else if (strcmp(task, "withdraw") == 0 ) {
      printf("Here in withdraw\n");
      amtInt = atoi(input2);

      printf("AmtInt is: %d\n", amtInt);

      value = (int *)hash_table_find(bank->ht, input1);

      printf("Subtraction: %d\n", (*value) - amtInt);

      if ( ( (*value) - amtInt) < 0 ) {

	printf("Insufficient funds\n");
	sprintf(sendline, "insufficient");
	bank_send(bank, sendline, strlen(sendline));
      }
      else {

	*value = *value - amtInt;
	sprintf(sendline, "confirmed");
	bank_send(bank, sendline, strlen(sendline));
      }
    }

    else if ( strcmp(task, "balance") == 0 ) {

      value = (int *)hash_table_find(bank->ht, input1);
      sprintf(sendline, "%d", (*value));
      bank_send(bank, sendline, strlen(sendline));

    }
    else {
      // else not "exists?" command.  This was the original code given to us
      sprintf(sendline, "Bank got: %s", command);
      bank_send(bank, sendline, strlen(sendline));
    }
   
    printf("Received the following:\n");
    fputs(command, stdout);
}


int create_user(Bank *bank, char *command, size_t len) {
  char task[MAX_LEN + 1];
  char input1[MAX_LEN + 1];
  char input2[MAX_LEN + 1];
  char input3[MAX_LEN + 1];
//  unsigned char cipher[128] = {0};
//  char key[MAX_LEN + 1];
//  char sendline[1000];
  int num;
  regex_t regexName;
  int retiName;
  regex_t regexPin;
  int retiPin;
  regex_t regexBalance;
  int retiBalance;
  char card[100];
  FILE *fptr;
//  char *ptr;
  int *balance;
  
//  int balancei;

  /* compile regular expression for name input */
  retiName = regcomp(&regexName, "^[a-zA-Z]+$", REG_EXTENDED);
  if (retiName) {
    printf("Could not compile regex name\n");
    return 1; 
  }
  /* compile regular expression for pin input */
  retiPin = regcomp(&regexPin, "^[0-9][0-9][0-9][0-9]$", 0);
  if (retiPin) {
    printf("Could not compile regex pin\n");
    return 1; 
  }
  /* compile regular expression for balance input */
  retiBalance = regcomp(&regexBalance, "^[0-9]+$", REG_EXTENDED);
  if (retiBalance) {
    printf("Could not compile regex for balance\n");
    return 1; 
  }

  num = sscanf(command, " %s %s %s %s ", task, input1, input2, input3);
  if (num != 4) {      /* sscanf will return the number of variables filled */
    printf("Invalid command\n");  /* remove later? */
    return 1;
  }
 
  /* user name */
  // execute regular expression 
  retiName = regexec(&regexName, input1, 0, NULL, 0);
  retiPin = regexec(&regexPin, input2, 0, NULL, 0);
  retiBalance = regexec(&regexBalance, input3, 0, NULL, 0);

  /* If the inputs to the command are invalid print the following: */
  if ((retiName == REG_NOMATCH) || (retiPin == REG_NOMATCH) || (retiBalance == REG_NOMATCH)) {
    printf("Usage:  create-user %s %s %s\n", input1, input2, input3);
    /* free regex structures */
    regfree(&regexName);
    regfree(&regexPin);
    regfree(&regexBalance);
    return 1;
  }
  /* free regex structures - we need to do this right after we're done using them */
  regfree(&regexName);
  regfree(&regexPin);
  regfree(&regexBalance);

  /* user already exists */  
  if (hash_table_find(bank->ht, input1) != NULL) { 
    printf("Error:  user %s already exists\n", input1);   
    return 1;      
  } 

  /* create new user */
  strncpy(card, input1, 99);
  card[100] = '\0';
  strcat(card, ".card");
  //printf("%u\n", hash_table_size(bank->ht));

  /* Creating card files */
  fptr = fopen(card, "w"); /* changed a+ to w... check tutorials point */  /* mode originally: r" */
  if (!fptr) {
    printf("Error creating initialization files\n"); /* remember to take out the 1 and 2 */
    return 1;
  }

  //////////////////////////////////////////////////////////////////////////////////////////////////
  /* writing pin to .card */
  // fprintf(fptr, "Hello");
//   encrypt(sendline, strlen(sendline)+1, key, cipher);
  fprintf(fptr, input2);

  fclose(fptr);

  /* if .card created successfully, add user to hashtable */
  /*  adding user-name, balance to hashtable */
// int *balance;
  balance = malloc(sizeof(int));
  *balance = atoi(input3);

  //printf("*balance is:  %d\n", (*balance));
  hash_table_add(bank->ht, input1, balance);   // hashtable created in bank.c's function bank create()  
  
///test hashtable
  /* now add contents to the file */
//  printf("hash table size: %d\n", hash_table_size(bank->ht));
//  printf("printing user info from table %d\n", (int *)(hash_table_find(bank->ht, input1)));

  printf ("Created user %s\n", input1);  // successfully created card file for user

  return 0; 
}



int deposit(Bank *bank, char *command, size_t len) {
  char task[MAX_LEN + 1];
  char input1[MAX_LEN + 1];
  char input2[MAX_LEN + 1];
  int num, amtInt, retiAmt, retiName, *value;
  regex_t regexName, regexAmt;

  /* compile regular expression for name input */
  retiName = regcomp(&regexName, "^[a-zA-Z]+$", REG_EXTENDED);
  if (retiName) {
    printf("Could not compile regex name\n");
    return 1; 
  }
  /* compile regular expression for amt input */
  retiAmt = regcomp(&regexAmt, "^[0-9]+$", REG_EXTENDED);
  if (retiAmt) {
    printf("Could not compile regex for balance\n");
    return 1; 
  }

  num = sscanf(command, " %s %s %s ", task, input1, input2);
  if (num != 3) {      /* sscanf will return the number of variables filled */
    printf("Invalid command\n");  /* remove later? */
    return 1;
  }

  /* user name */
  // execute regular expression 
  retiName = regexec(&regexName, input1, 0, NULL, 0);
  retiAmt = regexec(&regexAmt, input2, 0, NULL, 0);

  /* If the inputs to the command are invalid print the following: */
  if ((retiName == REG_NOMATCH) || (retiAmt == REG_NOMATCH)) {
    printf("Usage:  deposit %s %s\n", input1, input2);
    /* free regex structures */
    regfree(&regexName);
    regfree(&regexAmt);
    return 1;
  }
  /* free regex structures - we need to do this right after we're done using them */
  regfree(&regexName);
  regfree(&regexAmt);

//  printf("%s\n", hash_table_find(bank->ht, input1));   //////////////// 
  /* user already exists */  
  if (hash_table_find(bank->ht, input1) == NULL) { 
    printf("No such user\n");
    return 1;    
  }
  
  amtInt = atoi(input2);
  value = (int *)hash_table_find(bank->ht, input1);              // this prints fine

 // printf("printing value + amtInt: %d\n", ((*value) + amtInt));
  /* otherwise it would cause an integer overflow */
  if (((*value) + amtInt) < (*value)) {   // do we need to use INT_MAX anywhere?
     printf("Too rich for this program");
  }

  *value = *value + amtInt;   // was seg faulting here
  printf("$%s added to %s's account\n", input2, input1); 


  return 0;  // everything was ok!
}


//done
int balance(Bank *bank, char *command, size_t len) {
  char task[MAX_LEN + 1];
  char input1[MAX_LEN + 1];
  int num, retiName;
  regex_t regexName;

//  int findi;

  /* compile regular expression for name input */
  retiName = regcomp(&regexName, "^[a-zA-Z]+$", REG_EXTENDED);
  if (retiName) {
    printf("Could not compile regex name\n");
    return 1; 
  }

  num = sscanf(command, " %s %s ", task, input1);
  if (num != 2) {      /* sscanf will return the number of variables filled */
    printf("Invalid command\n");  /* remove later? */
    return 1;
  }
  
  //printf("%s\n", input1);   // for debugging

  /* user name */
  // execute regular expression 
  retiName = regexec(&regexName, input1, 0, NULL, 0);

  /* If the inputs to the command are invalid print the following: */
  if (retiName == REG_NOMATCH) {
    printf("Usage:  balance <user-name>");
    /* free regex structures */
    regfree(&regexName);
    return 1;
  }
  /* free regex structures - we need to do this right after we're done using them */
  regfree(&regexName);
 
  /* user does not exist */  
  if (hash_table_find(bank->ht, input1) == NULL) { 
    printf("No such user\n");
    return 1;    
  } 

  /* print user's balance */
  printf("$%d\n", *(int *)(hash_table_find(bank->ht, input1)));

  return 0;

}

