/*
 * The init program.
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <openssl/rand.h>

int main(int argc, char**argv)
{

  if (argc != 2) goto badparams;
  char *filename = argv[1];

  // protect: verify files don't already exist
  char *atmfname = malloc(strlen(filename) + 4);
  if (!atmfname) goto failerror;
  strcpy(atmfname, filename);
  strcat(atmfname, ".atm");
  if (access(atmfname, F_OK) != -1) goto failfileexists;
  char *bankfname = malloc(strlen(filename) + 5);
  if (!bankfname) goto failerror;
  strcpy(bankfname, filename);
  strcat(bankfname, ".bank");
  if (access(bankfname, F_OK) != -1) goto failfileexists;

  // protect against being unable to open files for writing
  FILE *atm = fopen(atmfname, "w");
  if (atm == NULL) goto failerror;
  FILE *bank = fopen(bankfname, "w");
  if (bank == NULL) {
    fclose(atm);
    goto failerror;
  }

  unsigned char key[16];
  if (!RAND_bytes(key, sizeof key)) {
      printf("openssl error");
      exit(-1);
  }

  fprintf(atm, "%s", key);
  fprintf(bank, "%s", key);

  fclose(atm);
  fclose(bank);

  printf("Successfully initialized bank state\n");
  return 0;
failerror:
  printf("Error creating initialization files\n");
  return 64;
failfileexists:
  printf("Error:  one of the files already exists\n");
  return 63;
badparams:
  printf("Usage:  init <filename>\n");
  return 62;
}
