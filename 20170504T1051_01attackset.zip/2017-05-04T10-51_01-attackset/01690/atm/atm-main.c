/*
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char**argv)
{
    char user_input[1000];

    ATM *atm = atm_create();

    if (argc != 2) goto badfile;
    FILE *atmf = fopen(argv[1], "r");
    if (atmf == NULL) goto badfile;
    fgets((char *) atm->key, 17, atmf);
    atm->key[16] = '\0';

    printf("ATM: ");
    fflush(stdout);

    while (fgets(user_input, 1000,stdin) != NULL)
    {
        user_input[999] = '\0';
        atm_process_command(atm, user_input);
        if (atm->username == NULL)
          printf("ATM: ");
        else
          printf("ATM (%s): ", atm->username);
        fflush(stdout);
    }
	return EXIT_SUCCESS;
badfile:
  printf("Error opening ATM initialization file\n");
  return 64;
}
