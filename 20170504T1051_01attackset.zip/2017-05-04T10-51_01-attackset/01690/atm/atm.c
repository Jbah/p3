#include "atm.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>

#include "util/crypto.h"

ATM* atm_create()
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    atm->username = NULL;
    atm->pin = NULL;

    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

// StackOverflow:
// http://stackoverflow.com/questions/30695064/checking-if-string-is-only-letters-and-spaces
int onlyAlpha(const char s[])
{
    unsigned char c;

    while ( ( c = *s ) && ( isalpha( c ) ) ) ++s;

    return *s == '\0';
}

int onlyDigits(const char s[])
{
    unsigned char c;

    while ( ( c = *s ) && ( c >= '0' && c <= '9' ) ) ++s;

    return *s == '\0';
}

char *sendToBank(ATM *atm, char *msg) {

  // TODO: request one-time token
  // TODO: receive one-time token

  // TODO: prepend one-time token with message
  // TODO: encrypt this with secret key
  unsigned char cipher[1000] = {0};
  int cipher_len = encrypt((unsigned char*) msg, strlen(msg)+1, atm->key, cipher);

  char *recvline = malloc(10000);
  int nbytes;
  // printf("'%s'\n", msg);
  // fflush(stdout);
  atm_send(atm, (char *) cipher, cipher_len);
  nbytes = atm_recv(atm,recvline,10000);
  recvline[nbytes] = '\0';

  // TODO: decrypt received message with secret key
  unsigned char plain[1000] = {0};
  int plain_len = decrypt((unsigned char *) recvline, nbytes, atm->key, plain);
  // TODO: remove one-time token (first line), validate it

  char *plainstr = malloc(plain_len);
  strcpy(plainstr, (char *) plain);
  return plainstr;
}

int userExists(ATM *atm, char *username) {
  char msg[1000];
  strcpy(msg, "username-lookup\n");
  strcat(msg, username);
  char *resp = sendToBank(atm, msg);
  int result = strncmp(resp, "1", 1) == 0;
  free(resp); resp = NULL;
  return result;
}

int validatePIN(ATM *atm, char *username, char *pin) {
  char msg[1000];
  strcpy(msg, "pin-check\n");
  strcat(msg, username);
  strcat(msg, "\n");
  strcat(msg, pin);
  char *resp = sendToBank(atm, msg);
  int result = strncmp(resp, "1", 1) == 0;
  free(resp); resp = NULL;
  return result;
}

int attemptWithdraw(ATM *atm, int amount) {
  char msg[1000];
  strcpy(msg, "withdraw\n");
  strcat(msg, atm->username);
  strcat(msg, "\n");
  strcat(msg, atm->pin);
  strcat(msg, "\n");
  char amountstr[11];
  sprintf(amountstr, "%d", amount);
  strcat(msg, amountstr);
  char *resp = sendToBank(atm, msg);
  int result = strncmp(resp, "1", 1) == 0;
  free(resp); resp = NULL;
  return result;
}

int getBalance(ATM *atm) {
  char msg[1000];
  strcpy(msg, "balance\n");
  strcat(msg, atm->username);
  strcat(msg, "\n");
  strcat(msg, atm->pin);
  char *resp = sendToBank(atm, msg);
  int result = strtol(resp, NULL, 10);
  free(resp); resp = NULL;
  return result;
}

void beginSession(ATM *atm, char *username) {
  if (!userExists(atm, username)) goto nouser;

  // verify card exists
  char fname[300];
  strcpy(fname, "./");
  strcat(fname, username);
  strcat(fname, ".card");
  if (access(fname, F_OK) == -1) goto carderror;
  FILE *f = fopen(fname, "r");
  if (f == NULL) goto carderror;
  fclose(f);

  // read PIN, validate it
  char pin[6];
  printf("PIN? ");
  fflush(stdout);
  if (fgets(pin,6,stdin) == NULL) goto unauth;
  fseek(stdin,0,SEEK_END); // skip over other stdin junk
  if (pin[4] != '\n' && pin[4] != '\0') goto unauth;
  pin[4] = '\0';
  if (!onlyDigits(pin)) goto unauth;
  // Read new line and any other stuff
  // validate
  if (!validatePIN(atm, username, pin)) goto unauth;

  printf("Authorized\n");
  char *usernameptr = malloc(strlen(username));
  strcpy(usernameptr, username);
  char *pinptr = malloc(5);
  strcpy(pinptr, pin);
  atm->username = usernameptr;
  atm->pin = pinptr;

  return;
carderror:
  printf("Unable to access %s’s card\n", username);
  return;
nouser:
  printf("No such user\n");
  return;
unauth:
  printf("Not authorized\n");
  return;
}

void withdraw(ATM *atm, int amount) {
  if (attemptWithdraw(atm, amount)) {
    printf("$%d dispensed\n", amount);
  } else {
    printf("Insufficient funds\n");
  }
}

void balance(ATM *atm) {
  printf("$%d\n", getBalance(atm));
}

void atm_process_command(ATM *atm, char *command)
{
  if (strncmp("begin-session", command, 13) == 0) {

    // chop off first few bytes -- we already know what is there
    char *cmd = &command[13]; // point to first space
    if (*cmd == '\0' || *cmd == '\n') {
      // protect against multiple sessions
      if (atm->username != NULL) goto inuse;
      else goto bs_badparams; // protect from: "begin-session"
    }
    if (*cmd != ' ') goto invalid; // protect from: "begin-sessionblah"

    // protect against multiple sessions
    if (atm->username != NULL) goto inuse;

    cmd = cmd+1; // move forward past space
    char *nextspace = strchr(cmd, '\n'); // find ending newline
    if (nextspace == NULL) {
      // if no newline, look for \0 char
      nextspace = strchr(cmd, '\0');
      if (nextspace == NULL) goto bs_badparams;
    }
    *nextspace = '\0'; // overwrite newline or \0
    char *username = cmd; // extract username
    // protect from invalid username length
    if (strlen(username) == 0 || strlen(username) > 250) goto bs_badparams;
    if (!onlyAlpha(username)) goto bs_badparams; // protect: only [a-zA-Z]

    beginSession(atm, username);

    return;
  inuse:
    printf("A user is already logged in\n");
    return;
  bs_badparams:
    printf("Usage:  begin-session <user-name>\n");
  }
  else if (strncmp("withdraw", command, 8) == 0) {
    // chop off first few bytes -- we already know what is there
    char *cmd = &command[8]; // point to first space
    if (*cmd == '\0' || *cmd == '\n') {
      if (atm->username == NULL) goto nologgedin;
      goto w_badparams; // protect from: "withdraw"
    }
    if (*cmd != ' ') goto invalid; // protect from: "withdrawblah"

    cmd = cmd+1; // point to next parameter
    char *nextspace = strchr(cmd, '\n'); // find ending newline
    if (nextspace == NULL) {
      // if no newline, look for \0 char
      nextspace = strchr(cmd, '\0');
      if (nextspace == NULL) goto w_badparams;
    }
    *nextspace = '\0'; // overwrite newline or \0
    char *amtstr = cmd; // extract amt
    // protect: MAX_INT: 2147483647 (len: 10)
    if (strlen(amtstr) == 0 || strlen(amtstr) > 10) goto w_badparams;
    if (!onlyDigits(amtstr)) goto w_badparams; // protect: only [0-9]+
    long amtlong = strtol(amtstr, NULL, 10);
    if (amtlong < 0 || amtlong > 2147483647) goto w_badparams;
    int amount = amtlong;

    withdraw(atm, amount);

    return;
  w_badparams:
    printf("Usage:  withdraw <amt>\n");
    return;
  }
  else if (strncmp("balance", command, 7) == 0) {
    // chop off first few bytes -- we already know what is there
    char *cmd = &command[7]; // point to first space
    if (*cmd == ' ') goto b_badparams; // protect from "balance blah"
    if (*cmd != '\0' && *cmd != '\n') goto invalid; // protect from: "balanceblah"
    *cmd = '\0'; // overwrite newline or \0
    if (atm->username == NULL) goto nologgedin;

    balance(atm);

    return;
  b_badparams:
    printf("Usage:  balance\n");
    return;
  }
  else if (strncmp("end-session", command, 11) == 0) {
    // chop off first few bytes -- we already know what is there
    char *cmd = &command[11]; // point to first space
    if (*cmd == ' ') goto es_badparams; // protect from "balance blah"
    if (*cmd != '\0' && *cmd != '\n') goto invalid; // protect from: "balanceblah"
    *cmd = '\0'; // overwrite newline or \0
    if (atm->username == NULL) goto nologgedin;

    free(atm->username);
    atm->username = NULL;
    free(atm->pin);
    atm->pin = NULL;
    printf("User logged out\n");

    return;
  es_badparams:
    printf("Usage:  end-session\n");
    return;
  }
  else {
  invalid:
    printf("Invalid command\n");
    return;
  }
  return; // safety to prevent execution of code below
nologgedin:
  printf("No user logged in\n");
  return;
	/*
	 * The following is a toy example that simply sends the
	 * user's command to the bank, receives a message from the
	 * bank, and then prints it to stdout.
	 */

	/*
    char recvline[10000];
    int n;

    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    fputs(recvline,stdout);
	*/
}
