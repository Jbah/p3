

#ifndef __CRYPTO_H__
#define __CRYPTO_H__

#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <string.h>

int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key,
        unsigned char *ciphertext);
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
      unsigned char *plaintext);

#endif
