/*
 * The main program for the Bank.
 *
 * You are free to change this as necessary.
 */

#include <string.h>
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>
#include "bank.h"
#include "ports.h"

static const char prompt[] = "BANK: ";

int main(int argc, char**argv)
{
   int n;
   char sendline[1000];
   char recvline[1000];

   Bank *bank = bank_create();

   if (argc != 2) goto badfile;
   FILE *bankf = fopen(argv[1], "r");
   if (bankf == NULL) goto badfile;
   fgets((char *)bank->key, 17, bankf);
   bank->key[16] = '\0';

   printf("%s", prompt);
   fflush(stdout);

   while(1)
   {
       fd_set fds;
       FD_ZERO(&fds);
       FD_SET(0, &fds);
       FD_SET(bank->sockfd, &fds);
       select(bank->sockfd+1, &fds, NULL, NULL, NULL);
       if(FD_ISSET(0, &fds))
       {
           fgets(sendline, 1000,stdin);
           sendline[999] = '\0';
           bank_process_local_command(bank, sendline, strlen(sendline));
           printf("%s", prompt);
           fflush(stdout);
       }
       else if(FD_ISSET(bank->sockfd, &fds))
       {
           n = bank_recv(bank, recvline, 1000);
           // probably unnecessary
           if (n > 999) {
             n = 999;
           }
           if (n < 0) {
             n = 0;
           }
           // but meh...
           recvline[n] = '\0';
           bank_process_remote_command(bank, recvline, n);
       }
   }

   return EXIT_SUCCESS;
  badfile:
   printf("Error opening bank initialization file\n");
   return 64;
}
