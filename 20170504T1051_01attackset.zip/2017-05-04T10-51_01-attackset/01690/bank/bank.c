#include "bank.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>

#include "hash_table.h"
#include "util/crypto.h"

Bank* bank_create()
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    const uint32_t TBL_SIZE = 1000;
    bank->pintbl = hash_table_create(TBL_SIZE);
    bank->baltbl = hash_table_create(TBL_SIZE);

    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

// StackOverflow:
// http://stackoverflow.com/questions/30695064/checking-if-string-is-only-letters-and-spaces
int onlyAlpha(const char s[])
{
    unsigned char c;

    while ( ( c = *s ) && ( isalpha( c ) ) ) ++s;

    return *s == '\0';
}

int onlyDigits(const char s[])
{
    unsigned char c;

    while ( ( c = *s ) && ( c >= '0' && c <= '9' ) ) ++s;

    return *s == '\0';
}

void createUser(Bank *bank, char *username, char *pin, int balance) {
  // printf("username: '%s'\n", username);
  // printf("pin: '%d'\n", pin);
  // printf("balance: '%d'\n", balance);

  // protect against creating same user twice
  if (hash_table_find(bank->pintbl, username)) goto failuserexists;

  // protect against being unable to write card to directory
  char fname[300];
  strcpy(fname, "./");
  strcat(fname, username);
  strcat(fname, ".card");
  // protect against card existing, but no registered user in ht
  // This could really only occur if an attacker maliciously
  // creates a fake card file OR if someone forgot to clean up the .card files
  if (access(fname, F_OK) != -1) goto failwritecard;
  FILE *f = fopen(fname, "w");
  if (!f) goto failwritecard;
  // TODO: fprintf(f, "");
  fclose(f);

  char *pinval = malloc(5);
  int *balval = malloc(sizeof(int));
  strcpy(pinval, pin);
  *balval = balance;
  hash_table_add(bank->pintbl, username, pinval);
  hash_table_add(bank->baltbl, username, balval);

  printf("Created user %s\n", username);
  return;
failwritecard:
  printf("Error creating card file for user %s\n", username);
  return;
failuserexists:
  printf("Error:  user %s already exists\n", username);
  return;
}

void deposit(Bank *bank, char *username, int amt) {
  // printf("username: '%s'\n", username);
  // printf("amt: '%d'\n", amt);

  int *curbalptr = hash_table_find(bank->baltbl, username);
  // protect against depositing non-existant user
  if (!curbalptr) goto failnouser;

  // protect against overflow
  int curbal = *curbalptr;
  int max_deposit = 2147483647 - curbal;
  if (amt > max_deposit) goto failoverflow;

  *curbalptr = curbal + amt;

  printf("$%d added to %s's account\n", amt, username);
  return;
failnouser:
  printf("No such user\n");
  return;
failoverflow:
  printf("Too rich for this program\n");
  return;
}

void balance(Bank *bank, char *username) {
  // printf("username: '%s'\n", username);

  int *curbalptr = hash_table_find(bank->baltbl, username);
  // protect against checking balance of non-existant user
  if (!curbalptr) goto failnouser;

  printf("$%d\n", *curbalptr);
  return;
failnouser:
  printf("No such user\n");
  return;
}

void bank_process_local_command(Bank *bank, char *command, size_t len)
{
    if (strncmp("create-user", command, 11) == 0) {

      // chop off first few bytes -- we already know what is there
      char *cmd = &command[11]; // point to first space
      if (*cmd == '\0' || *cmd == '\n') goto cu_badparams; // protect from: "create-user"
      if (*cmd != ' ') goto invalid; // protect from: "create-userblah"

      cmd = cmd+1; // move forward past space
      char *nextspace = strchr(cmd, ' '); // find next space
      if (nextspace == NULL) goto cu_badparams; // protect from: missing pin
      *nextspace = '\0'; // overwrite space char
      char *username = cmd; // extract username
      // protect from invalid username length
      if (strlen(username) == 0 || strlen(username) > 250) goto cu_badparams;
      if (!onlyAlpha(username)) goto cu_badparams; // protect: only [a-zA-Z]

      cmd = nextspace+1; // point to next parameter
      nextspace = strchr(cmd, ' '); // find next space
      if (nextspace == NULL) goto cu_badparams; // protect from: missing balance
      *nextspace = '\0'; // overwrite space char
      char *pinstr = cmd; // extract pin
      // protect from: invalid pin length
      if (strlen(pinstr) != 4) goto cu_badparams;
      if (!onlyDigits(pinstr)) goto cu_badparams; // protect: only [0-9]{4}

      cmd = nextspace+1; // point to next parameter
      nextspace = strchr(cmd, '\n'); // find ending newline
      if (nextspace == NULL) {
        // if no newline, look for \0 char
        nextspace = strchr(cmd, '\0');
        if (nextspace == NULL) goto cu_badparams;
      }
      *nextspace = '\0'; // overwrite newline or \0
      char *balancestr = cmd; // extract balance
      // protect: MAX_INT: 2147483647 (len: 10)
      if (strlen(balancestr) == 0 || strlen(balancestr) > 10) goto cu_badparams;
      if (!onlyDigits(balancestr)) goto cu_badparams; // protect: only [0-9]+
      long balancelong = strtol(balancestr, NULL, 10);
      if (balancelong < 0 || balancelong > 2147483647) goto cu_badparams;
      int balance = balancelong;

      createUser(bank, username, pinstr, balance);

      return;
    cu_badparams:
      printf("Usage:  create-user <user-name> <pin> <balance>\n");
    }
    else if (strncmp("deposit", command, 7) == 0) {

      // chop off first few bytes -- we already know what is there
      char *cmd = &command[7]; // point to first space
      if (*cmd == '\0' || *cmd == '\n') goto d_badparams; // protect from: "deposit"
      if (*cmd != ' ') goto invalid; // protect from: "depositblah"

      cmd = cmd+1; // move forward past space
      char *nextspace = strchr(cmd, ' '); // find next space
      if (nextspace == NULL) goto d_badparams; // protect from: missing amt
      *nextspace = '\0'; // overwrite space char
      char *username = cmd; // extract username
      // protect from invalid username length
      if (strlen(username) == 0 || strlen(username) > 250) goto d_badparams;
      if (!onlyAlpha(username)) goto d_badparams; // protect: only [a-zA-Z]

      cmd = nextspace+1; // point to next parameter
      nextspace = strchr(cmd, '\n'); // find ending newline
      if (nextspace == NULL) {
        // if no newline, look for \0 char
        nextspace = strchr(cmd, '\0');
        if (nextspace == NULL) goto d_badparams;
      }
      *nextspace = '\0'; // overwrite newline or \0
      char *amtstr = cmd; // extract amt
      // protect: MAX_INT: 2147483647 (len: 10)
      if (strlen(amtstr) == 0 || strlen(amtstr) > 10) goto d_badparams;
      if (!onlyDigits(amtstr)) goto d_badparams; // protect: only [0-9]+
      long amtlong = strtol(amtstr, NULL, 10);
      if (amtlong < 0 || amtlong > 2147483647) goto d_badparams;
      int amt = amtlong;

      deposit(bank, username, amt);

      return;
    d_badparams:
      printf("Usage:  deposit <user-name> <amt>\n");
    }
    else if (strncmp("balance", command, 7) == 0) {

      // chop off first few bytes -- we already know what is there
      char *cmd = &command[7]; // point to first space
      if (*cmd == '\0' || *cmd == '\n') goto b_badparams; // protect from: "balance"
      if (*cmd != ' ') goto invalid; // protect from: "balanceblah"

      cmd = cmd+1; // move forward past space
      char *nextspace = strchr(cmd, '\n'); // find ending newline
      if (nextspace == NULL) {
        // if no newline, look for \0 char
        nextspace = strchr(cmd, '\0');
        if (nextspace == NULL) goto b_badparams;
      }
      *nextspace = '\0'; // overwrite newline or \0
      char *username = cmd; // extract username
      // protect from invalid username length
      if (strlen(username) == 0 || strlen(username) > 250) goto b_badparams;
      if (!onlyAlpha(username)) goto b_badparams; // protect: only [a-zA-Z]

      balance(bank, username);

      return;
    b_badparams:
      printf("Usage:  balance <user-name>\n");
    }
    else {
    invalid:
      printf("Invalid command\n");
    }
}

int validateUsername(Bank *bank, char *username) {
  // protect from invalid username length
  if (strlen(username) == 0 || strlen(username) > 250) return 0;
  if (!onlyAlpha(username)) return 0; // protect: only [a-zA-Z]
  return 1;
}

int validatePIN(Bank *bank, char *pin) {
  if (strlen(pin) != 4) return 0;
  if (!onlyDigits(pin)) return 0;
  return 1;
}

void bank_process_remote_command(Bank *bank, char *commandcipher, size_t len)
{
  char response[1000];
  commandcipher[len] = '\0';
  char command[1000] = {0};
  int plain_len = decrypt((unsigned char *) commandcipher, len, bank->key, (unsigned char *) command);
  // TODO: decrypt with secret key
  // TODO: If we have a one-time token, does it match first line? else fail
  // if token AND no one-time token currently
  if (strncmp("token\n", command, 6) == 0 && 0) {
    // TODO: generate and store token
    // TODO: response w/ token
  }
  // if username-lookup
  else if (strncmp("username-lookup\n", command, 16) == 0) {
    // next line: username
    char *cmd = &command[16]; // skip initial bytes
    char *username = cmd;
    fflush(stdout);

    if (validateUsername(bank, username) && hash_table_find(bank->pintbl, username) != NULL) {
      strcpy(response, "1");
    } else {
      strcpy(response, "0");
    }
  }
  // if pin-check
  else if (strncmp("pin-check\n", command, 10) == 0) {
    // next: username
    char *cmd = &command[10]; // skip initial bytes
    char *nextline = strchr(cmd, '\n');
    if (nextline == NULL) goto drop;
    *nextline = '\0';
    char *username = cmd;
    // next: pin
    cmd = nextline+1;
    char *pin = cmd;
    // TODO: perform time-out check
    // response w/ true if username in table and PIN correct
    char *expected_pin = hash_table_find(bank->pintbl, username);
    if (validateUsername(bank, username) && validatePIN(bank, pin) && strncmp(expected_pin, pin, 4) == 0) {
      strcpy(response, "1");
    } else {
      strcpy(response, "0");
    }
  }
  // if withdraw
  else if (strncmp("withdraw\n", command, 9) == 0) {
    // next: username
    char *cmd = &command[9]; // skip initial bytes
    char *nextline = strchr(cmd, '\n');
    if (nextline == NULL) goto drop;
    *nextline = '\0';
    char *username = cmd;
    // next: pin
    cmd = nextline+1;
    nextline = strchr(cmd, '\n');
    if (nextline == NULL) goto drop;
    *nextline = '\0';
    char *pin = cmd;
    // next: amount
    cmd = nextline+1;
    char *amtstr = cmd; // extract amt
    // protect: MAX_INT: 2147483647 (len: 10)
    if (strlen(amtstr) == 0 || strlen(amtstr) > 10) goto drop;
    if (!onlyDigits(amtstr)) goto drop; // protect: only [0-9]+
    long amtlong = strtol(amtstr, NULL, 10);
    if (amtlong < 0 || amtlong > 2147483647) goto drop;
    int amt = amtlong;

    // TODO: response w/ true if username in table and PIN correct and valid withdraw
    char *expected_pin = hash_table_find(bank->pintbl, username);
    if (validateUsername(bank, username) && validatePIN(bank, pin) && strncmp(expected_pin, pin, 4) == 0) {
      // Check if valid withdraw
      int *curbal = hash_table_find(bank->baltbl, username);
      int maxwdl = 2147483647 - *curbal;
      if (amt > maxwdl || amt > *curbal) {
        strcpy(response, "0");
      } else {
        *curbal = *curbal - amt;
        strcpy(response, "1");
      }
    } else {
      strcpy(response, "0");
    }
  }
  // if balance
  else if (strncmp("balance\n", command, 8) == 0) {
    // next: username
    char *cmd = &command[8]; // skip initial bytes
    char *nextline = strchr(cmd, '\n');
    if (nextline == NULL) goto drop;
    *nextline = '\0';
    char *username = cmd;
    // next: pin
    cmd = nextline+1;
    char *pin = cmd;
    // response w/ true if username in table and PIN correct
    char *expected_pin = hash_table_find(bank->pintbl, username);
    if (validateUsername(bank, username) && validatePIN(bank, pin) && strncmp(expected_pin, pin, 4) == 0) {
      int *curbal = hash_table_find(bank->baltbl, username);
      char balstr[11];
      sprintf(balstr, "%d", *curbal);
      strcpy(response, balstr);
    } else {
      strcpy(response, "-1");
    }
  } else {
    printf("DROPPING PACKET\n");
    fflush(stdout);
    goto drop;
  }

  // TODO: clear the one-time token, if one existed
  // TODO: encrypt the response + OTT
  char cipher[1000] = {0};
  int cipher_len = encrypt((unsigned char *) response, strlen(response)+1, bank->key, (unsigned char *) cipher);

  bank_send(bank, cipher, cipher_len);
drop:
  return;
	// /*
    // char sendline[1000];
    // command[len]=0;
    // // sprintf(sendline, "Bank got: %s", command);
    // // bank_send(bank, sendline, strlen(sendline));
    // printf("Received the following:\n");
    // fputs(command, stdout);
	// */
}
