#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	
	/* % <path1>/init <path2>/<init-filename> */

	if (argc != 2) {
		printf("Usage:  init <filename>\n");
		return(62);
	}
	
	int pathLength = strlen(argv[1]);

	char* bankFileName = (char*) calloc(sizeof(char), (pathLength + 6));
	char* atmFileName = (char*) calloc(sizeof(char), (pathLength + 5));
	
	strcat(strncpy(bankFileName, argv[1], pathLength), ".bank");
	strcat(strncpy(atmFileName, argv[1], pathLength), ".atm");

	if(strlen(bankFileName) != pathLength+5 || strlen(atmFileName) != pathLength+4){
		printf("Error creating initialization files\n");
		return(64);
	}
	
	if(access(bankFileName, F_OK) != -1 || access(atmFileName, F_OK) != -1){
		printf("Error:  one of the files already exists\n");
		return(63);
	}
	
	FILE* bankFile = fopen(bankFileName, "w+");
	FILE* atmFile = fopen(atmFileName, "w+");

	if(bankFile==NULL || atmFile == NULL){
		printf("Error creating initialization files\n");
		return(64);
	}
	
	free(bankFileName);
	free(atmFileName);
	bankFileName = NULL;
	atmFileName = NULL;
	fclose(bankFile);
	fclose(atmFile);
	bankFile = NULL;
	atmFile = NULL;

	printf("Successfully initialized bank state\n");
	return(0);

}
