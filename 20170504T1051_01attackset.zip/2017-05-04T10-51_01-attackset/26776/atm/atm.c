#include "atm.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

ATM* atm_create()
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    atm->logged_in = 0;
    atm->user = NULL;
    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

void atm_process_command(ATM *atm, char *command)
{
    // TODO: Implement the ATM's side of the ATM-bank protocol

	/*
	 * The following is a toy example that simply sends the
	 * user's command to the bank, receives a message from the
	 * bank, and then prints it to stdout.
	 */

	int params = 0;
    	char *token = strtok(command," ");
    	char *commands[2];

	
    	if (strcmp(token, "begin-session") == 0 || strcmp(token, "begin-session\n") == 0) {
		if (atm->logged_in != 0) {
			printf("A user is already logged in\n");
			fflush(stdout);
		} else {
    		while (token != NULL && params <= 2) {
		   int token_len = strlen(token);
		   commands[params] = (char *) calloc(sizeof(char), token_len + 1);
		   strcpy(commands[params], token);
		   token = strtok(NULL, " ");
		   params = params + 1;	
		}
		if (params != 2 || strlen(commands[1]) > 250) {
	   		printf("Usage: begin-session <user-name>\n");
			fflush(stdout);
		} else {
			int i = 0;
	   		int alpha = 0;
		   	while (i < strlen(commands[1])-1 && alpha == 0) {
				if((commands[1][i]>='a' && commands[1][i]<='z') || (commands[1][i]>='A' && commands[1][i]<='Z')) {
			    		i = i + 1;
				} else {
			    		alpha = 1;
				}	
		   	} 

			if (alpha != 0) {
				printf("Usage: begin-session <user-name>\n");
				fflush(stdout);
			} else {
				int userLength = strlen(commands[1]);
				char recvline[10000];
				int n;
				char* beginCommand = (char*) calloc(sizeof(char), (userLength + 1));
	
				strcat(strncpy(beginCommand, "b", 1), commands[1]);
				atm_send(atm,beginCommand,strlen(beginCommand));
				n = atm_recv(atm,recvline,10000);
				recvline[n] = 0;
				if(strcmp(recvline, "find-pin") != 0) {
					printf("%s\n", recvline);
				} else {
					
				commands[1][strlen(commands[1])-1] = '\0';

				  int userLength = strlen(commands[1]);

				  char* cardFileName = (char*) calloc(sizeof(char), (userLength + 6));
				
				
				  strcat(strncpy(cardFileName, commands[1], userLength), ".card");

				  if(strlen(cardFileName) != userLength+5){
				      printf("Unable to access %s's card\n", commands[1]);
				      fflush(stdout);
				  }
	
	
				  FILE* cardFile = fopen(cardFileName, "r+");


				  if(cardFile==NULL){
				      printf("Unable to access %s's card\n", commands[1]);
					fflush(stdout);
				  } else {
					char user_input[1000];

					printf("PIN? ");
					if (fgets(user_input, 10000,stdin) != NULL)
				    	{
						int i = 0;
						int num = 0;
						user_input[strlen(user_input)-1] = '\0';
						while (i < strlen(user_input) && num == 0) {
							if(user_input[i]>='0' && user_input[i]<='9') {
							    i = i + 1;
							} else {
							    num = 1;
							}	
						}

						if(num != 0 || strlen(user_input) != 4) {
							printf("Not authorized\n");
							fflush(stdout);
						} else {
						strncpy(atm->pin, user_input, strlen(user_input));
						char recvpin[10000];
						strcat(user_input, commands[1]);
						atm_send(atm,user_input,strlen(user_input));
						n = atm_recv(atm,recvpin,10000);
						recvpin[n] = 0;
						if (strcmp(recvpin, "Authorized") == 0) {
							
							atm->user = calloc(sizeof(char), strlen(commands[1]));
							atm->logged_in = 1;
							strncpy(atm->user, commands[1], strlen(commands[1]));
							printf("Authorized\n");
							fflush(stdout);

						} else {
							printf("%s\n", recvpin);
							fflush(stdout);
						}
						}
				    	}
				}
				
				}
			}
		}
		}
	} else if (strcmp(token, "withdraw") == 0 || strcmp(token, "withdraw\n") == 0) {
		if (atm->logged_in != 1) {
			printf("No user logged in\n");
			fflush(stdout);
		} else {
			while (token != NULL && params <= 2) {
			   int token_len = strlen(token);
			   commands[params] = (char *) calloc(sizeof(char), token_len + 1);
			   strcpy(commands[params], token);
			   token = strtok(NULL, " ");
			   params = params + 1;	
			}
			if (params != 2 || strlen(commands[1]) > 250) {
		   		printf("Usage: withdraw <amt>\n");
				fflush(stdout);
			} else {
			  int i = 0;
			  int num = 0;
			  while (i < strlen(commands[1])-1 && num == 0) {
				if(commands[1][i]>='0' && commands[1][i]<='9') {
				    i = i + 1;
				} else {
				    num = 1;
				}	
			   }
			   if (num != 0) {
				printf("Usage: withdraw <amt>\n");
				fflush(stdout);
			   } else {
				commands[1][strlen(commands[1])-1] = '\0';
				int amtLength = strlen(commands[1]);
				int n;
				char recvline[10000];
				char *user_amt = (char*) calloc(sizeof(char), (amtLength + 2));

				strncpy(user_amt, "-", sizeof("-"));				
				strcat(user_amt, commands[1]);
				atm_send(atm,user_amt,strlen(user_amt));
				n = atm_recv(atm,recvline,10000);
				recvline[n] = 0;
				printf("%s\n", recvline);
				fflush(stdout);
			   
			   }

			}
		}

	} else if (strcmp(token, "balance\n") == 0 || strcmp(token, "balance") == 0 ) {
		if (atm->logged_in != 1) {
			printf("No user logged in\n");
			fflush(stdout);
		} else {
			while (token != NULL && params <= 1) {
			   int token_len = strlen(token);
			   commands[params] = (char *) calloc(sizeof(char), token_len + 1);
			   strcpy(commands[params], token);
			   token = strtok(NULL, " ");
			   params = params + 1;	
			}
			if (params != 1) {
		   		printf("Usage: balance\n");
				fflush(stdout);
			} else {
				char recvline[10000];
				int n;
				commands[0][strlen(commands[0])-1] = '\0';			
				
				atm_send(atm,commands[0],strlen(commands[0]));
				n = atm_recv(atm,recvline,10000);
				recvline[n] = 0;
				printf("%s\n", recvline);
				fflush(stdout);
			}
		}
	} else if(strcmp(token, "end-session\n") == 0 || strcmp(token, "end-session") == 0) {
		if (atm->logged_in != 1) {
			printf("No user logged in\n");
			fflush(stdout);
		} else {
			while (token != NULL && params <= 1) {
			   int token_len = strlen(token);
			   commands[params] = (char *) calloc(sizeof(char), token_len + 1);
			   strcpy(commands[params], token);
			   token = strtok(NULL, " ");
			   params = params + 1;	
			}
			if (params != 1) {
		   		printf("Usage: end-session\n");
				fflush(stdout);
			} else {
				char recvline[10000];
				int n;
				commands[0][strlen(commands[0])-1] = '\0';			
				
				atm_send(atm,commands[0],strlen(commands[0]));
				n = atm_recv(atm,recvline,10000);
				recvline[n] = 0;
				atm->logged_in = 0;
				free(atm->user);
				atm->user = NULL;
				printf("%s\n", recvline);
				fflush(stdout);
			}
		}

	} else {
		printf("Invalid command\n");
		fflush(stdout);	
	} 

	/*
    char recvline[10000];
    int n;

    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    fputs(recvline,stdout);
	*/
}
