#include "bank.h"
#include "ports.h"
#include "hash_table.h"
#include "crypto_sample.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>

Bank* bank_create()
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    bank->pins = hash_table_create(10);
    bank->users = hash_table_create(10);

    bank->hashes = hash_table_create(10);

    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

void bank_process_local_command(Bank *bank, char *command, size_t len)
{
    // TODO: Implement the bank's local commands
    int params = 0;
    char *token = strtok(command," ");
    char *commands[4];
    int invalid = 0;
    if (strcmp(token, "create-user") == 0 || strcmp(token, "create-user\n") == 0) {
	while (token != NULL && params <= 4) {
	   //commands[params] = token;
	   int token_len = strlen(token);
	   commands[params] = (char *) calloc(sizeof(char), token_len + 1);
	   strcpy(commands[params], token);
	   token = strtok(NULL, " ");
	   params = params + 1;	
	}
	if (params < 4 || params > 4 || strlen(commands[1]) > 250 || strlen(commands[2]) > 4) {
	   printf("Usage: create-user <user-name> <pin> <balance>\n");
	   fflush(stdout);
	} else {
	   int i = 0;
	   int alpha = 0;
	   int num = 0;
	   while (i < strlen(commands[1])-1 && alpha == 0) {
		if((commands[1][i]>='a' && commands[1][i]<='z') || (commands[1][i]>='A' && commands[1][i]<='Z')) {
		    i = i + 1;
		} else {
		    alpha = 1;
		}	
	   }
	   
	   i=0;
	   while (i < strlen(commands[2])-1 && num == 0) {
		if(commands[2][i]>='0' && commands[2][i]<='9') {
		    i = i + 1;
		} else {
		    num = 1;
		}	
	   }

	   i=0;
	   while (i < strlen(commands[3])-1 && num == 0) {
		if(commands[3][i]>='0' && commands[3][i]<='9') {
		    i = i + 1;
		} else {
		    num = 1;
		}	
	   }

	   int balance;
	   //int balance = atoi(commands[3]);

	   if (alpha != 0 || num != 0) {
	   	printf("Usage: create-user <user-name> <pin> <balance>\n");
		fflush(stdout);
	   } else {
		if (hash_table_find(bank->users, commands[1]) != NULL) {
		    printf("Error: user <user-name> already exists\n");
		    fflush(stdout);
		} else {
		  balance = atoi(commands[3]);
		  int userLength = strlen(commands[1]);

		  char* cardFileName = (char*) calloc(sizeof(char), (userLength + 6));
	
		  strcat(strncpy(cardFileName, commands[1], userLength), ".card");

		  if(strlen(cardFileName) != userLength+5){
		      printf("Error creating card file for user %s\n", commands[1]);
		      fflush(stdout);
		  }
	
		  //acquire randomness for card
		  FILE* cardFile = fopen(cardFileName, "w+");
		  FILE* randomFile = fopen("/dev/urandom", "r");
		  int rand;
		  fread(&rand, sizeof(int), 1, randomFile);
		  fclose(randomFile);

		  //get hash of pin
		  char* key =  calloc(sizeof(int), 2);
		  snprintf(key, sizeof(int), "%d", rand);

		  //printf("%s\n",key);

//		  unsigned char cipher[128] = {0};
		
		  unsigned char* cipher = calloc(sizeof(unsigned char), 128);
		  int cipher_length = encrypt(commands[2], strlen(commands[2])+1, key, cipher);

		  if(cardFile==NULL || cipher_length == 0){
		      printf("Error creating card file for user %s\n", commands[1]);
		      fflush(stdout);
		  } else {
		      fprintf(cardFile, "%s", key);
		  }
	
		  free(cardFileName);
		  cardFileName = NULL;
		  fclose(cardFile);
		  cardFile = NULL;

		  int* balancePtr = (int*) calloc(sizeof(int*), 1);
		  // memcpy(balancePtr, &balance, sizeof(int*)); 
		  *balancePtr = balance;

		  //printf("%p\n", &balancePtr);
		  //printf("%d\n", *balancePtr);
		  hash_table_add(bank->users,commands[1],balancePtr);
		  hash_table_add(bank->pins,commands[1],commands[2]);
		  hash_table_add(bank->hashes,commands[1],cipher);		  
		  
		  //printf("USER: %s\nPIN: %s\nCARD: %s\nCTXT: %s\nTABLE: %s\n", commands[1], commands[2], key, cipher, (unsigned char *) hash_table_find(bank->hashes, commands[1]));

		  printf("Created user %s\n",commands[1],cipher);
		  fflush(stdout);
		}
	   }
	}
    } else if(strcmp(token, "deposit") == 0 || strcmp(token, "deposit") == 0) {
	while (token != NULL && params <= 3) {
	   //commands[params] = token;
	   int token_len = strlen(token);
	   commands[params] = (char *) calloc(sizeof(char), token_len + 1);
	   strcpy(commands[params], token);
	   token = strtok(NULL, " ");
	   params = params + 1;	
	}
	if (params < 3 || params > 3) {
	   printf("Usage: deposit <user-name> <amt>\n");
	} else {
	   int i = 0;
	   int alpha = 0;
	   int num = 0;
	   int amt;
	   while (i < strlen(commands[1])-1 && alpha == 0) {
		if((commands[1][i]>='a' && commands[1][i]<='z') || (commands[1][i]>='A' && commands[1][i]<='Z')) {
		    i = i + 1;
		} else {
		    alpha = 1;
		}	
	   } 

	   //int amt = atoi(commands[2]);
	   i=0;
	   while (i < strlen(commands[2])-1 && num == 0) {
		if(commands[2][i]>='0' && commands[2][i]<='9') {
		    i = i + 1;
		} else {
		    num = 1;
		}	
	   }	   


	    if (alpha != 0 || num != 0) {
	   	printf("Usage: deposit <user-name> <amt>\n");
		fflush(stdout);
	   } else {
		amt = atoi(commands[2]);
		if (hash_table_find(bank->users, commands[1]) == NULL) {
		    printf("No such user\n");
		    fflush(stdout);
		} else {
		  int* balancePtr = (int*) hash_table_find(bank->users, commands[1]);
		  //printf("%p\n", balancePtr);
		  int balance = *balancePtr;
		  //printf("%d\n", balance);
		  balance = balance + amt;
		  //printf("%d\n", balance);
		  *balancePtr = balance;
		  if (balance < 0) {
		      printf("Too rich for this program\n");
		      fflush(stdout);
		  } else {
		      hash_table_add(bank->users, commands[1], balancePtr);
		      printf("$%d added to %s's account\n", amt, commands[1]);
		      fflush(stdout);
		  }
		}
	   }
	}   
    } else if(strcmp(token, "balance") == 0 || strcmp(token, "balance\n")==0) {
	while (token != NULL && params <= 3) {
	   //commands[params] = token;
	   int token_len = strlen(token);
	   commands[params] = (char *) calloc(sizeof(char), token_len + 1);
	   strcpy(commands[params], token);
	   token = strtok(NULL, " ");
	   params = params + 1;	
	}
	if (params < 2 || params > 2) {
	   printf("Usage: balance <user-name>\n");
	   fflush(stdout);
	} else {
	  int i = 0;
	  int alpha = 0;
	   while (i < strlen(commands[1])-1 && alpha == 0) {
		if((commands[1][i]>='a' && commands[1][i]<='z') || (commands[1][i]>='A' && commands[1][i]<='Z')) {
		    i = i + 1;
		} else {
		    alpha = 1;
		}	
	   } 
	   
	    if (alpha != 0) {
	   	printf("Usage: balance <user-name>\n");
		fflush(stdout);
	   } else {
		commands[1][strlen(commands[1])-1] = '\0';
		if (hash_table_find(bank->users, commands[1]) == NULL) {
		    printf("No such user\n");
		    fflush(stdout);
		} else {
		     //printf("$%d\n", (int) hash_table_find(bank->users, commands[1]));
		     int* balance = (int*) hash_table_find(bank->users, commands[1]);
		     printf("$%d\n", *balance);
		     fflush(stdout);
		}
	   }   
	} 
    } else {
	printf("Invalid command\n");
	fflush(stdout);
	invalid = 1;
    }

    int idx = 0;
    while (commands[idx] != NULL && idx < 4 && invalid == 0) {
      free(commands[idx]);
      commands[idx] = NULL;
    }

    
}

void bank_process_remote_command(Bank *bank, char *command, size_t len)
{
    // TODO: Implement the bank side of the ATM-bank protocol

	/*
	 * The following is a toy example that simply receives a
	 * string from the ATM, prepends "Bank got: " and echoes 
	 * it back to the ATM before printing it to stdout.
	 */


    char sendline[1000];
    command[len]=0;
    if (strcmp(command, "balance") == 0) {
	int* balance = (int*) hash_table_find(bank->users, bank->curr_user);
	sprintf(sendline, "$%d", *balance);
	bank_send(bank, sendline, strlen(sendline));
    } else if (command[0] == 'b') {
      command = command + 1;
	command[strlen(command)-1] = '\0';
      if (hash_table_find(bank->users, command) == NULL || hash_table_find(bank->pins, command) == NULL || hash_table_find(bank->hashes, command) == NULL ) {
	strncpy(sendline, "No such user", sizeof("No such user"));
      } else {
	strncpy(sendline, "find-pin", sizeof("find-pin"));
      }
      bank_send(bank, sendline, strlen(sendline));
    } else if(command[0] >='0' && command[0] <='9') {
      //char pin[5];
	char *pin = calloc(sizeof(char), 5);	      
	char *user;

      strncpy(pin, command, 4);

      command = command + 4;

      user = (char *) calloc(sizeof(char), strlen(command) + 1);
      strncpy(user, command, strlen(command));

		  int userLength = strlen(user);

		  char* cardFileName = (char*) calloc(sizeof(char), (userLength + 6));
	
		  strcat(strncpy(cardFileName, user, userLength), ".card");

      FILE* pinFile = fopen(cardFileName, "r");
      int key;


//		  comments are from code above
//		  char* key =  calloc(sizeof(int), 2);
//		  snprintf(key, sizeof(int), "%d", rand);


//int rand;
//		  fread(&rand, sizeof(int), 1, randomFile);

      //char * keyStr;
	fscanf(pinFile, "%d", &key);

	//fread(&key, sizeof(int), 1, pinFile);	
	fclose(pinFile);
	unsigned char* ctxt = calloc(sizeof(unsigned char), 128);


	char* keyStr =  calloc(sizeof(int), 2);
	snprintf(keyStr, sizeof(int), "%d", key);

	// int cipher_length = encrypt(commands[2], strlen(commands[2])+1, key, cipher);

	int enc_size = encrypt(pin, strlen(pin)+1, keyStr, ctxt);
	//printf("USER: %s\nPIN: %s\nCARD: %s\nCTXT: %s\nTABLE: %s\n", user, pin, keyStr, ctxt, (unsigned char *) hash_table_find(bank->hashes, user));

      if(strcmp((char *)hash_table_find(bank->pins, user),pin)==0){
	//if(enc_size !=0 && strcmp((char *)hash_table_find(bank->hashes, user),ctxt)==0){
	//int userLength = strlen(user);
	bank->curr_user = (char *) calloc(sizeof(char), userLength+1);
	strncpy(bank->curr_user, user, userLength);
	/*bank->curr_user[userLength] = '\0';*/
	//printf("curr user %s\n", bank->curr_user);
	strncpy(sendline, "Authorized", sizeof("Authorized"));
      } else {
	strncpy(sendline, "Not authorized", sizeof("Not authorized"));
      }
      bank_send(bank, sendline, strlen(sendline));
    } else if(command[0] == '-') {
	command = command + 1;
	/*printf("amt %s\n", command);*/
	int amt = atoi(command);
	int new_balance;
	
	int* balance = (int*) hash_table_find(bank->users, bank->curr_user);

	new_balance = *balance - amt;
	if (new_balance < 0) {
		strncpy(sendline, "Insufficient funds", sizeof("Insufficient funds"));
	} else {
		sprintf(sendline, "$%d dispensed", amt);
		/*int* new_balancePtr = (int*) calloc(sizeof(int*), 1);*/
		*balance= new_balance;
		hash_table_add(bank->users,bank->curr_user,balance);
	}
	bank_send(bank, sendline, strlen(sendline));
    } else if(strcmp(command, "end-session") == 0) {
	free(bank->curr_user);
	bank->curr_user = NULL;
	strncpy(sendline, "User logged out", sizeof("User logged out"));
	bank_send(bank, sendline, strlen(sendline));
    }


	/*
    char sendline[1000];
    command[len]=0;
    sprintf(sendline, "Bank got: %s", command);
    bank_send(bank, sendline, strlen(sendline));
    printf("Received the following:\n");
    fputs(command, stdout);
	*/
}
