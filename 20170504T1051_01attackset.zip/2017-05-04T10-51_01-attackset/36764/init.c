#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include <unistd.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>

int main(int argc, char**argv){
  
  FILE *atm, *bank, *key_file;
  char *atmpath, *bankpath;
  char *atm_fExt = ".atm";
  char *bank_fExt = ".bank";
  char *symm_key, *key;
  char *line;
  size_t length = 0;
  ssize_t lines;
  
  if(argc != 2){
    printf("Usage: init <filename>\n");
    return 62;
  }
  
  atmpath = malloc(strlen(argv[1]) + strlen(atm_fExt) + 1);
  bankpath = malloc(strlen(argv[1]) + strlen(bank_fExt) + 1);
  
  if(atmpath != NULL && bankpath != NULL){
    strcat(atmpath, argv[1]);
    strcat(atmpath, atm_fExt);
    strcat(bankpath,argv[1]);
    strcat(bankpath,bank_fExt);
    
  }

  if(access(bankpath, F_OK) != -1 || access(atmpath, F_OK) != -1){
    printf("Error: one of the files already exists\n");
    return 63;
  }
  
  key = malloc(512);
  symm_key = malloc(512);
  system("openssl rand -base64 256 > symm.key");
  
  key_file = fopen("symm.key", "r");
  
  while ((lines = getline(&line, &length, key_file)) != -1){
    strcat(key, line);
  }
  
  strncpy(symm_key, key, strlen(key));
  
  fclose(key_file);
  
  system("rm symm.key");
  
  
  if((atm = fopen(atmpath, "w")) == NULL 
     || (bank = fopen(bankpath, "w")) == NULL){
    printf("Error creating initialization files\n");
    return 64;
  }

  fputs(symm_key,bank);
  fputs(symm_key,atm);
   
  
  fclose(atm);
  fclose(bank);
  
  free(atmpath);
  free(bankpath);
  printf("Successfully initialized bank state\n");
  return 0;
  
}
