#include "atm.h"
#include "../ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>



ATM* atm_create()
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    // TODO set up more, as needed
  

    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
      fclose(atm->atm_init);
      close(atm->sockfd);
      free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

void atm_process_command(ATM *atm, char *command)
{

  char *arg1 = malloc(14*sizeof(char));
  char *arg2 = malloc(250*sizeof(char));
  
  sscanf(command, "%s %s", arg1, arg2);
  
  if(strlen(arg1) > 14 || strlen(arg1) < 1){
    printf("Invalid command\n");
    return;
  }
  
  if(strcmp(arg1, "begin-session") == 0){
    if(atm->in_session == 1){
      printf("A user is already logged in\n");
      return;
    }
    
    if(arg2 == NULL || strlen(arg2) < 1 || strlen(arg2) > 250
       || valid_user(arg2) == 0){
      printf("Usage: begin-session <user-name>\n");
      return;
    }
   
    int cipher_len, plain_len = 0;
    char cipher[128], recv[128],plain[128] = {0};
    char *msg = malloc((strlen(arg2)+9)*sizeof(char));

    strcpy(msg, "exists? ");
    strcat(msg, arg2);
    cipher_len = encrypt(msg,strlen(msg) + 1,atm->key,cipher);
    if (cipher_len == -1) {
      return;
    }
    atm_send(atm, cipher, sizeof(cipher));
    atm_recv(atm, recv, 20);
    
    plain_len = decrypt(recv,strlen(recv),atm->key,plain);
    if (plain_len == -1) {
      return;
    }
    
    if(strcmp(plain, "invalid") == 0){
      printf("Usage: begin-session <user-name>\n");
      return;
    }
    
    if(strcmp(plain, "ng") == 0){
      printf("No such user\n");
      return;
    }
    
    if(strcmp(plain, "s") != 0){
      printf("Usage: begin-session <user-name>\n");
      return;
    }
    
    char pin[5], temp[4], line[1000000] = {0};
    printf("PIN? ");

    fgets(line, 1000000, stdin);
    
    if(strlen(line) != 5){
      printf("Not authorized\n");
      return;
    }
    
    strcpy(pin, line);
    
    
    char msg1[260];
    
    memset(cipher,0,128);
    memset(recv,0,128);
    memset(plain,0,128);
    cipher_len,plain_len = 0;
    strcpy(msg1, "pin? ");
    strcat(msg1, arg2);
    strcat(msg1, " ");
    strcat(msg1, pin);
    cipher_len = encrypt(msg1, strlen(msg1)+1,atm->key,cipher);

    if(cipher_len == -1) {
      return;
    }
    atm_send(atm, cipher, sizeof(cipher));
    atm_recv(atm, recv, 20);
    
    plain_len = decrypt(recv,strlen(recv),atm->key,plain);
    
    if (plain_len == -1) {
      return;
    }
    
    if(strcmp(plain, "s") != 0){
      printf("Not authorized\n");
      return;
    } 
    else {
      printf("Authorized\n");
    }
    
    atm->in_session = 1;
    return;
    
  } 
  else if (strcmp(arg1, "withdraw") == 0){

    if(atm->in_session == 0){
      printf("No user logged in\n");
      return;
    }
    
    if(arg2 == NULL || strlen(arg2) < 1 || strlen(arg2) > 10
       || valid_digits(arg2) == -1){
      printf("Usage: withdraw <amt>\n");
      return;
    }
    
    int cipher_len, plain_len = 0;
    char cipher[128], recv[128],plain[128] = {0};
    char *msg = malloc((strlen(arg2)+10)*sizeof(char));
    
    strncpy(msg, "withdraw ", 10);
    strcat(msg, arg2);
    
    cipher_len = encrypt(msg,strlen(msg)+1,atm->key,cipher);
    if(cipher_len == -1) {
      return;
    }
    
    atm_send(atm, cipher, sizeof(cipher));
    atm_recv(atm, recv, 128);

    plain_len = decrypt(recv,strlen(recv),atm->key,plain);
    if(plain_len == -1) {
      return;
    }
    
    if(strcmp(plain, "invalid") == 0 || strcmp(plain, "une") == 0){
      printf("Usage: withdraw <amt>\n");
      return;
    }
    
    if(strcmp(plain, "ng") == 0){
      printf("Insufficient funds\n");
      return;
    }
    
    if(strcmp(plain, "s") == 0){
      printf("$%s dispensed\n", arg2);
      return;
    }
    
  } 
  else if (strcmp(arg1, "balance") == 0){
    if(atm->in_session == 0){
      printf("No user logged in\n");
      return;
    }
    
    int cipher_len, plain_len = 0;
    char cipher[128], recv[128],plain[128] = {0};
    char *msg = malloc(9*sizeof(char));
    strncpy(msg, "balance ", 9);
    
    
    cipher_len = encrypt(msg,strlen(msg)+1,atm->key,cipher);
    if(cipher_len == -1) {
      return;
    }
    atm_send(atm, cipher, sizeof(cipher));
    atm_recv(atm, recv, 128);
    
    plain_len = decrypt(recv,strlen(recv),atm->key,plain);
    if(plain_len == -1) {
      return;
    }
    
    if(strcmp(plain, "invalid") == 0 || strcmp(plain, "une") == 0){
      printf("Usage: balance\n");
      return;
    }
    
    printf("$%s\n", plain);
    return;
    
  } else if (strcmp(arg1, "end-session") == 0){
    if(atm->in_session == 0){
      printf("No user logged in\n");
      return;
    }
    int cipher_len, plain_len = 0;
    char cipher[128], recv[128],plain[128] = {0};
    char *msg = malloc(9*sizeof(char));
    strncpy(msg, "end-session", 12);

    
    cipher_len = encrypt(msg,strlen(msg)+1,atm->key,cipher);
    if(cipher_len == -1) {
      return;
    }
    
    atm_send(atm, cipher, sizeof(cipher));
    
    atm->in_session = 0;
    
    printf("User logged out\n");
    } else {
    printf("Invalid command\n");
    return;
  }
  
}
