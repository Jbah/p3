
#define _GNU_SOURCE
/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


static const char prompt[] = "ATM: ";

int main(int argc, char**argv)
{
    char user_input[1000];
    char *line;
    size_t length = 0;
    ssize_t lines;
    ATM *atm = atm_create();

    atm->atm_init = fopen(argv[1],"r");
    atm->key = malloc(512);
    while ((lines = getline(&line, &length, atm->atm_init)) != -1){
      strcat(atm->key, line);
    }
    atm->in_session = 0;
    printf("%s", prompt);
    fflush(stdout);

    while (fgets(user_input, 10000,stdin) != NULL)
    {
        atm_process_command(atm, user_input);
        printf("%s", prompt);
        fflush(stdout);
    }
	return EXIT_SUCCESS;
}
