
#include "../ports.h"
#include "bank.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#define _GNU_SOURCE
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <strings.h>
#include <sys/types.h>
#include <openssl/sha.h>


Bank* bank_create()
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as needed
    bank->curr_user = malloc(251*sizeof(char));
    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
	fclose(bank->bank_init);
        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

void bank_process_local_command(Bank *bank, char *command, size_t len)
{ 
  char *arg1 = malloc(11*sizeof(char));
  char *arg2 = malloc(250*sizeof(char));
  char *arg3 = malloc(4*sizeof(char));
  char *arg4 = malloc(10*sizeof(char));
  
  sscanf(command, "%s %s %s %s", arg1, arg2, arg3, arg4);
  
  if(strlen(arg1) < 1 || strlen(arg1) > 11){
    printf("Invalid command\n");
    return;
  }
  
  if(strcmp(arg1, "create-user") == 0){
    if(strlen(arg2) < 1 || strlen(arg3) != 4 || strlen(arg4) < 1
       || strlen(arg2) > 250 || strlen(arg4) > 10
       || valid_user(arg2) == -1 || valid_pin(arg3) == -1
       || strtol(arg4,NULL,10) > MAX_INT || strtol(arg4,NULL,10) < 0){
      printf("Usage: create-user <user-name> <pin> <balance>\n");
      return;
    }

    if(exists(arg2) == 0){
      printf("Error user %s already exists\n", arg2);
      return;
    }
    
    
    char *ext = ".card";
    char *temp = malloc(sizeof(char)*strlen(arg2));
    strcpy(temp,arg2);
    strcat(temp,ext);

    FILE *card = fopen(temp, "w");
    char cipher[128] = {0};
    int cipher_len = 0;

    if(card == NULL){
      printf("Error creating card file for user %s\n", arg2);
      remove(temp);
      return;
    }
    cipher_len = encrypt(arg3,strlen(arg3),bank->key,cipher);
    if (cipher_len == -1){
      return;
    }

    fputs(cipher, card);
    fclose(card);
    
    int balance = strtol(arg4, NULL, 10);
    insert(&bank->registry, arg2, balance);
    printf("Created user %s\n", arg2);
    return;
    
  }

  else if (strcmp(arg1, "deposit") == 0) {
    if(strlen(arg2) < 1 || strlen(arg3) < 1 || strlen(arg2) > 250
       || valid_user(arg2) == -1 || strtol(arg3,NULL,10) > MAX_INT 
       || strtol(arg3,NULL,10) < 0){
      printf("Usage: deposit <user-name> <amt>\n");
      return;
    }
    
    if(exists(arg2) == -1){
      printf("No such user\n");
      return;
    }
    
    if(strlen(arg3) > 10){
      
      if(valid_digits(arg3) == -1){
	printf("Usage: deposit <user-name> <amt>\n");
	return;
      } 
      else {
	printf("Too rich for this program\n");
	return;
      }
    }
    
    int curr_balance = get(&bank->registry,arg2);
    int to_deposit = strtol(arg3, NULL, 10);
    
    if(curr_balance + to_deposit > MAX_INT){
      printf("Too rich for this program\n");
      return;
    }
    
    insert(&bank->registry,arg2,curr_balance + to_deposit);
    
    printf("$%s added to %s's account\n", arg3, arg2);
    return;
    
  } else if (strcmp(arg1, "balance") == 0) {
    if(strlen(arg2) < 1 || valid_user(arg2) == -1 || strlen(arg2) > 250){
      printf("Usage: balance <user-name>\n");
      return;
    }
    
    if(exists(arg2) == -1){
      printf("No such user\n");
      return;
    }
    
    int curr_balance = get(&bank->registry,arg2);
    printf("$%d\n", curr_balance);
    return;
    
  } else {
    printf("Invalid command\n");
    return;
  }
}

void bank_process_remote_command(Bank *bank, char *command, size_t len)
{
  // TODO: Implement the bank side of the ATM-bank protocol
  
  char plain[128] = {0};
 
  char *arg1 = malloc(10*sizeof(char));
  char *arg2 = malloc(14*sizeof(char));
  char *arg3 = malloc(250*sizeof(char));

  decrypt(command,strlen(command),bank->key,plain);
  
  sscanf(plain, "%s %s %s", arg1, arg2, arg3);
  if(arg1 == NULL || strlen(arg1) < 1 || strlen(arg1) > 14
     || strlen(arg2) > 250){
    send_invalid(bank);
    return;
  }
  
  if(strcmp(arg1, "exists?") == 0){ 
    if(exists(arg2) != -1){
      strcpy(bank->curr_user,arg2);
      send_s(bank);
    } else {
      send_ng(bank);
    }
    return;
    
  } 
  else if (strcmp(arg1, "withdraw") == 0){
    if(arg2 == NULL || strlen(arg2) < 1 || strlen(arg2) > 10
       || valid_digits(arg2) == -1){
      send_invalid(bank);
      return;
    }
    
    if(strtol(arg2, NULL, 10) < 0 || strtol(arg2, NULL, 10) > MAX_INT){
      send_ng(bank);
      return;
    }
    
    int to_withdraw = strtol(arg2,NULL,10);
    int curr_balance = get(&bank->registry,bank->curr_user);
    
    if(curr_balance - to_withdraw < 0){
      send_ng(bank);
      return;
    }
    
    insert(&bank->registry,bank->curr_user,curr_balance - to_withdraw);
    
    send_s(bank);
    return;
       
  }   
  else if (strcmp(arg1, "balance") == 0){
    char num[11];
    int balance = get(&bank->registry,bank->curr_user);
    snprintf(num,11,"%d",balance);
    send_balance(bank,num);
    return;
    
  } 
  else if (strcmp(arg1, "pin?") == 0){ 
    if(exists(arg2) == -1){
      send_une(bank);
      return;
    }
    
    if(arg2 == NULL|| strlen(arg2) < 1 ||arg3 == NULL 
       || strlen(arg3) < 1 || strlen(arg3) != 4
       || valid_digits(arg3) == -1){
      send_invalid(bank);
      return;
    }
    char enc[128] = {0};
    char plain[128] = {0};
    int plain_len = 0;
    char temp[5];
    strcpy(enc, get_enc(arg2));
    plain_len = decrypt(enc,strlen(enc),bank->key,plain);

    strncpy(temp,plain,4);
    temp[4] = '\0';
    if(plain_len == -1) {
      return;
    }
    
    if(strcmp(temp,arg3) == 0){
      send_s(bank);
      return;
    } 
    else {
      send_ng(bank);
      return;
    }
    
  } 
  else {
    send_invalid(bank);
    return;
  }
  
}

int valid_user(char *user){
  if(user == NULL){
    return 0;
  }
  
  int i;
  for(i = 0; i < strlen(user); i++){
    if(user[i] > 122 || user[i] < 65){
      return -1;
    } else if (user[i] > 90 && user[i] < 97){
      return -1;
    }
  }
  return 1;
}

int exists(char *user){
  char *ext = ".card";
  int ufilelen = strlen(user) + 6; //5 = . c a r d and + 1 for null
  char userfile[ufilelen]; //5 = . c a r d
  memset(userfile, 0x00, ufilelen);
  strncpy(userfile, user, strlen(user));
  strncat(userfile, ext, 5);
  
  if(access(userfile, F_OK) != -1){
    return 0;
  } else {
    return - 1;
  }
}

int valid_pin(char *pin){
  if(valid_digits(pin) == -1){
    return -1;
  }
  
  long d = strtol(pin, NULL, 10);
  if (d < 0 || d > 9999){
    return -1;
  }
  return 0;
}


int valid_digits(char *str){
  int i;
  for(i = 0; i < strlen(str); i++){
    if(str[i] < 48 || str[i] > 57){
      return -1;
      
    }
  }
  return 0;
}

void send_invalid(Bank *bank){
  char cipher[1000] = {0};
  int cipher_len = 0;
  cipher_len = encrypt("invalid",8,bank->key, cipher);
  if(cipher_len != -1) {
    bank_send(bank, cipher, sizeof(cipher));
    return;
  }
}

void send_s(Bank *bank){
  char cipher[1000] = {0};
  int cipher_len = 0;
  cipher_len = encrypt("s",2,bank->key, cipher);
  if(cipher_len != -1) {
    bank_send(bank, cipher, sizeof(cipher));
    return;
  }
}

void send_ng(Bank *bank){
  char cipher[1000] = {0};
  int cipher_len = 0;
  cipher_len = encrypt("ng",3,bank->key, cipher);
  if(cipher_len != -1) {
    bank_send(bank, cipher, sizeof(cipher));
    return;
  }
}

void send_une(Bank *bank){
  char cipher[1000] = {0};
  int cipher_len = 0;
  cipher_len = encrypt("une",4,bank->key, cipher);
  if(cipher_len != -1) {
    bank_send(bank, cipher, sizeof(cipher));
    return;
  }
}

void send_ce(Bank *bank){
  char cipher[1000] = {0};
  int cipher_len = 0;
  cipher_len = encrypt("ce",3,bank->key, cipher);
  if(cipher_len != -1) {
    bank_send(bank, cipher, sizeof(cipher));
    return;
  }
}

void send_balance(Bank *bank, char *balance){
  char cipher[1000] = {0};
  int cipher_len = 0;
  cipher_len = encrypt(balance,strlen(balance)+1,bank->key, cipher);
  if(cipher_len != -1) {
    bank_send(bank, cipher, sizeof(cipher));
    return;
  }
}

char *get_enc(char *user){
  FILE *enc;
  char cipher[128] = {0};
  strcat(user,".card");
  enc = fopen(user,"r");
  if (enc == NULL) {
    return NULL;
  }
  char *line;
  size_t length = 0;
  ssize_t lines;
  
  while ((lines = getline(&line, &length, enc)) != -1){
    strcat(cipher, line);
  }
  return cipher;

}


/* TO BUILD: gcc -lcrypto -g crypto_sample.c
   ./a.out
*/


/*
 * Encrypt "plaintext_in" with "key" into "ciphertext"
 * "ciphertext" must be a char[] with enough space to hold the output
 * Uses IV of all zeroes
 *
 * Returns the length of "ciphertext" or -1 on error
 */
int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key,
	    unsigned char *ciphertext) {
  EVP_CIPHER_CTX *ctx;
  unsigned char iv[16] = {0};
  int len = 0;
  int ciphertext_len = 0;
  
  if(!(ctx = EVP_CIPHER_CTX_new())) {
    return -1;
  }
  if(EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv) != 1) {
    return -1;
  }
  if(EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext_in, plaintext_len) != 1) {
    return -1;
  }
  ciphertext_len = len;
  
  if(EVP_EncryptFinal_ex(ctx, ciphertext + len, &len) != 1) {
    return -1;
  }
  ciphertext_len += len;
  
  /* Clean up */
  EVP_CIPHER_CTX_free(ctx);
  
  return ciphertext_len;
}

/*
 * Decrypt "cipher" with "key" into "plain"
 */
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
	    unsigned char *plaintext) {
  EVP_CIPHER_CTX *ctx;
  unsigned char iv[16] = {0};
  int len;
  int plaintext_len;
  
  if(!(ctx = EVP_CIPHER_CTX_new())) {
    return -1;
  }
  if(EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv) != 1) {
    return -1;
  }
  if(EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len) != 1) {
    return -1;
  }
  plaintext_len = len;
  if(EVP_DecryptFinal_ex(ctx, plaintext + len, &len) != 1) {
    return -1;
  }
  plaintext_len += len;
  
  /* Clean up */
  EVP_CIPHER_CTX_free(ctx);
  
  return plaintext_len;
}

/*
 * Sign "cipher" with "key"
 */
int sign(const unsigned char* key, unsigned char* cipher, int cipher_len,
	 unsigned char* tag) {
  int len = 0;
  HMAC_CTX ctx;
  
  HMAC_CTX_init(&ctx);
  HMAC_Init_ex(&ctx, key, strlen(key), EVP_sha1(), NULL);
  HMAC_Update(&ctx, cipher, cipher_len);
  HMAC_Final(&ctx, tag, &len);
  
  HMAC_CTX_cleanup(&ctx);
  return len;
}

/*
 * Debugging purposes only
 */
void printhex(unsigned char * hex, int len) {
  int i;
  if (hex == NULL) return;
  for (i = 0; i < len; i++) {
    printf("%02x ", hex[i]);
  }
  printf("\n");
}

/*int main() {
  unsigned char m[] = "This is a secret";
  unsigned char * key = "1234567890123456";
  unsigned char cipher[128] = {0};
  unsigned char iv[16] = {0};
  unsigned char plain[128] = {0};
  unsigned char tag[128] = {0};
  
  
  int cipher_len = encrypt(m, strlen(m)+1, key, cipher);
  printf("ciphertext length: %d\nciphertext: ", cipher_len);
  printhex(cipher, cipher_len);
  int plain_len = decrypt(cipher, cipher_len, key, plain);
  printf("plaintext length: %d\nplaintext: ", plain_len);
  printf("%s\n", plain);
  
  int tag_len = sign(key, m, strlen(m) + 1, tag);
  printf("tag length: %d\ntag: ", tag_len);
  printhex(tag, tag_len);
  } */
