#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <openssl/rand.h>

int main(int argc, char *argv[])
{
	FILE *bank_file, *atm_file;
	char *bank_path_in, *atm_path_in;

	// If no user input provided
	if (argc != 2) {
		printf("Usage: init <filename>\n");
		return 62;
	}
	// ATM take <path/fname> from input and append extention
	if ((atm_path_in = malloc(strlen(argv[1]) + strlen(".atm") + 1)) == NULL) {
		printf("Error creating initialization files\n");
		return 64;
	} else {
		strncpy(atm_path_in, argv[1], strlen(argv[1]));
		strncat(atm_path_in, ".atm", 4);
	}

	// BANK take <path/fname> from input and append extention
	if ((bank_path_in = malloc(strlen(argv[1]) + strlen(".bank") + 1)) == NULL) {
		free(atm_path_in);
		printf("Error creating initialization files\n");
		return 64;
	} else {
		strncpy(bank_path_in, argv[1], strlen(argv[1]));
		strncat(bank_path_in, ".bank", 5);
	}

	// If ones of the files already exist
	if (access(bank_path_in, F_OK) != -1 || access(atm_path_in, F_OK) != -1) {
		free(atm_path_in);
		free(bank_path_in);
		printf("Error: one of the files already exists\n");
		return 63;
	}
	// Open files
	bank_file = fopen(bank_path_in, "w+");
	atm_file = fopen(atm_path_in, "w+");

	// Continue if both files opened. Otherwise fail with the general case.
	if (bank_file != NULL && atm_file != NULL) {

		unsigned char key[32];
		if (!RAND_bytes(key, sizeof(key))) {
			printf("Error creating initialization files\n");
			return 64;
		}
		
		fwrite(key, 1, sizeof(key), bank_file);
		fwrite(key, 1, sizeof(key), atm_file);

		fclose(atm_file);
		fclose(bank_file);

		free(atm_path_in);
		free(bank_path_in);

		printf("Successfully initialized bank state\n");
		return 0;

	} else {
		// Program failed somewhere
		free(atm_path_in);
		free(bank_path_in);

		printf("Error creating initialization files\n");
		return 64;
	}
}
