/*
 * The ATM interfaces with the user.  User commands should be
 * handled by atm_process_command.
 *
 * The ATM can read .card files, but not .pin files.
 *
 * Feel free to update the struct and the processing as you desire
 * (though you probably won't need/want to change send/recv).
 */

#ifndef __ATM_H__
#define __ATM_H__

#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <ctype.h>

typedef struct _ATM {
	// Networking state
	int sockfd;
	struct sockaddr_in rtr_addr;
	struct sockaddr_in atm_addr;

	// Protocol state
	int active_session;
	int login_attempts;
	unsigned char encryption_key[32];

} ATM;

ATM *atm_create(FILE * fp);
void atm_free(ATM * atm);
ssize_t atm_send(ATM * atm, char *data, size_t data_len);
ssize_t atm_recv(ATM * atm, char *data, size_t max_data_len);
void atm_process_command(ATM * atm, char *command);
int is_alpha(char *str, int len);
int is_digit(char *str, int len);
void process_session_command(char *command, ATM * atm, char *user_name);
int sha_256(void *salt, unsigned long salt_length, void *input, unsigned long input_length, unsigned char *salted_hash);
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
        unsigned char *plaintext, unsigned char *iv);
int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key, 
        unsigned char *ciphertext, unsigned char *iv);
int bank_io(ATM * atm, unsigned char *encrypted_command, unsigned char *iv, int cipher_length);
void handle_session(char *user_name, ATM * atm, size_t user_name_length);
#endif
