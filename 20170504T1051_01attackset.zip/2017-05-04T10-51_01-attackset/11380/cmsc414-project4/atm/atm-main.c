/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static const char prompt[] = "ATM: ";

int main(int argc, char **argv)
{
	char user_input[1000];
	FILE *fp = fopen(argv[1], "r");
	if (fp == NULL) {
		printf("Error opening ATM initialization file");
		return 64;
	}
	ATM *atm = atm_create(fp);

	printf("%s", prompt);
	fflush(stdout);
	while (fgets(user_input, 10000, stdin) != NULL) {
		// Ignore authorization messages
		if (strstr(user_input, "\n") - user_input == 0) {
			continue;
		}
		atm_process_command(atm, user_input);
		printf("%s", prompt);
		fflush(stdout);

	}
	atm_free(atm);
	return EXIT_SUCCESS;
}
