#include "atm.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <openssl/aes.h>
#include <openssl/evp.h>

ATM *atm_create(FILE * atm_file)
{
	ATM *atm = (ATM *) malloc(sizeof(ATM));
	if (atm == NULL) {
		perror("Could not allocate ATM");
		exit(1);
	}
	// Set up the network state
	atm->sockfd = socket(AF_INET, SOCK_DGRAM, 0);

	bzero(&atm->rtr_addr, sizeof(atm->rtr_addr));
	atm->rtr_addr.sin_family = AF_INET;
	atm->rtr_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
	atm->rtr_addr.sin_port = htons(ROUTER_PORT);

	bzero(&atm->atm_addr, sizeof(atm->atm_addr));
	atm->atm_addr.sin_family = AF_INET;
	atm->atm_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
	atm->atm_addr.sin_port = htons(ATM_PORT);
	bind(atm->sockfd, (struct sockaddr *)&atm->atm_addr, sizeof(atm->atm_addr));

	// Set up the protocol state
	atm->active_session = 0;
	atm->login_attempts = 0;
	char line[32];
	if (fgets(line, sizeof(line), atm_file) != NULL) {
		memcpy(atm->encryption_key, line, 32);
	} else {
		printf("Error opening ATM initialization file");
		exit(64);
	}
	return atm;
}

void atm_free(ATM * atm)
{
	if (atm != NULL) {
		close(atm->sockfd);
		free(atm);
	}
}

ssize_t atm_send(ATM * atm, char *data, size_t data_len)
{
	// Returns the number of bytes sent; negative on error
	return sendto(atm->sockfd, data, data_len, 0, (struct sockaddr *)&atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM * atm, char *data, size_t max_data_len)
{
	// Returns the number of bytes received; negative on error
	return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

int is_alpha(char *str, int len)
{
	int i;
	for (i = 0; i < len; i++) {
		if (!isalpha(str[i])) {
			return 0;
		}
	}
	return 1;
}

int is_digit(char *str, int len)
{
	int i;
	for (i = 0; i < len; i++) {
		if (!isdigit(str[i])) {
			return 0;
		}
	}
	return 1;
}

/*
 * Encrypt "plaintext_in" with "key" into "ciphertext"
 * "ciphertext" must be a char[] with enough space to hold the output
 * Uses IV of all zeroes
 *
 * Returns the length of "ciphertext" or -1 on error
 */ 
int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key, unsigned char *ciphertext, unsigned char *iv)
{    EVP_CIPHER_CTX * ctx;    int len = 0;	    int ciphertext_len = 0;    if (!(ctx = EVP_CIPHER_CTX_new()))         return -1;    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv) != 1)         return -1;    if (EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext_in, plaintext_len) != 1) 	        return -1;    ciphertext_len = len;    if (EVP_EncryptFinal_ex(ctx, ciphertext + len, &len) != 1) 
        return -1;	    ciphertext_len += len;
    /* Clean up */ 
    EVP_CIPHER_CTX_free(ctx);    return ciphertext_len;}
/*
 * Decrypt "cipher" with "key" into "plain"
 */ 
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key, unsigned char *plaintext, unsigned char *iv)
{    EVP_CIPHER_CTX * ctx;    int len;    int plaintext_len;    if (!(ctx = EVP_CIPHER_CTX_new()))         return -1;    if (EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv) != 1) 
		        return -1;    if (EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len) != 1)         return -1;    plaintext_len = len;    if (EVP_DecryptFinal_ex(ctx, plaintext + len, &len) != 1)         return -1;    plaintext_len += len;
    /* Clean up */ 
    EVP_CIPHER_CTX_free(ctx);
	return plaintext_len;}

int bank_io(ATM * atm, unsigned char *encrypted_command, unsigned char *iv, int cipher_length)
{
	int packet_length = 16 + 1 + cipher_length;
	char recvline[10000];
	char space[] = " ";
	char packet[packet_length];
	memcpy(packet, iv, AES_BLOCK_SIZE);
	memcpy(&packet[AES_BLOCK_SIZE], space, 1);
	memcpy(&packet[AES_BLOCK_SIZE + 1], encrypted_command, cipher_length);

	atm_send(atm, packet, packet_length);

	int n = atm_recv(atm, recvline, 10000);
	recvline[n] = 0;

	unsigned char dec_iv[AES_BLOCK_SIZE];
	memcpy(dec_iv, recvline, AES_BLOCK_SIZE);
	unsigned char cipher_text[n - 17];
	memcpy(cipher_text, &recvline[17], n - 1 - 16);

	unsigned char decrypted[512];
	int decrypted_length = decrypt(cipher_text, n - 17, atm->encryption_key, decrypted, dec_iv);
	decrypted[decrypted_length] = 0;
	int return_val = strtol((char *)decrypted, NULL, 10);

	return return_val;
}

void process_session_command(char *command, ATM * atm, char *user_name)
{
	// Tokenize input 
	char *input = strtok(command, " ");

	// Remove enter from end of input
	if (input[strlen(input) - 1] == '\n') {
		input[strlen(input) - 1] = 0;
	}
	// User already logged in
	if (strcmp(input, "begin-session") == 0) {
		char *user_name = strtok(NULL, " ");
		char *overflow = strtok(NULL, " ");

		if (user_name == NULL || overflow != NULL || strlen(user_name) > 250 || is_alpha(user_name, strlen(user_name) - 1) == 0) {
			printf("Usage: begin-session <user-name>\n");
		} else {
			printf("A user is already logged in\n");
		}

	} else if (strcmp(input, "withdraw") == 0) {

		char *amount = strtok(NULL, " ");
		char *overflow = strtok(NULL, " ");

		// Check for invalid input
		if (amount == NULL || overflow != NULL || is_digit(amount, strlen(amount) - 1) == 0
		    || strtol(amount, NULL, 10) > 2147483647u || strtol(amount, NULL, 10) < 0) {
			printf("Usage: withdraw <amt>\n");
		} else {

			// Remove enter from end of input
			if (amount[strlen(amount) - 1] == '\n') {
				amount[strlen(amount) - 1] = 0;
			}
			// Create command 'w <amt> <user_name>'
			char remote_command[1 + 1 + 4 + 1 + strlen(user_name)];
			sprintf(remote_command, "w %ld %s", strtol(amount, NULL, 10), user_name);

			// Create IV copies
			unsigned char enc_iv[AES_BLOCK_SIZE];
			unsigned char bank_iv[AES_BLOCK_SIZE];
			RAND_bytes(enc_iv, AES_BLOCK_SIZE);
			memcpy(bank_iv, enc_iv, AES_BLOCK_SIZE);

			// Encryption of message
			unsigned char cipher[512];
			int cipher_length = encrypt((unsigned char *)remote_command, strlen(remote_command) + 1, atm->encryption_key, cipher, enc_iv);

			// Communicate
			int return_val = bank_io(atm, cipher, bank_iv, cipher_length);

			if (return_val == 1) {
				printf("$%s dispensed\n", amount);
			} else {
				printf("Insufficient funds\n");
			}
		}

	} else if (strcmp(input, "balance") == 0) {
		char *overflow = strtok(NULL, " ");

		// Check for invalid input
		if (overflow != NULL) {
			printf("Usage: balance\n");
		} else {

			// Remove enter from end of input
			if (user_name[strlen(user_name) - 1] == '\n') {
				user_name[strlen(user_name) - 1] = 0;
			}
			// Create command 'b <user_name>'
			char remote_command[1 + 1 + strlen(user_name)];
			user_name[strlen(user_name)] = 0;
			sprintf(remote_command, "b %s", user_name);

			// Create IV copies
			unsigned char enc_iv[AES_BLOCK_SIZE];
			unsigned char bank_iv[AES_BLOCK_SIZE];
			RAND_bytes(enc_iv, AES_BLOCK_SIZE);
			memcpy(bank_iv, enc_iv, AES_BLOCK_SIZE);

			// Encryption of message
			unsigned char cipher[512];
			int cipher_length = encrypt((unsigned char *)remote_command, strlen(remote_command) + 1, atm->encryption_key, cipher, enc_iv);

			// Communicate
			int return_val = bank_io(atm, cipher, bank_iv, cipher_length);

			if (return_val >= 0) {
				printf("$%d\n", return_val);
			} else {
				printf("Usage: balance\n");
			}

		}

	} else if (strcmp(input, "end-session") == 0) {
		char *overflow = strtok(NULL, " ");

		// Check for invalid input
		if (overflow != NULL) {
			printf("Invalid command\n");
		} else {
			atm->active_session = 0;
			printf("User logged out\n");
		}
	} else {
		printf("Invalid command\n");
	}
}

void handle_session(char *user_name, ATM * atm, size_t user_name_length)
{
	char user_input[1000];

	// Set up prompt
	char prompt[user_name_length + 7 + 1];
	strncpy(prompt, "ATM (", 5 + 1);
	prompt[5] = '\0';
	strncat(prompt, user_name, user_name_length + 1);
	prompt[5 + user_name_length] = '\0';
	strncat(prompt, "): ", 3 + 1);
	prompt[5 + user_name_length + 3] = '\0';

	printf("%s", prompt);
	fflush(stdout);

	while (fgets(user_input, 10000, stdin) != NULL && atm->active_session == 1) {
		// Ignore authorization messages
		if (strstr(user_input, "\n") - user_input == 0) {
			continue;
		}
		process_session_command(user_input, atm, user_name);
		if (atm->active_session == 1) {
			printf("%s", prompt);
			fflush(stdout);
		} else {
			return;
		}
	}
}

// Hash with specified salt
int sha_256(void *salt, unsigned long salt_length, void *input, unsigned long input_length, unsigned char *salted_hash)
{
	SHA256_CTX IV;
	if (!SHA256_Init(&IV))
		return 0;

	// first apply salt
	if (!SHA256_Update(&IV, (unsigned char *)salt, salt_length))
		return 0;

	// continue with data...
	if (!SHA256_Update(&IV, (unsigned char *)input, input_length))
		return 0;

	if (!SHA256_Final(salted_hash, &IV))
		return 0;

	return 1;
}

void atm_process_command(ATM * atm, char *command)
{
	// Tokenize input 
	char *input = strtok(command, " ");
	char pin_input[5];
	int pin_input_int;

	// If input provided
	if (input != NULL) {

		// Remove enter from end of input
		if (input[strlen(input) - 1] == '\n') {
			input[strlen(input) - 1] = 0;
		}

		if (strcmp(input, "begin-session") == 0) {

			if (atm->active_session == 1) {
				printf("A user is already logged in\n");
				return;
			}

			char *user_name = strtok(NULL, " ");
			char *overflow = strtok(NULL, " ");

			// Check for invalid input
			if (user_name == NULL || overflow != NULL || strlen(user_name) > 250 || is_alpha(user_name, strlen(user_name) - 1) == 0) {
				printf("Usage: begin-session <user-name>\n");
			} else {

				// Remove enter from end of input
				if (user_name[strlen(user_name) - 1] == '\n') {
					user_name[strlen(user_name) - 1] = 0;
				}
				// Create card path
				char card_path[strlen(user_name) + 5 + 1];
				strncpy(card_path, user_name, strlen(user_name) + 1);
				card_path[strlen(user_name)] = '\0';
				strncat(card_path, ".card", strlen(".card"));

				// Check for user card
				if (access(card_path, F_OK) == -1) {
					printf("No such user\n");
					return;
				}
				// Check pin input
				printf("PIN? ");
				if (scanf("%d", &pin_input_int) >= 0 && pin_input_int <= 9999) {

					// Store pin in a string
					snprintf(pin_input, sizeof(pin_input), "%d", pin_input_int);
					char line[256];

					// Open the card file
					FILE *fp = fopen(card_path, "r");
					if (fp == NULL) {
						printf("Unable to access %s's card\n", user_name);
					} else {
						fread(line, 129, 1, fp);

						unsigned char iv[AES_BLOCK_SIZE];
						memcpy(iv, line, AES_BLOCK_SIZE);

						unsigned char cipher_text[112];
						memcpy(cipher_text, &line[17], 112);

						//salt=32 space=1 pin=4
						unsigned char plain_text[98];
						int plain_text_len = decrypt(cipher_text, 112, atm->encryption_key, plain_text, iv);
						if (plain_text_len == -1) {
							printf("Unable to access %s's card\n", user_name);
						} else {

							char salt[32];
							char digest[65];
							memcpy(salt, plain_text, 32);
							memcpy(digest, &plain_text[32], 64);

							// Hash the salted string and compare the two hashes
							unsigned char encrypted_pin[SHA256_DIGEST_LENGTH];
							if (sha_256(salt, 32, pin_input, 4, encrypted_pin) != 0) {

								char encrypted_pin_str[65];
								int i;
								for (i = 0; i < SHA256_DIGEST_LENGTH; i++) {
									sprintf(&encrypted_pin_str[i * 2], "%02x", encrypted_pin[i]);
								}

								// Given pin matched user pin
								if (strncmp(encrypted_pin_str, digest, 64) == 0) {
									// Remove enter from end of input
									if (user_name[strlen(user_name) - 1] == '\n') {
										user_name[strlen(user_name) - 1] = 0;
									}

									printf("Authorized\n");
									atm->active_session = 1;
									handle_session(user_name, atm, strlen(user_name));
									return;
								}
							}

						}
						fclose(fp);
					}
				}
				// This triggers if authorization failed.
				printf("Not authorized\n");
				atm->login_attempts++;
				if (atm->login_attempts >= 10) {
					printf("Too many login attempts. Wait 30 seconds and try again\n");
					sleep(30);
					atm->login_attempts = 0;
				}
			}
		} else if (strcmp(input, "withdraw") == 0) {
			printf("No user logged in\n");
		} else if (strcmp(input, "balance") == 0) {
			printf("No user logged in\n");
		} else {
			printf("Invalid command\n");
		}
	}
}
