/*
 * The Bank takes commands from stdin as well as from the ATM.  
 *
 * Commands from stdin be handled by bank_process_local_command.
 *
 * Remote commands from the ATM should be handled by
 * bank_process_remote_command.
 *
 * The Bank can read both .card files AND .pin files.
 *
 * Feel free to update the struct and the processing as you desire
 * (though you probably won't need/want to change send/recv).
 */

#ifndef __BANK_H__
#define __BANK_H__

#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include "list.h"
#include <ctype.h>

typedef struct _Bank {
	// Networking state
	int sockfd;
	struct sockaddr_in rtr_addr;
	struct sockaddr_in bank_addr;

	// Protocol state
	List *user_balance;
	unsigned char encryption_key[32];

} Bank;

Bank *bank_create();
void bank_free(Bank * bank);
ssize_t bank_send(Bank * bank, char *data, size_t data_len);
ssize_t bank_recv(Bank * bank, char *data, size_t max_data_len);
void bank_process_local_command(Bank * bank, char *command, size_t len);
void bank_process_remote_command(Bank * bank, char *command, size_t len);
int is_alpha(char *str, int len);
int is_digit(char *str, int len);
int sha_256(void *salt, unsigned long salt_length, void *input, unsigned long input_length, unsigned char *salted_hash);
void generate_salt(unsigned char *s, const int len);
int make_card(char *user_name, size_t user_len, char *pin, Bank * bank);
int safe_add(int a, int b);
int withdraw(Bank * bank, char *user_name, char *amount);
void atm_io(Bank * bank, unsigned char *encrypted_command, unsigned char *iv, int cipher_length);
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
        unsigned char *plaintext, unsigned char *iv);
int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key, 
        unsigned char *ciphertext, unsigned char *iv);
void send_error(Bank * bank);
void send_sucess(Bank * bank);
void send_balance(Bank * bank, char *balance);
#endif
