#include "bank.h"
#include "list.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <limits.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <openssl/evp.h>
#include <openssl/aes.h>

Bank *bank_create(FILE * bank_file)
{
	Bank *bank = (Bank *) malloc(sizeof(Bank));
	if (bank == NULL) {
		perror("Could not allocate Bank");
		exit(1);
	}
	// Set up the network state
	bank->sockfd = socket(AF_INET, SOCK_DGRAM, 0);

	bzero(&bank->rtr_addr, sizeof(bank->rtr_addr));
	bank->rtr_addr.sin_family = AF_INET;
	bank->rtr_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
	bank->rtr_addr.sin_port = htons(ROUTER_PORT);

	bzero(&bank->bank_addr, sizeof(bank->bank_addr));
	bank->bank_addr.sin_family = AF_INET;
	bank->bank_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
	bank->bank_addr.sin_port = htons(BANK_PORT);
	bind(bank->sockfd, (struct sockaddr *)&bank->bank_addr, sizeof(bank->bank_addr));

	// Set up the protocol state
	char line[32];
	if (fgets(line, sizeof(line), bank_file) != NULL) {
		memcpy(bank->encryption_key, line, 32);
	} else {
		printf("Error opening Bank initialization file");
		exit(64);
	}

	// Bank List (key = user_name, value = balance)
	bank->user_balance = list_create();
	return bank;
}

void bank_free(Bank * bank)
{
	if (bank->user_balance != NULL) {
		list_free(bank->user_balance);
	}

	if (bank != NULL) {
		close(bank->sockfd);
		free(bank);
	}
}

ssize_t bank_send(Bank * bank, char *data, size_t data_len)
{
	// Returns the number of bytes sent; negative on error
	return sendto(bank->sockfd, data, data_len, 0, (struct sockaddr *)&bank->rtr_addr, sizeof(bank->rtr_addr));

}

ssize_t bank_recv(Bank * bank, char *data, size_t max_data_len)
{
	// Returns the number of bytes received; negative on error
	return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

int is_alpha(char *str, int len)
{
	int i;
	for (i = 0; i < len; i++) {
		if (!isalpha(str[i])) {
			return 0;
		}
	}
	return 1;
}

int is_digit(char *str, int len)
{
	int i;
	for (i = 0; i < len; i++) {
		if (!isdigit(str[i])) {
			return 0;
		}
	}
	return 1;
}

/*
 * Encrypt "plaintext_in" with "key" into "ciphertext"
 * "ciphertext" must be a char[] with enough space to hold the output
 * Uses IV of all zeroes
 *
 * Returns the length of "ciphertext" or -1 on error
 */ 
int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key, unsigned char *ciphertext, unsigned char *iv)
{    EVP_CIPHER_CTX * ctx;    int len = 0;    int ciphertext_len = 0;    if (!(ctx = EVP_CIPHER_CTX_new())) {        return -1;    }    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv) != 1) {        return -1;    }    if (EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext_in, plaintext_len) != 1) {        return -1;    }
    ciphertext_len = len;    if (EVP_EncryptFinal_ex(ctx, ciphertext + len, &len) != 1) {        return -1;    }    ciphertext_len += len;
    /* Clean up */ 
    EVP_CIPHER_CTX_free(ctx);
    return ciphertext_len;}
/*
 * Decrypt "cipher" with "key" into "plain"
 */ 
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key, unsigned char *plaintext, unsigned char *iv)
{    EVP_CIPHER_CTX * ctx;    int len;    int plaintext_len;    if (!(ctx = EVP_CIPHER_CTX_new())) {        return -1;    }    if (EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv) != 1) {        return -1;    }    if (EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len) != 1) {	        return -1;    }    plaintext_len = len;    if (EVP_DecryptFinal_ex(ctx, plaintext + len, &len) != 1) {	        return -1;    }    plaintext_len += len;
    /* Clean up */ 
    EVP_CIPHER_CTX_free(ctx);    return plaintext_len;}

// Send packet to atm
void atm_io(Bank * bank, unsigned char *encrypted_command, unsigned char *iv, int cipher_length)
{
	char space[] = " ";
	char packet[16 + 1 + cipher_length];
	memcpy(packet, iv, AES_BLOCK_SIZE);
	memcpy(&packet[AES_BLOCK_SIZE], space, 1);
	memcpy(&packet[AES_BLOCK_SIZE + 1], encrypted_command, cipher_length);
	bank_send(bank, packet, 16 + 1 + cipher_length);
}

// Encrypt 0 and send packet to atm
void send_error(Bank * bank)
{
	char *error_message = "0";
	unsigned char enc_iv[AES_BLOCK_SIZE];
	unsigned char bank_iv[AES_BLOCK_SIZE];
	RAND_bytes(enc_iv, AES_BLOCK_SIZE);
	memcpy(bank_iv, enc_iv, AES_BLOCK_SIZE);
	unsigned char cipher[512];
	int cipher_length = encrypt((unsigned char *)error_message, strlen(error_message) + 1, bank->encryption_key, cipher, enc_iv);
	atm_io(bank, cipher, bank_iv, cipher_length);
}

// Encrypt 1 and send to packet atm
void send_success(Bank * bank)
{
	char *success_message = "1";
	unsigned char enc_iv[AES_BLOCK_SIZE];
	unsigned char bank_iv[AES_BLOCK_SIZE];
	RAND_bytes(enc_iv, AES_BLOCK_SIZE);
	memcpy(bank_iv, enc_iv, AES_BLOCK_SIZE);
	unsigned char cipher[512];
	int cipher_length = encrypt((unsigned char *)success_message, strlen(success_message) + 1, bank->encryption_key, cipher, enc_iv);
	atm_io(bank, cipher, bank_iv, cipher_length);
}

// Encrypt balance and send packet to atm
void send_balance(Bank * bank, char *balance)
{
	unsigned char enc_iv[AES_BLOCK_SIZE];
	unsigned char bank_iv[AES_BLOCK_SIZE];
	RAND_bytes(enc_iv, AES_BLOCK_SIZE);
	memcpy(bank_iv, enc_iv, AES_BLOCK_SIZE);
	unsigned char cipher[512];
	int cipher_length = encrypt((unsigned char *)balance, strlen(balance) + 1, bank->encryption_key, cipher, enc_iv);
	atm_io(bank, cipher, bank_iv, cipher_length);
}

// Generate random salt
void generate_salt(unsigned char *s, const int len)
{
	srand(time(NULL));
	static const char alphanum[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz;,.:><+=-_*&^$#@!";
	int i;

	for (i = 0; i < len; ++i) {
		s[i] = alphanum[rand() % (sizeof(alphanum) - 1)];
	}
}

// Hash with random salt
int sha_256(void *salt, unsigned long salt_length, void *input, unsigned long input_length, unsigned char *salted_hash)
{
	SHA256_CTX IV;
	if (!SHA256_Init(&IV))
		return 0;

	// first apply salt
	if (!SHA256_Update(&IV, (unsigned char *)salt, salt_length))
		return 0;

	// continue with data...
	if (!SHA256_Update(&IV, (unsigned char *)input, input_length))
		return 0;

	if (!SHA256_Final(salted_hash, &IV))
		return 0;

	return 1;
}

int make_card(char *user_name, size_t user_len, char *pin, Bank * bank)
{
	FILE *user_card_file = NULL;
	char user_card_path[user_len + 5 + 1];

	strncpy(user_card_path, user_name, user_len + 1);
	user_card_path[user_len] = '\0';
	strncat(user_card_path, ".card", strlen(".card"));

	// If file exists
	if (access(user_card_path, F_OK) != -1) {
		printf("Error: user %s already exists\n", user_name);
		return 1;
	}
	// If file opened successfully
	user_card_file = fopen(user_card_path, "w+");
	if (user_card_file != NULL) {

		// Generate random salt
		unsigned char salt[32];
		generate_salt(salt, 32);

		// Hash user pin
		unsigned char encrypted_pin[SHA256_DIGEST_LENGTH];
		if (sha_256(salt, 32, pin, 4, encrypted_pin) == 0) {

			fclose(user_card_file);

			printf("Error creating card file for user %s\n", user_name);
			return 1;
		} else {
			char encrypted_pin_str[65];
			int i;
			for (i = 0; i < SHA256_DIGEST_LENGTH; i++) {
				sprintf(&encrypted_pin_str[i * 2], "%02x", encrypted_pin[i]);
			}

			// Generate IV
			unsigned char IV[AES_BLOCK_SIZE];
			RAND_bytes(IV, AES_BLOCK_SIZE);

			// Create previous line for card (encrypted_pin_str = 65 space = 1 salt = 32)
			char line[98];
			strncpy(line, (char *)salt, 32 + 1);
			line[32] = '\0';
			strncat(line, encrypted_pin_str, 65);

			// Create Ciphertext input
			unsigned char cipher_line[250];
			int cipher_length = encrypt((unsigned char *)line, 98, bank->encryption_key, cipher_line, IV);
			if (cipher_length == -1) {
				printf("Error creating card file for user %s\n", user_name);
				return -1;
			} else {
				// Write to card (IV , encrypted salt hashed(salt || pin))
				fwrite(IV, 1, AES_BLOCK_SIZE, user_card_file);
				fwrite(" ", sizeof(char), 1, user_card_file);
				fwrite(cipher_line, 1, cipher_length, user_card_file);
			}

			fclose(user_card_file);
			return 0;
		}

	} else {
		return 1;
	}

}

int safe_add(int a, int b)
{
	if (a > 0 && b > INT_MAX - a) {
		/* handle overflow */
		printf("Too rich for this program\n");
		return -1;
	} else if (a < 0 && b < INT_MIN - a) {
		/* handle underflow */
		printf("Too rich for this program\n");
		return -1;
	}
	return a + b;
}

int withdraw(Bank * bank, char *user_name, char *amount_string)
{
	char *balance_string = list_find(bank->user_balance, user_name);

	if (balance_string == NULL) {
		return -1;

	} else {
		long int amount_int = strtol(amount_string, NULL, 10);
		long int balance_int = strtol(balance_string, NULL, 10);
		// Process withdraw
		int new_balance = balance_int - amount_int;

		if (new_balance < 0) {
			return -1;
		} else {

			// Convert balance int back to string
			char int_string[sizeof(int) * 4 + 1];
			sprintf(int_string, "%d", new_balance);

			// Update user_balance list
			list_del(bank->user_balance, user_name);
			list_add_char(bank->user_balance, user_name, int_string);
			return 1;
		}
	}
}

void bank_process_local_command(Bank * bank, char *command, size_t len)
{

	// Tokenize input 
	char *input = strtok(command, " ");

	// If input provided
	if (input != NULL) {

		if (strcmp(input, "create-user") == 0) {
			char *user_name = strtok(NULL, " ");
			char *pin = strtok(NULL, " ");
			char *balance = strtok(NULL, " ");
			char *overflow = strtok(NULL, " ");

			// Check for invalid input
			if (user_name == NULL || pin == NULL || balance == NULL || balance[0] == '\n' || overflow != NULL
			    || strlen(user_name) > 250 || is_alpha(user_name, strlen(user_name)) == 0 || strlen(pin) != 4
			    || is_digit(pin, strlen(pin)) == 0 || is_digit(balance, strlen(balance) - 1) == 0
			    || strtol(balance, NULL, 10) > 2147483647u || strtol(balance, NULL, 10) < 0) {
				printf("Usage: create-user <user-name> <pin> <balance>\n");
			} else {
				// Remove enter from end of input
				balance[strlen(balance) - 1] = 0;

				// Create card file
				char *user_exists = (char *)list_find(bank->user_balance, user_name);
				if (user_exists == NULL) {
					if (make_card(user_name, strlen(user_name), pin, bank) == 0) {
						list_add_char(bank->user_balance, user_name, balance);
						printf("Created user %s\n", user_name);
					} else {
						printf("Error creating card file for user %s\n", user_name);
					}
				} else {
					printf("Error: user %s already exists\n", user_name);
				}
			}

		} else if (strcmp(input, "deposit") == 0) {

			char *user_name = strtok(NULL, " ");
			char *amount = strtok(NULL, " ");
			char *overflow = strtok(NULL, " ");

			// Check for invalid input
			if (user_name == NULL || amount == NULL || amount[0] == '\n' || overflow != NULL
			    || strlen(user_name) > 250 || is_alpha(user_name, strlen(user_name)) == 0
			    || is_digit(amount, strlen(amount) - 1) == 0 || strtol(amount, NULL, 10) > 2147483647u || strtol(amount, NULL, 10) < 0) {
				printf("Usage: deposit <user-name> <amt>\n");
			} else {

				// Remove enter from end of input
				amount[strlen(amount) - 1] = 0;

				// Get user's balance
				char *balance_string = list_find(bank->user_balance, user_name);
				if (balance_string == NULL) {
					printf("No such user\n");
				} else {
					// Convert balance & amount strings to ints
					long int balance_int = strtol(balance_string, NULL, 10);
					long int amount_int = strtol(amount, NULL, 10);

					// Add the amount to the user's balance
					int new_balance = safe_add(balance_int, amount_int);
					if (new_balance != -1 || amount_int < 2147483647u) {

						// Convert int back to string and update user_balance list
						char int_string[sizeof(int) * 4 + 1];
						sprintf(int_string, "%d", new_balance);
						list_del(bank->user_balance, user_name);
						list_add_char(bank->user_balance, user_name, int_string);
						printf("$%s added to %s's account\n", amount, user_name);
					} else {
						printf("Too rich for this program\n");
					}
				}
			}

		} else if (strcmp(input, "balance") == 0) {
			char *user_name = strtok(NULL, " ");
			char *overflow = strtok(NULL, " ");

			// Remove enter from end of input
			user_name[strlen(user_name) - 1] = 0;

			// Check for invalid input
			if (user_name == NULL || overflow != NULL || strlen(user_name) > 250 || is_alpha(user_name, strlen(user_name)) == 0) {
				printf("Usage: balance <user-name>\n");
			} else {
				// Get user's balance from list
				char *balance_string = list_find(bank->user_balance, user_name);
				if (balance_string == NULL) {
					printf("No such user\n");
				} else {
					printf("$%s\n", balance_string);
				}
			}

		} else {
			// Incorrect input provided
			printf("Invalid command\n");
		}
	} else {
		// Null input provided
		printf("Invalid command\n");
	}
}

void bank_process_remote_command(Bank * bank, char *command, size_t len)
{
	unsigned char iv[16];
	memcpy(iv, command, 16);
	unsigned char cipher_text[len - 1 - 16];
	memcpy(cipher_text, &command[17], len - 1 - 16);

	// If input provided then decrypt
	if (iv != NULL && cipher_text != NULL) {
		char plain_text[512];
		int plain_text_len = decrypt(cipher_text, len - 17, bank->encryption_key, (unsigned char *)plain_text, iv);
		plain_text[plain_text_len] = 0;

		char *input = strtok(plain_text, " ");

		if (strcmp(input, "w") == 0) {
			char *amount = strtok(NULL, " ");
			char *user_name = strtok(NULL, " ");

			// Check for invalid input
			if (user_name == NULL || is_digit(amount, strlen(amount) - 1) == 0
			    || strtol(amount, NULL, 10) > 2147483647u || strtol(amount, NULL, 10) < 0) {

				// Sends encrypted error message to atm (0) 
				send_error(bank);

			} else {

				// Process withdraw
				if (withdraw(bank, user_name, amount) != 1) {

					// Sends encrypted error message to atm (0)
					send_error(bank);
					return;

				} else {

					// Sends encrypted sucess message to atm (1)
					send_success(bank);
					return;
				}
			}

		} else if (strcmp(input, "b") == 0) {
			char *user_name = strtok(NULL, " ");
			char *overflow = strtok(NULL, " ");

			// Check for invalid input
			if (user_name == NULL || overflow != NULL) {
				// Sends encrypted error message to atm (0)
				send_error(bank);
			} else {
				// Get user's balance from list
				char *balance_string = list_find(bank->user_balance, user_name);
				if (balance_string == NULL) {
					// Sends encrypted error message to atm (0)
					send_error(bank);
				} else {
					// Encrypt balance_string and send to atm
					send_balance(bank, balance_string);
				}

			}
		} else {
			// Invalid input from atm
			send_error(bank);
		}

	} else {
		// Null input from atm
		send_error(bank);
	}
}
