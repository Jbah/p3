#ifndef __CRYPTO_SAMPLE_H__
#define __CRYPTO_SAMPLE_H__

#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <string.h>


void printhex(unsigned char * hex, int len);
int encrypt(unsigned char *plaintext_in, int plaintext_len, unsigned char *key, 
	    unsigned char *ciphertext);
int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,  
	    unsigned char *plaintext);
int sign(const unsigned char* key, unsigned char* cipher, int cipher_len, 
	 unsigned char* tag);




#endif
