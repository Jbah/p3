#include "atm.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <wordexp.h>
#include <regex.h>
#include "crypto/crypto_sample.h"

#define MAX_INT 2147483647

ATM* atm_create()
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    atm->logged_in_name = NULL;
    atm->logged_in_bool = 0;

    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
  // Returns the number of bytes sent; negative on error
  return sendto(atm->sockfd, data, data_len, 0,
	     (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

void atm_process_command(ATM *atm, char *command)
{
  wordexp_t result;
  char **args = NULL;
  int argc = 0;

  command[strcspn(command, "\r\n")] = 0;

  wordexp(command, &result, 0);
  args = result.we_wordv;
  argc = result.we_wordc;

  if(argc < 1) {
    //check this first to avoid cases with no command
    printf("%s\n","Invalid command");
    return;
  } else if(strncmp(args[0],"begin-session", 14)==0) {
    if(argc != 2){
      printf("%s\n", "Usage: begin-session <user-name>");
      return;
    } else if(validate_name(args[1]) != 0){
      printf("%s\n", "Usage: begin-session <user-name>");
      return;
    } else {
      if(logged_in_atm(atm) == 1) {
	printf("%s\n","A user is already logged in");
	return;
      }
      //begin_session
      begin_session(atm, args[1]);
    }
  } else if(strncmp(args[0],"withdraw", 9)==0) {
    if(argc != 2){
      printf("%s\n", "Usage: withdraw <amount>");
      return;
    } else if(validate_amt(args[1]) != 0){
      printf("%s\n", "Usage: withdraw <amount>");
      return;
    } else {
      //withdraw
      withdraw(atm, args[1]);
    }
    
  } else if(strncmp(args[0],"balance", 8)==0) {
    if(argc != 1){
      printf("%s\n", "Usage: balance");
      return;
    } else {
      //balance
      display_balance(atm);
    }
    
  } else if(strncmp(args[0],"end-session",12)==0) {
    if(argc != 1){
      printf("%s\n", "Usage: end-session");
      return;
    } else {
      //end-session
      if(logged_in_atm(atm)==0){
	printf("%s\n", "No user logged in");
	return;
      }
      atm->logged_in_name = NULL;
      atm->logged_in_bool = 0;
      printf("%s\n", "User logged out");
    }
  } else {
    printf("%s\n", "Invalid command");
    return;
  }
}

	/*
	 * The following is a toy example that simply sends the
	 * user's command to the bank, receives a message from the
	 * bank, and then prints it to stdout.
	 */

	/*
    char recvline[10000];
    int n;

    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    fputs(recvline,stdout);
	*/

int validate_name(char *name){
  regex_t exp;
  int status;

  //create regular expression to match 
  status = regcomp(&exp, "^[a-zA-Z]{1,250}$", REG_EXTENDED);
  if(status != 0){
    return -1;
  }

  status = regexec(&exp, name, (size_t) 0, NULL, 0);
  regfree(&exp);
  if(status != 0){
    return -1;
  }

  return 0;
}

int validate_pin(char *pin_str){
  regex_t exp;
  int status;

  //create regular expression to match 
  status = regcomp(&exp, "^[0-9]{4}$", REG_EXTENDED);
  if(status != 0){
    return -1;
  }

  status = regexec(&exp, pin_str, (size_t) 0, NULL, 0);
  regfree(&exp);
  if(status != 0){
    return -1;
  }

  return 0;
}

int validate_amt(char *amt_str){
  regex_t exp;
  char *ptr;
  int status;
  unsigned long amt;

  //create regular expression to match 
  status = regcomp(&exp, "^[0-9]{1,10}$", REG_EXTENDED);
  if(status != 0){
    return -1;
  }

  status = regexec(&exp, amt_str, (size_t) 0, NULL, 0);
  regfree(&exp);
  if(status != 0){
    return -1;
  }

  amt = strtoul(amt_str,&ptr,10);
  if(amt > MAX_INT) {
    return -1;
  }
  
  return 0;
}

int begin_session(ATM *atm, char *name)
{
  char recvline[10000];
  char req[300];
  char card_name[250+6];
  char input_pin[1001];
  FILE* fp;
  int n;
  
  if(logged_in_atm(atm)==1){
    printf("%s\n", "A user is already logged in");
    return -1;
  }
  // Check if user exists in bank
  memset(req, '\0', sizeof(req));
  strncpy(req, "VF ", strlen("VF ")+1);
  strncat(req, name, strlen(name)+1);

  atm_send(atm, req, strlen(req));
  n = atm_recv(atm,recvline,10000);
  recvline[n]=0;
  //fputs(recvline,stdout);
  if(strcmp(recvline, "FAIL")==0){
    printf("%s\n", "No such user");
    return -1;
  } else if(strcmp(recvline, "SUCC")==0){
  
    // Read from <name>.card
    strncpy(card_name, name, strlen(name)+1);
    strncat(card_name, ".card", strlen(".card")+1);
    if( (fp=fopen(card_name, "r"))==NULL){
      printf("Unable to access %s's card\n", name);
      return -1;
    }
    
    // Prompt PIN
    memset(input_pin, '\0', sizeof(input_pin));
    printf("%s", "PIN? ");
    fflush(stdout);
    fgets(input_pin, 1000, stdin);
    input_pin[strcspn(input_pin,"\r\n")] = 0;

    if(validate_pin(input_pin)!=0){
      printf("%s\n", "Not authorized");
      return -1;
    }
    
    //Send pin verify request to bank
    memset(req, '\0', sizeof(req));
    strncpy(req, "PN ", strlen("PN ")+1);
    strncat(req, name, strlen(name)+1);
    strncat(req, " ", strlen(" ")+1);
    strncat(req, input_pin, strlen(input_pin)+1);
 
    memset(recvline, '\0', sizeof(recvline));
    atm_send(atm, req, strlen(req));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    
    if(strcmp(recvline, "FAIL")==0){
      printf("%s\n", "Not authorized");
      return -1;
      
    } else if(strcmp(recvline, "SUCC")==0) {
      printf("%s\n", "Authorized");
      atm->logged_in_bool = 1;
      atm->logged_in_name = strndup(name, strlen(name)+1);
      return 0;
    } else {
      return -1;
    }
  } else {
    printf("%s\n","ERROR in ATM (SUCC/FAIL)"); // delete later
    return -1;
  }
  
  /*
    char recvline[10000];
    int n;
    
    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    fputs(recvline,stdout);
  */
  
  return 0;
}

int withdraw(ATM *atm, char *amount)
{
  char recvline[10000];
  char req[300];
  int n;

  if(logged_in_atm(atm)==0){
    printf("%s\n", "No user logged in");
    return -1;
  }

  //construct withdraw request
  memset(req, '\0', sizeof(req));
  strncpy(req, "WD ", strlen("WD ")+1);
  strncat(req, atm->logged_in_name, strlen(atm->logged_in_name)+1);
  strncat(req, " ", strlen(" ")+1);
  strncat(req, amount, strlen(amount)+1);
  
  //send message to bank
  atm_send(atm, req, strlen(req));
  n = atm_recv(atm,recvline,10000);
  recvline[n]=0;
  
  if(strncmp(recvline, "FAIL", 5)==0){
    printf("%s\n", "Insufficient funds");
    return -1;
  } else if(strncmp(recvline, "SUCC", 5)==0){
    printf("$%s dispensed\n", amount);
    return 0;
  } else {
    return 0;
  }
  
  return 0;
}

int display_balance(ATM *atm)
{
  char recvline[10000];
  char req[300];
  int n;

  if(logged_in_atm(atm)==0){
    printf("%s\n", "No user logged in");
    return -1;
  }

   //construct withdraw request
  memset(req, '\0', sizeof(req));
  strncpy(req, "BA ", strlen("BA ")+1);
  strncat(req, atm->logged_in_name, strlen(atm->logged_in_name)+1);
    
  //send message to bank
  atm_send(atm, req, strlen(req));
  n = atm_recv(atm,recvline,10000);
  recvline[n]=0;
  
  printf("$%s\n", recvline);
  return 0;
}

int logged_in_atm(ATM *atm) 
{
  return atm->logged_in_bool;
}

int logged_in_name(ATM *atm, char *name)
{
  return 0;
}

int end_session(ATM *atm)
{
  return 0;
}
