/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#define MAX_LEN 50

static const char prompt[] = "ATM";

int main(int argc, char **argv)
{
    char user_input[1000];
    char filename[MAX_LEN+6];
    char key[129];
    FILE *fp;

    if(argc != 2) { // check there is the correct num of arguments
      printf("%s\n","Error opening ATM initilization file");
      return 64;
    }
    if(strlen(argv[1]) > MAX_LEN) {
      printf("%s\n", "Error opening ATM initilization file");
      return 64;
    }
    
    strncpy(filename, argv[1], strlen(argv[1])+1);
    
    // check if the .atm file exists
    if( access(filename, F_OK) != 0 ) {
      printf("%s\n", "Error opening ATM initilization file");
      return 64;
    } else if( (fp = fopen(filename, "r")) == NULL) {
      printf("%s\n", "Error opening ATM initilization file");
      return 64;
    }

     ATM *atm = atm_create();
    
    fclose(fp);
    
    printf("%s: ", prompt);
    fflush(stdout);

    while (fgets(user_input, 1000,stdin) != NULL)
    {
        atm_process_command(atm, user_input);
	if(atm->logged_in_bool == 1){
	  printf("%s (%s): ", prompt, atm->logged_in_name);
	}else {
	  printf("%s: ", prompt);
	}
        fflush(stdout);
    }
	return EXIT_SUCCESS;
}
