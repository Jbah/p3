#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "crypto/crypto_sample.h"
#define MAX_LEN 50 

int main(int argc, char *argv[]){
  unsigned char key[256];
  unsigned char str[256];
  char filename1[MAX_LEN+6];
  char filename2[MAX_LEN+6];
  FILE *fp1;
  FILE *fp2;
  
  if(argc != 2){ //need precisely one argument
    printf("%s\n", "Usage: init <filename>");
    return 62;
  }
  if(strlen(argv[1]) > MAX_LEN){
      printf("%s\n", "Error creating initialization files");
      return 64;
  }

  strncpy(filename1, argv[1], strlen(argv[1])+1);
  strncpy(filename2, argv[1], strlen(argv[1])+1);
  strncat(filename1, ".bank", strlen(".bank")+1);
  strncat(filename2, ".atm", strlen(".atm")+1);
  
  //either of the files exists
  if( (access(filename1, F_OK)==0) || (access(filename2, F_OK)==0) ){ 
    printf("%s\n", "Error: one of the files already exists");
    return 63;
  }

  if( (fp1 = fopen(filename1, "w+")) == NULL || (fp2 = fopen(filename2, "w+")) == NULL ){
    printf("%s\n", "Error creating initialization files");
    return 64;
  }

  memset(key, '\0', sizeof(key));
  memset(str, '\0', sizeof(str));
  
  // Write a symmetric key to "*.bank" file
  if(RAND_bytes(key, 128) != 1) {
    printf("%s\n","Error");
  }

  fwrite(key, sizeof(unsigned char), 129, fp1);
  fwrite(key, sizeof(unsigned char), 129, fp2);
  
  fclose(fp1);
  fclose(fp2);
  printf("%s\n", "Successfully initialized bank state");

  return 0;
}
