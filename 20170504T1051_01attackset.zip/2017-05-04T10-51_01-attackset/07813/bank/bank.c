#include "bank.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <wordexp.h>
#include <regex.h>
#include "crypto/crypto_sample.h"

#define MAX_INT 2147483647

Bank* bank_create()
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    bank->user_table = hash_table_create(100);
    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
	hash_table_free(bank->user_table);
        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
  // Returns the number of bytes received; negative on error
  return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

// TODO: Implement the bank's local commands
// Handles stdin input (bank commands like deposit)
void bank_process_local_command(Bank *bank, char *command, size_t len)
{
  wordexp_t result;
  char **args = NULL;
  int argc = 0;
  int pin;
  int balance;
  int amt;
  
  command[strcspn(command, "\r\n")] = 0;

  wordexp(command, &result, 0);
  args = result.we_wordv;
  argc = result.we_wordc;

  if(argc < 1) {
    //check this first to avoid cases with no command or many
      printf("%s\n","Invalid command");
      return;
  } 
  else if(strncmp(args[0],"create-user",12)==0) {
    if(argc != 4){
      printf("%s\n", "Usage: create-user <user-name> <pin> <balance>");
      return;
    } else if(validate_name(args[1]) != 0){
      printf("%s\n", "Usage: create-user <user-name> <pin> <balance>");
      return;
    } else if(validate_pin(args[2]) != 0) {
      printf("%s\n", "Usage: create-user <user-name> <pin> <balance>");
      return;
    } else if(validate_amt(args[3]) != 0) {
      printf("%s\n", "Usage: create-user <user-name> <pin> <balance>");
      return;
    } else {
      //turn pin and balance into integers
      pin = atoi(args[2]);
      balance = atoi(args[3]);
      if(create_user(bank, args[1], pin, balance)!=0){
	printf("%s%s%s\n", "Error: user <", args[1], "> already exists"); 
	return;
      }
    }
  }
  else if(strncmp(args[0],"deposit",8)==0) {
    if(argc != 3) {
      printf("%s\n", "Usage: deposit <user-name> <amt>");
      return;
    } else if(validate_name(args[1]) != 0) {
      printf("%s\n", "Usage: deposit <user-name> <amt>");
      return;
    } else if(validate_amt(args[2]) != 0) {
      printf("%s\n", "Usage: deposit <user-name> <amt>");
      return;
    } else {
      // make_deposit()
      amt = atoi(args[2]);
      make_deposit(bank, args[1], amt);
    }
  }
  else if(strncmp(args[0],"balance",8)==0) {
    if(argc != 2) {
      printf("%s\n", "Usage: balance <user-name>");
      return;
    } else if(validate_name(args[1]) != 0) {
      printf("%s\n", "Usage: balance <user-name>");
      return;
    } else {
      // display_balance()
      display_balance(bank, args[1]);
    }
  }
  else {
    printf("%s\n","Invalid command");
    return;
  }
  
  wordfree(&result);
}

int validate_name(char *name){
  regex_t exp;
  int status;

  //create regular expression to match 
  status = regcomp(&exp, "^[a-zA-Z]{1,250}$", REG_EXTENDED);
  if(status != 0){
    return -1;
  }

  status = regexec(&exp, name, (size_t) 0, NULL, 0);
  regfree(&exp);
  if(status != 0){
    return -1;
  }

  return 0;
}

int validate_pin(char *pin_str){
  regex_t exp;
  int status;

  //create regular expression to match 
  status = regcomp(&exp, "^[0-9]{4}$", REG_EXTENDED);
  if(status != 0){
    return -1;
  }

  status = regexec(&exp, pin_str, (size_t) 0, NULL, 0);
  regfree(&exp);
  if(status != 0){
    return -1;
  }

  return 0;
}

int validate_amt(char *amt_str){
  regex_t exp;
  char *ptr;
  int status;
  unsigned long amt;

  //create regular expression to match 
  status = regcomp(&exp, "^[0-9]{1,10}$", REG_EXTENDED);
  if(status != 0){
    return -1;
  }

  status = regexec(&exp, amt_str, (size_t) 0, NULL, 0);
  regfree(&exp);
  if(status != 0){
    return -1;
  }

  amt = strtoul(amt_str,&ptr,10);
  if(amt > MAX_INT) {
    return -2;
  }

  return 0;
}

int create_user(Bank *bank, char *name, int pin, int balance){
  user_info *info;
  char filename[250+6];
  FILE *fp;
  
  if(hash_table_find(bank->user_table, name)!=NULL){
    return -1; //username already exists
  }
  
  info = (user_info*) malloc(sizeof(user_info));
  info->pin = pin;
  info->balance = balance;

  hash_table_add(bank->user_table, name, info);

  //create <name>.card file in current directory
  strncpy(filename, name, strlen(name)+1);
  strncat(filename, ".card", strlen(".card")+1);
  fp = fopen(filename, "w+");
  if(fp == NULL){
    printf("%s%s\n", "Error creating card file for user ", name);
  } else {
    printf("%s%s\n", "Created user ", name);
  }
  fclose(fp);
   
  return 0;
}

int make_deposit(Bank *bank, char *name, int amt){
  user_info *info;
  unsigned long new_bal;
 
  if(hash_table_find(bank->user_table, name)==NULL){
    printf("%s\n", "No such user");
    return -1; //user doesn't exist
  }

  info = hash_table_find(bank->user_table, name);
  new_bal = info->balance + amt;
  if(new_bal > MAX_INT){
    printf("%s\n", "Too rich for this program");
    return -1;
  } else {
    info->balance += amt;
    printf("$%d added to %s's account\n", amt, name);
    return 0;
  }
  
  return 0;
}

int display_balance(Bank *bank, char *name){
  user_info *info;
  
  if(hash_table_find(bank->user_table, name)==NULL){
    printf("%s\n", "No such user");
    return -1; //user doesn't exist
  }

  info = hash_table_find(bank->user_table, name);
  printf("$%d\n", info->balance);
  return 0;
}
  
// TODO: Implement the bank side of the ATM-bank protocol
void bank_process_remote_command(Bank *bank, char *command, size_t len)
{
  wordexp_t result;
  char **args;
  int argc;
  char fail[5] = "FAIL";
  char succ[5] = "SUCC";
  user_info *info;
  int pin, input_pin;
  char balance[10];

  command[len]=0;
 
  wordexp(command, &result, 0);
  args = result.we_wordv;
  argc = result.we_wordc;

  if(argc < 1) {
    printf("%s\n","Invalid ATM message");
    bank_send(bank, fail, strlen(fail)+1);
    return;

  } else if( (strncmp(args[0],"VF",3)==0) && (argc == 2) ) {
    // verify user
    if(hash_table_find(bank->user_table,args[1])==NULL) {
      bank_send(bank, fail, strlen(fail)+1);
      return;
    } else {
      bank_send(bank, succ, strlen(succ)+1);
      return;
    }

  } else if( (strncmp(args[0],"PN",3)==0) && (argc == 3) ) {
    // verify pin
    info = hash_table_find(bank->user_table,args[1]);
    pin = info->pin;
    input_pin = atoi(args[2]);
    if(pin != input_pin) {
      bank_send(bank, fail, strlen(fail)+1);
      return;
    } else {
      bank_send(bank, succ, strlen(succ)+1);
      return;
    }

  } else if( (strncmp(args[0],"WD",3)==0) && (argc == 3) ) {
    // withdraw funds
    if(withdraw(bank, args[1], atoi(args[2])) == -1) {
      bank_send(bank, fail, strlen(fail)+1);
      return;
    } else {
      bank_send(bank, succ, strlen(succ)+1);
      return;
    }
  } else if( (strncmp(args[0],"BA",3)==0) && (argc == 2) ) {
    // balance request
    if(hash_table_find(bank->user_table,args[1]) == NULL) {
      bank_send(bank, fail, strlen(fail)+1);
      return;
    } else {
      info = hash_table_find(bank->user_table,args[1]);
      sprintf(balance, "%d", info->balance);
      balance[strlen(balance)+1] = 0;
      bank_send(bank, balance, strlen(balance)+1);
      return;
    }
  } else {
    printf("%s\n","Invalid ATM message");
    bank_send(bank, fail, strlen(fail)+1);
    return;
  }


  wordfree(&result);
}

int withdraw(Bank *bank, char *name, int amt) {
  user_info *info;
  int balance;

  if( (info = hash_table_find(bank->user_table, name)) == NULL) {
    return -1;
  }
  balance = info->balance;
  
  if(amt > balance) {
    return -1;
  } else {
    info->balance = balance - amt;
    return 0;
  }
}




        /*
	 * The following is a toy example that simply receives a
	 * string from the ATM, prepends "Bank got: " and echoes 
	 * it back to the ATM before printing it to stdout.
	 */

	/*
    char sendline[1000];
    command[len]=0;
    sprintf(sendline, "Bank got: %s", command);
    bank_send(bank, sendline, strlen(sendline));
    printf("Received the following:\n");
    fputs(command, stdout);
	*/
