 /**********************
 * David Kanney 	*
 * 113039065 (dkanney)	*
 *			*
  **********************/
#include "bank.h"
#include "ports.h"
#include "util/hash_table.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "sys/stat.h"

#define COMMAND_MAX_LEN 279
#define USERNAME_MAX_LEN 250
#define INT_MAX_LEN sizeof("2147483648")-1
#define INT_MAX 2147483648

Bank* bank_create()
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }
    // Set up user table
    bank->ht = hash_table_create(10);

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as needed

    return bank;
}

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
        free(bank);
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

void bank_process_local_command(Bank *bank, char *command, size_t len)
{
    FILE *f;
    char buf[COMMAND_MAX_LEN], *p[5];
    int i = 0;
    void *b;
	static char *res;

    // p[0] = malloc(12);			// command
    // p[1] = malloc(USERNAME_MAX_LEN + 5); 	// Username
    // p[2] = malloc(1);			// PIN
    // p[3] = malloc(INT_MAX_LEN);		// Balance
    p[4] = NULL;

  if (len > COMMAND_MAX_LEN)
    printf("Invalid command\n\n");

  else {
    strcpy(buf, command);

    switch(command[0])
    {
      case 'c': 				/*** create-user <user-name> <pin> <balance> ***/
      {
	char *cardfile;
            
	// Parsing arguments
        for (p[i] = strtok(buf, " "); p[i] != NULL; p[i] = strtok(NULL, " "))
             i += 1;
        
	if (strcmp(p[0], "create-user") && strcmp(p[0], "create-user\n")) {
	    printf("Invalid command\n\n");
	    break;
	}


        if (!p[1] || !p[2] || !p[3] || strlen(p[1]) > USERNAME_MAX_LEN || 
	    strlen(p[2]) > 4 || /* !atoi(p[2]) || !atoi(p[3]) ||*/ len > COMMAND_MAX_LEN) // Print Usage message
             printf("Usage: create-user <user-name> <pin> <balance>\n\n");

	else if (hash_table_find(bank->ht, p[1]) == NULL) {			// Creating user's bank card
 	     p[3][strlen(p[3]) - 1] = 0;	// Removing newline
	     (atoi(p[3]) > INT_MAX) ? (printf("Usage: create-user <user-name> <pin> <balance>\n\n")) : 
				      (b = malloc(strlen(p[3]) + 1));
	     strcpy(b, p[3]);	     
	     hash_table_add(bank->ht, p[1], b);

	     cardfile = malloc(strlen(p[1]) + strlen(".card"));
	     strcpy(cardfile, p[1]);
     	     strcat(cardfile, ".card");
	
	     f = fopen(cardfile, "a");
	     if (f) {
		 fprintf(f, "%s\n%s", p[2], p[3]);
		 chmod(cardfile, 777);
		 printf("Created user %s\n\n", p[1]);
		 fclose(f);
	     } else 
	         printf("Error creating card file for user %s\n\n", p[1]);
	     
	} else
	     printf("Error: user %s already exists\n\n", p[1]);

        break;
      }
      case 'd':				/*** deposit <user-name> <amt> ***/
	p[3] = NULL;

	// Parsing arguments
        for (p[i] = strtok(buf, " "); p[i] != NULL; p[i] = strtok(NULL, " "))
             i += 1;

        if (strcmp(p[0], "deposit") && strcmp(p[0], "deposit\n")) {
	    printf("Invalid command\n\n");
	    break;
	}

	if (!p[1] || !p[2] || !strcmp(p[1], "\n") || !strcmp(p[2], "\n") || strlen(p[1]) > USERNAME_MAX_LEN) { // Print Usage message
            printf("Usage: deposit <user-name> <amt>\n\n");
	    break;	
	}

	if (!hash_table_find(bank->ht, p[1]))
	     printf("No such user\n\n");
	else {
 	     p[2][strlen(p[2]) - 1] = 0;	// Removing newline 

	     (atoi(p[2]) > INT_MAX) ? (printf("Too rich for this program\n\n")) : (b = malloc(strlen(p[2]) + 1));
	     sprintf( b, "%d", (atoi(hash_table_find(bank->ht, p[1])) + atoi(p[2])) );
		  
	     hash_table_del(bank->ht, p[1]);
	     hash_table_add(bank->ht, p[1], b);
	     printf("$%s added to %s's account\n\n", p[2], p[1]); 
        }    
      break;



      case 'b':				/*** balance <user-name> ***/
	p[2] = NULL;
        for (p[i] = strtok(buf, " "); p[i] != NULL; p[i] = strtok(NULL, " "))
            i += 1;

        if (strcmp(p[0], "balance") && strcmp(p[0], "balance\n")) {
	    printf("Invalid command\n\n");
	    break;
	}
	
	if (!p[1] || !strcmp(p[1], "\n") || strlen(p[1]) > USERNAME_MAX_LEN) { // Print Usage message
            printf("Usage: balance <user-name>\n\n");
	    break;	
	}

	p[1][strlen(p[1]) - 1] = 0;
	if (!hash_table_find(bank->ht, p[1]))
	    printf("No such user\n\n");
	else {
	    bank->result = malloc(sizeof(bank->result));
	    bank->result = (char *) hash_table_find(bank->ht, p[1]);
	    // printf("$%s\n\n", (char *) hash_table_find(bank->ht, p[1])); 
	    printf("$%s\n\n", bank->result); 
	}     	     
      break;

      default:
        printf("Invalid command\n\n");
    }
  }
}

void bank_process_remote_command(Bank *bank, char *command, size_t len)
{
    // TODO: Implement the bank side of the ATM-bank protocol

	/*
	 * The following is a toy example that simply receives a
	 * string from the ATM, prepends "Bank got: " and echoes 
	 * it back to the ATM before printing it to stdout.
	 */

    char sendline[10000];
    char *res;
    command[len]=0;
    bank_process_local_command(bank, sendline, len);

    // sprintf(sendline, "Bank got: %s", comamnd);
    sprintf(sendline, "%s", bank->result);
	    						//    bank_process_local_command(bank, sendline, len)
    bank_send(bank, sendline, (strlen(sendline))); 	// OG: bank_send(bank, sendline, strlen(sendline));
    printf("Received the following:\n");
    fputs(command, stdout);
}

