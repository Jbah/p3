/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char prompt[] = "ATM";
static const char end[] = ": ";

int main(int argc, char *argv[])
{
    char user_input[1000], pin[5], balance[5];
    FILE *f;

    ATM *atm = atm_create();

    f = fopen(argv[1], "r");
    
    if (!f) 
    {
        printf("Error opening ATM initialization file\n\n");
        return 64;
    } else 
    {
    // fgets(pin, 5, f);
    // getchar();
    // fgets(balance, 5, f);

    /*
    printf("PIN: %s, BAL: %s\n", pin, balance);
    get_args(pin, balance);
    */

    printf("%s%s", prompt, end);
    fflush(stdout);

    while (fgets(user_input, 10000,stdin) != NULL)
	//    while (fscanf(user_input, 10000,stdin) != NULL)
    {
	// strtok(user_input, "\n");
        atm_process_command(atm, user_input);
        switch (atm->in_use->x) {
	    case 1:
		printf("%s (%s): ", prompt, atm->in_use->name);
	    break;
	    default:
	        printf("%s%s", prompt, end);
        }
        fflush(stdout);
	// fflush(stdin);
    }
    }
	return EXIT_SUCCESS;
}
