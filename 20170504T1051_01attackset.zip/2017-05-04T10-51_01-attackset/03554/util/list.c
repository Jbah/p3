#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "list.h"

List* list_create()
{
    List *list = (List*) malloc(sizeof(List));
    list->head = list->tail = NULL;
    list->size = 0;
    return list;
}

void list_free(List *list)
{
    if(list != NULL)
    {
        ListElem *curr = list->head;
        ListElem *next;
        while(curr != NULL)
        {
            next = curr->next;
            free(curr);
            curr = next;
        }
        free(list);
    }
}

void* list_find(enum type t, List *list, const char *user)
{
    if(list == NULL) {
        return NULL;
	 }

    ListElem *curr = list->head;
	 //printf("finding val for: %s\n", user);
    while(curr != NULL)
    { 
        if(strcmp(curr->user, user) == 0) {
			   switch (t) {
					case TYPE_PIN:
						//printf("curr: %s pin: %s\n", curr->key, (char *) curr->val);
            		return (char *) curr->pin;
					case TYPE_BAL:
						//printf("curr: %s",curr->key);
						//printf("bal: %d\n", (int) curr->val);
						return (int *) curr->bal;
				}
			  //return curr->bal;
		  }
        curr = curr->next;
    }
    return NULL;
}

void list_add(enum type t, List *list, char *user, char *pin, int *bal)
{
    // Allow duplicates
    // assert(list_find(list, key) == NULL);

    ListElem *elem = (ListElem*) malloc(sizeof(ListElem));
    
	 elem->user = malloc(strlen(user) + 1); //key;
	 strncpy(elem->user, user, strlen(user) + 1);
	 
	 elem->pin = malloc(strlen(pin) + 1);
	 strncpy(elem->pin, pin, strlen(pin) + 1);

	 elem->bal = malloc(sizeof(int));
	 memcpy(elem->bal, bal, sizeof(int));

	 elem->next = NULL;

    if(list->tail == NULL) {
        list->head = list->tail = elem;
	 } else {
        list->tail->next = elem;
		  list->tail = elem;
	 }
    list->size++;
}

void list_del(List *list, const char *user)
{
    // Remove the element with key 'key'
    ListElem *curr, *prev;

    curr = list->head;
    prev = NULL;
    while(curr != NULL)
    {
        if(strcmp(curr->user, user) == 0)
        {
            // Found it: now delete it

            if(curr == list->tail)
                list->tail = prev;

            if(prev == NULL)
                list->head = list->head->next;
            else
                prev->next = curr->next;

            list->size--;

            free(curr);
            return;
        }

        prev = curr;
        curr = curr->next;
    }
}

void* list_set(List *list, char *user, int *new_bal) {
	 ListElem *curr;

	 if (list == NULL) {
		 return NULL;
	 }

	 curr = list->head;
	 while (curr != NULL) {
		 if (strcmp(curr->user, user) == 0) {
			 memcpy(curr->bal, new_bal, sizeof(int));
			 return new_bal;
		 }
		 curr = curr->next;
	 }

	 return NULL;
}

int list_verify_elem(List *list, const char *user, const char *pin)
{
    if(list == NULL) {
        return -1;
	 }

    ListElem *curr = list->head;
	 //printf("finding val for: %s\n", user);
    while(curr != NULL)
    { 
        if(strcmp(curr->user, user) == 0 &&
			  strcmp(curr->pin, pin) == 0) {
			  return 1;
			  //return curr->bal;
		  }
        curr = curr->next;
    }
    return -1;
}

int list_withdraw(List *list, char *user, char *amt)
{
    if(list == NULL) {
        return -1;
	 }
	 //printf("okay wtf\n");
    ListElem *curr = list->head;
	 //printf("finding val for: %s\n", user);
    while(curr != NULL)
    {
		//printf("enter this?\n");
	  //char amtcpy[11];
	  //memset(amtcpy, 0x00, 11);
  	 //memcpy(amtcpy, amt, strlen(amt));
	 //printf("list amt(copy): %s\n", amtcpy);
	//printf("%s == %s?\n", curr->user, user);	 
        if(strcmp(curr->user, user) == 0) {
			  //printf("list amt(string): %s\n", amt);
			  int amount = atoi(amt);
			  //printf("list amt: %d\n", amount);
			  int old_balance = *((int *) curr->bal);
			  int new_balance = old_balance - amount;
			  if (new_balance < 0) {
				  return -2;
			  }
			  list_set(list, user, &new_balance);
			  //memset(amt, 0x00, strlen(amt));
			  return 1;
			  //return curr->bal;
		  }
        curr = curr->next;
    }
	 //memset(amt, 0x00, strlen(amt));
    return -1;
}

uint32_t list_size(const List *list)
{
    return list->size;
}
