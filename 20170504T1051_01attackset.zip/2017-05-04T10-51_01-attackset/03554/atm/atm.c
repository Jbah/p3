#include "atm.h"
#include "ports.h"
#include "crypto.h"
#include <limits.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

ATM* atm_create()
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    // Set up the protocol state
    // TODO set up more, as needed
	 atm->active_session = 0;
    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

void atm_process_command(ATM *atm, char *command)
{
    // TODO: Implement the ATM's side of the ATM-bank protocol

	/*
	 * The following is a toy example that simply sends the
	 * user's command to the bank, receives a message from the
	 * bank, and then prints it to stdout.
	 */

	/*
    char recvline[10000];
    int n;

    atm_send(atm, command, strlen(command));
    n = atm_recv(atm,recvline,10000);
    recvline[n]=0;
    fputs(recvline,stdout);
	*/
	 char tmp1[1000], tmp2[1000];
	 memset(tmp1, 0x00, 1000);
	 memset(tmp2, 0x00, 1000);
	 
	 char cmd[14];
	 memset(cmd, 0x00, 14);
	 
	 char arg2[251];
	 memset(arg2, 0x00, 251);

	 sscanf(command, "%s%s", tmp1, tmp2);

	 if (tmp1 == NULL || strlen(tmp1) == 0 || strlen(tmp1) > 13) {
		 printf("Invalid command\n");
		 return;
	 }

	 strncpy(cmd, tmp1, strlen(tmp1));
	 if (strcmp("begin-session", cmd) == 0) {
		 //printf("beginning session...\n");	
		 if (atm->active_session == 1) {
			 printf("A user is already logged in\n");
			 return;
		 }

		 if (strlen(tmp2) < 1 || strlen(tmp2) > 250) {
			printf("Usage: begin-session <user-name>\n");
			return;
		}

		strncpy(arg2, tmp2, strlen(tmp2));
	
		if (valid_username(arg2) == -1) {
			printf("Usage: begin-session <user-name>\n");
			return;
		}
		//printf("%d\n", user_has_account(atm, arg2));;
		if (user_has_account(atm, arg2) != 0) {
			printf("No such user\n");
			return;
		}
		
		char pin[5], tmp[1000];
		memset(pin, 0x00, 5);
		memset(tmp, 0x00, 1000);
		sleep(atm->sleep_time);
		printf("PIN? ");
		fgets(tmp, 1000, stdin);
		//printf("%d\n", strlen(tmp));
		if (strlen(tmp) != 5) {
			printf("Not authorized\n");
			return;
		}
		
		strncpy(pin, tmp, 4);
		//printf("entered: %s\n", pin);
		if (valid_pin(pin) == -1) {
			printf("Not authorized\n");
			return;
		}

		if (correct_pin(atm, arg2, pin) != 0) {
			atm->failed_attempts++;
			atm->sleep_time = atm->sleep_time << 1;
			printf("Not authorized\n");
		   if (atm->failed_attempts > 5) {
				printf("Too many failed attempts. Exiting.\n");
				exit(0);
			}
			return;
		}
		printf("Authorized\n");
		atm->active_session = 1;
		atm->failed_attempts = 0;
		atm->sleep_time = 2;
		strncpy(atm->user, arg2, strlen(arg2));
		return;
	 } else if (strcmp("withdraw", cmd) == 0) {
		if (atm->active_session == 0) {
			printf("No user logged in\n");
			return;
		}

		if (valid_amount(tmp2)  == -1) {
			printf("Usage: withdraw <amt>\n");
			return;
		}
		
		strncpy(arg2, tmp2, strlen(tmp2));
		int w = withdraw(atm, atm->user, arg2);
		//printf("withdraw: %d\n", w);
		if (w == -2) {
			printf("Insufficient funds\n");
			return;
		} else if (w == -1) {
			printf("Unknown error\n");
			return;
		}
		printf("$%d dispensed\n", atoi(arg2));
		return;


	 } else if (strcmp("balance", cmd) == 0) {
		if (atm->active_session == 0) {
			printf("No user logged in\n");
			return;
		}
		//printf("%d\n", strlen(command));
		if (strlen(command) > 8) {
			printf("Usage: balance\n");
			return;
		}
		printf("$%d\n", balance(atm));
		return;

	 } else if (strcmp("end-session", cmd) == 0) {
		 if (atm->active_session == 0) {
			 printf("No user logged in \n");
			 return;
		 }
		 //printf("%s: %d\n", command, strlen(command));
		 if (strlen(command) > 12) {
			printf("Usage: end-session\n");
			return;
		 }

		 atm->active_session = 0;
		 memset(atm->user, 0x00, 251);
		 printf("User logged out\n");
		 return;
		 
	 } else {
		 printf("Invalid command\n");
		 return;
	 }
}

int valid_username(char *username) {
	int i;
	for (i = 0; i < strlen(username); i++) {
		if (username[i] < 65 || username[i] > 122) {
			return -1;
		} else if (username[i] > 90 && username[i] < 97) {
			return -1;
		}
	}
	return 1;
}

int valid_pin(char *pin) {
	 int i;
	 for (i = 0; i < strlen(pin); i++) {
		 if (pin[i] < 48 || pin[i] > 57) {
			 return -1;
		 }
	 }

	 int tmp = atoi(pin);
	 //printf("pin: %d\n", tmp);
	 if (tmp < 0 || tmp > 9999) {
		 return -1;
	 }

	 return 1;
}

int correct_pin(ATM *atm, char *username, char *pin) {
	 char snd[257];
	 memset(snd, 0x00, 257);

	 char rcv[2];
	 memset(rcv, 0x00, 2);

	 int n;
	 strncpy(snd, "1 ", 2);
	 strncat(snd, username, strlen(username));
	 strncat(snd, " ", 1);
	 strncat(snd, pin, strlen(pin));

	 //atm_send(atm, snd, strlen(snd));
	 encrypted_send(atm, snd, strlen(snd));
	 n = recv_decrypt(atm, rcv); //atm_recv(atm, rcv, 2);

	 int ret = atoi(rcv);
	 return ret;

}

int valid_amount(char *amt) {
	int i;
	for (i = 0; i < strlen(amt); i++) {
		if (amt[i] < 48 || amt[i] > 57) {
			return -1;
		}
	}

	int tmp = atoi(amt);
	if (tmp < 0 || tmp > INT_MAX) {
		return -1;
	}

	if (tmp == INT_MAX && strcmp("2147483647", amt) != 0) {
		return -1;
	}

	if (tmp == 0 && strcmp("0", amt) != 0) {
		return -1;
	}
	return 1;
}

int withdraw(ATM *atm, char *username, char *amt) {
	 char snd[262];
	 memset(snd, 0x00, 262);
	 char rcv[2];
	 memset(rcv, 0x00, 2);

	 int n;
	 strncpy(snd, "2 ", 2);
	 strncat(snd, username, strlen(username));
	 strncat(snd, " ", 1);
	 strncat(snd, amt, strlen(amt));

	 encrypted_send(atm, snd, strlen(snd));
	 //atm_send(atm, snd, strlen(snd));

	 //n = atm_recv(atm, rcv, 1);
	 n = recv_decrypt(atm, rcv);
	 int ret = atoi(rcv);
	 return ret;
}

int balance(ATM *atm) {
	unsigned char snd[253];
	memset(snd, 0x00, 253);
	char rcv[11];
	memset(rcv, 0x00, 11);

	int n;
	strncpy(snd, "3 ", 2);
	strncat(snd, atm->user, strlen(atm->user));

	encrypted_send(atm, snd, strlen(snd));

	//n = atm_recv(atm, rcv, 11);
	n = recv_decrypt(atm, rcv);
	int ret = atoi(rcv);
	return ret;
}

int user_has_account(ATM *atm, char *username) {
	unsigned char snd[253]; //(len(username) + 1 for msg type +1 for space + 1 for null byte
	memset(snd, 0x00, 253);
	unsigned char rcv[128];
	memset(rcv, 0x00, 128);
	int n;
	strncpy(snd, "0 ", 2);
   strncat(snd, username, strlen(username));
	
	//printf("%d\n", authenticate(atm));
	// send user_in_bank request
	encrypted_send(atm, snd, strlen(snd));
	//atm_send(atm, snd, strlen(snd));
	
	// receive user_in_bank request
	//n = atm_recv(atm, rcv, 2);
	//atm_decrypt(atm, rcv, strlen(rcv));
	recv_decrypt(atm, rcv);
	int ret = atoi(rcv);
	return ret;

	/*int buf_size = strlen(username) + 6; // len(".card\0")
	char fname[buf_size];
	memset(fname, 0x00, buf_size);
	strncpy(fname, username, strlen(username));
	strncat(fname, ".card", 5);
	if (access(fname, F_OK) == -1) {
		return -1;
	} else {
		return 0;
	}
	*/
}


void plaintext_send(ATM *atm, unsigned char *plaintext, int plaintext_len) {
	
	/*unsigned char data[plaintext_len + 2];
	memset(data, 0x00, plaintext_len + 2);
	strncpy(data, "p ", strlen("p "));
	strncat(data, plaintext, plaintext_len);
	printf("%s\n", data);
	atm_send(atm, data, strlen(data));*/
	atm_send(atm, plaintext, plaintext_len);

}


void encrypted_send(ATM *atm, unsigned char *plaintext, int plaintext_len) {
	
	int data_len = 0;

	unsigned char ciphertext[plaintext_len];
	memset(ciphertext, 0x00, plaintext_len);
	unsigned char *key = malloc(2100);
   memset(key, 0x00, 2100);
	unsigned char *tag = malloc(50);
	memset(tag, 0x00, 50);

	strncpy(key, getkey(atm->init_file), 2100);

	//printf("\n%s\n",key);
	int cipher_len = encrypt(plaintext, strlen(plaintext) + 1, key, ciphertext);
	int length = snprintf(NULL, 0, "%d", cipher_len);
	char *scipher_len = malloc(length + 1);
	snprintf(scipher_len, length + 1, "%d", cipher_len);
	//printf("%s\n", len);

	data_len += length + 1;
	data_len += cipher_len + 1;	

	char buf[cipher_len + 1];
	memset(buf, 0x00, cipher_len + 1);
	strncpy(buf, ciphertext, cipher_len);
	//printf("%s %d\n", buf, cipher_len);
	//int tag_len = sign(key, ciphertext, cipher_len + 1, tag);	
	int tag_len = sign(key, ciphertext, cipher_len + 1, tag);
	length = snprintf(NULL, 0, "%d", tag_len);
	char *stag_len = malloc(length + 1);
	snprintf(stag_len, length + 1, "%d", tag_len);
	
	data_len += length + 1;
	data_len += tag_len + 1;

	unsigned char data[data_len];
	memset(data, 0x00, data_len);

	//unsigned char data[cipher_len + tag_len + 5];
	//memset(data, 0x00, cipher_len + tag_len + 5);
	//strncpy(data, "e ", strlen("e "));
	
	strncpy(data, scipher_len, strlen(scipher_len));
	strncat(data, " ", 1);
	strncat(data, ciphertext, cipher_len);
	strncat(data, " ", 1);
	strncat(data, stag_len, strlen(stag_len));
	strncat(data, " ", 1);
	strncat(data, tag, tag_len);

	//printf("%s\n", tag);
	atm_send(atm, data, data_len);
	//atm_send(atm, data, cipher_len + tag_len + 5);
	//atm_send(atm, ciphertext, cipher_len);
	free(key);
	free(scipher_len);
	free(stag_len);
	scipher_len = NULL;
	stag_len = NULL;
	key = NULL;
}

int recv_decrypt(ATM *atm, unsigned char *plaintext) {

	unsigned char rcv[128] = {0};
	atm_recv(atm, rcv, 128);
	//unsigned char plain[strlen(rcv)];
	//memset(plain, 0x00, strlen(rcv));

	unsigned char *key = malloc(2100);
	memset(key, 0x00, 2100);
	strncpy(key, getkey(atm->init_file), 2100);
	int plain_len = decrypt(rcv, strlen(rcv), key, plaintext);
	int ret = atoi(plaintext);
	return ret;
	
}

int authenticate(ATM *atm) {
	
	int r = rand();
	char *s = malloc(128);
	char rand_string[100] = {0};
	sprintf(rand_string, "%d", r);
	strncpy(s, "4  ", 3);
	strncat(s, rand_string, strlen(rand_string));
	plaintext_send(atm, s, strlen(s));

	unsigned char plain[128] = {0};
   recv_decrypt(atm, plain);

	//printf("%s == %s\n", rand_string, plain);
	if (strcmp(rand_string, plain) != 0) {
		return -1;
	}
	return 0;

}
