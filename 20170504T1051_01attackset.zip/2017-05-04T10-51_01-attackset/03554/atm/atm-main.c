/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

static const char prompt[] = "ATM: ";

int main(int argc, char **argv)
{
    char user_input[1000];
    ATM *atm = atm_create();
    if (argv[1] == NULL) {
		 printf("Error opening ATM initialization file\n");
		 return 64;
	 }

	 if (access(argv[1], F_OK) == -1) {
		 printf("Error opening ATM initialization file\n");
		 return 64;
	 }

	 srand(time(NULL));
	 atm->init_file = fopen(argv[1], "r");
	 atm->active_session = 0;
	 atm->failed_attempts = 0;
	 atm->sleep_time = 1;
	 authenticate(atm); 
	 authenticate(atm);
	 authenticate(atm);
	 if (authenticate(atm) != 0) {
		 printf("Error verifying bank\n");
		 exit(0);
	 }

	 char tmp[5] = {0};
	 strncpy(tmp, "test", 5);
	 user_has_account(atm, tmp);
	 printf("%s", prompt);
    fflush(stdout);

    while (fgets(user_input, 10000,stdin) != NULL)
    {
        atm_process_command(atm, user_input);
        if (atm->active_session == 1) {
			  printf("ATM (%s): ", atm->user);
		  } else {
		  	  printf("%s", prompt);
		  }
        fflush(stdout);
    }
	return EXIT_SUCCESS;
}
