#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main() {

	char *p = "hello";
	char t[256];
	strncpy(t, p, 256);
	strncat(t, ".txt", 4);

	printf("%d\n", access(t, F_OK));
	printf("%s",t);
	/*char *p = "create-user Jim";
	char buf[100];
	strlcpy(buf, p, sizeof buf);
	char *tmp;

	tmp = strtok(buf, " ");
	while (tmp != NULL) {
		printf("%s\n", tmp);
		tmp = strtok(NULL, " ");
	}

	char arg1[100];
	char arg2[100];
	char arg3[100];
	char arg4[100];
	//sscanf(p, "%s%s%s%s", arg1, arg2, arg3, arg4);
	//strcpy(arg1, strtok_r(p, " ", &tmp));
	if (strcmp("create-user", arg1) == 0) {

		printf("%s\n",arg1);
	}*/
	/*strcpy(arg2, strtok(NULL, " "));
	strcpy(arg3, strtok(NULL, " "));
	strcpy(arg4, strtok(NULL, " "));

	printf("%s",arg1); //, %s, %s, %s", arg1, arg2, arg3, arg4);
*/
	return 0;
}
