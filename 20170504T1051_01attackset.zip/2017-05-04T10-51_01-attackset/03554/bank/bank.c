#include "bank.h"
#include "crypto.h"
#include "ports.h"
#include <limits.h>
#include <openssl/sha.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

Bank* bank_create()
{
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL)
    {
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    // Set up the protocol state
    // TODO set up more, as needed

	 bank->users = list_create();
	 //bank->pin_to_usr = list_create();
	 //bank->pin_to_balance = list_create();
    return bank;
}

//void bank_remove_cards

void bank_free(Bank *bank)
{
    if(bank != NULL)
    {
        close(bank->sockfd);
        fclose(bank->init_file);
		  list_free(bank->users);
		  //list_free(bank->pin_to_usr);
		  //list_free(bank->pin_to_balance);
		  free(bank);

		  //bank_remove_cards();
    }
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                  (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

void bank_process_local_command(Bank *bank, char *command, size_t len)
{
	 char tmp1[1000], tmp2[1000], tmp3[1000], tmp4[1000];
	 memset(tmp1, 0x00, 1000);
	 memset(tmp2, 0x00, 1000);
	 memset(tmp3, 0x00, 1000);
	 memset(tmp4, 0x00, 1000);	 
	 
	 char cmd[12];
	 memset(cmd, 0x00, 12);
	 
	 char username[251];
	 memset(username, 0x00, 251);
	 
	 char arg3[11]; // up to len(2147483648) (or pin) + null
	 memset(arg3, 0x00, 11);
 
	 char balance[11]; // up to len(2147483648) + null
	 memset(balance, 0x00, 11);

	 /*
	 strcpy(cmd, strtok(command, " "));
	 strcpy(username, strtok(NULL, " "));
	 strcpy(arg3, strtok(NULL), " "));
	 strcpy(balance, strtok(NULL, " "));
	 */

	 sscanf(command, "%s%s%s%s", tmp1, tmp2, tmp3, tmp4);
	 //printf("%s %s %s %s\n", tmp1, tmp2, tmp3, tmp4);
	 if (tmp1 == NULL || strlen(tmp1) == 0 || strlen(tmp1) > 11) {
		 printf("Invalid command\n");
		 return;
	 }

	 strncpy(cmd, tmp1, strlen(tmp1));
	 //printf("Command: %s\n",cmd);
	 if (strcmp("create-user", cmd) == 0) {
		 if (strlen(tmp2) < 1 || strlen(tmp2) > 250 ||
			  strlen(tmp3) != 4 ||
			  strlen(tmp4) < 1 || strlen(tmp4) > 10) {
			 printf("Usage: create-user <user-name> <pin> <balance>\n");
			 return;
		 }

		 strncpy(username, tmp2, strlen(tmp2));
		 strncpy(arg3, tmp3, strlen(tmp3));
		 strncpy(balance, tmp4, strlen(tmp4));

		 //printf("%d %d %d\n", valid_username(username), valid_pin(arg3),
		 //		 valid_balance(balance));
		 if (valid_username(username) == -1 ||
			  valid_pin(arg3) == -1 ||
			  valid_balance(balance) == -1) {
			 printf("Usage: create-user <user-name> <pin> <balance>\n");
			 return;
		 }

		 if (user_in_bank(bank, username) == 0) {
			 printf("Error: user %s already exists\n", username);
			 return;
		 }

		 // Make new user
		 FILE *card;
		 char fname[256];
		 memset(fname, 0x00, 256);
		 strncpy(fname, username, strlen(username));
		 strncat(fname, ".card", 5);

		 card = fopen(fname, "w");
		 if (card == NULL) {
			 printf("Error creating card file for user %s\n", username);
			 remove(fname);
			 return;
		 }

		 //printf("%s %d\n", arg3, strlen(arg3));
		 SHA256_CTX context;
		 unsigned char md[SHA256_DIGEST_LENGTH];
		 SHA256_Init(&context);
		 SHA256_Update(&context, (unsigned char*)arg3, strlen(arg3));
		 SHA256_Final(md, &context);
		 fputs(md, card);
		 //printf("orig: %s\n", md);
		 fclose(card);

		 int b = atoi(balance);
		 list_add(TYPE_PIN, bank->users, username, arg3, &b);
		 //list_add(TYPE_CHAR, bank->pin_to_usr, arg3, username);
		 //list_add(TYPE_INT, bank->pin_to_balance, arg3, &b);

		 printf("Created user %s\n", username);
		 return;

	 } else if (strcmp("deposit", cmd) == 0) {
		
		 if (strlen(tmp2) < 1 || strlen(tmp2) > 250 ||
			  strlen(tmp3) < 1 || strlen(tmp3) > 10) {
			 printf("Usage: deposit <user-name> <amt>\n");
			 return;
		 }

		 strncpy(username, tmp2, strlen(tmp2));
		 strncpy(arg3, tmp3, strlen(tmp3));

		 if (valid_username(username) == -1 ||
			  valid_balance(arg3) == -1) {
			 printf("Usage: deposit <user-name> <amt>\n");
			 return;
		 } 

		 if (user_in_bank(bank, username) == -1) {
			 printf("No such user\n");
			 return;
		 }

		 if (valid_amt(bank, username, arg3) == -1) {
			 printf("Too rich for this program\n");
			 return;
		 }

		 // Update balance
		 int int_amt = atoi(arg3);
		 //char *pin = (char *) list_find(TYPE_PIN, bank->users, username);
		 int old_balance = *((int *) list_find(TYPE_BAL, bank->users, username));
		 int new_balance = old_balance + int_amt;

		 //list_del(bank->users, username);
		 //list_add(TYPE_PIN, bank->users, username, pin, &new_balance);
		 list_set(bank->users, username, &new_balance);
		 printf("$%d added to %s's account\n", int_amt, username);

		 return;


	 } else if (strcmp("balance", cmd) == 0) {
		 if (strlen(tmp2) < 1 || strlen(tmp2) > 250) {
			 printf("Usage: balance <user-name>\n");
		 	 return;
		 }

		 strncpy(username, tmp2, strlen(tmp2));
		 if (valid_username(username) == -1) {
			 printf("Usage: balance <user-name>\n");
			 return;
		 }
		 //printf("user: %s\n", username);
		 if (user_in_bank(bank, username) == -1) {
			 printf("No such user\n");
			 //printf("list size: %d\n", bank->users->size);
			 return;
		 }

		 //char *pin = (char *) list_find(TYPE_PIN, bank->users, username);
		 //printf("pin: %s\n", pin);
		 int *user_balance = list_find(TYPE_BAL, bank->users, username);
		 printf("$%d\n", *user_balance);
		 return;

	 }
	 
	 else {
		 printf("Invalid command\n");
		 return;
	 }

}

void bank_process_remote_command(Bank *bank, char *command, size_t len)
{
    // TODO: Implement the bank side of the ATM-bank protocol

	/*
	 * The following is a toy example that simply receives a
	 * string from the ATM, prepends "Bank got: " and echoes 
	 * it back to the ATM before printing it to stdout.
	 */

	/*
    char sendline[1000];
    command[len]=0;
    sprintf(sendline, "Bank got: %s", command);
    bank_send(bank, sendline, strlen(sendline));
    printf("Received the following:\n");
    fputs(command, stdout);
	*/
	 //printf("command: %s\n", command);
	 //char tmp0[1000];
	 char tmp0[1000], tmp1[1000], tmp2[1000], tmp3[1000];
	 memset(tmp0, 0x00, 1000);
	 memset(tmp1, 0x00, 1000);
	 memset(tmp2, 0x00, 1000);	 
	 memset(tmp3, 0x00, 1000);
	 
	 /*char encryption[2];
	 memset(encryption, 0x00, 2);
	 sscanf(command, "%s%s%s", tmp0, tmp1, tmp2);
	 printf("tmp0: %s, tmp1: %s, tmp2: %s\n", tmp0, tmp1, tmp2);
	 strncpy(encryption, tmp0, strlen(tmp0));
	 memset(command, 0x00, strlen(command)); 
	 */
	 char cmd[2];
	 memset(cmd, 0x00, 2);
	 
	 char arg2[251];
	 memset(arg2, 0x00, 251);

	 char arg3[11];
	 memset(arg3, 0x00, 11);

 		 
	 strncpy(tmp0, command, 2);
	 //printf("tmp0: %s\n", tmp0);
	 
	 if (strcmp("4 ", tmp0) == 0) {
		 //printf("hello\n");
	 	 sscanf(command, "%s%s", tmp1, tmp2);
		 memset(command, 0x00, strlen(command));
		 strncpy(arg2, tmp2, strlen(tmp2));
		 encrypted_send(bank, arg2, strlen(arg2));
		 return;
	 }	 
	 
	 //sscanf(command, "%s%s%s%s", tmp0, tmp1, tmp2, tmp3);
	 command += 3;
	 strncpy(tmp1, command, atoi(tmp0));
	 //printf("tmp1: %s\n", tmp1);
	 command += atoi(tmp0) + 1;
	 strncpy(tmp2, command, 2);
	 //printf("tmp2: %s\n", tmp2);
	 command += 3;
	 strncpy(tmp3, command, atoi(tmp2));
	 //printf("tmp3: %s\n", tmp3);
	 

	 //printf("%s\n", command);

	 //printf("%s %s %s %s\n", tmp0, tmp1, tmp2, tmp3);

	 //printf("tag: %s\n", tmp3);
	 //has_integrity(bank, tmp1, atoi(tmp0), tmp3, atoi(tmp2)); 

	 //memset(tmp1, 0x00, 1000);
	 //memset(tmp2, 0x00, 1000);
	 unsigned char plaintext[1000] = {0};
	 unsigned char *key = malloc(2100);
	 memset(key, 0x00, 2100);
	 strncpy(key, getkey(bank->init_file), 2100);
	 unsigned char *ciphertext = tmp1;
	 //printf("%s %d\n", tmp1, atoi(tmp0));
	 decrypt(ciphertext, atoi(tmp0), key, plaintext);
	 //decrypt(ciphertext, len, key, plaintext);
	 free(key);
	 key = NULL;
	 //printf("%s\n", plaintext);
	 //
	 memset(tmp1, 0x00, 1000);
	 sscanf(plaintext, "%s%s%s", tmp1, tmp2, tmp3);
	 memset(plaintext, 0x00, strlen(plaintext));
	 memset(command, 0x00, strlen(command));
	 //printf("%s: %d\n", tmp2, strlen(tmp2));
	 //strncpy(encryption, tmp0, strlen(tmp0));
	 //printf("encryption: %s\n", encryption);
	 //printf("%s\n", tmp1);
	 strncpy(cmd, tmp1, strlen(tmp1));
	 //printf("cmd: %s\n", cmd);

	 if (strcmp("0", cmd) == 0) {
		 strncpy(arg2, tmp2, strlen(tmp2));
	 	 char ret[3];
	 	 sprintf(ret, "%d", user_in_bank(bank, arg2));
	 	 //printf("user %s in bank? %s\n", arg2, ret);
	 	 encrypted_send(bank, ret, strlen(ret));
	 	 //bank_send(bank, ret, strlen(ret));
	  	 return;
	 } else if (strcmp("1", cmd) == 0) {
	 	 strncpy(arg2, tmp2, strlen(tmp2));
	 	 strncpy(arg3, tmp3, strlen(tmp3));
	 	 char ret[2];
	 	 memset(ret, 0x00, 2);
	 	 //sprintf(ret, "%d", list_verify_elem(bank->users, arg2, arg3));
	 	 sprintf(ret, "%d", verified_pin(bank, arg2, arg3));
		 encrypted_send(bank, ret, strlen(ret));
	 	 //bank_send(bank, ret, strlen(ret));
	 	 return;
	 } else if (strcmp("2", cmd) == 0) {
		 strncpy(arg2, tmp2, strlen(tmp2));
		 strncpy(arg3, tmp3, strlen(tmp3));
	 	 //printf("Trying to withdraw %s\n",arg3);
		 char ret[2];
		 memset(ret, 0x00, 2);
		 sprintf(ret, "%d", list_withdraw(bank->users, arg2, arg3));
		 //bank_send(bank, ret, strlen(ret));
		 encrypted_send(bank, ret, strlen(ret));
		 return;
	 } else if (strcmp("3", cmd) == 0) {
	 	 strncpy(arg2, tmp2, strlen(tmp2));
	    char ret[11];
	  	 memset(ret, 0x00, 11);
	  	 sprintf(ret, "%d", *((int *)list_find(TYPE_BAL, bank->users, arg2)));
		 encrypted_send(bank, ret, strlen(ret));
		 //bank_send(bank, ret, strlen(ret));
	  	 return;
	 } else if (strcmp("4", cmd) == 0) {
		 strncpy(arg2, tmp2, strlen(tmp2));
		 //printf("%s\n", arg2);
		 encrypted_send(bank, arg2, strlen(arg2));
		 return;
	 } else {
		 //printf("cmd? %s\n", cmd);
		 encrypted_send(bank, "-1", strlen("-1"));
		 return;
	 }
	/* } else if (strcmp("p", encryption) == 0) {
		 memset(command, 0x00, strlen(command));
		 printf("%s --> %s --> %s\n", encryption, tmp1, tmp2);
		 strncpy(cmd, tmp1, strlen(tmp1));
		
		if (strcmp("4", cmd) == 0) {
			strncpy(arg2, tmp2, strlen(tmp2));
			encrypted_send(bank, arg2, strlen(arg2));
		}
	 } else {
	 	return;
	 }*/
	 
}	 


int valid_username(char *username) {
	int i;
	for (i = 0; i < strlen(username); i++) {
		if (username[i] < 65 || username[i] > 122) {
			return -1;
		} else if (username[i] > 90 && username[i] < 97) {
			return -1;
		}
	}
	return 1;
}

int valid_pin(char *pin) {
	int i;
	for (i = 0; i < strlen(pin); i++) {
		if (pin[i] < 48 || pin[i] > 57) {
			return -1;
		}
	}

	int tmp = atoi(pin);
	if (tmp < 0 || tmp > 9999) {
		return -1;
	}

	return 1;
}

int valid_balance(char *balance) {
	int i;
	for (i = 0; i < strlen(balance); i++) {
		if (balance[i] < 48 || balance[i] > 57) { // non-digit
			return -1;
		}
	}
	int tmp = atoi(balance);
	//printf("Balance: %d\n", tmp);
	if (tmp < 0 || tmp > INT_MAX) {
		return -1;
	}

	if (tmp == INT_MAX && strcmp("2147483647", balance) != 0) {
		return -1;
	}

	// b/c atoi returns 0 on fail, check to see if balance actually 0
	if (tmp == 0 && strcmp("0", balance) != 0) {
		return -1;
	}
	return 1;
}

int user_in_bank(Bank *bank, char *username) {
	int buf_size = strlen(username) + 6;
	char fname[buf_size];
	memset(fname, 0x00, buf_size);
	strncpy(fname, username, strlen(username));
	strncat(fname, ".card", 5);
	if (access(fname, F_OK) == -1) {
		return -1;
	}
	if (list_find(TYPE_PIN, bank->users, username) == NULL) {
		return -1;
	}

	return 0;
}

int valid_amt(Bank *bank, char *username, char *amt) {
	//char *pin = (char *) list_find(TYPE_CHAR, bank->usr_to_pin, username);
	int *old_balance = list_find(TYPE_BAL, bank->users, username);
	int int_amt = atoi(amt);
	int new_balance = *old_balance + int_amt;
	//printf("Current balance: %d\n", *old_balance);
	if ((new_balance == INT_MAX && ((new_balance - int_amt) != *old_balance)) ||
		   new_balance > INT_MAX || new_balance < 0) {
		return -1; //overflow
	}
	return 0;
}

void encrypted_send(Bank *bank, unsigned char *plaintext, int plaintext_len) {
	unsigned char ciphertext[plaintext_len];
	memset(ciphertext, 0x00, plaintext_len);
	unsigned char *key = malloc(2100);
	memset(key, 0x00, 2100);
	strncpy(key, getkey(bank->init_file), 2100);
	int cipher_len = encrypt(plaintext, strlen(plaintext) + 1, key, ciphertext);
	bank_send(bank, ciphertext, cipher_len);
	free(key);
	key = NULL;
}

int verified_pin(Bank *bank, char *user, char *pin) {

	FILE *card;
	char path[257] = {0};
	strncpy(path, user, strlen(user));
	strncat(path, ".card", 5);
	if (access(path, F_OK) == -1) {
		return -1;
	}
	char p[6] = {0};
	strncpy(p, pin, strlen(pin));
	//printf("%s %d\n", p, strlen(p));
	SHA256_CTX context2;
	unsigned char md2[SHA256_DIGEST_LENGTH];
	SHA256_Init(&context2);
	SHA256_Update(&context2, (unsigned char*) p,strlen(p));
	SHA256_Final(md2, &context2);
	card = fopen(path, "r");
	//char hash[SHA256_DIGEST_LENGTH] = {0};
	//fgets(hash, sizeof(hash), card);
	
	char *hash = NULL;
	size_t len;
	ssize_t bytes_read = getdelim(&hash, &len, '\0', card);
	if (bytes_read == -1) {
		return -1;
	}
	
	fclose(card);

	char new_hash[33] ={0};
	strncpy(new_hash, md2, 32);

	//printf("%s == %s %d\n", new_hash, hash, strlen(hash));
	//printf("%d\n", strcmp(new_hash, hash));
	return strcmp(new_hash, hash);

}

int has_integrity(Bank *bank, unsigned char *msg, int msg_len, unsigned char *tag, int tag_len) {

	 //unsigned char *ciphertext[strlen(msg)];
	 //memset(ciphertext, 0x00, strlen(msg));
	 unsigned char *tag2[tag_len];
	 memset(tag2, 0x00, tag_len);
	 unsigned char *key = malloc(2100);
	 memset(key, 0x00, 2100);
	 strncpy(key, getkey(bank->init_file), 2100);
	 //printf("%d\n", bank->init_file != NULL);
	 //printf("\n%s\n", key);
	 //int cipher_len = encrypt(msg, strlen(msg) + 1, key, ciphertext); 
	 //printf("%s %d\n", msg, msg_len);
	 int tag_l = sign(key, msg, msg_len + 1, tag2);

	 printf("%s == %s\n", tag, tag2);

	 return 0;


}
