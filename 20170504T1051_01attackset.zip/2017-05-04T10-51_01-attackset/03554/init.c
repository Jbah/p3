#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char** argv) {
	FILE *fp, *atm, *bank;
	char *path_to_atm, *path_to_bank; 
	char *line = NULL;
	char key[2100] = {0};
	size_t len = 0;
	ssize_t read;
	
	if (argc != 2) {
		printf("Usage: init <filename>\n");
		return 62;
	}

	path_to_atm = malloc(strlen(argv[1]) + 4); // ".atm" + null
	path_to_bank = malloc(strlen(argv[1]) + 5); // ".bank" + null

	strncpy(path_to_atm, argv[1], strlen(argv[1]));
	strcat(path_to_atm, ".atm");
	strncpy(path_to_bank, argv[1], strlen(argv[1]));
	strcat(path_to_bank, ".bank");

	//printf("%s\n%s\n", path_to_atm, path_to_bank)
	//
	
	//system("rm -f *.atm *.bank *.card");


	//printf("%s, %d\n", path_to_atm, access(path_to_atm, F_OK));
	if (access(path_to_atm, F_OK) != -1 || access(path_to_bank, F_OK) != -1) {
		printf("Error: one of the files already exists\n");
		return 63;
	}

	// make secret key
	system("openssl genrsa -out private.pem 2048 &> /dev/null");
	fp = fopen("private.pem", "r");
	
	if (fp == NULL)
		exit(EXIT_FAILURE);

	while ((read = getline(&line, &len, fp)) != -1) {
		strncat(key, line, strlen(line));
	}

	fclose(fp);
	system("rm -f private.pem");
	if (line)
		free(line);

	atm = fopen(path_to_atm, "w");
	bank = fopen(path_to_bank, "w");
	
	if (atm == NULL || bank == NULL) {
		printf("Error creating initialization files\n");
		return 64;
	}

	fputs(key, atm);
	fputs(key, bank);

	fclose(atm);
	fclose(bank);

	free(path_to_atm);
	free(path_to_bank);
	
	printf("Successfully initialized bank state\n");
	return 0;

}
