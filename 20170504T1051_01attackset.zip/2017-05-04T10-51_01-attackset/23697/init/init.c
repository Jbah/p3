#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <openssl/rand.h>

#define KEY_SIZE 4096

const char* BANK_FILE_EXTENSION = ".bank";
const char* ATM_FILE_EXTENSION = ".atm";

int main(int argc, char** argv) {
  FILE *bank, *atm;
  char *bank_path, *atm_path;

  if (argc != 2) {
    return 62;
  }

  bank_path = malloc(strlen(argv[1]) + strlen(BANK_FILE_EXTENSION) + 1);
  atm_path = malloc(strlen(argv[1]) + strlen(ATM_FILE_EXTENSION) + 1);

  if (!bank_path || !atm_path) {
    return 64;
  }

  strcpy(bank_path, argv[1]);
  strcat(bank_path, BANK_FILE_EXTENSION);
  strcpy(atm_path, argv[1]);
  strcat(atm_path, ATM_FILE_EXTENSION);

  if (access(bank_path, F_OK) != -1 || access(atm_path, F_OK) != -1) {
    return 63;
  }

  bank = fopen(bank_path, "wx");
  atm = fopen(atm_path, "wx");

  if (!(bank && atm)) {
    return 64;
  }

  unsigned char key[KEY_SIZE];

  RAND_bytes(key, KEY_SIZE);
  fwrite(key, sizeof(unsigned char), KEY_SIZE, bank);
  fwrite(key, sizeof(unsigned char), KEY_SIZE, atm);
  fclose(bank);
  fclose(atm);

  printf("Successfully initialized bank state\n");

  return 0;
}
