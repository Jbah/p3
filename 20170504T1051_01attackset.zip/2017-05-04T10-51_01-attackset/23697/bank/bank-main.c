/*
 * The main program for the Bank.
 *
 * You are free to change this as necessary.
 */

#include <string.h>
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>
#include "bank.h"
#include "ports.h"

unsigned char* key;

static const char prompt[] = "BANK: ";

int main(int argc, char** argv) {
  if (argc != 2 || !fopen(argv[1], "r")) {
    return 64;
  }

  long length;
  FILE* input_file = fopen(argv[1], "r");
  fseek(input_file, 0, SEEK_END);
  length = ftell(input_file);
  rewind(input_file);
  key = calloc(sizeof(unsigned char), length);
  fread(key, sizeof(unsigned char), length, input_file);
  fclose(input_file);

  int n;
  char sendline[10000] = {0};
  char recvline[10000] = {0};

  Bank* bank = bank_create();

  printf("%s", prompt);
  fflush(stdout);

  while (1) {
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(0, &fds);
    FD_SET(bank->sockfd, &fds);
    select(bank->sockfd + 1, &fds, NULL, NULL, NULL);

    if (FD_ISSET(0, &fds)) {
      fgets(sendline, 1000, stdin);
      bank_process_local_command(bank, sendline, strlen(sendline));
      printf("%s", prompt);
      fflush(stdout);
    } else if (FD_ISSET(bank->sockfd, &fds)) {
      n = bank_recv(bank, recvline, 1000);
      bank_process_remote_command(bank, recvline, n);
    }
  }

  return EXIT_SUCCESS;
}
