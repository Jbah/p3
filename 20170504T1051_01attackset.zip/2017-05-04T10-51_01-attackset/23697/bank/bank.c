#include "bank.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <regex.h>
#include <stdio.h>
#include <limits.h>
#include "hashtable.h"
#include "crypto.c"
#include <openssl/rand.h>

#define MID_SIZE 256

struct StrHashTable message_history = {{0}, NULL, NULL, foo_strhash, strcmp};

void free_key(char* key) {
  free(key);
}

void free_value(void* key) {
  free(key);
}

Bank* bank_create() {
  Bank* bank = (Bank*)malloc(sizeof(Bank));
  if (bank == NULL) {
    perror("Could not allocate Bank");
    exit(1);
  }

  // Set up the network state
  bank->sockfd = socket(AF_INET, SOCK_DGRAM, 0);

  bzero(&bank->rtr_addr, sizeof(bank->rtr_addr));
  bank->rtr_addr.sin_family = AF_INET;
  bank->rtr_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
  bank->rtr_addr.sin_port = htons(ROUTER_PORT);

  bzero(&bank->bank_addr, sizeof(bank->bank_addr));
  bank->bank_addr.sin_family = AF_INET;
  bank->bank_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
  bank->bank_addr.sin_port = htons(BANK_PORT);
  bind(bank->sockfd, (struct sockaddr*)&bank->bank_addr,
       sizeof(bank->bank_addr));

  // Set up the protocol state
  // TODO set up more, as needed

  // initialize hash tables
  struct StrHashTable tbl = {{0}, free_key, free_value, foo_strhash, strcmp};
  memcpy(&(bank->balances), &tbl, sizeof(struct StrHashTable));

  return bank;
}

void bank_free(Bank* bank) {
  if (bank != NULL) {
    close(bank->sockfd);
    free(bank);
  }
}

ssize_t bank_send(Bank* bank, char* data, size_t data_len) {
  // encrypt and sign
  char cipher[10000] = {0};
  char plain[10000] = {0};
  char tag[10000] = {0};
  char msg[10000] = {0};
  char tdata[10000] = {0};
  char mid[MID_SIZE];
  RAND_bytes(mid, MID_SIZE);

  memcpy(tdata, mid, MID_SIZE);
  memcpy(tdata + MID_SIZE, data, data_len);

  int cipher_len = encrypt(tdata, data_len + MID_SIZE, key, cipher);
  int tag_len = sign(key, cipher, cipher_len, tag);

  memcpy(msg, &cipher_len, sizeof(int));
  memcpy(msg + sizeof(int), &tag_len, sizeof(int));
  memcpy(msg + 2 * sizeof(int), cipher, cipher_len);
  memcpy(msg + 2 * sizeof(int) + cipher_len, tag, tag_len);

  return sendto(bank->sockfd, msg, 2 * sizeof(int) + cipher_len + tag_len, 0,
                (struct sockaddr*)&bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank* bank, char* data, size_t max_data_len) {
  char cipher[10000] = {0};
  char plain[10000] = {0};
  char tag[10000] = {0};
  char msg[10000] = {0};
  char tag2[10000] = {0};
  char mid[MID_SIZE + 1];

  ssize_t something = recvfrom(bank->sockfd, msg, 3000, 0, NULL, NULL);
  if (something < 2 * sizeof(int)) {
    perror("Invalid messge\n");
    exit(1);
  }

  int cipher_len, tag_len;
  memcpy(&cipher_len, msg, sizeof(int));
  memcpy(&tag_len, msg + sizeof(int), sizeof(int));

  if (2 * sizeof(int) + cipher_len + tag_len != something) {
    perror("Invalid messge\n");
    exit(1);
  }

  memcpy(cipher, msg + 2 * sizeof(int), cipher_len);
  memcpy(tag, msg + 2 * sizeof(int) + cipher_len, tag_len);

  int tag_len2 = sign(key, cipher, cipher_len, tag2);
  if (tag_len2 != tag_len) {
    perror("Invalid messge\n");
    exit(1);
  }

  if (memcmp(tag, tag2, tag_len) != 0) {
    perror("Invalid messge\n");
    exit(1);
  }

  int plain_len = decrypt(cipher, cipher_len, key, plain);

  memcpy(mid, cipher, MID_SIZE);
  mid[MID_SIZE] = 0;

  if (get(&message_history, mid) != NULL) {
    perror("Invalid messge\n");
    exit(1);
  }
  insert(&message_history, mid, 1);

  // TODO handle max_datalen ?

  memcpy(data, plain + MID_SIZE, plain_len - MID_SIZE);

  return plain_len - MID_SIZE;
}

void bank_process_local_command(Bank* bank, char* command, size_t len) {
  // remove new line from the end of the command
  if (command[len - 1] == '\n') {
    command[len - 1] = 0;
    len = len - 1;
  }

  int step = 0;
  char* args[] = {NULL, NULL, NULL, NULL};
  char* tmp;

  tmp = strtok(command, " ");
  while (tmp != NULL) {
    if (step > 3) {
      printf("Invalid command\n");
      return;
    }

    args[step] = malloc(strlen(tmp) + 1);
    strcpy(args[step], tmp);

    // printf("^%s$\n", args[step]);
    tmp = strtok(NULL, " ");
    step++;
  }

  regex_t regex;

  if (args[0] != NULL) {
    if (strcmp("create-user", args[0]) == 0) {
      // printf("create user command\n");
      if (args[1] != NULL && args[2] != NULL && args[3] != NULL) {
        regcomp(&regex, "^[a-zA-Z]{1,250}$", REG_EXTENDED);
        if (!regexec(&regex, args[1], 0, NULL, 0)) {
          char* username = args[1];

          regcomp(&regex, "^[0-9]{4}$", REG_EXTENDED);
          if (!regexec(&regex, args[2], 0, NULL, 0)) {
            char* pin = args[2];

            regcomp(&regex, "^[0-9]+$", REG_EXTENDED);
            if (!regexec(&regex, args[3], 0, NULL, 0)) {
              // puts("Match");
              int balance = atoi(args[3]);
              char str[100];
              snprintf(str, 100, "%d", balance);
              if (strcmp(str, args[3]) == 0) {
                if (get(&bank->balances, username) != NULL) {
                  printf("Error: user %s already exists\n", username);
                  free(args[0]);
                  free(args[1]);
                  free(args[2]);
                  free(args[3]);
                  return;
                }

                char* ext = ".card";
                char* path = malloc(strlen(username) + strlen(ext) + 1);
                strcpy(path, username);
                strcat(path, ext);

                FILE* card;
                card = fopen(path, "wx");
                free(path);
                if (!card) {
                  printf("Error creating card file for user %s\n", username);
                  free(args[0]);
                  free(args[3]);
                  return;
                }

                char cipher[10000] = {0};
                char plain[10000] = {0};
                char tag[10000] = {0};
                char msg[10000] = {0};

                memcpy(plain, pin, 4);
                memcpy(plain + 4, username, strlen(username));

                int cipher_len =
                    encrypt(plain, 4 + strlen(username), key, cipher);
                int tag_len = sign(key, cipher, cipher_len, tag);

                memcpy(msg, &cipher_len, sizeof(int));
                memcpy(msg + sizeof(int), &tag_len, sizeof(int));
                memcpy(msg + 2 * sizeof(int), cipher, cipher_len);
                memcpy(msg + 2 * sizeof(int) + cipher_len, tag, tag_len);

                fwrite(msg, 1, 2 * sizeof(int) + cipher_len + tag_len, card);
                fclose(card);

                int* bal = malloc(sizeof(int));
                *bal = balance;
                insert(&bank->balances, username, bal);

                printf("Created user %s\n", username);
                free(args[0]);
                free(args[3]);
                return;
              }
            }
          }
        }
      }
      printf("Usage: create-user <user-name> <pin> <balance>\n");
      free(args[0]);
      free(args[1]);
      free(args[2]);
      free(args[3]);
      return;
    } else if (strcmp("deposit", args[0]) == 0) {
      // printf("deposit command\n");

      if (args[1] != NULL && args[2] != NULL && args[3] == NULL) {
        regcomp(&regex, "^[a-zA-Z]{1,250}$", REG_EXTENDED);
        if (!regexec(&regex, args[1], 0, NULL, 0)) {
          char* username = args[1];

          regcomp(&regex, "^[0-9]+$", REG_EXTENDED);
          if (!regexec(&regex, args[2], 0, NULL, 0)) {
            int amount = atoi(args[2]);
            char str[100];
            snprintf(str, 100, "%d", amount);
            if (strcmp(str, args[2]) == 0) {
              int* bal = NULL;
              bal = get(&bank->balances, username);

              if (bal == NULL) {
                printf("No such user\n");
                free(args[0]);
                free(args[1]);
                free(args[2]);
                return;
              }

              if (*bal > INT_MAX - amount) {
                printf("Too rich for this program\n");
                free(args[0]);
                free(args[1]);
                free(args[2]);
                return;
              }

              int total = *bal + amount;
              bal = malloc(sizeof(int));
              *bal = total;
              insert(&bank->balances, username, bal);

              printf("$%d added to %s’s account\n", amount, username);

              free(args[0]);
              free(args[2]);
              return;
            }
          }
        }
      }

      printf("Usage: deposit <user-name> <amt>\n");
      free(args[0]);
      free(args[1]);
      free(args[2]);
      free(args[3]);
      return;
    } else if (strcmp("balance", args[0]) == 0) {
      // printf("balance command\n");

      if (args[1] != NULL && args[2] == NULL && args[3] == NULL) {
        regcomp(&regex, "^[a-zA-Z]{1,250}$", REG_EXTENDED);
        if (!regexec(&regex, args[1], 0, NULL, 0)) {
          char* username = args[1];

          int* bal = NULL;
          bal = get(&(bank->balances), username);

          if (bal == NULL) {
            printf("No such user\n");
            free(args[0]);
            free(args[1]);
            return;
          }

          printf("$%d\n", *bal);

          free(args[0]);
          free(args[1]);
          return;
        }
      }
      printf("Usage: balance <user-name>\n");
      free(args[0]);
      free(args[1]);
      free(args[2]);
      free(args[3]);
      return;
    }
  }
  printf("Invalid command\n");
  free(args[0]);
  free(args[1]);
  free(args[2]);
  free(args[3]);
}

void bank_process_remote_command(Bank* bank, char* command, size_t len) {
  if (command[0] == 'b') {
    char* user;
    user = &(command[1]);

    int* bal = NULL;
    bal = get(&(bank->balances), user);
    if (bal == NULL) {
      bank_send(bank, "No user logged in\n", strlen("No user logged in\n"));
      return;
    }

    char str[100];
    snprintf(str, 100, "$%d\n", *bal);
    bank_send(bank, str, strlen(str));
    return;
  } else if (command[0] == 'w') {
    int amount;
    memcpy(&amount, &(command[1]), sizeof(int));

    char* user = calloc(1000, sizeof(char));
    strcpy(user, &(command[1 + sizeof(int)]));

    int* bal = NULL;
    bal = get(&bank->balances, user);
    if (bal == NULL) {
      bank_send(bank, "No user logged in\n", strlen("No user logged in\n"));
      return;
    }

    if (*bal < amount) {
      bank_send(bank, "Insufficient funds\n", strlen("Insufficient funds\n"));
      return;
    }

    int total = *bal - amount;
    bal = malloc(sizeof(int));
    *bal = total;
    insert(&bank->balances, user, bal);

    char str[100];
    snprintf(str, 100, "$%d dispensed\n", amount);
    bank_send(bank, str, strlen(str));
  }
}
