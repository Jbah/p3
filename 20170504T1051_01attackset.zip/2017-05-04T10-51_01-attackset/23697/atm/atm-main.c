/*
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include <stdio.h>
#include <stdlib.h>
#include "atm.h"

unsigned char* key;

int main(int argc, char** argv) {
  if (argc != 2 || !fopen(argv[1], "r")) {
    return 64;
  }

  long length;
  FILE* input_file = fopen(argv[1], "r");
  fseek(input_file, 0, SEEK_END);
  length = ftell(input_file);
  rewind(input_file);
  key = calloc(sizeof(unsigned char), length);
  fread(key, sizeof(unsigned char), length, input_file);
  fclose(input_file);

  char user_input[10000] = {0};

  ATM* atm = atm_create();

  if (user == NULL) {
    printf("ATM: ");
  } else {
    printf("ATM (%s): ", user);
  }
  fflush(stdout);

  while (fgets(user_input, 1000, stdin) != NULL) {
    atm_process_command(atm, user_input);
    if (user == NULL) {
      printf("ATM: ");
    } else {
      printf("ATM (%s): ", user);
    }
    fflush(stdout);
  }
  return EXIT_SUCCESS;
}
