#include "atm.h"
#include "ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <regex.h>
#include <stdio.h>
#include <limits.h>
#include "crypto.c"
#include "hashtable.h"
#include <openssl/rand.h>

#define MID_SIZE 256

struct StrHashTable message_history = {{0}, NULL, NULL, foo_strhash, strcmp};

char* user = NULL;

ATM* atm_create() {
  ATM* atm = (ATM*)malloc(sizeof(ATM));
  if (atm == NULL) {
    perror("Could not allocate ATM");
    exit(1);
  }

  // Set up the network state
  atm->sockfd = socket(AF_INET, SOCK_DGRAM, 0);

  bzero(&atm->rtr_addr, sizeof(atm->rtr_addr));
  atm->rtr_addr.sin_family = AF_INET;
  atm->rtr_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
  atm->rtr_addr.sin_port = htons(ROUTER_PORT);

  bzero(&atm->atm_addr, sizeof(atm->atm_addr));
  atm->atm_addr.sin_family = AF_INET;
  atm->atm_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
  atm->atm_addr.sin_port = htons(ATM_PORT);
  bind(atm->sockfd, (struct sockaddr*)&atm->atm_addr, sizeof(atm->atm_addr));

  return atm;
}

void atm_free(ATM* atm) {
  if (atm != NULL) {
    close(atm->sockfd);
    free(atm);
  }
}

ssize_t atm_send(ATM* atm, char* data, size_t data_len) {
  // encrypt and sign
  char cipher[10000] = {0};
  char plain[10000] = {0};
  char tag[10000] = {0};
  char msg[10000] = {0};
  char tdata[10000] = {0};
  char mid[MID_SIZE];
  RAND_bytes(mid, MID_SIZE);

  memcpy(tdata, mid, MID_SIZE);
  memcpy(tdata + MID_SIZE, data, data_len);

  int cipher_len = encrypt(tdata, data_len + MID_SIZE, key, cipher);
  int tag_len = sign(key, cipher, cipher_len, tag);

  memcpy(msg, &cipher_len, sizeof(int));
  memcpy(msg + sizeof(int), &tag_len, sizeof(int));
  memcpy(msg + 2 * sizeof(int), cipher, cipher_len);
  memcpy(msg + 2 * sizeof(int) + cipher_len, tag, tag_len);

  // Returns the number of bytes sent; negative on error
  return sendto(atm->sockfd, msg, 2 * sizeof(int) + cipher_len + tag_len, 0,
                (struct sockaddr*)&atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM* atm, char* data, size_t max_data_len) {
  char cipher[10000] = {0};
  char plain[10000] = {0};
  char tag[10000] = {0};
  char msg[10000] = {0};
  char tag2[10000] = {0};
  char mid[MID_SIZE + 1];

  ssize_t something = recvfrom(atm->sockfd, msg, 3000, 0, NULL, NULL);
  if (something < 2 * sizeof(int)) {
    perror("Invalid messge\n");
    exit(1);
  }

  int cipher_len, tag_len;
  memcpy(&cipher_len, msg, sizeof(int));
  memcpy(&tag_len, msg + sizeof(int), sizeof(int));

  if (2 * sizeof(int) + cipher_len + tag_len != something) {
    perror("Invalid messge\n");
    exit(1);
  }

  memcpy(cipher, msg + 2 * sizeof(int), cipher_len);
  memcpy(tag, msg + 2 * sizeof(int) + cipher_len, tag_len);

  int tag_len2 = sign(key, cipher, cipher_len, tag2);
  if (tag_len2 != tag_len) {
    perror("Invalid messge\n");
    exit(1);
  }

  if (memcmp(tag, tag2, tag_len) != 0) {
    perror("Invalid messge\n");
    exit(1);
  }

  int plain_len = decrypt(cipher, cipher_len, key, plain);

  memcpy(mid, cipher, MID_SIZE);
  mid[MID_SIZE] = 0;

  if (get(&message_history, mid) != NULL) {
    perror("Invalid messge\n");
    exit(1);
  }
  insert(&message_history, mid, 1);

  // TODO handle max_datalen ?

  memcpy(data, plain + MID_SIZE, plain_len - MID_SIZE);

  return plain_len - MID_SIZE;
}

void atm_process_command(ATM* atm, char* command) {
  // TODO: Implement the ATM's side of the ATM-bank protocol
  // printf("atm process command %s\n", command);
  /*
   * The following is a toy example that simply sends the
   * user's command to the bank, receives a message from the
   * bank, and then prints it to stdout.
   */

  // char recvline[10000];
  // int n;

  // atm_send(atm, command, strlen(command));
  // n = atm_recv(atm,recvline,10000);
  // recvline[n]=0;
  // fputs(recvline,stdout);

  int len = strlen(command);
  // remove new line from the end of the command
  if (command[len - 1] == '\n') {
    command[len - 1] = 0;
    len = len - 1;
  }

  int step = 0;
  char* args[] = {NULL, NULL};
  char* tmp;

  tmp = strtok(command, " ");
  while (tmp != NULL) {
    if (step > 1) {
      printf("Invalid command\n");
      return;
    }

    args[step] = malloc(strlen(tmp) + 1);
    strcpy(args[step], tmp);

    // printf("^%s$\n", args[step]);
    tmp = strtok(NULL, " ");
    step++;
  }

  regex_t regex;

  if (args[0] != NULL) {
    if (strcmp("begin-session", args[0]) == 0) {
      // printf("begin session command\n");

      if (args[1] != NULL) {
        regcomp(&regex, "^[a-zA-Z]{1,250}$", REG_EXTENDED);
        if (!regexec(&regex, args[1], 0, NULL, 0)) {
          char* username = args[1];

          if (user != NULL) {
            printf("A user is already logged in\n");
            free(args[0]);
            free(args[1]);
            return;
          }

          char* ext = ".card";
          char* path = malloc(strlen(username) + strlen(ext) + 1);
          strcpy(path, username);
          strcat(path, ext);

          FILE* card;
          card = fopen(path, "r");
          free(path);
          if (!card) {
            printf("Unable to access %s’s card\n", username);
            free(args[0]);
            free(args[1]);
            return;
          }

          printf("PIN? ");
          fflush(stdout);

          char pin[10000];
          if (fgets(pin, 1000, stdin) == NULL) {
            printf("Not authorized\n");
            free(args[0]);
            free(args[1]);
            fclose(card);
            return;
          }

          // remove new line from the end of the pin
          if (pin[strlen(pin) - 1] == '\n') {
            pin[strlen(pin) - 1] = 0;
          }

          regcomp(&regex, "^[0-9]{4}$", REG_EXTENDED);
          if (regexec(&regex, pin, 0, NULL, 0)) {
            printf("Not authorized\n");
            free(args[0]);
            free(args[1]);
            fclose(card);
            return;
          }

          char cipher[10000] = {0};
          char plain[10000] = {0};
          char tag[10000] = {0};
          char msg[10000] = {0};
          char tag2[10000] = {0};

          long input_file_size;
          fseek(card, 0, SEEK_END);
          input_file_size = ftell(card);
          if (input_file_size > 1000) {  // prevent reading large fake card
            printf("Not authorized\n");
            free(args[0]);
            free(args[1]);
            fclose(card);
            return;
          }
          rewind(card);
          fread(msg, sizeof(char), input_file_size, card);
          fclose(card);

          if (input_file_size < 2 * sizeof(int)) {
            // TODO denial of service isn't really an attack?
            printf("1/n");
            exit(1);
          }

          int cipher_len, tag_len;
          memcpy(&cipher_len, msg, sizeof(int));
          memcpy(&tag_len, msg + sizeof(int), sizeof(int));

          if (2 * sizeof(int) + cipher_len + tag_len != input_file_size) {
            printf("2\n");
            exit(1);  // TODO
          }

          memcpy(cipher, msg + 2 * sizeof(int), cipher_len);
          memcpy(tag, msg + 2 * sizeof(int) + cipher_len, tag_len);

          int tag_len2 = sign(key, cipher, cipher_len, tag2);

          if (tag_len2 != tag_len) {
            printf("3/n");
            exit(1);  // TODO
          }

          if (memcmp(tag, tag2, tag_len) != 0) {
            printf("4/n");
            exit(1);  // TODO
          }

          int plain_len = decrypt(cipher, cipher_len, key, plain);

          char cpin[1000];
          char cusername[1000];
          memcpy(cpin, plain, 4);
          memcpy(cusername, plain + 4, plain_len - 4);

          sleep(2);
          if (strcmp(cpin, pin) != 0 || strcmp(username, cusername) != 0) {
            printf("Not authorized\n");
            free(args[0]);
            free(args[1]);
            return;
          }

          user = username;
          printf("Authorized\n");
          free(args[0]);
          return;
        }
      }
      printf("Usage: begin-session <user-name>\n");
      free(args[0]);
      free(args[1]);
      return;
    } else if (strcmp("end-session", args[0]) == 0) {
      // printf("end session command\n");

      if (args[1] == NULL) {
        if (user == NULL) {
          printf("No user logged in\n");
        } else {
          free(user);
          user = NULL;
          printf("User logged out\n");
        }

        free(args[0]);
        free(args[1]);
        return;
      }
    } else if (strcmp("balance", args[0]) == 0) {
      // printf("balance command\n");

      if (args[1] == NULL) {
        if (user == NULL) {
          printf("No user logged in\n");
        } else {
          // TODO get balance and print

          char recvline[10000] = {0};

          char server_command[1000] = {0};
          server_command[0] = 'b';
          strcpy(&(server_command[1]), user);
          // printf("Sending ^%s$\n", server_command);

          atm_send(atm, server_command, strlen(server_command) + 1);
          // printf("Recieving...\n");

          atm_recv(atm, recvline, 1000);
          printf("%s", recvline);
        }

        free(args[0]);
        free(args[1]);
        return;
      }
    } else if (strcmp("withdraw", args[0]) == 0) {
      // printf("withdraw command\n");
      if (user == NULL) {
        printf("No user logged in\n");
        free(args[0]);
        free(args[1]);
        return;
      }

      if (args[1] != NULL) {
        regcomp(&regex, "^[0-9]+$", REG_EXTENDED);
        if (!regexec(&regex, args[1], 0, NULL, 0)) {
          // puts("Match");
          int amount = atoi(args[1]);
          char str[100];
          snprintf(str, 100, "%d", amount);
          if (strcmp(str, args[1]) == 0) {
            // TODO try to withdraw
            char recvline[10000] = {0};

            char server_command[1000] = {0};
            server_command[0] = 'w';
            memcpy(server_command + 1, &amount, sizeof(int));
            strcpy(server_command + 1 + sizeof(int), user);

            // printf("Sending ^%s$\n", server_command);
            atm_send(atm, server_command, 1 + sizeof(int) + strlen(user) + 1);
            // printf("Recieving...\n");

            atm_recv(atm, recvline, 1000);
            printf("%s", recvline);

            // printf("Insufficient funds\n");
            // printf("$%d dispensed\n", amount);

            free(args[0]);
            free(args[1]);
            return;
          }
        }

        printf("Usage: withdraw <amt>\n");
        free(args[0]);
        free(args[1]);
        return;
      }
    }
  }
  printf("Invalid command\n");
  free(args[0]);
  free(args[1]);
}
