//
// I did not write this.
//

#ifndef __HASHTABLE_H__
#define __HASHTABLE_H__

#include <string.h>
#include <stdlib.h>

#define NR_BUCKETS 1024

struct StrHashNode {
  char* key;
  void* value;
  struct StrHashNode* next;
};

struct StrHashTable {
  struct StrHashNode* buckets[NR_BUCKETS];
  void (*free_key)(char*);
  void (*free_value)(void*);
  unsigned int (*hash)(char* key);
  int (*cmp)(char* first, char* second);
};

void* get(struct StrHashTable* table, char* key);
int insert(struct StrHashTable* table, char* key, void* value);
unsigned int foo_strhash(char* str);

#endif