//
// I did not write this.
//

#include <string.h>
#include <stdlib.h>
#include "hashtable.h"

#define NR_BUCKETS 1024

void* get(struct StrHashTable* table, char* key) {
  unsigned int bucket = table->hash(key) % NR_BUCKETS;
  struct StrHashNode* node;
  node = table->buckets[bucket];
  while (node) {
    if (table->cmp(key, node->key) == 0)
      return node->value;
    node = node->next;
  }
  return NULL;
}

int insert(struct StrHashTable* table, char* key, void* value) {
  unsigned int bucket = table->hash(key) % NR_BUCKETS;
  struct StrHashNode** tmp;
  struct StrHashNode* node;

  tmp = &table->buckets[bucket];
  while (*tmp) {
    if (table->cmp(key, (*tmp)->key) == 0)
      break;
    tmp = &(*tmp)->next;
  }
  if (*tmp) {
    if (table->free_key != NULL)
      table->free_key((*tmp)->key);
    if (table->free_value != NULL)
      table->free_value((*tmp)->value);
    node = *tmp;
  } else {
    node = malloc(sizeof *node);
    if (node == NULL)
      return -1;
    node->next = NULL;
    *tmp = node;
  }
  node->key = key;
  node->value = value;

  return 0;
}

unsigned int foo_strhash(char* str) {
  unsigned int hash = 0;
  for (; *str; str++)
    hash = 31 * hash + *str;
  return hash;
}
