#include "bank.h"
#include "../ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include <openssl/rand.h>
#include <openssl/evp.h>
#include <openssl/conf.h>
#include <openssl/err.h>

#include "../util/hash_table.h"
#include "../common/common.h"

char *commands[] = {"create-user", "deposit", "balance"};

int get_command(char *input);

void process_create(Bank *bank);
void deposit(Bank *bank);
void balance(Bank *bank);

struct user{
    char *name, *pin;
    uint8_t card_data[16];
    uint32_t balance;
};

Bank* bank_create(){
    Bank *bank = (Bank*) malloc(sizeof(Bank));
    if(bank == NULL){
        perror("Could not allocate Bank");
        exit(1);
    }

    // Set up the network state
    bank->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&bank->rtr_addr,sizeof(bank->rtr_addr));
    bank->rtr_addr.sin_family = AF_INET;
    bank->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&bank->bank_addr, sizeof(bank->bank_addr));
    bank->bank_addr.sin_family = AF_INET;
    bank->bank_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    bank->bank_addr.sin_port = htons(BANK_PORT);
    bind(bank->sockfd,(struct sockaddr *)&bank->bank_addr,sizeof(bank->bank_addr));

    bank->ht = hash_table_create(10);

    bank->nonce_used = 1;

    //RAND_bytes((unsigned char *) &id, sizeof(id));

    return bank;
}

void bank_free(Bank *bank){
    if(bank != NULL){
        close(bank->sockfd);
        free(bank);
    }
}

int get_command(char *input){
    int i;

    if(!input){
        return -1;
    }

    for(i=0; i < 3; i++){
        if(strcmp(input, commands[i]) == 0){
            return i;
        }
    }
    return -1;
}

ssize_t bank_send(Bank *bank, char *data, size_t data_len){
    // Returns the number of bytes sent; negative on error
    return sendto(bank->sockfd, data, data_len, 0,
                    (struct sockaddr*) &bank->rtr_addr, sizeof(bank->rtr_addr));
}

ssize_t bank_recv(Bank *bank, char *data, size_t max_data_len){
    // Returns the number of bytes received; negative on error
    return recvfrom(bank->sockfd, data, max_data_len, 0, NULL, NULL);
}

void bank_process_local_command(Bank *bank, char *command, size_t len){
    int com;

    len++;
    com = get_command(strtok(command, " "));

    switch(com){
        case 0:
            process_create(bank);
            break;
        case 1:
            deposit(bank);
            break;
        case 2:
            balance(bank);
            break;
        default:
            printf("Invalid command\n");
            break;
    }
}

void process_create(Bank *bank){
    char *name, *pin, *balance_s, card_out[260];
    uint8_t card_data[16];
    int balance, len;
    void *res;
    FILE *card;
    struct user *new;

    name = strtok(NULL, " ");
    pin = strtok(NULL, " ");
    balance_s = strtok(NULL, "\n");

    if(!name || !pin || !balance_s){
        printf("Usage: create-user <user-name> <pin> <balance>\n");
        return;
    }

    len = strlen(name);
    if(len == 0 || len > 250 || !validate_username(name, len)){
        printf("Usage: create-user <user-name> <pin> <balance>\n");
        return;
    }

    if(strlen(pin) != 4 || !validate_number(pin, 4)){
        printf("Usage: create-user <user-name> <pin> <balance>\n");
        return;
    }

    if(strlen(balance_s) == 0 || !validate_number(balance_s, strlen(balance_s))){
        printf("Usage: create-user <user-name> <pin> <balance>\n");
        return;
    }

    balance = strtol(balance_s, NULL, 10);

    res = hash_table_find(bank->ht, name);

    if(res){
        printf("Error: user %s already exists\n", name);
        return;
    }
    RAND_bytes(card_data, 16);

    snprintf(card_out, 260, "./%s.card", name);

    card = fopen(card_out, "w");

    if(card == NULL){
        printf("Error creating card file for user %s\n", name);
        return;
    }

    fwrite(card_data, 1, 16, card);

    fclose(card);

    new = malloc(sizeof(struct user));

    new->name = calloc(strlen(name)+1, 1);
    strcpy(new->name, name);

    new->pin = malloc(strlen(pin)+1);
    strcpy(new->pin, pin);

    new->balance = balance;

    memcpy(new->card_data, card_data, 16);

    hash_table_add(bank->ht, new->name, new);

    printf("Created user %s\n", name);
}

void deposit(Bank *bank){
    char *name, *deposit_s;
    int32_t deposit, len;
    struct user *user;

    name = strtok(NULL, " ");
    deposit_s = strtok(NULL, "\n");

    if(!name || !deposit_s){
        printf("Usage: deposit <user-name> <amt>\n");
        return;
    }

    len = strlen(name);
    if(len == 0 || len > 250 || !validate_username(name, len)){
        printf("Usage: deposit <user-name> <amt>\n");
        return;
    }

    if(strlen(deposit_s) == 0 || !validate_number(deposit_s, strlen(deposit_s))){
        printf("Usage: deposit <user-name> <amt>\n");
        return;
    }

    deposit = strtol(deposit_s, NULL, 10);

    user = hash_table_find(bank->ht, name);

    if(!user){
        printf("No such user\n");
        return;
    }

    if(user->balance + deposit < user->balance){
        printf("Too rich for this program\n");
        return;
    }

    user->balance += deposit;

    printf("$%d added to %s\'s account\n", deposit, name);
}

void balance(Bank *bank){
    char *name;
    struct user *user;
    int len;

    name = strtok(NULL, "\n");

    if(!name){
        printf("Usage: balance <user-name>\n");
        return;
    }

    len = strlen(name);
    if(len == 0 || len > 250 || !validate_username(name, len)){
        printf("Usage: balance <user-name>\n");
        return;
    }

    user = hash_table_find(bank->ht, name);

    if(!user){
        printf("No such user\n");
        return;
    }

    printf("$%d\n", user->balance);
}

void send_nonce(Bank *bank){
    RAND_bytes(bank->nonce, 16);

    bank->nonce_used = 0;

    bank_send(bank, (char *) bank->nonce, 16);
}

void login(Bank *bank, struct request req){
    uint8_t *buf;
    struct user *user;
    struct resp resp;
    int len;

    memcpy(resp.nonce, bank->nonce, 16);

    resp.value = 0;

    user = hash_table_find(bank->ht, req.name);

    if(!user){
        resp.value = 2;
    }

    if(user && !memcmp(req.card_data, user->card_data, 16) && !memcmp(req.pin, user->pin, 4)){
        resp.value = 1;
    }

    buf = pack_resp(resp, &len);

    bank_send(bank, (char *) buf, len);
}

void withdraw(Bank *bank, struct request req){
    uint8_t *buf;
    struct user *user;
    struct resp resp;
    int len;

    resp.value = 0;

    memcpy(resp.nonce, bank->nonce, 16);

    user = hash_table_find(bank->ht, req.name);

    if(user && !memcmp(req.card_data, user->card_data, 16) && !memcmp(req.pin, user->pin, 4)){
        if(user->balance >= req.value){
            user->balance -= req.value;
            resp.value = 1;
        }
    }

    buf = pack_resp(resp, &len);

    bank_send(bank, (char *) buf, len);
}

void balance_recv(Bank *bank, struct request req){
    uint8_t *buf;
    struct user *user;
    struct resp resp;
    int len;

    resp.value = 0;

    memcpy(resp.nonce, bank->nonce, 16);


    user = hash_table_find(bank->ht, req.name);

    if(user && !memcmp(req.card_data, user->card_data, 16) && !memcmp(req.pin, user->pin, 4)){
        if(user->balance >= req.value){
            resp.value = user->balance;
        }
    }

    buf = pack_resp(resp, &len);

    bank_send(bank, (char *) buf, len);
}

void bank_process_remote_command(Bank *bank, char *command, size_t len){
    struct request req;
    if(len == 1){
        send_nonce(bank);
        return;
    }

    req = unpack_request((uint8_t *) command);

    if(bank->nonce_used || memcmp(req.nonce, bank->nonce, 16)){
        printf("Nonce failed\n");
        return;
    }

    switch(req.type){
        case LOGIN:
            login(bank, req);
            break;
        case WITHDRAW:
            withdraw(bank, req);
            break;
        case BALANCE:
            balance_recv(bank, req);
            break;
    }
}
