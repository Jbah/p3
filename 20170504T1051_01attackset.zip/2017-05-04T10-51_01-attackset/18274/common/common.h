#ifndef COMMON_H
#define COMMON_H

#include <stdint.h>
#include <stdbool.h>

#define BUFFER_SIZE 

enum m_type{
	LOGIN,
	WITHDRAW,
	BALANCE
};

struct request{
	uint8_t card_data[16], nonce[16];
	char pin[4], *name;
	uint32_t value;
	uint16_t name_len;
	enum m_type type;
};

struct resp {
	uint8_t nonce[16];
	uint32_t value;
};

extern uint8_t key[16];

int pack_buf(uint8_t **out, uint8_t *buf, int len);
int unpack_buf(uint8_t **out, uint8_t *buf);

uint8_t *pack_request(struct request req, int *len);
struct request unpack_request(uint8_t *buf);

uint8_t *pack_resp(struct resp resp, int *len);
struct resp unpack_resp(uint8_t *buf);

bool validate_username(char *name, int len);
bool validate_number(char *name, int len);

void buf_print(void *buf, int size);



#endif