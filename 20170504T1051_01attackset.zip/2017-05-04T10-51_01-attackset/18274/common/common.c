#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>

#include <openssl/rand.h>
#include <openssl/evp.h>
#include <openssl/conf.h>
#include <openssl/err.h>

#include <arpa/inet.h>

#include "common.h"

int pack_buf(uint8_t **out, uint8_t *buf, int len){
	int l =0, a = 0;
	EVP_CIPHER_CTX *ctx;

	*out = malloc(2048);

	RAND_bytes((*out)+18, 16);

	if(!(ctx = EVP_CIPHER_CTX_new())){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}

	if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_128_gcm(), NULL, NULL, NULL)){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}

	if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, 16, NULL)){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}

	if(1 != EVP_EncryptInit_ex(ctx, NULL, NULL, key, (*out)+18)){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}

	if(1 != EVP_EncryptUpdate(ctx, NULL, &a, (*out)+18, 16)){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}

	if(1 != EVP_EncryptUpdate(ctx, (*out)+34, &a, buf, len)){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}

	l += a;

	if(1 != EVP_EncryptFinal_ex(ctx, (*out) + l, &a)){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}

	l += a;

	if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, 16, (*out)+2)){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}

	l+= 34;

	*((uint16_t *)(*out)) = htons(l);

	EVP_CIPHER_CTX_free(ctx);

	return l;
}

int unpack_buf(uint8_t **out, uint8_t *buf){
	int l, a, b, ret;
	EVP_CIPHER_CTX *ctx;

	*out = malloc(2048);
	l = ntohs(*((uint16_t *)(buf)));

	if(!(ctx = EVP_CIPHER_CTX_new())){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}

	if(!EVP_DecryptInit_ex(ctx, EVP_aes_128_gcm(), NULL, NULL, NULL)){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}

	if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, 16, NULL)){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}

	if(1 != EVP_DecryptInit_ex(ctx, NULL, NULL, key, buf+18)){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}

	if(1 != EVP_DecryptUpdate(ctx, NULL, &a, buf+18, 16)){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}



	if(1 != EVP_DecryptUpdate(ctx, (*out), &a, buf+34, l-34)){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}

	b = a;

	if(!EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, 16, buf+2)){
		free(*out);
		printf("Error %d\n", __LINE__);
		return -1;
	}

	ret = EVP_DecryptFinal_ex(ctx, *out + b, &a);

	b += a;

	EVP_CIPHER_CTX_free(ctx);

	return ret > 0 ? b : -1;

}

uint8_t *pack_request(struct request req, int *len){
	uint8_t *out = calloc(1, 16 + 1 + 4 + 16 + 4 + 2 + req.name_len), *a;
	int l;

	*len = 16 + 1 + 4 + 16 + 4 + 2 + req.name_len;

	memcpy(out, req.nonce, 16);
	*(out+16) = req.type;
	*((uint32_t *) (out+17)) = htonl(req.value);
	memcpy(out+21, req.card_data, 16);
	memcpy(out+37, req.pin, 4);
	*((uint16_t *) (out + 41)) = htons(req.name_len);
	memcpy(out+43, req.name, req.name_len);

	l = pack_buf(&a, out, *len);

	if(l == -1){
		printf("Error\n");
		return out;
	}

	*len = l;

	free(out);

	return a;
}

struct request unpack_request(uint8_t *buf){
	uint8_t *a;
	struct request out;
	int l;

	l = unpack_buf(&a, buf);

	if(l == -1){
		memset(&out, '\0', sizeof(struct request));
		return out;
	}

	buf = a;

	memcpy(out.nonce, buf, 16);
	out.type = *(buf+16);
	out.value = ntohl(*((uint32_t *)(buf+17)));
	memcpy(out.card_data, buf+21, 16);
	memcpy(out.pin, buf+37, 4);
	out.name_len = ntohs(*((uint16_t *)(buf+41)));
	out.name = calloc(out.name_len + 1, 1);
	memcpy(out.name, buf+43, out.name_len);

	return out;
}

uint8_t *pack_resp(struct resp resp, int *len){
	uint8_t *out = calloc(1, 16 + 4), *a;
	int l;

	*len = 20;

	memcpy(out, resp.nonce, 16);
	*((uint32_t *)(out + 16)) = htonl(resp.value);

	l = pack_buf(&a, out, *len);

	if(l == -1){
		printf("Error\n");
		return out;
	}

	*len = l;

	free(out);

	return a;
}

struct resp unpack_resp(uint8_t *buf){
	struct resp out;
	uint8_t *a;
	int l;

	l = unpack_buf(&a, buf);

	if(l == -1){
		memset(&out, '\0', sizeof(struct request));
		return out;
	}

	buf = a;

	memcpy(out.nonce, buf, 16);

	out.value = ntohl(*((uint32_t *)(buf+16)));

	return out;
}

bool validate_username(char *name, int len){
	int i;

	for(i=0; i < len; i++){
		if(*(name+i) < 'A' || *(name+i) > 'Z'){
			if(*(name+i) < 'a' || *(name+i) > 'z'){
				return false;
			}
		}
	}
	return true;
}

bool validate_number(char *name, int len){
	int i;

	for(i=0; i < len; i++){
		if(*(name+i) < '0' || *(name+i) > '9'){
			return false;
		}
	}
	return true;
}

void buf_print(void *buf, int size){
  uint8_t *t = buf;
  int i;

  for(i = 0; i < size; i++){
    if(i % 16 == 0){
      printf("\n%08x", i);
    }

    if(i % 2 == 0){
      printf(" ");
    }

    printf("%02x", *(t+i));


  }

  printf("\n\n");
}

/*
void send_encrypt(ATM *atm, uint8_t type, char *buf, int len){
    uint8_t ciphertext[1024];
    uint8_t iv[16];
    int l, ciphertext_len = 0;

    RAND_bytes(&iv[0], 16);

    EVP_CIPHER_CTX *ctx;
    ctx = EVP_CIPHER_CTX_new();

    EVP_EncryptInit_ex(ctx, EVP_aes_128_gcm(), NULL, NULL, NULL);

    EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, 16, NULL);

    EVP_EncryptInit_ex(ctx, NULL, NULL, key, iv);

    EVP_EncryptUpdate(ctx, NULL, &l, &type, 1);
    EVP_EncryptUpdate(ctx, NULL, &l, iv, 16);

    *ciphertext = type;
    ciphertext_len+=1;
    memcpy(ciphertext + ciphertext_len, iv, 16);
    ciphertext_len+=16;

    EVP_EncryptUpdate(ctx, ciphertext+ciphertext_len, &l, atm->nonce, 16);
    ciphertext_len += l;
    EVP_EncryptUpdate(ctx, ciphertext+ciphertext_len, &l, buf, len);
    ciphertext_len += l;
    EVP_EncryptFinal_ex(ctx, ciphertext+ciphertext_len, &l);
    ciphertext_len += l;
    EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, 16, ciphertext+ciphertext_len);
    ciphertext_len += 16;

    EVP_CIPHER_CTX_free(ctx);

    atm_send(atm, (char *) ciphertext, ciphertext_len);
}

char *recv_decrypt(ATM *atm){
    uint8_t ciphertext[1024], plaintext[1024];

    atm_recv(atm, (char *)ciphertext, 1024);

    *plaintext = *ciphertext;
}*/