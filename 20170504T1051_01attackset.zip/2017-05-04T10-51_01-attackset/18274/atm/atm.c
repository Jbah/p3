#include "atm.h"
#include "../ports.h"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include <openssl/rand.h>
#include <openssl/evp.h>
#include <openssl/conf.h>
#include <openssl/err.h>

#include "../common/common.h"

char *commands[] = {"begin-session", "withdraw", "balance", "end-session"};

void create_session(ATM *atm);

ATM* atm_create()
{
    ATM *atm = (ATM*) malloc(sizeof(ATM));
    if(atm == NULL)
    {
        perror("Could not allocate ATM");
        exit(1);
    }

    // Set up the network state
    atm->sockfd=socket(AF_INET,SOCK_DGRAM,0);

    bzero(&atm->rtr_addr,sizeof(atm->rtr_addr));
    atm->rtr_addr.sin_family = AF_INET;
    atm->rtr_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->rtr_addr.sin_port=htons(ROUTER_PORT);

    bzero(&atm->atm_addr, sizeof(atm->atm_addr));
    atm->atm_addr.sin_family = AF_INET;
    atm->atm_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
    atm->atm_addr.sin_port = htons(ATM_PORT);
    bind(atm->sockfd,(struct sockaddr *)&atm->atm_addr,sizeof(atm->atm_addr));

    atm->logged_in = 0;

    return atm;
}

void atm_free(ATM *atm)
{
    if(atm != NULL)
    {
        close(atm->sockfd);
        free(atm);
    }
}

ssize_t atm_send(ATM *atm, char *data, size_t data_len)
{
    // Returns the number of bytes sent; negative on error
    return sendto(atm->sockfd, data, data_len, 0,
                  (struct sockaddr*) &atm->rtr_addr, sizeof(atm->rtr_addr));
}

ssize_t atm_recv(ATM *atm, char *data, size_t max_data_len)
{
    // Returns the number of bytes received; negative on error
    return recvfrom(atm->sockfd, data, max_data_len, 0, NULL, NULL);
}

int get_command(char *input){
  int i;

  if(!input){
    return -1;
  }


  for(i=0; i < 4; i++){
    if(strcmp(input, commands[i]) == 0){
      return i;
    }
  }
  return -1;
}

int get_nonce(ATM *atm){
    char message = 0;
    int ret;

    ret = atm_send(atm, &message, 1);

    if(ret != 1){
        printf("Error with send\n");
        return -1;
    }

    ret = atm_recv(atm, (char *) atm->nonce, 16);
    if(ret != 16){
        printf("Error with recv\n");
        return -1;
    }

    return 1;


}

void create_session(ATM *atm){
    char *name, pin[100], card_name[260], card_data[16], in[100];
    uint8_t *out;
    struct request req = {{0}};
    struct resp resp;
    int res, len;
    FILE *card;
    

    if(atm->logged_in){
        printf("A user is already logged in\n");
        return;
    }

    name = strtok(NULL, "\n");

    if(!name){
        printf("Usage: begin-session <user-name>\n");
        return;
    }

    if(strlen(name) > 250 || !validate_username(name, strlen(name))){
        printf("Usage: begin-session <user-name>\n");
        return;
    }

    req.type = LOGIN;
    req.name_len = strlen(name);
    req.name = name;

    res = get_nonce(atm);

    if(res == -1){
        printf("Error\n");
        return;
    }

    memcpy(req.nonce, atm->nonce, 16);

    out = pack_request(req, &len);

    res = atm_send(atm, (char *) out, len);

    if(!res){
        printf("Error\n");
        return;
    }

    free(out);

    res = atm_recv(atm, in, 100);

    if(!res){
        printf("Error\n");
        return;
    }

    resp = unpack_resp((uint8_t *) in);

    if(memcmp(resp.nonce, atm->nonce, 16)){
        printf("Error\n");
        return;
    }

    if(resp.value == 2) {
        printf("No such user\n");
        return;
    }

    //-----------------------

    snprintf(card_name, 260, "%s.card", name);

    card = fopen(card_name, "r");

    if(!card){
        printf("Unable to access %s\'s card\n", name);
        perror(NULL);
        return;
    }

    fread(card_data, 1, 16, card);
    fclose(card);

    printf("PIN? ");
    fgets(pin, 100, stdin);
    pin[strlen(pin)-1] = '\0';

    if(strlen(pin) != 4 || !validate_number(pin, 4)){
        printf("Not authorized\n");
        return;
    }

    res = get_nonce(atm);

    if(res == -1){
        printf("Error\n");
        return;
    }

    memcpy(req.nonce, atm->nonce, 16);
    memcpy(req.card_data, card_data, 16);
    memcpy(req.pin, pin, 4);

    out = pack_request(req, &len);

    res = atm_send(atm, (char *) out, len);

    if(!res){
        printf("Error\n");
        return;
    }

    free(out);

    res = atm_recv(atm, in, 100);

    if(!res){
        printf("Error\n");
        return;
    }

    resp = unpack_resp((uint8_t *) in);

    if(memcmp(resp.nonce, atm->nonce, 16)){
        printf("Error\n");
        return;
    }

    if(resp.value == 1){
        printf("Authorized\n");
        atm->logged_in = 1;
        atm->name = calloc(strlen(name)+1, 1);
        memcpy(atm->name, name, strlen(name));
        memcpy(atm->pin, pin, 4);
        memcpy(atm->card_data, card_data, 16);
        return;
    } else if(resp.value == 2) {
        printf("Not authorized\n");
        return;
    }else {
        printf("No such user\n");
        return;
    }


}

void withdraw(ATM *atm){
    char *withdraw_s, in[100];
    uint8_t *out;
    uint32_t withdraw;
    struct request req;
    struct resp resp;
    int res, len;
    

    if(!atm->logged_in){
        printf("No user logged in\n");
        return;
    }

    withdraw_s = strtok(NULL, "\n");

    if(!withdraw_s){
        printf("Usage: withdraw <amt>\n");
        return;
    }

    if(!validate_number(withdraw_s, strlen(withdraw_s))){
        printf("Usage: withdraw <amt>\n");
        return;
    }

    withdraw = strtol(withdraw_s, NULL, 10);

    res = get_nonce(atm);

    if(res == -1){
        printf("Error\n");
        return;
    }

    req.type = WITHDRAW;
    req.name_len = strlen(atm->name);
    req.name = atm->name;
    req.value = withdraw;
    memcpy(req.nonce, atm->nonce, 16);
    memcpy(req.card_data, atm->card_data, 16);
    memcpy(req.pin, atm->pin, 4);

    out = pack_request(req, &len);

    res = atm_send(atm, (char *) out, len);

    if(!res){
        printf("Error\n");
        return;
    }

    free(out);

    res = atm_recv(atm, in, 100);

    if(!res){
        printf("Error\n");
        return;
    }

    resp = unpack_resp((uint8_t *) in);

    if(memcmp(resp.nonce, atm->nonce, 16)){
        printf("Error\n");
        return;
    }

    if(resp.value){
        printf("$%d dispensed\n", withdraw);
        return;
    } else {
        printf("Insufficient funds\n");
        return;
    }
}

void balance(ATM *atm){
    char  in[100], *a;
    uint8_t *out;
    struct request req;
    struct resp resp;
    int res, len;    


    if(!atm->logged_in){
        printf("No user logged in\n");
        return;
    }

    a = strtok(NULL, "\n");

    if(a && strlen(a) != 0){
        printf("Usage: balance\n");
        return;
    }

    res = get_nonce(atm);

    if(res == -1){
        printf("Error\n");
        return;
    }

    req.type = BALANCE;
    req.name_len = strlen(atm->name);
    req.name = atm->name;
    memcpy(req.nonce, atm->nonce, 16);
    memcpy(req.card_data, atm->card_data, 16);
    memcpy(req.pin, atm->pin, 4);

    out = pack_request(req, &len);

    res = atm_send(atm, (char *) out, len);

    if(!res){
        printf("Error\n");
        return;
    }

    free(out);

    res = atm_recv(atm, in, 100);

    if(!res){
        printf("Error\n");
        return;
    }

    resp = unpack_resp((uint8_t *) in);

    if(memcmp(resp.nonce, atm->nonce, 16)){
        printf("Error\n");
        return;
    }

    printf("$%d\n", resp.value);
}

void end_session(ATM *atm){

    if(!atm->logged_in){
        printf("No user logged in\n");
        return;
    }
    free(atm->name);
    memset(atm->card_data, '\0', 16);
    memset(atm->pin, '\0', 4);
    atm->logged_in = 0;
    printf("User logged out\n");
}

void atm_process_command(ATM *atm, char *command)
{
    int com;

  com = get_command(strtok(command, " "));

  switch(com){
    case 0:
        create_session(atm);
        break;
    case 1:
        withdraw(atm);
        break;
    case 2:
        balance(atm);
        break;
    case 3:
        end_session(atm);
        break;
    default:
        printf("Invalid command %s\n", command);
        break;
    }
}
