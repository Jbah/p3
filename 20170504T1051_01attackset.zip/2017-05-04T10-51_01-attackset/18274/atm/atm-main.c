/* 
 * The main program for the ATM.
 *
 * You are free to change this as necessary.
 */

#include "atm.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../common/common.h"

static const char prompt[] = "ATM: ";

uint8_t key[16] = {0};

int main(int argc, char **argv)
{
  char user_input[1000];
  ATM *atm = atm_create();
  FILE *key_f;

  if(argc != 2){
    exit(0);
  }

  key_f = fopen(argv[1], "r");

  if(key_f == NULL){
    printf("Error opening ATM initialization file\n");
    perror(NULL);
    exit(64);
  }

  fread(key, 1, 16, key_f);
  fclose(key_f);

  printf("%s", prompt);
  fflush(stdout);

  while(fgets(user_input, 1000,stdin) != NULL){

    if(strlen(user_input) > 0 && user_input[strlen(user_input)-1] == '\n'){
        user_input[strlen(user_input)-1] = '\0';
    }

    atm_process_command(atm, user_input);




    if(atm->logged_in){
        printf("ATM (%s): ", atm->name);
    } else {
        printf("%s", prompt);
    }

    fflush(stdout);
  }
	return EXIT_SUCCESS;
}
